<?php
declare(strict_types=1);

/*
 | Shared bootstrap for the web front controller, the CLI console and the tests.
 | Loads the autoloader, environment, configuration and global helpers.
 */

define('BASE_PATH', dirname(__DIR__));
define('APP_START', microtime(true));

if (is_file(BASE_PATH . '/vendor/autoload.php')) {
    require BASE_PATH . '/vendor/autoload.php';
}

spl_autoload_register(static function (string $class): void {
    if (!str_starts_with($class, 'App\\')) {
        return;
    }
    $file = BASE_PATH . '/app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

require_once BASE_PATH . '/app/Helpers/functions.php'; // may already be loaded by Composer's "files" autoload

App\Core\Env::load(BASE_PATH . '/.env');
App\Core\Config::load(BASE_PATH . '/config');

date_default_timezone_set('UTC'); // storage timezone; display uses config('app.timezone')
mb_internal_encoding('UTF-8');

$debug = (bool) config('app.debug');
error_reporting(E_ALL);
ini_set('display_errors', $debug ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', BASE_PATH . '/storage/logs/php-error.log');
