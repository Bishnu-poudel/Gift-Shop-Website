<?php
declare(strict_types=1);

/*
 | Test bootstrap (PHPUnit or tests/run.php).
 | Integration tests use a separate database (DB_DATABASE + "_test" unless TEST_DB_DATABASE is set)
 | which is dropped and rebuilt with base + demo data once per run. Never point this at production.
 */

require dirname(__DIR__) . '/bootstrap/app.php';

use App\Core\Config;
use App\Core\Database;

if (!class_exists(\PHPUnit\Framework\TestCase::class)) {
    require __DIR__ . '/TestCaseShim.php';
}

$testDb = getenv('TEST_DB_DATABASE') ?: (config('database.database') . '_test');
if (!preg_match('/_test$/', $testDb)) {
    fwrite(STDERR, "Refusing to run: test database name must end with _test\n");
    exit(1);
}
Config::set('database.database', $testDb);
Config::set('payments.simulator', false);
Config::set('mail.mode', 'log');
Config::set('app.cache_enabled', false);

final class TestDatabase
{
    private static bool $ready = false;

    public static function ensure(): void
    {
        if (self::$ready) {
            return;
        }
        $c = config('database');
        $pdo = new PDO(sprintf('mysql:host=%s;port=%d;charset=utf8mb4', $c['host'], (int) $c['port']), $c['username'], $c['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $pdo->exec('DROP DATABASE IF EXISTS `' . $c['database'] . '`');
        $pdo->exec('CREATE DATABASE `' . $c['database'] . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        Database::setPdo(null);
        App\Services\Installer::migrate();
        App\Services\Installer::seedBase();
        App\Services\Installer::seedDemo(true);
        self::$ready = true;
    }

    /** Builds CartService-shaped lines for direct OrderService::place() calls. */
    public static function lines(array $productQty): array
    {
        $out = [];
        foreach ($productQty as $sku => $qty) {
            $row = Database::fetch(
                'SELECT 0 AS id, p.id AS product_id, 0 AS variant_id, :q AS quantity, NULL AS personalization, p.status, p.price, p.sale_price,
                        0 AS price_adjustment, 1 AS variant_active, p.allow_backorder, COALESCE(i.quantity,0) AS stock, p.gift_wrap_available,
                        p.lead_time_days, p.valley_only, p.name, p.sku, NULL AS variant_sku, NULL AS variant_name, p.cost_price, p.category_id
                 FROM products p LEFT JOIN inventory i ON i.product_id = p.id AND i.variant_id = 0 WHERE p.sku = :s',
                ['q' => $qty, 's' => $sku]
            );
            $out[] = $row;
        }
        return $out;
    }

    public static function orderData(string $method = 'cod', array $extra = []): array
    {
        return $extra + [
            'customer_name' => 'Test Buyer', 'email' => 'buyer' . random_int(1000, 99999) . '@example.com', 'phone' => '9841234567',
            'payment_method' => $method,
            'shipping' => ['full_name' => 'Test Buyer', 'phone' => '9841234567', 'province' => 'Bagmati', 'district' => 'Lalitpur', 'municipality' => 'Lalitpur Metropolitan City', 'ward' => '3', 'street' => 'Jhamsikhel', 'landmark' => ''],
            'billing' => null, 'gift_wrap' => false, 'gift_message' => '', 'requested_delivery_date' => null,
            'coupon_code' => null, 'checkout_token' => null, 'user_id' => null, 'source' => 'web',
        ];
    }
}
