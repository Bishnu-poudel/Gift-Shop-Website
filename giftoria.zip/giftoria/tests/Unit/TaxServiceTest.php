<?php
declare(strict_types=1);

namespace Tests\Unit;

use App\Services\TaxService;
use PHPUnit\Framework\TestCase;

final class TaxServiceTest extends TestCase
{
    public function testInclusiveVatIsExtractedFromTotal(): void
    {
        $t = TaxService::breakdown(1130.0, ['registered' => true, 'rate' => 13.0, 'inclusive' => true]);
        $this->assertEquals(1000.0, $t['taxable']);
        $this->assertEquals(130.0, $t['vat']);
        $this->assertEquals(1130.0, $t['total']);
    }

    public function testExclusiveVatIsAddedOnTop(): void
    {
        $t = TaxService::breakdown(1000.0, ['registered' => true, 'rate' => 13.0, 'inclusive' => false]);
        $this->assertEquals(1000.0, $t['taxable']);
        $this->assertEquals(130.0, $t['vat']);
        $this->assertEquals(1130.0, $t['total']);
    }

    public function testTaxableAndVatAlwaysSumToTotal(): void
    {
        foreach ([1050.0, 999.99, 2490.0, 13.0, 0.0] as $amount) {
            $t = TaxService::breakdown($amount, ['registered' => true, 'rate' => 13.0, 'inclusive' => true]);
            $this->assertEquals(round($amount, 2), round($t['taxable'] + $t['vat'], 2), "Split of $amount must add up");
        }
    }

    public function testNonVatSellerChargesNoVat(): void
    {
        $t = TaxService::breakdown(1050.0, ['registered' => false, 'rate' => 0.0, 'inclusive' => true]);
        $this->assertEquals(0.0, $t['vat']);
        $this->assertEquals(1050.0, $t['total']);
    }

    public function testNepaliFiscalYear(): void
    {
        $this->assertSame('2083/84', TaxService::fiscalYear('2026-10-12'));
        $this->assertSame('2083/84', TaxService::fiscalYear('2026-07-17'));
        $this->assertSame('2082/83', TaxService::fiscalYear('2026-07-16'));
        $this->assertSame('2082/83', TaxService::fiscalYear('2026-01-05'));
    }

    public function testAmountInWordsUsesLakhAndCrore(): void
    {
        $this->assertSame('Rupees One Thousand Fifty Only', TaxService::amountInWords(1050));
        $this->assertSame('Rupees One Lakh Twenty Three Thousand Four Hundred Fifty Six and Paisa Seventy Five Only', TaxService::amountInWords(123456.75));
        $this->assertSame('Rupees Two Crore Only', TaxService::amountInWords(20000000));
        $this->assertSame('Rupees Zero Only', TaxService::amountInWords(0));
    }
}
