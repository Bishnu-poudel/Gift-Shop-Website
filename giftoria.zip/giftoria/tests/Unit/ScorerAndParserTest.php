<?php
declare(strict_types=1);

namespace Tests\Unit;

use App\Services\Payments\EsewaGateway;
use App\Services\Payments\KhaltiGateway;
use App\Services\OrderStateMachine;
use App\Services\Recommendation\QueryParser;
use App\Services\Recommendation\Scorer;
use App\Core\Validator;
use PHPUnit\Framework\TestCase;

final class ScorerAndParserTest extends TestCase
{
    private function parser(): QueryParser
    {
        return new QueryParser([
            'baby girl' => ['recipient:baby-girl'],
            'toddler girl' => ['recipient:baby-girl', 'agemonths:12-35'],
            'toddler' => ['agemonths:12-35'],
            'mom' => ['recipient:mother'],
            'princess toys' => ['interest:princess-toys'],
            'princess' => ['interest:princess-toys'],
            'educational toys' => ['interest:educational-toys'],
            'first birthday' => ['occasion:first-birthday'],
            'birthday' => ['occasion:birthday'],
            'personalized' => ['flag:personalized'],
        ], ['wallet', 'journal']);
    }

    public function testParsesRecipientAndPriceCeiling(): void
    {
        $r = $this->parser()->parse('Princess gifts under NPR 2,000');
        $this->assertSame(['princess-toys'], $r['interests']);
        $this->assertEquals(2000.0, $r['max_price']);
        $this->assertSame([], $r['keywords']);
    }

    public function testLongestPhraseWins(): void
    {
        $r = $this->parser()->parse('first birthday gift for toddler girl');
        $this->assertSame('first-birthday', $r['occasion']);
        $this->assertSame('baby-girl', $r['recipient']);
        $this->assertSame(12, $r['age_min_months']);
    }

    public function testTypoTolerance(): void
    {
        $r = $this->parser()->parse('educatonal toyz');
        $this->assertContains('educational-toys', $r['interests']);
        $this->assertNotEmpty($r['corrections']);
    }

    public function testPriceRange(): void
    {
        $r = $this->parser()->parse('gifts for mom between 1,000 and 2,500');
        $this->assertSame('mother', $r['recipient']);
        $this->assertEquals(1000.0, $r['min_price']);
        $this->assertEquals(2500.0, $r['max_price']);
    }

    public function testUnknownWordsBecomeKeywords(): void
    {
        $r = $this->parser()->parse('wallet');
        $this->assertSame(['wallet'], $r['keywords']);
    }

    public function testScoringRewardsMatchesAndNormalises(): void
    {
        $scorer = new Scorer();
        $criteria = ['recipient' => 'baby-girl', 'interests' => ['princess-toys', 'educational-toys'], 'occasion' => 'first-birthday',
            'age_min_months' => 12, 'age_max_months' => 35, 'min_price' => 500.0, 'max_price' => 2500.0, 'prefs' => []];
        $great = ['id' => 1, 'recipient_slugs' => ['baby-girl'], 'interest_slugs' => ['princess-toys', 'educational-toys'], 'occasion_slugs' => ['first-birthday'],
            'age_min_months' => 12, 'age_max_months' => 48, 'effective_price' => 1650, 'sales_count' => 5, 'rating_count' => 0, 'tag_slugs' => []];
        $weak = ['id' => 2, 'recipient_slugs' => ['baby-girl'], 'interest_slugs' => ['music'], 'occasion_slugs' => ['baby-shower'],
            'age_min_months' => 3, 'age_max_months' => 18, 'effective_price' => 850, 'sales_count' => 0, 'rating_count' => 0, 'tag_slugs' => []];
        $a = $scorer->score($great, $criteria, ['max_sales' => 10]);
        $b = $scorer->score($weak, $criteria, ['max_sales' => 10]);
        $this->assertGreaterThan($b['score'], $a['score']);
        $this->assertLessThanOrEqual(100.0, $a['score']);
        $this->assertNotEmpty($a['reasons']);
    }

    public function testMissingMetadataIsNotZeroed(): void
    {
        $scorer = new Scorer();
        $criteria = ['occasion' => 'birthday', 'interests' => [], 'prefs' => []];
        $untagged = ['id' => 3, 'occasion_slugs' => [], 'sales_count' => 0, 'rating_count' => 0];
        $wrong = ['id' => 4, 'occasion_slugs' => ['wedding'], 'sales_count' => 0, 'rating_count' => 0];
        $this->assertGreaterThan($scorer->score($wrong, $criteria)['score'], $scorer->score($untagged, $criteria)['score']);
    }

    public function testDislikePenalty(): void
    {
        $scorer = new Scorer();
        $p = ['id' => 9, 'sales_count' => 0, 'rating_count' => 0];
        $this->assertGreaterThan($scorer->score($p, [], ['disliked_ids' => [9]])['score'], $scorer->score($p, [])['score']);
    }

    public function testCustomWeightsAreApplied(): void
    {
        $this->assertEquals(40.0, (new Scorer(['recipient' => 40]))->weights()['recipient']);
    }

    /**
     * Vector from the sample request form in eSewa's ePay v2 docs (total_amount=110, transaction_uuid=241028,
     * signature i94zsd3o...). Note: the docs' separate "signature example" value does not correspond to its
     * own inputs, so the form sample is used.
     */
    public function testEsewaSignatureMatchesDocumentation(): void
    {
        $sig = EsewaGateway::sign('total_amount=110,transaction_uuid=241028,product_code=EPAYTEST', '8gBm/:&EnhH.1/q');
        $this->assertSame('i94zsd3oXF6ZsSr/kGqT4sSzYQzjj1W/waxjWyRwaME=', $sig);
    }

    public function testEsewaCallbackSignatureVerification(): void
    {
        $gw = new EsewaGateway(['secret_key' => '8gBm/:&EnhH.1/q', 'product_code' => 'EPAYTEST'], new \App\Services\Payments\CurlHttpClient());
        $data = ['transaction_code' => 'X1', 'status' => 'COMPLETE', 'total_amount' => '100', 'transaction_uuid' => 'T-1', 'product_code' => 'EPAYTEST', 'signed_field_names' => 'transaction_code,status,total_amount,transaction_uuid,product_code,signed_field_names'];
        $data['signature'] = EsewaGateway::sign('transaction_code=X1,status=COMPLETE,total_amount=100,transaction_uuid=T-1,product_code=EPAYTEST,signed_field_names=' . $data['signed_field_names'], '8gBm/:&EnhH.1/q');
        $this->assertTrue($gw->decodeCallback(base64_encode(json_encode($data)))['signature_valid']);
        $data['total_amount'] = '1';
        $this->assertFalse($gw->decodeCallback(base64_encode(json_encode($data)))['signature_valid']);
    }

    public function testKhaltiAmountsInPaisa(): void
    {
        $this->assertSame(125050, KhaltiGateway::toPaisa(1250.50));
    }

    public function testOrderStateMachine(): void
    {
        $this->assertTrue(OrderStateMachine::canOrder('pending_payment', 'confirmed'));
        $this->assertFalse(OrderStateMachine::canOrder('pending_payment', 'shipped'));
        $this->assertFalse(OrderStateMachine::canOrder('delivered', 'processing'));
        $this->assertFalse(OrderStateMachine::canOrder('refunded', 'confirmed'));
        $this->assertTrue(OrderStateMachine::canPayment('expired', 'paid'));
        $this->assertFalse(OrderStateMachine::canPayment('refunded', 'paid'));
    }

    public function testValidatorRules(): void
    {
        $v = Validator::make(['email' => 'nope', 'phone' => '9841234567', 'ward' => '40'], ['email' => 'required|email', 'phone' => 'required|phone', 'ward' => 'nullable|integer|between:1,35']);
        $this->assertTrue($v->fails());
        $errors = $v->errors();
        $this->assertNotNull($errors['email'] ?? null);
        $this->assertNull($errors['phone'] ?? null);
        $this->assertNotNull($errors['ward'] ?? null);
    }
}
