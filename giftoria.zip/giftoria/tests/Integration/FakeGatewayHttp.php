<?php
declare(strict_types=1);

namespace Tests\Integration;

use App\Services\Payments\HttpClient;

/** Scriptable fake for gateway verification calls. */
final class FakeGatewayHttp implements HttpClient
{
    public array $calls = [];

    /** @param callable(string $method, string $url, ?string $body): array{status:int, body:string} $responder */
    public function __construct(private $responder)
    {
    }

    public function request(string $method, string $url, array $headers = [], ?string $body = null): array
    {
        $this->calls[] = [$method, $url, $body];
        return ($this->responder)($method, $url, $body);
    }

    public static function esewa(string $status, ?float $amount = null, string $refId = 'REF123'): self
    {
        return new self(static function (string $m, string $url) use ($status, $amount, $refId) {
            parse_str((string) parse_url($url, PHP_URL_QUERY), $q);
            return ['status' => 200, 'body' => json_encode([
                'product_code' => $q['product_code'], 'transaction_uuid' => $q['transaction_uuid'],
                'total_amount' => $amount ?? (float) $q['total_amount'], 'status' => $status, 'ref_id' => $refId,
            ])];
        });
    }
}
