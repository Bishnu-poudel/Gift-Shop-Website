<?php
declare(strict_types=1);

namespace Tests\Integration;

require_once __DIR__ . '/FakeGatewayHttp.php';

use App\Core\Auth;
use App\Core\Database;
use App\Core\Gate;
use App\Core\Kernel;
use App\Core\Request;
use App\Core\Router;
use App\Core\Session;
use App\Services\AuthService;
use App\Services\CampaignService;
use App\Services\CouponService;
use App\Services\InventoryService;
use App\Services\OrderService;
use App\Services\PaymentService;
use App\Services\PricingService;
use App\Services\Recommendation\RecommendationEngine;
use App\Services\SearchService;
use PHPUnit\Framework\TestCase;

/**
 * End-to-end acceptance scenarios from the project brief (tests A–N), against a disposable database.
 */
final class AcceptanceTest extends TestCase
{
    public static function setUpBeforeClass(): void
    {
        \TestDatabase::ensure();
    }

    protected function setUp(): void
    {
        \TestDatabase::ensure();
        Auth::flushCache();
        Session::forget('auth_staff');
        Session::forget('auth_customer');
    }

    private function stock(string $sku): int
    {
        return (int) Database::fetchColumn('SELECT COALESCE(SUM(i.quantity),0) FROM inventory i JOIN products p ON p.id = i.product_id WHERE p.sku = :s', ['s' => $sku]);
    }

    // TEST A
    public function testA_GiftForBabyGirlReturnsBabyGifts(): void
    {
        $r = (new SearchService())->search(['q' => 'gift for baby girl']);
        $this->assertGreaterThan(5, $r['total']);
        $this->assertSame('baby-girl', $r['parsed']['recipient']);
        foreach ($r['items'] as $p) {
            $tagged = Database::fetchColumn(
                "SELECT 1 FROM product_recipients pr JOIN recipients r ON r.id = pr.recipient_id WHERE pr.product_id = :p AND r.slug = 'baby-girl'",
                ['p' => (int) $p['id']]
            );
            $this->assertNotNull($tagged, $p['name'] . ' is not a baby-girl gift');
        }
    }

    // TEST B
    public function testB_FilteredRecommendationsRespectAgeBudgetAndSafety(): void
    {
        $e = new RecommendationEngine();
        $c = $e->normalize(['recipient' => 'baby-girl', 'age' => '1-2-years', 'occasion' => 'first-birthday',
            'interests' => ['princess-toys', 'educational-toys'], 'min_price' => 500, 'max_price' => 2500]);
        $r = $e->recommend($c);
        $this->assertGreaterThan(5, $r['total']);
        $names = array_column($r['items'], 'name');
        foreach ($r['items'] as $p) {
            $this->assertGreaterThanOrEqual(500, (float) $p['effective_price']);
            $this->assertLessThanOrEqual(2500, (float) $p['effective_price']);
            $this->assertLessThanOrEqual(12, (int) $p['age_min_months'], $p['name'] . ' is not suitable from 12 months');
            $this->assertSame(0, (int) $p['has_small_parts'], $p['name'] . ' has small parts');
        }
        $this->assertNotContains('Action Hero Figure Set (5 pieces)', $names);
        $this->assertNotContains('Smart Fitness Band', $names);
        $this->assertNotContains('Non-stick Cookware Set', $names);
        $this->assertNotContains('Princess Wooden Tea Party Set', $names, 'A 2y+ toy must not be offered for 12-month-olds');
        // Top results match the selected interests.
        $this->assertNotEmpty(array_intersect(['princess-toys', 'educational-toys'], $r['items'][0]['interest_slugs']));
    }

    // TEST C
    public function testC_MisspelledOrUnknownInterestDoesNotCrash(): void
    {
        $r = (new SearchService())->search(['q' => 'pricess toyz']);
        $this->assertNotNull($r['did_you_mean']);
        $this->assertGreaterThan(0, $r['total']);
        $none = (new SearchService())->search(['q' => 'zzqxv']);
        $this->assertSame(0, $none['total']);
        $this->assertNotEmpty($none['suggestions']['categories']);
        $e = new RecommendationEngine();
        $res = $e->recommend($e->normalize(['recipient' => 'brother', 'custom_interest' => 'qwzxv']));
        $this->assertNotEmpty($res['relaxed']);
    }

    // TEST D
    public function testD_RegisterVerifyLoginWishlistAddresses(): void
    {
        $email = 'newuser' . random_int(1000, 9999) . '@example.com';
        $auth = new AuthService();
        $id = $auth->registerCustomer('New User', $email, 'secret-pass-1', false);
        $this->assertNotNull($id);
        $this->assertNull(Auth::attempt($email, 'wrong-pass', 'customer', '10.0.0.1'));
        $user = Auth::attempt($email, 'secret-pass-1', 'customer', '10.0.0.1');
        $this->assertSame('pending', $user['status'], 'Unverified accounts stay pending');
        $token = $auth->createToken($id, 'verify');
        $verified = $auth->verifyEmail($token);
        $this->assertSame('active', $verified['status']);
        $this->assertNull($auth->verifyEmail($token), 'Verification tokens are single use');
        $pid = (int) Database::fetchColumn("SELECT id FROM products WHERE sku = 'GFT-1003'");
        $this->assertTrue((new \App\Services\WishlistService())->toggle($id, $pid));
        $this->assertContains($pid, (new \App\Services\WishlistService())->savedProductIds($id));
        $this->assertSame(0, (int) Database::fetchColumn('SELECT COUNT(*) FROM user_roles WHERE user_id = :u', ['u' => $id]));
    }

    // TEST E
    public function testE_TotalsAreRecalculatedFromServerPrices(): void
    {
        $lines = \TestDatabase::lines(['GFT-1002' => 2, 'GFT-1005' => 1]); // 990 (sale) x2 + 650
        $lines[0]['price'] = '1.00'; // tampering with a line copy must not matter: unit price comes from sale/price columns
        $lines[0]['sale_price'] = '990.00';
        $t = (new PricingService())->calculate($lines, ['district' => 'Lalitpur']);
        $this->assertEquals(2630.0, $t['subtotal']);
        $this->assertEquals(100.0, $t['shipping'], 'Valley rate below free threshold');
        $this->assertEquals(2730.0, $t['grand_total']);
        $t2 = (new PricingService())->calculate(\TestDatabase::lines(['GFT-1002' => 4]), ['district' => 'Lalitpur']);
        $this->assertEquals(0.0, $t2['shipping'], 'Free delivery over NPR 3,000 in the Valley');
    }

    // TEST F + G + H
    public function testFGH_CheckoutPaymentVerificationAndIdempotency(): void
    {
        $sku = 'GFT-1014';
        $before = $this->stock($sku);
        $orders = new OrderService();
        $order = $orders->place(\TestDatabase::orderData('esewa', ['checkout_token' => random_token()]), \TestDatabase::lines([$sku => 2]));
        $this->assertSame('pending_payment', $order['status']);
        $this->assertSame($before - 2, $this->stock($sku), 'Stock reserved at order creation');

        // G: gateway says PENDING -> must not be paid even though the customer hit the success URL.
        $pending = new PaymentService(FakeGatewayHttp::esewa('PENDING'));
        $start = $pending->start($order, 'esewa');
        $ref = $start['fields']['transaction_uuid'];
        $forged = base64_encode(json_encode(['status' => 'COMPLETE', 'transaction_uuid' => $ref, 'total_amount' => $order['grand_total']]));
        $r = $pending->handleEsewaSuccess($ref, $forged);
        $this->assertNotSame('paid', $r['status']);
        $this->assertNotSame('paid', $orders->find((int) $order['id'])['payment_status']);

        // G: amount mismatch reported by the gateway is rejected.
        $tampered = new PaymentService(FakeGatewayHttp::esewa('COMPLETE', 1.0));
        $tampered->handleEsewaSuccess($ref, $forged);
        $this->assertNotSame('paid', $orders->find((int) $order['id'])['payment_status']);

        // Verified success.
        $ok = new PaymentService(FakeGatewayHttp::esewa('COMPLETE', null, 'TXN-777'));
        $this->assertSame('paid', $ok->handleEsewaSuccess($ref, $forged)['status']);
        $paid = $orders->find((int) $order['id']);
        $this->assertSame('paid', $paid['payment_status']);
        $this->assertSame('confirmed', $paid['status']);

        // H: repeated callbacks change nothing.
        $ok->handleEsewaSuccess($ref, $forged);
        $ok->handleEsewaSuccess($ref, $forged);
        $this->assertSame(1, (int) Database::fetchColumn("SELECT COUNT(*) FROM payments WHERE order_id = :o AND status = 'paid'", ['o' => (int) $order['id']]));
        $this->assertSame($before - 2, $this->stock($sku), 'Stock deducted exactly once');
        $this->assertSame(1, (int) Database::fetchColumn("SELECT COUNT(*) FROM order_status_history WHERE order_id = :o AND to_status = 'confirmed'", ['o' => (int) $order['id']]));

        // Idempotent checkout: same token returns the same order.
        $again = $orders->place(\TestDatabase::orderData('esewa', ['checkout_token' => $order['checkout_token']]), \TestDatabase::lines([$sku => 2]));
        $this->assertSame((int) $order['id'], (int) $again['id']);
    }

    public function testKhaltiLookupAndPending(): void
    {
        $orders = new OrderService();
        $order = $orders->place(\TestDatabase::orderData('khalti'), \TestDatabase::lines(['GFT-1029' => 1]));
        $paisa = (int) round((float) $order['grand_total'] * 100);
        $state = 'Pending';
        $http = new FakeGatewayHttp(static function (string $m, string $url, ?string $body) use (&$state, $paisa) {
            if (str_contains($url, 'initiate')) {
                return ['status' => 200, 'body' => json_encode(['pidx' => 'PIDX1' . $paisa, 'payment_url' => 'https://test-pay.khalti.com/?pidx=x', 'expires_at' => null])];
            }
            return ['status' => 200, 'body' => json_encode(['pidx' => 'PIDX1' . $paisa, 'total_amount' => $paisa, 'status' => $state, 'transaction_id' => $state === 'Completed' ? 'KTX1' : null])];
        });
        \App\Core\Config::set('payments.khalti.secret_key', 'test_secret');
        $svc = new PaymentService($http);
        $svc->start($order, 'khalti');
        $r = $svc->handleKhaltiReturn(['pidx' => 'PIDX1' . $paisa, 'status' => 'Completed']);
        $this->assertSame('pending', $r['status'], 'Query string "Completed" is not trusted');
        $state = 'Completed';
        $r = $svc->handleKhaltiReturn(['pidx' => 'PIDX1' . $paisa]);
        $this->assertSame('paid', $r['status']);
        $lookup = array_values(array_filter($http->calls, static fn ($c) => str_contains($c[1], 'lookup')));
        $this->assertNotEmpty($lookup);
    }

    public function testExpiredOrderReleasesStockOnce(): void
    {
        $sku = 'GFT-1018';
        $before = $this->stock($sku);
        $orders = new OrderService();
        $order = $orders->place(\TestDatabase::orderData('esewa'), \TestDatabase::lines([$sku => 3]));
        Database::query('UPDATE orders SET expires_at = UTC_TIMESTAMP() - INTERVAL 1 MINUTE WHERE id = :id', ['id' => (int) $order['id']]);
        $orders->expireStale(false);
        $orders->expireStale(false);
        $this->assertSame('cancelled', $orders->find((int) $order['id'])['status']);
        $this->assertSame($before, $this->stock($sku));
    }

    // TEST I + J
    public function testIJ_RolePermissionsAndNoAdminEscalation(): void
    {
        $marketing = (int) Database::fetchColumn("SELECT id FROM users WHERE email = 'marketing-staff.demo@example.com'");
        $this->assertTrue(Gate::allows('campaigns.manage', $marketing));
        $this->assertFalse(Gate::allows('inventory.manage', $marketing));
        $this->assertFalse(Gate::allows('refunds.manage', $marketing));
        $superRole = (int) Database::fetchColumn("SELECT id FROM roles WHERE slug = 'super-admin'");
        $this->assertFalse(Gate::canAssignRole($marketing, $superRole));

        // HTTP layer: marketing staff gets 403 on inventory and refunds routes.
        $router = new Router();
        require BASE_PATH . '/routes/web.php';
        require BASE_PATH . '/routes/admin.php';
        $user = Database::fetch('SELECT * FROM users WHERE id = :id', ['id' => $marketing]);
        Session::put('auth_staff', ['id' => $marketing, 'v' => (int) $user['session_version']]);
        Auth::flushCache();
        foreach (['/admin/inventory', '/admin/refunds', '/admin/staff', '/admin/roles'] as $path) {
            $res = (new Kernel($router))->handle(new Request('GET', $path, [], [], [], ['REMOTE_ADDR' => '127.0.0.1']));
            $this->assertSame(403, $res->status, "$path must be forbidden for marketing staff");
        }
        $ok = (new Kernel($router))->handle(new Request('GET', '/admin/campaigns', [], [], [], ['REMOTE_ADDR' => '127.0.0.1']));
        $this->assertSame(200, $ok->status);

        // J: no public route creates staff; registration always makes customers without roles.
        foreach ($router->routes() as $route) {
            if (!str_starts_with($route['pattern'], '/admin')) {
                $this->assertFalse(str_contains($route['pattern'], 'staff') || str_contains($route['pattern'], 'role'), 'Public route ' . $route['pattern']);
            }
        }
        $id = (new AuthService())->registerCustomer('Sneaky', 'sneaky' . random_int(1, 99999) . '@example.com', 'password-123', false);
        $this->assertSame('customer', Database::fetchColumn('SELECT type FROM users WHERE id = :id', ['id' => $id]));
        $this->assertNull(Auth::attempt('owner@example.com', 'x', 'customer', '10.0.0.9'));
    }

    // TEST K
    public function testK_ProductManagerCanManageProducts(): void
    {
        $pm = (int) Database::fetchColumn("SELECT id FROM users WHERE email = 'product-manager.demo@example.com'");
        $this->assertTrue(Gate::allows('products.manage', $pm));
        $router = new Router();
        require BASE_PATH . '/routes/web.php';
        require BASE_PATH . '/routes/admin.php';
        $user = Database::fetch('SELECT * FROM users WHERE id = :id', ['id' => $pm]);
        Session::put('auth_staff', ['id' => $pm, 'v' => (int) $user['session_version']]);
        Auth::flushCache();
        $res = (new Kernel($router))->handle(new Request('GET', '/admin/products', [], [], [], ['REMOTE_ADDR' => '127.0.0.1']));
        $this->assertSame(200, $res->status);
        $create = (new Kernel($router))->handle(new Request('GET', '/admin/products/create', [], [], [], ['REMOTE_ADDR' => '127.0.0.1']));
        $this->assertSame(200, $create->status);
        // Deactivation removes it from the storefront.
        $pid = (int) Database::fetchColumn("SELECT id FROM products WHERE sku = 'GFT-1060'");
        Database::update('products', ['status' => 'inactive'], ['id' => $pid]);
        $this->assertSame([], (new \App\Repositories\ProductRepository())->cardsByIds([$pid]));
        Database::update('products', ['status' => 'active'], ['id' => $pid]);
    }

    // TEST L
    public function testL_CouponAndScheduledCampaign(): void
    {
        $id = Database::insert('coupons', ['code' => 'TESTL20', 'type' => 'percent', 'value' => 20, 'min_subtotal' => 1000, 'max_discount' => 300, 'is_active' => 1]);
        $coupon = (new CouponService())->findByCode('testl20');
        $lines = \TestDatabase::lines(['GFT-1030' => 1]);
        $res = (new CouponService())->evaluate($coupon, [['product_id' => $lines[0]['product_id'], 'line_total' => 2200, 'category_id' => $lines[0]['category_id']]], 2200, null, 'x@example.com');
        $this->assertTrue($res['ok']);
        $this->assertEquals(300.0, $res['discount'], 'Capped by max_discount');
        $low = (new CouponService())->evaluate($coupon, [], 500, null, 'x@example.com');
        $this->assertFalse($low['ok']);
        $cid = Database::insert('campaigns', ['name' => 'Future', 'slug' => 'future-' . $id, 'type' => 'seasonal', 'starts_at' => gmdate('Y-m-d H:i:s', time() + 86400), 'is_active' => 1]);
        $row = Database::fetch('SELECT * FROM campaigns WHERE id = :id', ['id' => $cid]);
        $this->assertSame('scheduled', CampaignService::statusOf($row));
        $this->assertNull((new CampaignService())->findLiveBySlug($row['slug']));
    }

    // TEST N
    public function testN_LastUnitCannotBeSoldTwice(): void
    {
        $sku = 'GFT-1053'; // seeded with exactly one unit
        $this->assertSame(1, $this->stock($sku));
        $orders = new OrderService();
        $first = $orders->place(\TestDatabase::orderData('cod'), \TestDatabase::lines([$sku => 1]));
        $this->assertSame('confirmed', $first['status']);
        $failed = false;
        try {
            $orders->place(\TestDatabase::orderData('cod'), \TestDatabase::lines([$sku => 1]));
        } catch (\RuntimeException $e) {
            $failed = true;
        }
        $this->assertTrue($failed, 'Second purchase of the last unit must fail');
        $this->assertSame(0, $this->stock($sku));
        $this->assertSame(1, (int) Database::fetchColumn('SELECT COUNT(*) FROM order_items WHERE sku = :s', ['s' => $sku]));
    }

    public function testInventoryNeverNegative(): void
    {
        $pid = (int) Database::fetchColumn("SELECT id FROM products WHERE sku = 'GFT-1024'");
        $this->expectException(\RuntimeException::class);
        (new InventoryService())->change($pid, 0, -100000, 'adjustment');
    }

    public function testCancelAfterPaymentCreatesRefundRequest(): void
    {
        $orders = new OrderService();
        $order = $orders->place(\TestDatabase::orderData('esewa'), \TestDatabase::lines(['GFT-1046' => 1]));
        $svc = new PaymentService(FakeGatewayHttp::esewa('COMPLETE', null, 'TXN-' . $order['id']));
        $start = $svc->start($order, 'esewa');
        $svc->handleEsewaSuccess($start['fields']['transaction_uuid'], '');
        $orders->transition((int) $order['id'], 'cancelled', null, 'Customer changed mind');
        $o = $orders->find((int) $order['id']);
        $this->assertSame('refund_pending', $o['status']);
        $this->assertSame('refund_pending', $o['payment_status']);
        $this->assertSame(1, (int) Database::fetchColumn("SELECT COUNT(*) FROM refunds WHERE order_id = :o AND status = 'requested'", ['o' => (int) $order['id']]));
    }

    public function testBillIsIssuedBeforePaymentWithTaxDetails(): void
    {
        \App\Services\SettingsService::set('vat_registered', true, 'billing');
        \App\Services\SettingsService::set('store_vat_number', '609876543', 'billing');
        \App\Services\SettingsService::set('store_pan', '609876543', 'billing');
        \App\Services\SettingsService::set('prices_include_vat', true, 'billing');
        \App\Services\SettingsService::set('vat_rate', 13, 'billing');
        try {
            $orders = new OrderService();
            $a = $orders->place(\TestDatabase::orderData('esewa', ['buyer_pan' => '301234567', 'buyer_company' => 'Acme Traders']), \TestDatabase::lines(['GFT-1029' => 2]));
            $b = $orders->place(\TestDatabase::orderData('esewa'), \TestDatabase::lines(['GFT-1029' => 1]));
            // Sequential, per fiscal year, assigned at order placement (before payment).
            $this->assertNotNull($a['bill_number']);
            $na = (int) substr($a['bill_number'], -6);
            $nb = (int) substr($b['bill_number'], -6);
            $this->assertSame($na + 1, $nb);
            $this->assertStringContainsString(\App\Services\TaxService::fiscalYear(), $a['bill_number']);
            // Tax split stored on the order and consistent with the total.
            $this->assertEquals((float) $a['grand_total'], round((float) $a['taxable_amount'] + (float) $a['vat_amount'], 2));
            $this->assertGreaterThan(0, (float) $a['vat_amount']);

            $html = \App\Services\BillService::render($a, 'customer');
            $this->assertStringContainsString('Proforma invoice', $html);
            $this->assertStringContainsString('609876543', $html);
            $this->assertStringContainsString('301234567', $html);
            $this->assertStringContainsString('Acme Traders', $html);
            $this->assertStringContainsString('VAT @ 13%', $html);
            $this->assertStringContainsString('Rupees', $html);

            // After verified payment the same bill becomes the tax invoice (same number).
            $svc = new PaymentService(FakeGatewayHttp::esewa('COMPLETE', null, 'TXN-BILL-' . $a['id']));
            $start = $svc->start($a, 'esewa');
            $svc->handleEsewaSuccess($start['fields']['transaction_uuid'], '');
            $paid = $orders->find((int) $a['id']);
            $this->assertSame($a['bill_number'], $paid['bill_number']);
            $this->assertStringContainsString('Tax invoice', \App\Services\BillService::render($paid, 'customer'));
        } finally {
            \App\Services\SettingsService::set('vat_registered', false, 'billing');
        }
    }

    public function testCsrfIsRequiredForPosts(): void
    {
        $router = new Router();
        require BASE_PATH . '/routes/web.php';
        $res = (new Kernel($router))->handle(new Request('POST', '/newsletter', [], ['email' => 'a@example.com'], [], ['REMOTE_ADDR' => '127.0.0.1', 'HTTP_ACCEPT' => 'application/json']));
        $this->assertSame(419, $res->status);
    }
}
