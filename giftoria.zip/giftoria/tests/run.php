<?php
declare(strict_types=1);

/*
 | Zero-dependency test runner:  php tests/run.php [filter]
 | Runs every *Test.php in tests/Unit and tests/Integration. Prefer vendor/bin/phpunit when Composer is available.
 */

require __DIR__ . '/bootstrap.php';

$filter = $argv[1] ?? '';
$files = array_merge(glob(__DIR__ . '/Unit/*Test.php') ?: [], glob(__DIR__ . '/Integration/*Test.php') ?: []);
$passed = $failed = 0;
$failures = [];
$start = microtime(true);

foreach ($files as $file) {
    require_once $file;
    $class = 'Tests\\' . basename(dirname($file)) . '\\' . basename($file, '.php');
    if (!class_exists($class)) {
        continue;
    }
    $class::setUpBeforeClass();
    foreach (get_class_methods($class) as $method) {
        if (!str_starts_with($method, 'test') || ($filter !== '' && stripos($class . '::' . $method, $filter) === false)) {
            continue;
        }
        $test = new $class();
        try {
            $test->runTestMethod($method);
            if ($expected = $test->getExpectedException()) {
                throw new PHPUnit\Framework\AssertionFailedError("Expected exception $expected was not thrown.");
            }
            $passed++;
            echo '.';
        } catch (Throwable $e) {
            $expected = $test->getExpectedException();
            if ($expected && $e instanceof $expected) {
                $passed++;
                echo '.';
                continue;
            }
            $failed++;
            echo 'F';
            $failures[] = sprintf("%s::%s\n   %s: %s\n   at %s:%d", $class, $method, get_class($e), $e->getMessage(), $e->getFile(), $e->getLine());
        }
    }
}

echo "\n\n";
foreach ($failures as $i => $f) {
    echo ($i + 1) . ") $f\n\n";
}
printf("%s — %d passed, %d failed (%.1fs)\n", $failed ? 'FAILURES' : 'OK', $passed, $failed, microtime(true) - $start);
exit($failed ? 1 : 0);
