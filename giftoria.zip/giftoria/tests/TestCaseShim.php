<?php
declare(strict_types=1);

/*
 | Minimal stand-in for PHPUnit\Framework\TestCase so the suite runs on a plain XAMPP install
 | (php tests/run.php) without Composer. With Composer, `vendor/bin/phpunit` uses real PHPUnit.
 */

namespace PHPUnit\Framework;

class AssertionFailedError extends \RuntimeException
{
}

abstract class TestCase
{
    protected function setUp(): void
    {
    }

    protected function tearDown(): void
    {
    }

    public static function setUpBeforeClass(): void
    {
    }

    public function runTestMethod(string $method): void
    {
        $this->setUp();
        try {
            $this->$method();
        } finally {
            $this->tearDown();
        }
    }

    private static function fail(string $message): void
    {
        throw new AssertionFailedError($message);
    }

    public static function assertTrue(mixed $v, string $m = ''): void
    {
        if ($v !== true) {
            self::fail($m ?: 'Failed asserting that value is true.');
        }
    }

    public static function assertFalse(mixed $v, string $m = ''): void
    {
        if ($v !== false) {
            self::fail($m ?: 'Failed asserting that value is false.');
        }
    }

    public static function assertSame(mixed $expected, mixed $actual, string $m = ''): void
    {
        if ($expected !== $actual) {
            self::fail($m ?: 'Failed asserting that ' . var_export($actual, true) . ' is identical to ' . var_export($expected, true) . '.');
        }
    }

    public static function assertEquals(mixed $expected, mixed $actual, string $m = ''): void
    {
        if ($expected != $actual) {
            self::fail($m ?: 'Failed asserting that ' . var_export($actual, true) . ' equals ' . var_export($expected, true) . '.');
        }
    }

    public static function assertNotSame(mixed $expected, mixed $actual, string $m = ''): void
    {
        if ($expected === $actual) {
            self::fail($m ?: 'Failed asserting that values differ.');
        }
    }

    public static function assertNull(mixed $v, string $m = ''): void
    {
        if ($v !== null) {
            self::fail($m ?: 'Failed asserting that ' . var_export($v, true) . ' is null.');
        }
    }

    public static function assertNotNull(mixed $v, string $m = ''): void
    {
        if ($v === null) {
            self::fail($m ?: 'Failed asserting that value is not null.');
        }
    }

    public static function assertContains(mixed $needle, iterable $haystack, string $m = ''): void
    {
        foreach ($haystack as $h) {
            if ($h === $needle) {
                return;
            }
        }
        self::fail($m ?: 'Failed asserting that array contains ' . var_export($needle, true) . '.');
    }

    public static function assertNotContains(mixed $needle, iterable $haystack, string $m = ''): void
    {
        foreach ($haystack as $h) {
            if ($h === $needle) {
                self::fail($m ?: 'Failed asserting that array does not contain ' . var_export($needle, true) . '.');
            }
        }
    }

    public static function assertCount(int $n, \Countable|array $v, string $m = ''): void
    {
        if (count($v) !== $n) {
            self::fail($m ?: 'Failed asserting count ' . count($v) . ' is ' . $n . '.');
        }
    }

    public static function assertGreaterThan(mixed $expected, mixed $actual, string $m = ''): void
    {
        if (!($actual > $expected)) {
            self::fail($m ?: "Failed asserting that $actual is greater than $expected.");
        }
    }

    public static function assertGreaterThanOrEqual(mixed $expected, mixed $actual, string $m = ''): void
    {
        if (!($actual >= $expected)) {
            self::fail($m ?: "Failed asserting that $actual >= $expected.");
        }
    }

    public static function assertLessThanOrEqual(mixed $expected, mixed $actual, string $m = ''): void
    {
        if (!($actual <= $expected)) {
            self::fail($m ?: "Failed asserting that $actual <= $expected.");
        }
    }

    public static function assertStringContainsString(string $needle, string $haystack, string $m = ''): void
    {
        if (!str_contains($haystack, $needle)) {
            self::fail($m ?: "Failed asserting that string contains \"$needle\".");
        }
    }

    public static function assertEmpty(mixed $v, string $m = ''): void
    {
        if (!empty($v)) {
            self::fail($m ?: 'Failed asserting that value is empty.');
        }
    }

    public static function assertNotEmpty(mixed $v, string $m = ''): void
    {
        if (empty($v)) {
            self::fail($m ?: 'Failed asserting that value is not empty.');
        }
    }

    private ?string $expectedException = null;

    public function expectException(string $class): void
    {
        $this->expectedException = $class;
    }

    public function getExpectedException(): ?string
    {
        return $this->expectedException;
    }

    public function resetExpectedException(): void
    {
        $this->expectedException = null;
    }
}
