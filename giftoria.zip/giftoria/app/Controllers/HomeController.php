<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Services\HomepageService;
use App\Services\WishlistService;
use App\Core\Auth;

final class HomeController extends Controller
{
    public function index(Request $request): Response
    {
        $service = new HomepageService();
        $sections = array_map([$service, 'hydrate'], $service->sections());
        $store = (string) setting('store_name', config('app.name'));
        return $this->view('storefront/home/index', [
            'sections' => $sections,
            'saved' => (new WishlistService())->savedProductIds(Auth::customerId()),
            'metaDescription' => $store . ' — original gifts for every person and occasion in Nepal. Personalized keepsakes, handmade treasures and a smart Gift Finder. Pay with eSewa, Khalti or cash on delivery.',
            'jsonLd' => [[
                '@context' => 'https://schema.org',
                '@type' => 'Organization',
                'name' => $store,
                'url' => url('/'),
                'email' => setting('store_email'),
                'telephone' => setting('store_phone'),
            ], [
                '@context' => 'https://schema.org',
                '@type' => 'WebSite',
                'name' => $store,
                'url' => url('/'),
                'potentialAction' => [
                    '@type' => 'SearchAction',
                    'target' => url('/search') . '?q={search_term_string}',
                    'query-input' => 'required name=search_term_string',
                ],
            ]],
        ]);
    }
}
