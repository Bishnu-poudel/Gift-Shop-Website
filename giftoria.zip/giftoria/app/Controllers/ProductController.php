<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Repositories\ProductRepository;
use App\Services\Analytics;
use App\Services\ShippingService;
use App\Services\WishlistService;

final class ProductController extends Controller
{
    public function show(Request $request, string $slug): Response
    {
        $repo = new ProductRepository();
        $p = $repo->findBySlug($slug);
        if (!$p || $p['status'] !== 'active') {
            throw new HttpException(404);
        }
        $repo->incrementViews((int) $p['id']);
        Analytics::increment('product_views');

        // Recently viewed (session-based, no tracking cookie beyond the session)
        $recent = array_values(array_filter((array) Session::get('recently_viewed', []), static fn ($id) => (int) $id !== (int) $p['id']));
        Session::put('recently_viewed', array_slice(array_merge([(int) $p['id']], $recent), 0, 12));
        $recentProducts = $repo->cardsByIds(array_slice($recent, 0, 4));

        $reviews = Database::fetchAll(
            "SELECT r.*, u.name FROM reviews r JOIN users u ON u.id = r.user_id
             WHERE r.product_id = :id AND r.status = 'approved' ORDER BY r.is_verified DESC, r.created_at DESC LIMIT 20",
            ['id' => (int) $p['id']]
        );
        $distribution = array_fill(1, 5, 0);
        foreach (Database::fetchAll("SELECT rating, COUNT(*) n FROM reviews WHERE product_id = :id AND status = 'approved' GROUP BY rating", ['id' => (int) $p['id']]) as $row) {
            $distribution[(int) $row['rating']] = (int) $row['n'];
        }
        $questions = Database::fetchAll(
            "SELECT * FROM product_questions WHERE product_id = :id AND status = 'published' ORDER BY created_at DESC LIMIT 10",
            ['id' => (int) $p['id']]
        );

        $customerId = Auth::customerId();
        $canReview = false;
        $hasReviewed = false;
        if ($customerId) {
            $hasReviewed = (bool) Database::fetchColumn('SELECT 1 FROM reviews WHERE user_id = :u AND product_id = :p', ['u' => $customerId, 'p' => (int) $p['id']]);
            $canReview = !$hasReviewed;
        }

        // Delivery estimate only when we know where (saved default address); otherwise show zone ranges.
        $estimate = null;
        if ($customerId) {
            $district = Database::fetchColumn('SELECT district FROM addresses WHERE user_id = :u ORDER BY is_default DESC, id DESC LIMIT 1', ['u' => $customerId]);
            if ($district) {
                $estimate = ShippingService::estimate((int) $p['lead_time_days'], ShippingService::zoneForDistrict((string) $district)) + ['district' => $district];
            }
        }

        $offerAvailability = ($p['stock'] > 0 || (int) $p['allow_backorder']) ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock';
        $ld = [
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            'name' => $p['name'],
            'sku' => $p['sku'],
            'description' => $p['short_description'] ?: str_limit(strip_tags((string) $p['description']), 300),
            'image' => array_map(static fn ($i) => image_url($i['path']), $p['images']),
            'offers' => [
                '@type' => 'Offer',
                'priceCurrency' => 'NPR',
                'price' => number_format((float) $p['effective_price'], 2, '.', ''),
                'availability' => $offerAvailability,
                'url' => url('/product/' . $p['slug']),
            ],
        ];
        if ($p['maker_name']) {
            $ld['brand'] = ['@type' => 'Brand', 'name' => $p['maker_name']];
        }
        // Only real, approved reviews are exposed in structured data.
        if ((int) $p['rating_count'] > 0) {
            $ld['aggregateRating'] = ['@type' => 'AggregateRating', 'ratingValue' => (float) $p['rating_avg'], 'reviewCount' => (int) $p['rating_count']];
        }
        $crumbs = [];
        if ($p['category_slug']) {
            $crumbs[] = [$p['category_name'], url('/category/' . $p['category_slug'])];
        }
        $crumbs[] = [$p['name'], null];

        return $this->view('storefront/product/show', [
            'title' => $p['seo_title'] ?: $p['name'],
            'metaDescription' => $p['seo_description'] ?: ($p['short_description'] ?: $p['name']),
            'ogType' => 'product',
            'ogImage' => $p['image'] ? image_url($p['image']) : null,
            'p' => $p,
            'related' => $repo->related($p, 4),
            'together' => $repo->boughtTogether($p, 3),
            'recent' => $recentProducts,
            'reviews' => $reviews,
            'distribution' => $distribution,
            'questions' => $questions,
            'canReview' => $canReview,
            'hasReviewed' => $hasReviewed,
            'estimate' => $estimate,
            'zones' => ShippingService::zones(),
            'saved' => (new WishlistService())->savedProductIds($customerId),
            'crumbs' => $crumbs,
            'jsonLd' => [$ld, CatalogController::breadcrumbLd($crumbs)],
        ]);
    }

    public function question(Request $request, string $slug): Response
    {
        $p = Database::fetch("SELECT id, slug FROM products WHERE slug = :s AND status = 'active'", ['s' => $slug]);
        if (!$p) {
            throw new HttpException(404);
        }
        RateLimiter::enforce('question:' . $request->ip(), 5, 3600);
        $customer = Auth::customer();
        $data = $this->validate($request, [
            'name' => $customer ? 'nullable|max:120' : 'required|max:120',
            'question' => 'required|min:8|max:1000',
        ]);
        Database::insert('product_questions', [
            'product_id' => (int) $p['id'],
            'user_id' => $customer['id'] ?? null,
            'name' => $customer['name'] ?? strip_tags((string) $data['name']),
            'question' => strip_tags((string) $data['question']),
            'status' => 'pending',
        ]);
        flash('success', 'Thanks! Your question will appear once our team has answered it.');
        return $this->redirect('/product/' . $p['slug'] . '#questions');
    }
}
