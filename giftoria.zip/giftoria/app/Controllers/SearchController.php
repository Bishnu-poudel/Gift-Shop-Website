<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Repositories\TaxonomyRepository;
use App\Services\SearchService;

final class SearchController extends Controller
{
    public function index(Request $request): Response
    {
        $page = max(1, (int) $request->query('page', 1));
        $result = (new SearchService())->search($request->query(), $page, 24);
        $tax = new TaxonomyRepository();
        $q = $result['filters']['q'];
        return $this->view('storefront/catalog/listing', [
            'title' => $q !== '' ? 'Search: ' . $q : 'Search',
            'heading' => $q !== '' ? '“' . $q . '”' : 'Search gifts',
            'eyebrow' => 'Search results',
            'intro' => null,
            'isSearch' => true,
            'result' => $result,
            'paginator' => new Paginator($result['total'], 24, $page),
            'fixed' => [],
            'facets' => [
                'categories' => array_values(array_filter($tax->categories(), static fn ($c) => $c['parent_id'] === null)),
                'recipients' => $tax->all('recipients'),
                'occasions' => $tax->all('occasions'),
                'interests' => $tax->all('interests'),
                'ages' => $tax->ageRanges(),
                'makers' => $tax->makers(),
                'budgets' => $tax->budgets(),
            ],
            'crumbs' => [['Search', null]],
            'noindex' => true,
        ]);
    }

    public function suggest(Request $request): Response
    {
        return $this->json((new SearchService())->suggest((string) $request->query('q', '')));
    }
}
