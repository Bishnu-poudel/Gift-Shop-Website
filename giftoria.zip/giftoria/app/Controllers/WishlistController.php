<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Logger;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Validator;
use App\Services\CartService;
use App\Services\Recommendation\RecommendationEngine;
use App\Services\WishlistService;
use RuntimeException;

/** Wishlist heart toggle (site-wide) and the customer's wishlist pages (default + recipient lists). */
final class WishlistController extends Controller
{
    private const MAX_LISTS = 20;

    private WishlistService $wishlists;

    public function __construct()
    {
        $this->wishlists = new WishlistService();
    }

    /** POST /wishlist/toggle — JSON {product_id, wishlist_id?} → {saved: bool}. Works as a normal form post too. */
    public function toggle(Request $request): Response
    {
        $uid = Auth::customerId();
        if (!$uid) {
            if (!$request->wantsJson()) {
                flash('info', 'Please sign in to save gifts to your wishlist.');
                return $this->redirect('/login');
            }
            return $this->json(['message' => 'Please sign in to save gifts to your wishlist.', 'login' => url('/login')], 401);
        }
        $productId = $request->int('product_id');
        if ($productId <= 0) {
            return $this->json(['message' => 'Unknown product.'], 422);
        }
        $wishlistId = $request->int('wishlist_id') ?: null;
        if ($wishlistId !== null && !$this->wishlists->owned($wishlistId, $uid)) {
            $wishlistId = null; // never write to someone else's list
        }
        $exists = (bool) Database::fetchColumn("SELECT 1 FROM products WHERE id = :id AND status = 'active'", ['id' => $productId]);
        if (!$exists) {
            return $this->json(['message' => 'This product is no longer available.'], 404);
        }
        $saved = $this->wishlists->toggle($uid, $productId, $wishlistId);

        if ($saved && $this->personalizationAllowed($uid)) {
            try {
                (new RecommendationEngine())->recordFeedback($productId, 'wishlist', $uid, Session::visitorKey());
            } catch (\Throwable $e) {
                Logger::warning('Wishlist feedback not recorded', ['error' => $e->getMessage()]);
            }
        }

        if (!$request->wantsJson()) {
            flash('success', $saved ? 'Saved to your wishlist.' : 'Removed from your wishlist.');
            return $this->back('/account/wishlist');
        }
        return $this->json(['saved' => $saved]);
    }

    /** GET /account/wishlist[?list=id] */
    public function index(Request $request): Response
    {
        $uid = $this->uid();
        $defaultId = $this->wishlists->defaultId($uid);
        $lists = Database::fetchAll(
            'SELECT w.*, gr.name AS recipient_name,
                    (SELECT COUNT(*) FROM wishlist_items wi WHERE wi.wishlist_id = w.id) AS item_count
             FROM wishlists w
             LEFT JOIN gift_recipients gr ON gr.id = w.gift_recipient_id AND gr.user_id = w.user_id
             WHERE w.user_id = :u
             ORDER BY (w.id = :d) DESC, w.gift_recipient_id IS NOT NULL, w.name, w.id',
            ['u' => $uid, 'd' => $defaultId]
        );
        $listId = $request->int('list') ?: $defaultId;
        $current = null;
        foreach ($lists as $l) {
            if ((int) $l['id'] === $listId) {
                $current = $l;
            }
        }
        if (!$current) {
            throw new HttpException(404);
        }
        $recipients = Database::fetchAll('SELECT id, name FROM gift_recipients WHERE user_id = :u ORDER BY name', ['u' => $uid]);

        return $this->view('account/wishlist/index', [
            'title' => 'My wishlist',
            'noindex' => true,
            'lists' => $lists,
            'current' => $current,
            'defaultId' => $defaultId,
            'items' => $this->wishlists->items((int) $current['id']),
            'recipients' => $recipients,
            'canCreate' => count($lists) < self::MAX_LISTS,
        ]);
    }

    /** POST /account/wishlists — create a named list, optionally tied to a saved gift recipient. */
    public function createList(Request $request): Response
    {
        $uid = $this->uid();
        $data = Validator::validate([
            'name' => strip_tags($request->str('name')),
            'gift_recipient_id' => $request->str('gift_recipient_id'),
        ], [
            'name' => 'required|max:100',
            'gift_recipient_id' => 'nullable|integer',
        ], ['gift_recipient_id' => 'Recipient']);

        $count = (int) Database::fetchColumn('SELECT COUNT(*) FROM wishlists WHERE user_id = :u', ['u' => $uid]);
        if ($count >= self::MAX_LISTS) {
            flash('error', 'You can have up to ' . self::MAX_LISTS . ' wishlists. Delete one to create another.');
            return $this->redirect('/account/wishlist');
        }
        $recipientId = null;
        if ($data['gift_recipient_id'] !== null && $data['gift_recipient_id'] !== '') {
            $recipientId = (int) $data['gift_recipient_id'];
            if (!Database::fetchColumn('SELECT 1 FROM gift_recipients WHERE id = :id AND user_id = :u', ['id' => $recipientId, 'u' => $uid])) {
                throw new HttpException(404);
            }
            $existing = Database::fetchColumn('SELECT id FROM wishlists WHERE user_id = :u AND gift_recipient_id = :r ORDER BY id LIMIT 1', ['u' => $uid, 'r' => $recipientId]);
            if ($existing) {
                flash('info', 'This recipient already has a list of saved ideas.');
                return $this->redirect('/account/wishlist?list=' . (int) $existing);
            }
        }
        $id = Database::insert('wishlists', ['user_id' => $uid, 'gift_recipient_id' => $recipientId, 'name' => $data['name']]);
        flash('success', 'Wishlist created.');
        return $this->redirect('/account/wishlist?list=' . $id);
    }

    /** POST /account/wishlists/{id}/delete — the default list cannot be deleted. */
    public function deleteList(Request $request, string $id): Response
    {
        $uid = $this->uid();
        $list = $this->wishlists->owned((int) $id, $uid);
        if (!$list) {
            throw new HttpException(404);
        }
        if ((int) $list['id'] === $this->wishlists->defaultId($uid)) {
            flash('error', 'Your main wishlist cannot be deleted.');
            return $this->redirect('/account/wishlist');
        }
        Database::delete('wishlists', ['id' => (int) $list['id'], 'user_id' => $uid]);
        flash('success', 'Wishlist deleted.');
        return $this->redirect('/account/wishlist');
    }

    /** POST /account/wishlist/items/{id}/remove */
    public function removeItem(Request $request, string $id): Response
    {
        $uid = $this->uid();
        $item = Database::fetch(
            'SELECT wi.id, wi.wishlist_id FROM wishlist_items wi JOIN wishlists w ON w.id = wi.wishlist_id
             WHERE wi.id = :id AND w.user_id = :u',
            ['id' => (int) $id, 'u' => $uid]
        );
        if (!$item) {
            throw new HttpException(404);
        }
        Database::delete('wishlist_items', ['id' => (int) $item['id']]);
        if ($request->wantsJson()) {
            return $this->json(['removed' => true]);
        }
        flash('success', 'Removed from your wishlist.');
        return $this->redirect('/account/wishlist?list=' . (int) $item['wishlist_id']);
    }

    /** POST /account/wishlist/move-to-cart/{productId} (body: wishlist_id) */
    public function moveToCart(Request $request, string $productId): Response
    {
        $uid = $this->uid();
        $pid = (int) $productId;
        $listId = $request->int('wishlist_id');
        $list = $listId > 0 ? $this->wishlists->owned($listId, $uid) : null;
        $listId = $list ? (int) $list['id'] : $this->wishlists->defaultId($uid);
        $redirect = '/account/wishlist?list=' . $listId;

        $inList = Database::fetchColumn(
            'SELECT wi.id FROM wishlist_items wi JOIN wishlists w ON w.id = wi.wishlist_id
             WHERE wi.wishlist_id = :w AND wi.product_id = :p AND w.user_id = :u',
            ['w' => $listId, 'p' => $pid, 'u' => $uid]
        );
        if (!$inList) {
            throw new HttpException(404);
        }
        try {
            (new CartService())->add($pid, 0, 1, null);
        } catch (RuntimeException $e) {
            $msg = $e->getMessage();
            if ($msg === 'Please choose an option first.') {
                $slug = Database::fetchColumn('SELECT slug FROM products WHERE id = :id', ['id' => $pid]);
                flash('info', 'This gift comes in several options. Choose one on the product page.');
                return $this->redirect($slug ? '/product/' . $slug : $redirect);
            }
            flash('error', $msg);
            return $this->redirect($redirect);
        }
        Database::delete('wishlist_items', ['id' => (int) $inList]);
        flash('success', 'Moved to your bag.');
        return $this->redirect($redirect);
    }

    private function uid(): int
    {
        $uid = Auth::customerId();
        if (!$uid) {
            throw new HttpException(403);
        }
        return $uid;
    }

    private function personalizationAllowed(int $uid): bool
    {
        $v = Database::fetchColumn('SELECT personalization_enabled FROM customer_profiles WHERE user_id = :u', ['u' => $uid]);
        return $v === null || (int) $v === 1;
    }
}
