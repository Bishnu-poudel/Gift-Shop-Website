<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Cache;
use App\Core\Database;
use App\Core\Request;
use App\Core\Response;

final class SeoController extends Controller
{
    public function sitemap(Request $request): Response
    {
        $xml = Cache::remember('catalog', 'sitemap', 3600, static function () {
            $urls = [[url('/'), null, '1.0'], [url('/shop'), null, '0.9'], [url('/gift-finder'), null, '0.9'],
                [url('/bestsellers'), null, '0.8'], [url('/new-arrivals'), null, '0.8'], [url('/personalized-gifts'), null, '0.8']];
            foreach (Database::fetchAll("SELECT slug, updated_at FROM products WHERE status = 'active'") as $p) {
                $urls[] = [url('/product/' . $p['slug']), $p['updated_at'], '0.7'];
            }
            foreach (Database::fetchAll('SELECT slug, updated_at FROM categories WHERE is_active = 1') as $c) {
                $urls[] = [url('/category/' . $c['slug']), $c['updated_at'], '0.6'];
            }
            foreach (['recipients' => 'for', 'occasions' => 'occasion', 'interests' => 'interest'] as $t => $seg) {
                foreach (Database::fetchCol("SELECT slug FROM `$t` WHERE is_active = 1") as $slug) {
                    $urls[] = [url('/gifts/' . $seg . '/' . $slug), null, '0.6'];
                }
            }
            foreach (Database::fetchCol('SELECT slug FROM makers') as $slug) {
                $urls[] = [url('/makers/' . $slug), null, '0.4'];
            }
            foreach (array_keys(PageController::PAGES) as $slug) {
                $urls[] = [url('/pages/' . $slug), null, '0.3'];
            }
            $out = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
            foreach ($urls as [$loc, $mod, $prio]) {
                $out .= '  <url><loc>' . htmlspecialchars($loc, ENT_XML1) . '</loc>'
                    . ($mod ? '<lastmod>' . substr((string) $mod, 0, 10) . '</lastmod>' : '')
                    . '<priority>' . $prio . '</priority></url>' . "\n";
            }
            return $out . '</urlset>';
        });
        return new Response($xml, 200, ['Content-Type' => 'application/xml; charset=UTF-8']);
    }

    public function robots(Request $request): Response
    {
        $admin = '/' . trim((string) config('app.admin_path'), '/');
        $prefix = base_path_prefix();
        $lines = ['User-agent: *'];
        if (config('app.env') !== 'production') {
            $lines[] = 'Disallow: /';
        } else {
            foreach ([$admin . '/', '/account', '/cart', '/checkout', '/order/', '/payment/', '/search', '/gift-finder/results', '/install'] as $p) {
                $lines[] = 'Disallow: ' . $prefix . $p;
            }
        }
        $lines[] = 'Sitemap: ' . url('/sitemap.xml');
        return new Response(implode("\n", $lines) . "\n", 200, ['Content-Type' => 'text/plain; charset=UTF-8']);
    }
}
