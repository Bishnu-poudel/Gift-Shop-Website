<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Services\AuthService;
use App\Services\CartService;

/** Customer authentication. Public registration can only ever create customer accounts. */
final class AuthController extends Controller
{
    public function loginForm(Request $request): Response
    {
        return $this->view('storefront/auth/login', ['title' => 'Sign in', 'noindex' => true]);
    }

    public function login(Request $request): Response
    {
        $data = $this->validate($request, ['email' => 'required|email', 'password' => 'required|max:128']);
        $user = Auth::attempt((string) $data['email'], (string) $data['password'], 'customer', $request->ip());
        if (!$user) {
            Session::flash('old', ['email' => $data['email']]);
            flash('error', 'That email and password combination did not match.');
            return $this->redirect('/login');
        }
        if ($user['status'] === 'pending' || $user['email_verified_at'] === null) {
            Session::put('verify_email_for', (int) $user['id']);
            flash('warning', 'Please verify your email address first. We can resend the link.');
            return $this->redirect('/verify-email');
        }
        Auth::login($user, 'customer');
        (new CartService())->mergeGuestCartInto((int) $user['id']);
        AuditLogger::log('customer.login', 'user', (int) $user['id'], null, null, (int) $user['id']);
        $intended = (string) Session::pull('intended', '');
        return $this->redirect($intended !== '' && str_starts_with($intended, rtrim((string) config('app.url'), '/')) ? $intended : '/account');
    }

    public function logout(Request $request): Response
    {
        Auth::logout('customer');
        flash('success', 'You have been signed out.');
        return $this->redirect('/');
    }

    public function registerForm(Request $request): Response
    {
        return $this->view('storefront/auth/register', ['title' => 'Create your account', 'noindex' => true]);
    }

    public function register(Request $request): Response
    {
        RateLimiter::enforce('register:' . $request->ip(), 10, 3600);
        // Honeypot field for basic bot protection.
        if ($request->str('website') !== '') {
            return $this->redirect('/verify-email');
        }
        $data = $this->validate($request, [
            'name' => 'required|min:2|max:120',
            'email' => 'required|email',
            'password' => AuthService::passwordRules(),
            'terms' => 'accepted',
        ], ['terms' => 'Terms and privacy policy']);
        $id = (new AuthService())->registerCustomer(strip_tags((string) $data['name']), (string) $data['email'], (string) $data['password'], $request->bool('marketing'));
        if ($id) {
            Session::put('verify_email_for', $id);
        }
        // Same response whether or not the email already existed (no account enumeration).
        flash('success', 'Almost there! We have sent a verification link to ' . $data['email'] . '. Open it to activate your account.');
        return $this->redirect('/verify-email');
    }

    public function verifyNotice(Request $request): Response
    {
        return $this->view('storefront/auth/verify', ['title' => 'Verify your email', 'noindex' => true, 'canResend' => (bool) Session::get('verify_email_for')]);
    }

    public function verify(Request $request, string $token): Response
    {
        $user = (new AuthService())->verifyEmail($token);
        if (!$user) {
            flash('error', 'This verification link is invalid or has expired. Sign in to request a new one.');
            return $this->redirect('/login');
        }
        Session::forget('verify_email_for');
        Auth::login($user, 'customer');
        (new CartService())->mergeGuestCartInto((int) $user['id']);
        flash('success', 'Your email is verified. Welcome to ' . setting('store_name', config('app.name')) . '!');
        return $this->redirect('/account');
    }

    public function resendVerification(Request $request): Response
    {
        $id = (int) Session::get('verify_email_for', 0);
        if ($id) {
            RateLimiter::enforce('verify-resend:' . $id, 3, 3600);
            (new AuthService())->sendVerification($id);
        }
        flash('success', 'If your account still needs verification, a new link is on its way.');
        return $this->redirect('/verify-email');
    }

    public function forgotForm(Request $request): Response
    {
        return $this->view('storefront/auth/forgot', ['title' => 'Reset your password', 'noindex' => true]);
    }

    public function forgot(Request $request): Response
    {
        RateLimiter::enforce('forgot:' . $request->ip(), 5, 900);
        $data = $this->validate($request, ['email' => 'required|email']);
        (new AuthService())->requestPasswordReset((string) $data['email'], 'customer');
        flash('success', 'If an account exists for that email, you will receive a reset link within a few minutes. The link is valid for 1 hour.');
        return $this->redirect('/forgot-password');
    }

    public function resetForm(Request $request, string $token): Response
    {
        $valid = (new AuthService())->consumeToken($token, 'reset', false) !== null;
        return $this->view('storefront/auth/reset', ['title' => 'Choose a new password', 'noindex' => true, 'token' => $token, 'valid' => $valid]);
    }

    public function reset(Request $request, string $token): Response
    {
        RateLimiter::enforce('reset:' . $request->ip(), 10, 900);
        $data = $this->validate($request, ['password' => AuthService::passwordRules()]);
        if (!(new AuthService())->resetPassword($token, (string) $data['password'], 'customer')) {
            flash('error', 'This reset link is invalid or has expired. Please request a new one.');
            return $this->redirect('/forgot-password');
        }
        flash('success', 'Your password has been changed. Please sign in.');
        return $this->redirect('/login');
    }
}
