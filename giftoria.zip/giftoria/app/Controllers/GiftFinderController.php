<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Paginator;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Repositories\TaxonomyRepository;
use App\Services\Recommendation\RecommendationEngine;
use App\Services\ShippingService;
use App\Services\WishlistService;

final class GiftFinderController extends Controller
{
    /** Icons for recipients in the wizard. */
    public const RECIPIENT_ICONS = [
        'baby-girl' => 'baby', 'baby-boy' => 'baby', 'child' => 'sparkles', 'teenager' => 'zap', 'mother' => 'heart',
        'father' => 'user', 'sister' => 'heart', 'brother' => 'user', 'wife' => 'heart', 'husband' => 'heart',
        'girlfriend' => 'heart', 'boyfriend' => 'heart', 'friend' => 'users', 'grandparent' => 'home', 'colleague' => 'card',
        'teacher' => 'file', 'couple' => 'users', 'pet-lover' => 'leaf', 'anyone-else' => 'gift',
    ];

    public const OCCASION_ICONS = [
        'birthday' => 'cake', 'baby-shower' => 'baby', 'birth-celebration' => 'baby', 'naming-ceremony' => 'pen', 'first-birthday' => 'cake',
        'anniversary' => 'heart', 'wedding' => 'heart', 'graduation' => 'star', 'festival' => 'sparkles', 'dashain' => 'star', 'tihar' => 'sparkles',
        'valentines-day' => 'heart', 'mothers-day' => 'heart', 'fathers-day' => 'user', 'thank-you' => 'hand', 'housewarming' => 'home',
        'corporate-gifting' => 'card', 'just-because' => 'gift',
    ];

    public function index(Request $request): Response
    {
        $tax = new TaxonomyRepository();
        return $this->view('storefront/gift-finder/index', [
            'title' => 'Gift Finder',
            'metaDescription' => 'Answer a few quick questions and get gift ideas matched to who they are, their age, interests, the occasion and your budget.',
            'recipients' => $tax->all('recipients'),
            'occasions' => $tax->all('occasions'),
            'interests' => $tax->all('interests'),
            'ages' => $tax->ageRanges(),
            'budgets' => $tax->budgets(),
            'prefs' => $tax->preferenceTags(),
            'districts' => config('nepal.provinces'),
            'prefill' => $request->query(),
        ]);
    }

    public function results(Request $request): Response
    {
        $engine = new RecommendationEngine();
        $criteria = $engine->normalize($request->query());
        $sort = in_array($request->query('sort'), ['relevance', 'price_asc', 'price_desc', 'popular', 'newest', 'rating'], true) ? (string) $request->query('sort') : 'relevance';
        $page = max(1, (int) $request->query('page', 1));
        $userId = Auth::customerId();
        $sessionKey = Session::visitorKey();

        $result = $engine->recommend($criteria, $sort, $page, 24, $userId, $sessionKey);
        if ($page === 1 && !$request->query('similar_to')) {
            $engine->logSession($result['criteria'], $result['total'], $userId, $sessionKey);
        }

        $tax = new TaxonomyRepository();
        return $this->view('storefront/gift-finder/results', [
            'title' => 'Your gift ideas',
            'noindex' => true,
            'result' => $result,
            'criteria' => $result['criteria'],
            'sort' => $sort,
            'paginator' => new Paginator($result['total'], 24, $page),
            'labels' => [
                'recipients' => $tax->keyed('recipients'),
                'occasions' => $tax->keyed('occasions'),
                'interests' => $tax->keyed('interests'),
            ],
            'ageRange' => $criteria['age'] ? $tax->ageRange($criteria['age']) : null,
            'prefs' => array_column($tax->preferenceTags(), 'name', 'slug'),
            'saved' => (new WishlistService())->savedProductIds($userId),
        ]);
    }

    public function feedback(Request $request): Response
    {
        RateLimiter::enforce('feedback:' . Session::visitorKey(), 120, 3600);
        $productId = $request->int('product_id');
        $action = $request->str('action');
        $criteria = $request->input('criteria');
        $context = is_array($criteria) ? array_intersect_key($criteria, array_flip(['recipient', 'occasion', 'interests', 'age'])) : [];
        $ok = (new RecommendationEngine())->recordFeedback($productId, $action, Auth::customerId(), Session::visitorKey(), $context);
        if (!$ok) {
            return $this->json(['message' => 'Could not record feedback.'], 422);
        }
        $response = ['ok' => true];
        if ($action === 'more_like_this') {
            $query = is_array($criteria) ? array_intersect_key($criteria, array_flip(['recipient', 'occasion', 'interests', 'age', 'budget', 'min_price', 'max_price', 'prefs'])) : [];
            $query = array_filter($query, static fn ($v) => $v !== null && $v !== '' && $v !== []);
            $query['similar_to'] = $productId;
            $response['redirect'] = url('/gift-finder/results', $query);
        }
        return $this->json($response);
    }

    public static function districtsValid(string $d): bool
    {
        return ShippingService::isValidDistrict($d);
    }
}
