<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Validator;
use App\Services\Analytics;
use App\Services\AuthService;
use App\Services\CartService;
use App\Services\OrderService;
use App\Services\PaymentService;
use App\Services\PricingService;
use App\Services\ShippingService;
use RuntimeException;

final class CheckoutController extends Controller
{
    public function index(Request $request): Response
    {
        $cartService = new CartService();
        $cart = $cartService->current();
        $lines = $cartService->lines();
        if (!$lines) {
            flash('info', 'Your bag is empty.');
            return $this->redirect('/cart');
        }
        (new OrderService())->expireStale(false, 20);
        $customer = Auth::customer();
        $addresses = $customer ? Database::fetchAll('SELECT * FROM addresses WHERE user_id = :u ORDER BY is_default DESC, id DESC', ['u' => (int) $customer['id']]) : [];
        $default = $addresses[0] ?? null;
        $district = (string) old('district', $default['district'] ?? '');
        $totals = (new PricingService())->calculate($lines, [
            'coupon_code' => $cart['coupon_code'] ?? null,
            'gift_wrap' => (bool) ($cart['gift_wrap'] ?? false),
            'district' => $district !== '' ? $district : null,
            'user_id' => $customer['id'] ?? null,
            'email' => $customer['email'] ?? null,
        ]);
        // One-time token makes a double-submitted checkout idempotent.
        $token = random_token();
        Session::put('checkout_token', $token);
        Analytics::increment('checkouts_started');

        return $this->view('storefront/checkout/index', [
            'title' => 'Checkout',
            'noindex' => true,
            'cart' => $cart,
            'totals' => $totals,
            'customer' => $customer,
            'addresses' => $addresses,
            'default' => $default,
            'provinces' => config('nepal.provinces'),
            'methods' => OrderService::availablePaymentMethods($totals['zone'], $totals['grand_total']),
            'allMethods' => ['esewa' => 'eSewa', 'khalti' => 'Khalti', 'cod' => 'Cash on delivery'],
            'checkoutToken' => $token,
            'giftWrapFee' => (float) setting('gift_wrap_fee', 150),
        ]);
    }

    /** AJAX: recalculates totals for a district / gift wrap choice (server-side, never trusts client totals). */
    public function quote(Request $request): Response
    {
        $cartService = new CartService();
        $cart = $cartService->current();
        $district = $request->str('district');
        $customer = Auth::customer();
        $t = (new PricingService())->calculate($cartService->lines(), [
            'coupon_code' => $cart['coupon_code'] ?? null,
            'gift_wrap' => $request->bool('gift_wrap'),
            'district' => ShippingService::isValidDistrict($district) ? $district : null,
            'user_id' => $customer['id'] ?? null,
            'email' => $customer['email'] ?? ($request->str('email') ?: null),
        ]);
        return $this->json([
            'subtotal' => money($t['subtotal']),
            'discount' => $t['discount'] > 0 ? '−' . money($t['discount']) : null,
            'shipping' => $t['shipping_known'] ? ($t['shipping'] > 0 ? money($t['shipping']) : 'Free') : 'Select district',
            'gift_wrap' => $t['gift_wrap'] > 0 ? money($t['gift_wrap']) : null,
            'total' => money($t['grand_total']),
            'vat' => $t['tax']['registered'] && $t['tax']['rate'] > 0 ? money($t['vat_amount']) : null,
            'taxable' => money($t['taxable_amount']),
            'estimate' => $t['delivery_estimate']['label'] ?? null,
            'methods' => array_keys(OrderService::availablePaymentMethods($t['zone'], $t['grand_total'])),
            'issues' => array_column($t['issues'], 'message'),
            'zone' => $t['zone']['name'] ?? null,
        ]);
    }

    public function place(Request $request): Response
    {
        RateLimiter::enforce('checkout:' . $request->ip(), 15, 600);
        $cartService = new CartService();
        $cart = $cartService->current();
        $lines = $cartService->lines();
        $customer = Auth::customer();

        $rules = [
            'customer_name' => 'required|max:120',
            'email' => 'required|email',
            'phone' => 'required|phone',
            'full_name' => 'required|max:120',
            'ship_phone' => 'required|phone',
            'province' => 'required|in:' . implode(',', array_keys(config('nepal.provinces'))),
            'district' => 'required|max:60',
            'municipality' => 'required|max:100',
            'ward' => 'nullable|integer|between:1,35',
            'street' => 'nullable|max:190',
            'landmark' => 'nullable|max:190',
            'payment_method' => 'required|in:esewa,khalti,cod',
            'gift_message' => 'nullable|max:300',
            'customer_note' => 'nullable|max:500',
            'requested_delivery_date' => 'nullable|date',
            'buyer_company' => 'nullable|max:150',
            'buyer_pan' => 'nullable|regex:/^\d{9}$/',
            'terms' => 'accepted',
        ];
        $billingSame = !$request->has('billing_different') || !$request->bool('billing_different');
        if (!$billingSame) {
            $rules += [
                'b_full_name' => 'required|max:120', 'b_phone' => 'required|phone', 'b_province' => 'required|in:' . implode(',', array_keys(config('nepal.provinces'))),
                'b_district' => 'required|max:60', 'b_municipality' => 'required|max:100', 'b_ward' => 'nullable|integer|between:1,35', 'b_street' => 'nullable|max:190',
            ];
        }
        $data = Validator::validate($request->all(), $rules, [
            'customer_name' => 'Your name', 'full_name' => 'Recipient name', 'ship_phone' => 'Recipient phone', 'terms' => 'Terms and conditions',
            'buyer_pan' => 'Buyer PAN/VAT number (9 digits)', 'buyer_company' => 'Company name',
        ]);
        $errors = [];
        if (ShippingService::provinceOf((string) $data['district']) !== $data['province']) {
            $errors['district'] = 'Please choose a district in ' . $data['province'] . '.';
        }
        if (!$billingSame && ShippingService::provinceOf((string) $data['b_district']) !== $data['b_province']) {
            $errors['b_district'] = 'Please choose a billing district in the selected province.';
        }
        if ($data['requested_delivery_date'] && $data['requested_delivery_date'] < local_today()) {
            $errors['requested_delivery_date'] = 'Delivery date cannot be in the past.';
        }
        if ($errors) {
            throw new \App\Core\ValidationException($errors, $request->all());
        }

        $token = (string) $request->str('checkout_token');
        if ($token === '' || !hash_equals((string) Session::get('checkout_token', ''), $token)) {
            // A reused token may belong to an order we already created (double submit): show it.
            $existing = $token !== '' ? Database::fetch('SELECT * FROM orders WHERE checkout_token = :t', ['t' => $token]) : null;
            if ($existing) {
                return $this->afterPlace($existing);
            }
            flash('error', 'Your checkout session expired. Please review your order and try again.');
            return $this->redirect('/checkout');
        }

        $address = [
            'full_name' => strip_tags((string) $data['full_name']), 'phone' => $data['ship_phone'], 'province' => $data['province'],
            'district' => $data['district'], 'municipality' => strip_tags((string) $data['municipality']), 'ward' => $data['ward'] ? (string) (int) $data['ward'] : null,
            'street' => strip_tags((string) ($data['street'] ?? '')), 'landmark' => strip_tags((string) ($data['landmark'] ?? '')),
        ];
        $billing = $billingSame ? null : [
            'full_name' => strip_tags((string) $data['b_full_name']), 'phone' => $data['b_phone'], 'province' => $data['b_province'],
            'district' => $data['b_district'], 'municipality' => strip_tags((string) $data['b_municipality']), 'ward' => $data['b_ward'] ? (string) (int) $data['b_ward'] : null,
            'street' => strip_tags((string) ($data['b_street'] ?? '')), 'landmark' => null,
        ];

        try {
            $order = (new OrderService())->place([
                'customer_name' => strip_tags((string) $data['customer_name']),
                'email' => $data['email'],
                'phone' => $data['phone'],
                'payment_method' => $data['payment_method'],
                'shipping' => $address,
                'billing' => $billing,
                'gift_wrap' => $request->bool('gift_wrap'),
                'gift_message' => strip_tags((string) ($data['gift_message'] ?? '')),
                'customer_note' => strip_tags((string) ($data['customer_note'] ?? '')) ?: null,
                'requested_delivery_date' => $data['requested_delivery_date'] ?: null,
                'buyer_pan' => $data['buyer_pan'] ?: null,
                'buyer_company' => strip_tags((string) ($data['buyer_company'] ?? '')) ?: null,
                'coupon_code' => $cart['coupon_code'] ?? null,
                'checkout_token' => $token,
                'user_id' => $customer['id'] ?? null,
                'source' => 'web',
            ], $lines);
        } catch (RuntimeException | \DomainException $e) {
            flash('error', $e->getMessage());
            Session::flash('old', $request->all());
            return $this->redirect('/checkout');
        }

        Session::forget('checkout_token');
        $cartService->clear($cart);
        if ($customer && $request->bool('save_address')) {
            $count = (int) Database::fetchColumn('SELECT COUNT(*) FROM addresses WHERE user_id = :u', ['u' => (int) $customer['id']]);
            if ($count < 10) {
                Database::insert('addresses', $address + ['user_id' => (int) $customer['id'], 'label' => 'Home', 'is_default' => $count === 0 ? 1 : 0]);
            }
        }
        // Guests can view their order page via a signed-in-session grant.
        $grants = (array) Session::get('order_grants', []);
        $grants[$order['order_number']] = $order['access_token'];
        Session::put('order_grants', array_slice($grants, -10, null, true));
        return $this->afterPlace($order);
    }

    private function afterPlace(array $order): Response
    {
        if ($order['payment_method'] === 'cod' || $order['status'] !== 'pending_payment') {
            return $this->redirect('/order/' . $order['order_number'] . '?t=' . $order['access_token']);
        }
        return $this->redirect('/checkout/pay/' . $order['order_number'] . '?t=' . $order['access_token']);
    }

    private function viewerOrder(Request $request, string $number): array
    {
        $token = (string) ($request->input('t') ?: (Session::get('order_grants', [])[$number] ?? ''));
        $order = (new OrderService())->findForViewer($number, Auth::customerId(), $token ?: null);
        if (!$order) {
            throw new HttpException(404);
        }
        return $order;
    }

    /** Payment page for an unpaid online order (also used for safe retries — never creates a new order). */
    public function pay(Request $request, string $number): Response
    {
        $order = $this->viewerOrder($request, $number);
        $orders = new OrderService();
        $payments = new PaymentService();
        if ($order['status'] === 'pending_payment' && $order['expires_at'] && $order['expires_at'] < gmdate('Y-m-d H:i:s')) {
            $orders->expireStale(true, 5);
            $order = $orders->find((int) $order['id']);
        }
        if (!$payments->canPay($order)) {
            return $this->redirect('/order/' . $order['order_number'] . '?t=' . $order['access_token']);
        }
        return $this->view('storefront/checkout/pay', [
            'title' => 'Complete payment',
            'noindex' => true,
            'order' => $order,
            'items' => $orders->items((int) $order['id']),
            'methods' => array_filter(['esewa' => config('payments.esewa.enabled'), 'khalti' => config('payments.khalti.enabled')]),
            'lastPayment' => Database::fetch('SELECT * FROM payments WHERE order_id = :o ORDER BY id DESC LIMIT 1', ['o' => (int) $order['id']]),
            'testMode' => config('payments.esewa.environment') !== 'production' || config('payments.khalti.environment') !== 'production',
            'simulator' => (bool) config('payments.simulator'),
        ]);
    }

    public function startPayment(Request $request, string $number): Response
    {
        $order = $this->viewerOrder($request, $number);
        RateLimiter::enforce('pay:' . $order['order_number'], 10, 3600);
        $gateway = $request->str('gateway') ?: $order['payment_method'];
        try {
            $next = (new PaymentService())->start($order, $gateway);
        } catch (RuntimeException $e) {
            flash('error', $e->getMessage());
            return $this->redirect('/checkout/pay/' . $order['order_number'] . '?t=' . $order['access_token']);
        }
        if ($next['type'] === 'redirect') {
            return Response::redirect($next['url']);
        }
        // eSewa: auto-submitting signed form (POST to the gateway).
        return $this->view('storefront/checkout/redirect-form', ['action' => $next['action'], 'fields' => $next['fields'], 'title' => 'Redirecting to eSewa…', 'noindex' => true], 'layouts/blank');
    }

    public function orderStatus(Request $request, string $number): Response
    {
        $order = $this->viewerOrder($request, $number);
        $orders = new OrderService();
        return $this->view('storefront/checkout/order', [
            'title' => 'Order ' . $order['order_number'],
            'noindex' => true,
            'order' => $order,
            'items' => $orders->items((int) $order['id']),
            'address' => $orders->address((int) $order['id']),
            'history' => Database::fetchAll("SELECT * FROM order_status_history WHERE order_id = :o AND field = 'status' ORDER BY id", ['o' => (int) $order['id']]),
            'shipment' => Database::fetch('SELECT * FROM shipments WHERE order_id = :o ORDER BY id DESC LIMIT 1', ['o' => (int) $order['id']]),
            'canPay' => (new PaymentService())->canPay($order),
            'isGuest' => !Auth::customerId(),
            'accountExists' => (bool) Database::fetchColumn("SELECT 1 FROM users WHERE email = :e AND type = 'customer'", ['e' => $order['email']]),
        ]);
    }

    /** Printable bill: a proforma before payment, the tax invoice afterwards. Owner or guest token only. */
    public function bill(Request $request, string $number): Response
    {
        $order = $this->viewerOrder($request, $number);
        $tq = ['t' => $order['access_token']];
        $html = \App\Services\BillService::render($order, Auth::customerId() ? 'customer' : 'guest', [
            'back_url' => url('/order/' . $order['order_number'], $tq),
            'pay_url' => (new PaymentService())->canPay($order) ? url('/checkout/pay/' . $order['order_number'], $tq) : null,
        ]);
        return Response::html($html);
    }

    /** Customer-triggered re-verification for pending payments. */
    public function recheck(Request $request, string $number): Response
    {
        $order = $this->viewerOrder($request, $number);
        RateLimiter::enforce('recheck:' . $order['order_number'], 10, 600);
        $paid = (new PaymentService())->reverifyOrder((int) $order['id']);
        flash($paid ? 'success' : 'info', $paid ? 'Payment confirmed. Thank you!' : 'We have not received confirmation from the payment provider yet.');
        return $this->redirect('/order/' . $order['order_number'] . '?t=' . $order['access_token']);
    }

    /** Guest checkout → optional account creation afterwards (same email as the order). */
    public function createAccount(Request $request, string $number): Response
    {
        $order = $this->viewerOrder($request, $number);
        if (Auth::customerId() || $order['user_id']) {
            return $this->redirect('/account');
        }
        $data = $this->validate($request, ['password' => AuthService::passwordRules()]);
        $userId = (new AuthService())->registerCustomer($order['customer_name'], $order['email'], (string) $data['password'], false);
        if ($userId) {
            Database::query('UPDATE orders SET user_id = :u WHERE email = :e AND user_id IS NULL', ['u' => $userId, 'e' => $order['email']]);
            flash('success', 'Account created. Please check your email to verify it, then sign in to track your orders.');
        } else {
            flash('info', 'If an account already exists for this email, we have sent sign-in instructions.');
        }
        return $this->redirect('/order/' . $order['order_number'] . '?t=' . $order['access_token']);
    }
}
