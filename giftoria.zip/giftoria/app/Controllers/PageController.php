<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Services\MailService;

final class PageController extends Controller
{
    public const PAGES = [
        'about' => 'Our story',
        'makers' => 'Our makers',
        'shipping' => 'Delivery information',
        'returns' => 'Returns & refunds',
        'faq' => 'Frequently asked questions',
        'privacy' => 'Privacy policy',
        'terms' => 'Terms & conditions',
        'corporate-gifting' => 'Corporate gifting',
    ];

    public function show(Request $request, string $slug): Response
    {
        if (!isset(self::PAGES[$slug])) {
            throw new HttpException(404);
        }
        $data = ['title' => self::PAGES[$slug], 'slug' => $slug];
        if ($slug === 'shipping') {
            $data['zones'] = \App\Services\ShippingService::zones();
        }
        if ($slug === 'makers') {
            $data['makers'] = Database::fetchAll('SELECT * FROM makers ORDER BY is_featured DESC, name');
        }
        return $this->view('storefront/pages/' . $slug, $data);
    }

    public function contact(Request $request): Response
    {
        $customer = Auth::customer();
        $orders = $customer ? Database::fetchAll('SELECT order_number FROM orders WHERE user_id = :u ORDER BY id DESC LIMIT 20', ['u' => (int) $customer['id']]) : [];
        return $this->view('storefront/pages/contact', ['title' => 'Contact us', 'customer' => $customer, 'orders' => $orders]);
    }

    /** Contact form creates a support ticket (visible to staff in Admin > Support tickets). */
    public function submitContact(Request $request): Response
    {
        RateLimiter::enforce('contact:' . $request->ip(), 5, 3600);
        if ($request->str('website') !== '') { // honeypot
            flash('success', 'Thanks — we will get back to you soon.');
            return $this->redirect('/contact');
        }
        $customer = Auth::customer();
        $data = $this->validate($request, [
            'name' => $customer ? 'nullable|max:120' : 'required|max:120',
            'email' => $customer ? 'nullable|email' : 'required|email',
            'subject' => 'required|max:190',
            'category' => 'required|in:general,order,delivery,payment,product,return,corporate',
            'order_number' => 'nullable|max:30',
            'message' => 'required|min:10|max:4000',
        ]);
        $orderId = null;
        if ($data['order_number']) {
            $orderId = Database::fetchColumn('SELECT id FROM orders WHERE order_number = :n AND email = :e', [
                'n' => strtoupper(trim((string) $data['order_number'])),
                'e' => mb_strtolower((string) ($customer['email'] ?? $data['email'])),
            ]) ?: null;
        }
        do {
            $number = 'TKT-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
        } while (Database::fetchColumn('SELECT 1 FROM support_tickets WHERE ticket_number = :n', ['n' => $number]));
        $email = mb_strtolower((string) ($customer['email'] ?? $data['email']));
        $name = (string) ($customer['name'] ?? strip_tags((string) $data['name']));
        $ticketId = Database::insert('support_tickets', [
            'ticket_number' => $number,
            'user_id' => $customer['id'] ?? null,
            'name' => $name,
            'email' => $email,
            'subject' => strip_tags((string) $data['subject']),
            'category' => $data['category'],
            'order_id' => $orderId,
            'priority' => in_array($data['category'], ['payment', 'order'], true) ? 'high' : 'normal',
        ]);
        Database::insert('ticket_messages', [
            'ticket_id' => $ticketId, 'user_id' => $customer['id'] ?? null, 'author_type' => 'customer',
            'body' => strip_tags((string) $data['message']),
        ]);
        (new MailService())->send($email, 'ticket_received', ['customer_name' => $name, 'ticket_number' => $number, 'subject' => strip_tags((string) $data['subject'])]);
        flash('success', 'Thanks, ' . $name . '! Your request ' . $number . ' has been received. We usually reply within one working day.');
        return $this->redirect('/contact');
    }
}
