<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Repositories\ProductRepository;
use App\Services\CartService;
use App\Services\PricingService;
use RuntimeException;

/** Every action recalculates totals on the server (PricingService). JSON for AJAX, redirects otherwise. */
final class CartController extends Controller
{
    private CartService $cart;

    public function __construct()
    {
        $this->cart = new CartService();
    }

    private function totals(): array
    {
        $cart = $this->cart->current();
        $customer = Auth::customer();
        return (new PricingService())->calculate($this->cart->lines(), [
            'coupon_code' => $cart['coupon_code'] ?? null,
            'gift_wrap' => (bool) ($cart['gift_wrap'] ?? false),
            'user_id' => $customer['id'] ?? null,
            'email' => $customer['email'] ?? null,
        ]);
    }

    private function respond(Request $request, string $message, bool $ok = true): Response
    {
        if ($request->wantsJson()) {
            $t = $this->totals();
            return $this->json([
                'ok' => $ok,
                'message' => $message,
                'count' => $this->cart->count(),
                'subtotal' => money($t['subtotal']),
                'discount' => money($t['discount']),
                'total' => money($t['grand_total']),
            ], $ok ? 200 : 422);
        }
        flash($ok ? 'success' : 'error', $message);
        return $this->redirect('/cart');
    }

    public function index(Request $request): Response
    {
        $cart = $this->cart->current();
        $totals = $this->totals();
        $saved = array_values(array_filter($this->cart->lines(null, true), static fn ($l) => (int) $l['saved_for_later'] === 1));
        $suggestions = [];
        if ($totals['lines']) {
            $first = (new ProductRepository())->find((int) $totals['lines'][0]['product_id']);
            if ($first) {
                $inCart = array_map(static fn ($l) => (int) $l['product_id'], $totals['lines']);
                $suggestions = array_values(array_filter((new ProductRepository())->related($first, 8), static fn ($p) => !in_array((int) $p['id'], $inCart, true)));
                $suggestions = array_slice($suggestions, 0, 4);
            }
        }
        return $this->view('storefront/cart/index', [
            'title' => 'Your bag',
            'noindex' => true,
            'cart' => $cart,
            'totals' => $totals,
            'savedItems' => $saved,
            'suggestions' => $suggestions,
            'giftWrapFee' => (float) setting('gift_wrap_fee', 150),
        ]);
    }

    public function summary(Request $request): Response
    {
        $t = $this->totals();
        return $this->json(['count' => $this->cart->count(), 'total' => money($t['grand_total'])]);
    }

    public function add(Request $request): Response
    {
        RateLimiter::enforce('cart:' . $request->ip(), 120, 300);
        try {
            $this->cart->add(
                $request->int('product_id'),
                $request->int('variant_id'),
                max(1, $request->int('quantity', 1)),
                $request->has('personalization') ? $request->str('personalization') : null
            );
        } catch (RuntimeException $e) {
            if (!$request->wantsJson()) {
                flash('error', $e->getMessage());
                return $this->back('/cart');
            }
            return $this->respond($request, $e->getMessage(), false);
        }
        return $this->respond($request, 'Added to your bag.');
    }

    public function update(Request $request): Response
    {
        try {
            $this->cart->update($request->int('item_id'), $request->int('quantity'));
        } catch (RuntimeException $e) {
            return $this->respond($request, $e->getMessage(), false);
        }
        return $this->respond($request, 'Bag updated.');
    }

    public function remove(Request $request): Response
    {
        $this->cart->remove($request->int('item_id'));
        return $this->respond($request, 'Item removed.');
    }

    public function saveForLater(Request $request): Response
    {
        $this->cart->saveForLater($request->int('item_id'), $request->bool('saved'));
        return $this->respond($request, $request->bool('saved') ? 'Saved for later.' : 'Moved back to your bag.');
    }

    public function coupon(Request $request): Response
    {
        if ($request->bool('remove')) {
            $this->cart->setCoupon(null);
            return $this->respond($request, 'Coupon removed.');
        }
        RateLimiter::enforce('coupon:' . $request->ip(), 20, 600);
        $code = strtoupper($request->str('code'));
        if ($code === '' || !preg_match('/^[A-Z0-9-]{3,40}$/', $code)) {
            return $this->respond($request, 'Please enter a valid coupon code.', false);
        }
        $this->cart->setCoupon($code);
        $t = $this->totals();
        if (!$t['coupon'] || !$t['coupon']['ok']) {
            $this->cart->setCoupon(null);
            return $this->respond($request, $t['coupon']['message'] ?? 'This coupon code is not valid.', false);
        }
        return $this->respond($request, 'Coupon applied: ' . $code);
    }

    public function giftOptions(Request $request): Response
    {
        $message = $request->str('gift_message');
        if (mb_strlen($message) > 300) {
            return $this->respond($request, 'Gift messages are limited to 300 characters.', false);
        }
        $this->cart->setGiftOptions($request->bool('gift_wrap'), $message);
        return $this->respond($request, 'Gift options saved.');
    }
}
