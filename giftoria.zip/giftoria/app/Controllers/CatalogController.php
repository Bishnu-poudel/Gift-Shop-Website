<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Repositories\ProductRepository;
use App\Repositories\TaxonomyRepository;
use App\Services\CampaignService;
use App\Services\SearchService;

/**
 * Listing pages. They all share the search/filter pipeline so filters are preserved in the URL
 * and shareable: /gifts/for/mother?max_price=2500&interest[]=jewelry&sort=price_asc
 */
final class CatalogController extends Controller
{
    private const PER_PAGE = 24;

    private function listing(Request $request, array $fixed, array $page): Response
    {
        $filters = array_merge($request->query(), $fixed);
        $current = max(1, (int) $request->query('page', 1));
        $result = (new SearchService())->search($filters, $current, self::PER_PAGE);
        $tax = new TaxonomyRepository();
        $paginator = new Paginator($result['total'], self::PER_PAGE, $current);

        $crumbs = $page['crumbs'] ?? [[$page['title'], null]];
        return $this->view('storefront/catalog/listing', $page + [
            'result' => $result,
            'paginator' => $paginator,
            'fixed' => $fixed,
            'facets' => [
                'categories' => array_values(array_filter($tax->categories(), static fn ($c) => $c['parent_id'] === null)),
                'recipients' => $tax->all('recipients'),
                'occasions' => $tax->all('occasions'),
                'interests' => $tax->all('interests'),
                'ages' => $tax->ageRanges(),
                'makers' => $tax->makers(),
                'budgets' => $tax->budgets(),
            ],
            'crumbs' => $crumbs,
            'canonical' => url($request->path) . ($current > 1 ? '?page=' . $current : ''),
            'noindex' => count(array_diff_key($request->query(), ['page' => 1])) > 0,
            'jsonLd' => [self::breadcrumbLd($crumbs)],
        ]);
    }

    public static function breadcrumbLd(array $crumbs): array
    {
        $items = [['@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => url('/')]];
        foreach ($crumbs as $i => [$label, $href]) {
            $items[] = ['@type' => 'ListItem', 'position' => $i + 2, 'name' => $label] + ($href ? ['item' => $href] : []);
        }
        return ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $items];
    }

    public function shop(Request $request): Response
    {
        return $this->listing($request, [], [
            'title' => 'Shop all gifts',
            'intro' => 'Every gift in the shop — filter by who it is for, the occasion, interests, age and budget.',
        ]);
    }

    public function category(Request $request, string $slug): Response
    {
        $cat = (new TaxonomyRepository())->category($slug);
        if (!$cat) {
            throw new HttpException(404);
        }
        $crumbs = [];
        if ($cat['parent_id']) {
            $parent = Database::fetch('SELECT name, slug FROM categories WHERE id = :id', ['id' => (int) $cat['parent_id']]);
            if ($parent) {
                $crumbs[] = [$parent['name'], url('/category/' . $parent['slug'])];
            }
        }
        $crumbs[] = [$cat['name'], null];
        return $this->listing($request, ['category' => $slug], [
            'title' => $cat['seo_title'] ?: $cat['name'],
            'heading' => $cat['name'],
            'intro' => $cat['description'],
            'metaDescription' => $cat['seo_description'] ?: $cat['description'],
            'crumbs' => $crumbs,
        ]);
    }

    private function taxonomyPage(Request $request, string $type, string $slug, string $filterKey, string $titleFmt): Response
    {
        $row = (new TaxonomyRepository())->findBySlug($type, $slug);
        if (!$row) {
            throw new HttpException(404);
        }
        $value = $filterKey === 'interest' ? [$slug] : $slug;
        $title = sprintf($titleFmt, $row['name']);
        return $this->listing($request, [$filterKey => $value], [
            'title' => $title,
            'intro' => $row['description'] ?: null,
            'metaDescription' => $title . ' — thoughtful, original ideas with delivery across Nepal.',
            'taxonomyType' => $type,
            'taxonomyRow' => $row,
        ]);
    }

    public function recipient(Request $request, string $slug): Response
    {
        return $this->taxonomyPage($request, 'recipients', $slug, 'recipient', 'Gifts for %s');
    }

    public function occasion(Request $request, string $slug): Response
    {
        return $this->taxonomyPage($request, 'occasions', $slug, 'occasion', '%s gifts');
    }

    public function interest(Request $request, string $slug): Response
    {
        return $this->taxonomyPage($request, 'interests', $slug, 'interest', 'Gifts for %s lovers');
    }

    public function bestsellers(Request $request): Response
    {
        $q = $request->query();
        $q['sort'] ??= 'popular';
        $request2 = new Request('GET', $request->path, $q, [], [], $_SERVER);
        Request::setCurrent($request2);
        return $this->listing($request2, [], ['title' => 'Bestsellers', 'intro' => 'The gifts our customers come back for, ranked by real orders.']);
    }

    public function newArrivals(Request $request): Response
    {
        $q = $request->query();
        $q['sort'] ??= 'newest';
        $request2 = new Request('GET', $request->path, $q, [], [], $_SERVER);
        Request::setCurrent($request2);
        return $this->listing($request2, [], ['title' => 'New arrivals', 'intro' => 'Fresh finds from our makers, newest first.']);
    }

    public function personalized(Request $request): Response
    {
        return $this->listing($request, ['personalized' => '1'], [
            'title' => 'Personalized gifts',
            'intro' => 'Names, dates and messages — engraved, embroidered or printed to make it theirs.',
        ]);
    }

    public function maker(Request $request, string $slug): Response
    {
        $maker = Database::fetch('SELECT * FROM makers WHERE slug = :s', ['s' => $slug]);
        if (!$maker) {
            throw new HttpException(404);
        }
        return $this->listing($request, ['maker' => $slug], [
            'title' => $maker['name'],
            'intro' => $maker['story'],
            'eyebrow' => 'Maker · ' . ($maker['location'] ?? ''),
            'crumbs' => [['Makers', null], [$maker['name'], null]],
        ]);
    }

    public function campaign(Request $request, string $slug): Response
    {
        $campaign = (new CampaignService())->findLiveBySlug($slug);
        if (!$campaign) {
            throw new HttpException(404);
        }
        $ids = array_filter(array_map('intval', explode(',', (string) $campaign['product_ids'])));
        $products = $ids ? (new ProductRepository())->cardsByIds($ids) : (new ProductRepository())->flagged('featured', 12);
        $coupon = $campaign['coupon_id'] ? Database::fetch('SELECT code, description FROM coupons WHERE id = :id AND is_active = 1', ['id' => (int) $campaign['coupon_id']]) : null;
        return $this->view('storefront/catalog/campaign', [
            'title' => $campaign['headline'] ?: $campaign['name'],
            'metaDescription' => $campaign['subheadline'],
            'campaign' => $campaign,
            'products' => $products,
            'coupon' => $coupon,
            'ogImage' => $campaign['image'] ? image_url($campaign['image']) : null,
        ]);
    }
}
