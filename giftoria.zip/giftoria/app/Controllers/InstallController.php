<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\HttpException;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Services\Installer;

/**
 * One-time web installer. Requires INSTALL_TOKEN from .env and refuses to run once a Super Admin
 * exists or storage/installed.lock is present. The CLI (php bin/console.php install) is preferred.
 */
final class InstallController extends Controller
{
    private function guard(): void
    {
        if (Installer::isInstalled()) {
            throw new HttpException(404);
        }
        $token = (string) config('app.install_token');
        if (strlen($token) < 16 || $token === 'change-me-to-a-long-random-string') {
            throw new HttpException(403, 'Set a long random INSTALL_TOKEN in .env to use the web installer, or run: php bin/console.php install');
        }
    }

    public function form(Request $request): Response
    {
        $this->guard();
        return $this->view('install/form', ['title' => 'Install'], 'layouts/minimal');
    }

    public function install(Request $request): Response
    {
        $this->guard();
        try {
            RateLimiter::enforce('install:' . $request->ip(), 10, 3600);
        } catch (\PDOException) {
            // tables may not exist yet
        }
        if (!hash_equals((string) config('app.install_token'), $request->str('install_token'))) {
            flash('error', 'The install token does not match INSTALL_TOKEN in .env.');
            return $this->redirect('/install');
        }
        $data = $this->validate($request, [
            'name' => 'required|max:120',
            'email' => 'required|email',
            'password' => 'required|min:12|max:128|confirmed',
        ]);
        try {
            Installer::ensureDatabase();
            Installer::migrate();
            Installer::seedBase();
            if ($request->bool('demo')) {
                Installer::seedDemo(false);
            }
            Installer::createFirstAdmin((string) $data['name'], (string) $data['email'], (string) $data['password']);
        } catch (\Throwable $e) {
            flash('error', 'Installation failed: ' . $e->getMessage());
            return $this->redirect('/install');
        }
        flash('success', 'Giftoria is installed. Sign in with your new administrator account. The installer is now disabled.');
        return Response::redirect(admin_url('login'));
    }
}
