<?php
declare(strict_types=1);

namespace App\Controllers\Account;

use App\Controllers\Controller;
use App\Core\Auth;
use App\Core\Cache;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;
use App\Repositories\ProductRepository;

/** Product reviews written by signed-in customers (one per product). */
final class ReviewController extends Controller
{
    /** POST /product/{slug}/review */
    public function store(Request $request, string $slug): Response
    {
        $uid = Auth::customerId();
        if (!$uid) {
            throw new HttpException(403);
        }
        $product = Database::fetch("SELECT id, slug FROM products WHERE slug = :s AND status = 'active'", ['s' => $slug]);
        if (!$product) {
            throw new HttpException(404);
        }
        $pid = (int) $product['id'];
        $back = '/product/' . $product['slug'] . '#reviews';

        $data = Validator::validate([
            'rating' => $request->str('rating'),
            'title' => trim(strip_tags($request->str('title'))),
            'body' => trim(strip_tags($request->str('body'))),
        ], [
            'rating' => 'required|integer|between:1,5',
            'title' => 'nullable|max:150',
            'body' => 'required|min:10|max:2000',
        ], ['body' => 'Review']);

        if (Database::fetchColumn('SELECT 1 FROM reviews WHERE user_id = :u AND product_id = :p', ['u' => $uid, 'p' => $pid])) {
            flash('info', 'You have already reviewed this gift. Thank you!');
            return $this->redirect($back);
        }
        RateLimiter::enforce('review:' . $uid, 10, 3600);

        $orderId = Database::fetchColumn(
            "SELECT o.id FROM orders o JOIN order_items oi ON oi.order_id = o.id
             WHERE o.user_id = :u AND oi.product_id = :p AND o.status = 'delivered'
             ORDER BY o.delivered_at DESC, o.id DESC LIMIT 1",
            ['u' => $uid, 'p' => $pid]
        );
        $verified = (bool) $orderId;
        $approved = $verified && (bool) setting('review_auto_approve_verified', false);

        try {
            Database::insert('reviews', [
                'product_id' => $pid,
                'user_id' => $uid,
                'order_id' => $orderId ? (int) $orderId : null,
                'rating' => (int) $data['rating'],
                'title' => $data['title'] !== '' ? $data['title'] : null,
                'body' => $data['body'],
                'is_verified' => $verified ? 1 : 0,
                'status' => $approved ? 'approved' : 'pending',
            ]);
        } catch (\PDOException $e) {
            if ((string) $e->getCode() === '23000') { // unique (user_id, product_id) — double submit
                flash('info', 'You have already reviewed this gift. Thank you!');
                return $this->redirect($back);
            }
            throw $e;
        }

        if ($approved) {
            (new ProductRepository())->recordRatingSummary($pid);
            Cache::bump('catalog');
            flash('success', 'Thanks for your review — it is now live.');
        } else {
            flash('success', 'Thanks for your review! It will appear once our team has checked it.');
        }
        return $this->redirect($back);
    }
}
