<?php
declare(strict_types=1);

namespace App\Controllers\Account;

use App\Controllers\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;
use App\Core\Validator;
use App\Repositories\TaxonomyRepository;
use App\Services\ReminderService;

/**
 * Gift Center: saved gift recipients (only what is needed to suggest gifts), their saved-idea lists,
 * and occasion reminders (emails are opt-in via notify_gift_reminders).
 */
final class GiftCenterController extends Controller
{
    private const MAX_RECIPIENTS = 50;
    private const MAX_REMINDERS = 100;
    public const RELATIONSHIPS = ['Partner', 'Spouse', 'Mother', 'Father', 'Sister', 'Brother', 'Daughter', 'Son', 'Grandparent', 'Friend', 'Colleague', 'Teacher', 'Other'];

    private TaxonomyRepository $tax;

    public function __construct()
    {
        $this->tax = new TaxonomyRepository();
    }

    /** GET /account/gift-center */
    public function index(Request $request): Response
    {
        $uid = $this->uid();
        $recipients = Database::fetchAll(
            'SELECT gr.*, (SELECT w.id FROM wishlists w WHERE w.user_id = gr.user_id AND w.gift_recipient_id = gr.id ORDER BY w.id LIMIT 1) AS wishlist_id,
                    (SELECT COUNT(*) FROM wishlist_items wi JOIN wishlists w2 ON w2.id = wi.wishlist_id
                      WHERE w2.user_id = gr.user_id AND w2.gift_recipient_id = gr.id) AS idea_count
             FROM gift_recipients gr WHERE gr.user_id = :u ORDER BY gr.name, gr.id',
            ['u' => $uid]
        );
        foreach ($recipients as &$r) {
            $r['finder_url'] = ReminderService::finderUrl($r);
        }
        unset($r);
        $reminders = Database::fetchAll(
            'SELECT gm.*, gr.name AS recipient_name FROM gift_reminders gm
             LEFT JOIN gift_recipients gr ON gr.id = gm.gift_recipient_id AND gr.user_id = gm.user_id
             WHERE gm.user_id = :u ORDER BY gm.is_active DESC, gm.event_date, gm.id',
            ['u' => $uid]
        );
        foreach ($reminders as &$rem) {
            $rem['next_date'] = ReminderService::nextOccurrence((string) $rem['event_date'], (bool) $rem['recurring_yearly']);
        }
        unset($rem);
        $profile = AccountController::profileFor($uid);

        return $this->view('account/gift-center/index', [
            'title' => 'Gift Center',
            'noindex' => true,
            'recipients' => $recipients,
            'reminders' => $reminders,
            'upcoming' => (new ReminderService())->upcoming($uid, 60),
            'remindersEnabled' => (int) ($profile['notify_gift_reminders'] ?? 1) === 1,
            'labels' => $this->labels(),
            'occasions' => $this->tax->all('occasions'),
            'canAddRecipient' => count($recipients) < self::MAX_RECIPIENTS,
        ]);
    }

    /** GET /account/gift-center/recipients — new recipient form */
    public function createRecipient(Request $request): Response
    {
        $this->uid();
        return $this->view('account/gift-center/recipient-form', $this->formData(null) + ['title' => 'Add a gift recipient']);
    }

    /** POST /account/gift-center/recipients */
    public function storeRecipient(Request $request): Response
    {
        $uid = $this->uid();
        if ((int) Database::fetchColumn('SELECT COUNT(*) FROM gift_recipients WHERE user_id = :u', ['u' => $uid]) >= self::MAX_RECIPIENTS) {
            flash('error', 'You can save up to ' . self::MAX_RECIPIENTS . ' recipients.');
            return $this->redirect('/account/gift-center');
        }
        $data = $this->validatedRecipient($request);
        Database::insert('gift_recipients', $data + ['user_id' => $uid]);
        flash('success', $data['name'] . ' has been added to your Gift Center.');
        return $this->redirect('/account/gift-center');
    }

    /** GET /account/gift-center/recipients/{id}/edit */
    public function editRecipient(Request $request, string $id): Response
    {
        $uid = $this->uid();
        $recipient = $this->ownedRecipient((int) $id, $uid);
        return $this->view('account/gift-center/recipient-form', $this->formData($recipient) + ['title' => 'Edit ' . $recipient['name']]);
    }

    /** POST /account/gift-center/recipients/{id} */
    public function updateRecipient(Request $request, string $id): Response
    {
        $uid = $this->uid();
        $recipient = $this->ownedRecipient((int) $id, $uid);
        $data = $this->validatedRecipient($request);
        Database::update('gift_recipients', $data, ['id' => (int) $recipient['id'], 'user_id' => $uid]);
        // Keep the recipient's saved-ideas list name in sync.
        Database::query(
            "UPDATE wishlists SET name = :n WHERE user_id = :u AND gift_recipient_id = :r",
            ['n' => mb_substr('Ideas for ' . $data['name'], 0, 100), 'u' => $uid, 'r' => (int) $recipient['id']]
        );
        flash('success', 'Recipient updated.');
        return $this->redirect('/account/gift-center');
    }

    /** POST /account/gift-center/recipients/{id}/delete — also removes their reminders and saved ideas (FK cascade). */
    public function deleteRecipient(Request $request, string $id): Response
    {
        $uid = $this->uid();
        $recipient = $this->ownedRecipient((int) $id, $uid);
        Database::delete('gift_recipients', ['id' => (int) $recipient['id'], 'user_id' => $uid]);
        flash('success', $recipient['name'] . ' and their reminders have been removed.');
        return $this->redirect('/account/gift-center');
    }

    /** GET /account/gift-center/recipients/{id}/ideas — opens (creating on demand) the recipient's wishlist. */
    public function recipientIdeas(Request $request, string $id): Response
    {
        $uid = $this->uid();
        $recipient = $this->ownedRecipient((int) $id, $uid);
        $listId = Database::fetchColumn(
            'SELECT id FROM wishlists WHERE user_id = :u AND gift_recipient_id = :r ORDER BY id LIMIT 1',
            ['u' => $uid, 'r' => (int) $recipient['id']]
        );
        if (!$listId) {
            $listId = Database::insert('wishlists', [
                'user_id' => $uid,
                'gift_recipient_id' => (int) $recipient['id'],
                'name' => mb_substr('Ideas for ' . $recipient['name'], 0, 100),
            ]);
        }
        return $this->redirect('/account/wishlist?list=' . (int) $listId);
    }

    /** POST /account/gift-center/reminders */
    public function storeReminder(Request $request): Response
    {
        $uid = $this->uid();
        $occasionSlugs = array_column($this->tax->all('occasions'), 'slug');
        $in = [
            'title' => trim(strip_tags($request->str('title'))),
            'gift_recipient_id' => $request->str('gift_recipient_id'),
            'occasion_slug' => $request->str('occasion_slug'),
            'event_date' => $request->str('event_date'),
            'remind_days_before' => $request->str('remind_days_before', '7'),
        ];
        $data = Validator::validate($in, [
            'title' => 'required|max:120',
            'gift_recipient_id' => 'nullable|integer',
            'occasion_slug' => 'nullable|in:' . implode(',', $occasionSlugs),
            'event_date' => 'required|date',
            'remind_days_before' => 'required|integer|between:1,30',
        ], ['gift_recipient_id' => 'Recipient', 'occasion_slug' => 'Occasion', 'remind_days_before' => 'Reminder days']);
        $recurring = $request->bool('recurring_yearly');
        if (!$recurring && $data['event_date'] < local_today()) {
            throw new ValidationException(['event_date' => 'Choose a future date, or make the reminder repeat every year.'], $in);
        }
        $recipientId = null;
        if ($data['gift_recipient_id'] !== '' && $data['gift_recipient_id'] !== null) {
            $recipientId = (int) $this->ownedRecipient((int) $data['gift_recipient_id'], $uid)['id'];
        }
        if ((int) Database::fetchColumn('SELECT COUNT(*) FROM gift_reminders WHERE user_id = :u', ['u' => $uid]) >= self::MAX_REMINDERS) {
            flash('error', 'You can have up to ' . self::MAX_REMINDERS . ' reminders.');
            return $this->redirect('/account/gift-center');
        }
        Database::insert('gift_reminders', [
            'user_id' => $uid,
            'gift_recipient_id' => $recipientId,
            'title' => $data['title'],
            'occasion_slug' => $data['occasion_slug'] !== '' ? $data['occasion_slug'] : null,
            'event_date' => $data['event_date'],
            'recurring_yearly' => $recurring ? 1 : 0,
            'remind_days_before' => (int) $data['remind_days_before'],
            'is_active' => 1,
        ]);
        $profile = AccountController::profileFor($uid);
        if ((int) ($profile['notify_gift_reminders'] ?? 1) !== 1) {
            flash('warning', 'Reminder saved, but reminder emails are turned off in your notification settings.');
        } else {
            flash('success', 'Reminder saved. We will email you ' . (int) $data['remind_days_before'] . ' day' . ((int) $data['remind_days_before'] === 1 ? '' : 's') . ' before.');
        }
        return $this->redirect('/account/gift-center#reminders');
    }

    /** POST /account/gift-center/reminders/{id}/delete */
    public function deleteReminder(Request $request, string $id): Response
    {
        $uid = $this->uid();
        $rem = $this->ownedReminder((int) $id, $uid);
        Database::delete('gift_reminders', ['id' => (int) $rem['id'], 'user_id' => $uid]);
        flash('success', 'Reminder deleted.');
        return $this->redirect('/account/gift-center#reminders');
    }

    /** POST /account/gift-center/reminders/{id}/toggle */
    public function toggleReminder(Request $request, string $id): Response
    {
        $uid = $this->uid();
        $rem = $this->ownedReminder((int) $id, $uid);
        $active = (int) $rem['is_active'] === 1 ? 0 : 1;
        Database::update('gift_reminders', ['is_active' => $active], ['id' => (int) $rem['id'], 'user_id' => $uid]);
        flash('success', $active ? 'Reminder turned on.' : 'Reminder paused.');
        return $this->redirect('/account/gift-center#reminders');
    }

    /** Validated gift_recipients columns. Only gift-relevant data is collected. */
    private function validatedRecipient(Request $request): array
    {
        $recipientSlugs = array_column($this->tax->all('recipients'), 'slug');
        $ageSlugs = array_column($this->tax->ageRanges(), 'slug');
        $interestSlugs = array_column($this->tax->all('interests'), 'slug');
        $prefSlugs = array_column($this->tax->preferenceTags(), 'slug');

        $in = [
            'name' => trim(strip_tags($request->str('name'))),
            'relationship' => trim(strip_tags($request->str('relationship'))),
            'recipient_slug' => $request->str('recipient_slug'),
            'birthday' => $request->str('birthday'),
            'age_range_slug' => $request->str('age_range_slug'),
            'interests' => array_values(array_unique(array_filter(array_map('strval', array_filter($request->arr('interests'), 'is_scalar'))))),
            'preferences' => array_values(array_unique(array_filter(array_map('strval', array_filter($request->arr('preferences'), 'is_scalar'))))),
            'notes' => trim(strip_tags($request->str('notes'))),
        ];
        $data = Validator::validate($in, [
            'name' => 'required|max:80',
            'relationship' => 'nullable|max:60',
            'recipient_slug' => 'nullable|in:' . implode(',', $recipientSlugs),
            'birthday' => 'nullable|date',
            'age_range_slug' => 'nullable|in:' . implode(',', $ageSlugs),
            'interests' => 'array|max:15|in:' . implode(',', $interestSlugs),
            'preferences' => 'array|max:10|in:' . implode(',', $prefSlugs),
            'notes' => 'nullable|max:1000',
        ], ['recipient_slug' => 'Recipient type', 'age_range_slug' => 'Age range', 'interests' => 'interests', 'preferences' => 'preferences']);

        if ($data['birthday'] && ($data['birthday'] > local_today() || $data['birthday'] < '1900-01-01')) {
            throw new ValidationException(['birthday' => 'Please enter a valid birthday.'], $in);
        }
        $interests = implode(',', (array) $data['interests']);
        $prefs = implode(',', (array) $data['preferences']);
        if (strlen($interests) > 500 || strlen($prefs) > 500) {
            throw new ValidationException(['interests' => 'Please choose fewer interests.'], $in);
        }
        return [
            'name' => $data['name'],
            'relationship' => $data['relationship'] !== '' ? $data['relationship'] : null,
            'recipient_slug' => $data['recipient_slug'] !== '' ? $data['recipient_slug'] : null,
            'birthday' => $data['birthday'] !== '' ? $data['birthday'] : null,
            'age_range_slug' => $data['age_range_slug'] !== '' ? $data['age_range_slug'] : null,
            'interests' => $interests !== '' ? $interests : null,
            'preferences' => $prefs !== '' ? $prefs : null,
            'notes' => $data['notes'] !== '' ? $data['notes'] : null,
        ];
    }

    private function formData(?array $recipient): array
    {
        return [
            'noindex' => true,
            'recipient' => $recipient,
            'recipientTypes' => $this->tax->all('recipients'),
            'ageRanges' => $this->tax->ageRanges(),
            'interests' => $this->tax->all('interests'),
            'prefTags' => $this->tax->preferenceTags(),
            'relationships' => self::RELATIONSHIPS,
        ];
    }

    /** slug → display name maps for cards. */
    private function labels(): array
    {
        $out = ['recipients' => [], 'interests' => [], 'ages' => [], 'prefs' => [], 'occasions' => []];
        foreach ($this->tax->all('recipients') as $r) {
            $out['recipients'][$r['slug']] = $r['name'];
        }
        foreach ($this->tax->all('interests') as $r) {
            $out['interests'][$r['slug']] = $r['name'];
        }
        foreach ($this->tax->all('occasions') as $r) {
            $out['occasions'][$r['slug']] = $r['name'];
        }
        foreach ($this->tax->ageRanges() as $r) {
            $out['ages'][$r['slug']] = $r['label'];
        }
        foreach ($this->tax->preferenceTags() as $r) {
            $out['prefs'][$r['slug']] = $r['name'];
        }
        return $out;
    }

    private function ownedRecipient(int $id, int $uid): array
    {
        $r = Database::fetch('SELECT * FROM gift_recipients WHERE id = :id AND user_id = :u', ['id' => $id, 'u' => $uid]);
        if (!$r) {
            throw new HttpException(404);
        }
        return $r;
    }

    private function ownedReminder(int $id, int $uid): array
    {
        $r = Database::fetch('SELECT * FROM gift_reminders WHERE id = :id AND user_id = :u', ['id' => $id, 'u' => $uid]);
        if (!$r) {
            throw new HttpException(404);
        }
        return $r;
    }

    private function uid(): int
    {
        $uid = Auth::customerId();
        if (!$uid) {
            throw new HttpException(403);
        }
        return $uid;
    }
}
