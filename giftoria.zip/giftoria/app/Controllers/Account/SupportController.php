<?php
declare(strict_types=1);

namespace App\Controllers\Account;

use App\Controllers\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Logger;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;
use App\Services\MailService;

/** Customer support tickets: list, open, view thread (no internal notes), reply. */
final class SupportController extends Controller
{
    public const CATEGORIES = [
        'general' => 'General question',
        'order' => 'An order',
        'delivery' => 'Delivery',
        'payment' => 'Payment',
        'product' => 'A product',
        'return' => 'Return or refund',
    ];

    public const STATUS_LABELS = ['open' => 'Open', 'pending' => 'Awaiting your reply', 'resolved' => 'Resolved', 'closed' => 'Closed'];

    /** GET /account/support */
    public function index(Request $request): Response
    {
        $uid = $this->uid();
        $tickets = Database::fetchAll(
            'SELECT t.*, o.order_number,
                    (SELECT COUNT(*) FROM ticket_messages m WHERE m.ticket_id = t.id AND m.is_internal = 0) AS message_count,
                    (SELECT m2.author_type FROM ticket_messages m2 WHERE m2.ticket_id = t.id AND m2.is_internal = 0 ORDER BY m2.id DESC LIMIT 1) AS last_author
             FROM support_tickets t LEFT JOIN orders o ON o.id = t.order_id AND o.user_id = t.user_id
             WHERE t.user_id = :u ORDER BY t.updated_at DESC, t.id DESC LIMIT 100',
            ['u' => $uid]
        );
        return $this->view('account/support/index', [
            'title' => 'Support',
            'noindex' => true,
            'tickets' => $tickets,
            'categories' => self::CATEGORIES + ['account_deletion' => 'Account deletion'],
        ]);
    }

    /** GET /account/support/new[?order=GFT-...] */
    public function create(Request $request): Response
    {
        $uid = $this->uid();
        return $this->view('account/support/create', [
            'title' => 'Contact support',
            'noindex' => true,
            'categories' => self::CATEGORIES,
            'orders' => $this->myOrders($uid),
            'preselectOrder' => (string) $request->query('order', ''),
        ]);
    }

    /** POST /account/support/new */
    public function store(Request $request): Response
    {
        $user = Auth::customer();
        if (!$user) {
            throw new HttpException(403);
        }
        $uid = (int) $user['id'];
        $data = Validator::validate([
            'subject' => trim(strip_tags($request->str('subject'))),
            'category' => $request->str('category'),
            'order_id' => $request->str('order_id'),
            'message' => trim(strip_tags($request->str('message'))),
        ], [
            'subject' => 'required|min:4|max:190',
            'category' => 'required|in:' . implode(',', array_keys(self::CATEGORIES)),
            'order_id' => 'nullable|integer',
            'message' => 'required|min:10|max:5000',
        ], ['order_id' => 'Order']);

        $orderId = null;
        if ($data['order_id'] !== null && $data['order_id'] !== '') {
            $orderId = (int) Database::fetchColumn('SELECT id FROM orders WHERE id = :id AND user_id = :u', ['id' => (int) $data['order_id'], 'u' => $uid]);
            if (!$orderId) {
                throw new HttpException(404);
            }
        }
        RateLimiter::enforce('ticket:' . $uid, 5, 3600);

        $ticket = self::openTicket($user, $data['subject'], $data['category'], $orderId, $data['message']);
        try {
            (new MailService())->send((string) $user['email'], 'support_ticket_received', [
                'customer_name' => (string) $user['name'],
                'ticket_number' => $ticket['ticket_number'],
                'ticket_subject' => $ticket['subject'],
                'ticket_url' => url('/account/support/' . $ticket['ticket_number']),
            ]);
        } catch (\Throwable $e) {
            Logger::warning('Ticket confirmation email failed', ['error' => $e->getMessage()]);
        }
        flash('success', 'Thanks — your request ' . $ticket['ticket_number'] . ' has been sent. We usually reply within one working day.');
        return $this->redirect('/account/support/' . $ticket['ticket_number']);
    }

    /** GET /account/support/{number} */
    public function show(Request $request, string $number): Response
    {
        $uid = $this->uid();
        $ticket = $this->ownedTicket($number, $uid);
        $messages = Database::fetchAll(
            'SELECT id, author_type, body, created_at FROM ticket_messages
             WHERE ticket_id = :t AND is_internal = 0 ORDER BY created_at, id',
            ['t' => (int) $ticket['id']]
        );
        return $this->view('account/support/show', [
            'title' => 'Ticket ' . $ticket['ticket_number'],
            'noindex' => true,
            'ticket' => $ticket,
            'messages' => $messages,
            'categories' => self::CATEGORIES + ['account_deletion' => 'Account deletion'],
        ]);
    }

    /** POST /account/support/{number}/reply — reopens resolved/pending tickets; closed tickets need a new request. */
    public function reply(Request $request, string $number): Response
    {
        $uid = $this->uid();
        $ticket = $this->ownedTicket($number, $uid);
        $data = Validator::validate(['message' => trim(strip_tags($request->str('message')))], ['message' => 'required|min:2|max:5000']);
        if ($ticket['status'] === 'closed') {
            flash('error', 'This ticket is closed. Please open a new request and mention ' . $ticket['ticket_number'] . '.');
            return $this->redirect('/account/support/' . $ticket['ticket_number']);
        }
        RateLimiter::enforce('ticket-reply:' . $uid, 30, 3600);
        Database::transaction(function () use ($ticket, $uid, $data) {
            Database::insert('ticket_messages', [
                'ticket_id' => (int) $ticket['id'], 'user_id' => $uid, 'author_type' => 'customer',
                'body' => $data['message'], 'is_internal' => 0,
            ]);
            // Customer replies always move the ticket back to staff (open); updated_at changes either way.
            Database::query("UPDATE support_tickets SET status = 'open', updated_at = UTC_TIMESTAMP() WHERE id = :id AND user_id = :u",
                ['id' => (int) $ticket['id'], 'u' => $uid]);
        });
        flash('success', $ticket['status'] === 'resolved' ? 'Reply sent — we have reopened your ticket.' : 'Reply sent.');
        return $this->redirect('/account/support/' . $ticket['ticket_number']);
    }

    /**
     * Creates a ticket with its first customer message. Used by the support form and account deletion requests.
     * @param array $user users row (id, name, email)
     */
    public static function openTicket(array $user, string $subject, string $category, ?int $orderId, string $message, string $priority = 'normal'): array
    {
        return Database::transaction(function () use ($user, $subject, $category, $orderId, $message, $priority) {
            $number = self::generateNumber();
            $id = Database::insert('support_tickets', [
                'ticket_number' => $number,
                'user_id' => (int) $user['id'],
                'name' => mb_substr((string) $user['name'], 0, 120),
                'email' => (string) $user['email'],
                'subject' => mb_substr($subject, 0, 190),
                'category' => mb_substr($category, 0, 40),
                'order_id' => $orderId,
                'status' => 'open',
                'priority' => $priority,
            ]);
            Database::insert('ticket_messages', [
                'ticket_id' => $id, 'user_id' => (int) $user['id'], 'author_type' => 'customer',
                'body' => $message, 'is_internal' => 0,
            ]);
            return Database::fetch('SELECT * FROM support_tickets WHERE id = :id', ['id' => $id]);
        });
    }

    /** TKT-XXXXXX (uppercase letters/digits without look-alikes), unique. */
    public static function generateNumber(): string
    {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        do {
            $s = '';
            for ($i = 0; $i < 6; $i++) {
                $s .= $alphabet[random_int(0, strlen($alphabet) - 1)];
            }
            $n = 'TKT-' . $s;
        } while (Database::fetchColumn('SELECT 1 FROM support_tickets WHERE ticket_number = :n', ['n' => $n]));
        return $n;
    }

    private function ownedTicket(string $number, int $uid): array
    {
        if (!preg_match('/^TKT-[A-Z0-9]{6}$/', $number)) {
            throw new HttpException(404);
        }
        $t = Database::fetch(
            'SELECT t.*, o.order_number FROM support_tickets t LEFT JOIN orders o ON o.id = t.order_id AND o.user_id = t.user_id
             WHERE t.ticket_number = :n AND t.user_id = :u',
            ['n' => $number, 'u' => $uid]
        );
        if (!$t) {
            throw new HttpException(404);
        }
        return $t;
    }

    private function myOrders(int $uid): array
    {
        return Database::fetchAll(
            'SELECT id, order_number, created_at, grand_total FROM orders WHERE user_id = :u ORDER BY created_at DESC, id DESC LIMIT 50',
            ['u' => $uid]
        );
    }

    private function uid(): int
    {
        $uid = Auth::customerId();
        if (!$uid) {
            throw new HttpException(403);
        }
        return $uid;
    }
}
