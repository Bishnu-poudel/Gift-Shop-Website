<?php
declare(strict_types=1);

namespace App\Controllers\Account;

use App\Controllers\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;
use App\Services\CartService;
use App\Services\OrderService;
use App\Services\PaymentService;
use RuntimeException;

/** Customer order history, order detail, printable invoice, returns and reorder. Owner-only. */
final class OrdersController extends Controller
{
    public const RETURN_REASONS = [
        'damaged' => 'Arrived damaged',
        'wrong_item' => 'Wrong item received',
        'not_as_described' => 'Not as described',
        'missing_parts' => 'Missing parts or items',
        'changed_mind' => 'Changed my mind',
        'other' => 'Other',
    ];

    private OrderService $orders;

    public function __construct()
    {
        $this->orders = new OrderService();
    }

    /** GET /account/orders */
    public function index(Request $request): Response
    {
        $uid = $this->uid();
        $total = (int) Database::fetchColumn('SELECT COUNT(*) FROM orders WHERE user_id = :u', ['u' => $uid]);
        $p = Paginator::fromRequest($total, 10);
        $orders = Database::fetchAll(
            "SELECT o.id, o.order_number, o.status, o.payment_status, o.payment_method, o.grand_total, o.created_at,
                    (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi WHERE oi.order_id = o.id) AS item_count,
                    (SELECT GROUP_CONCAT(oi2.name ORDER BY oi2.id SEPARATOR ', ') FROM order_items oi2 WHERE oi2.order_id = o.id) AS item_names,
                    (SELECT pi.path FROM order_items oi3 JOIN product_images pi ON pi.product_id = oi3.product_id
                       WHERE oi3.order_id = o.id ORDER BY oi3.id, pi.sort_order, pi.id LIMIT 1) AS image
             FROM orders o WHERE o.user_id = :u
             ORDER BY o.created_at DESC, o.id DESC LIMIT {$p->perPage} OFFSET {$p->offset}",
            ['u' => $uid]
        );
        return $this->view('account/orders/index', [
            'title' => 'My orders',
            'noindex' => true,
            'orders' => $orders,
            'paginator' => $p,
            'total' => $total,
        ]);
    }

    /** GET /account/orders/{number} */
    public function show(Request $request, string $number): Response
    {
        $uid = $this->uid();
        $order = $this->owned($number, $uid);
        $id = (int) $order['id'];
        $items = $this->orders->items($id);

        $reviewed = array_map('intval', Database::fetchCol('SELECT product_id FROM reviews WHERE user_id = :u', ['u' => $uid]));
        $returnRequest = Database::fetch('SELECT * FROM return_requests WHERE order_id = :o ORDER BY id DESC LIMIT 1', ['o' => $id]);

        return $this->view('account/orders/show', [
            'title' => 'Order ' . $order['order_number'],
            'noindex' => true,
            'order' => $order,
            'items' => $items,
            'shipping' => $this->orders->address($id, 'shipping'),
            'billing' => $this->orders->address($id, 'billing'),
            'history' => Database::fetchAll(
                "SELECT from_status, to_status, note, created_at FROM order_status_history
                 WHERE order_id = :o AND field = 'status' ORDER BY created_at, id",
                ['o' => $id]
            ),
            'shipments' => Database::fetchAll('SELECT * FROM shipments WHERE order_id = :o ORDER BY id', ['o' => $id]),
            'canPay' => (new PaymentService())->canPay($order),
            'canReturn' => $this->canReturn($order) && !$returnRequest,
            'returnRequest' => $returnRequest,
            'returnReasons' => self::RETURN_REASONS,
            'returnDays' => $this->returnDays(),
            'reviewed' => $reviewed,
            'canReview' => $order['status'] === 'delivered',
        ]);
    }

    /** GET /account/orders/{number}/invoice — standalone printable page (no site chrome). */
    public function invoice(Request $request, string $number): Response
    {
        $uid = $this->uid();
        $order = $this->owned($number, $uid);
        // One bill design everywhere (proforma before payment, tax invoice after).
        return Response::html(\App\Services\BillService::render($order, 'customer', [
            'back_url' => url('/account/orders/' . $order['order_number']),
            'pay_url' => (new PaymentService())->canPay($order) ? url('/checkout/pay/' . $order['order_number']) : null,
        ]));
    }

    /** POST /account/orders/{number}/return */
    public function requestReturn(Request $request, string $number): Response
    {
        $uid = $this->uid();
        $order = $this->owned($number, $uid);
        $back = '/account/orders/' . $order['order_number'];
        $data = Validator::validate([
            'reason' => $request->str('reason'),
            'details' => trim(strip_tags($request->str('details'))),
        ], [
            'reason' => 'required|in:' . implode(',', array_keys(self::RETURN_REASONS)),
            'details' => 'nullable|max:1000',
        ]);
        if (!$this->canReturn($order)) {
            flash('error', 'This order is no longer eligible for a return. Please contact support if you need help.');
            return $this->redirect($back);
        }
        if (Database::fetchColumn('SELECT 1 FROM return_requests WHERE order_id = :o', ['o' => (int) $order['id']])) {
            flash('info', 'A return has already been requested for this order.');
            return $this->redirect($back);
        }
        try {
            Database::transaction(function () use ($order, $uid, $data) {
                Database::insert('return_requests', [
                    'order_id' => (int) $order['id'],
                    'user_id' => $uid,
                    'reason' => self::RETURN_REASONS[$data['reason']],
                    'details' => $data['details'] !== '' ? $data['details'] : null,
                    'status' => 'requested',
                ]);
                $this->orders->transition((int) $order['id'], 'return_requested', null, 'Customer return request');
            });
        } catch (\DomainException | RuntimeException $e) {
            flash('error', 'We could not register the return: ' . $e->getMessage());
            return $this->redirect($back);
        }
        flash('success', 'Return requested. Our team will review it and contact you within 1–2 working days.');
        return $this->redirect($back);
    }

    /** POST /account/orders/{number}/reorder — adds still-available items to the bag. */
    public function reorder(Request $request, string $number): Response
    {
        $uid = $this->uid();
        $order = $this->owned($number, $uid);
        $cart = new CartService();
        $added = 0;
        $problems = [];
        foreach ($this->orders->items((int) $order['id']) as $item) {
            if (!$item['product_id']) {
                $problems[] = $item['name'] . ' is no longer sold';
                continue;
            }
            try {
                $cart->add((int) $item['product_id'], (int) $item['variant_id'], (int) $item['quantity'], $item['personalization']);
                $added++;
            } catch (RuntimeException $e) {
                $problems[] = $item['name'] . ': ' . $e->getMessage();
            }
        }
        if ($added > 0) {
            flash('success', $added . ' item' . ($added === 1 ? '' : 's') . ' added to your bag.');
        }
        if ($problems) {
            flash($added > 0 ? 'warning' : 'error', 'Some items could not be added — ' . implode('; ', array_slice($problems, 0, 5)));
        }
        return $this->redirect($added > 0 ? '/cart' : '/account/orders/' . $order['order_number']);
    }

    private function returnDays(): int
    {
        return max(1, (int) setting('return_window_days', 7));
    }

    private function canReturn(array $order): bool
    {
        if ($order['status'] !== 'delivered' || !$order['delivered_at']) {
            return false;
        }
        return strtotime($order['delivered_at'] . ' UTC') >= time() - 86400 * $this->returnDays();
    }

    private function owned(string $number, int $uid): array
    {
        $order = Database::fetch('SELECT * FROM orders WHERE order_number = :n AND user_id = :u', ['n' => $number, 'u' => $uid]);
        if (!$order) {
            throw new HttpException(404);
        }
        return $order;
    }

    private function uid(): int
    {
        $uid = Auth::customerId();
        if (!$uid) {
            throw new HttpException(403);
        }
        return $uid;
    }
}
