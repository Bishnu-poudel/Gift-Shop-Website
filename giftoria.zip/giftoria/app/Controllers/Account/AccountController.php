<?php
declare(strict_types=1);

namespace App\Controllers\Account;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;
use App\Core\Validator;
use App\Services\AuthService;
use App\Services\NewsletterService;
use App\Services\ReminderService;
use App\Services\WishlistService;

/** Account overview, profile & password, notification preferences and account deletion requests. */
final class AccountController extends Controller
{
    /** GET /account */
    public function dashboard(Request $request): Response
    {
        $user = $this->user();
        $uid = (int) $user['id'];
        $profile = self::profileFor($uid);
        (new WishlistService())->defaultId($uid);

        $upcoming = (new ReminderService())->upcoming($uid, 30);
        return $this->view('account/dashboard', [
            'title' => 'My account',
            'noindex' => true,
            'user' => $user,
            'profile' => $profile,
            'orderCount' => (int) Database::fetchColumn('SELECT COUNT(*) FROM orders WHERE user_id = :u', ['u' => $uid]),
            'wishlistCount' => (int) Database::fetchColumn(
                'SELECT COUNT(DISTINCT wi.product_id) FROM wishlist_items wi JOIN wishlists w ON w.id = wi.wishlist_id WHERE w.user_id = :u',
                ['u' => $uid]
            ),
            'upcoming' => $upcoming,
            'recentOrders' => Database::fetchAll(
                'SELECT o.id, o.order_number, o.status, o.payment_status, o.grand_total, o.created_at,
                        (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi WHERE oi.order_id = o.id) AS item_count
                 FROM orders o WHERE o.user_id = :u ORDER BY o.created_at DESC, o.id DESC LIMIT 5',
                ['u' => $uid]
            ),
            'openTickets' => (int) Database::fetchColumn("SELECT COUNT(*) FROM support_tickets WHERE user_id = :u AND status IN ('open','pending')", ['u' => $uid]),
        ]);
    }

    /** GET /account/profile */
    public function profile(Request $request): Response
    {
        $user = $this->user();
        $uid = (int) $user['id'];
        return $this->view('account/profile', [
            'title' => 'Profile & security',
            'noindex' => true,
            'user' => $user,
            'profile' => self::profileFor($uid),
            'recipientCount' => (int) Database::fetchColumn('SELECT COUNT(*) FROM gift_recipients WHERE user_id = :u', ['u' => $uid]),
        ]);
    }

    /** POST /account/profile */
    public function updateProfile(Request $request): Response
    {
        $user = $this->user();
        $uid = (int) $user['id'];
        $data = Validator::validate([
            'name' => strip_tags($request->str('name')),
            'phone' => $request->str('phone'),
            'birthday' => $request->str('birthday'),
        ], [
            'name' => 'required|min:2|max:120',
            'phone' => 'nullable|max:20|phone',
            'birthday' => 'nullable|date',
        ]);
        if ($data['birthday'] && ($data['birthday'] > local_today() || $data['birthday'] < '1900-01-01')) {
            throw new ValidationException(['birthday' => 'Please enter a valid birthday.'], $data);
        }
        $phone = $data['phone'] ? preg_replace('/[\s-]/', '', $data['phone']) : null;
        $profile = self::profileFor($uid);

        Database::transaction(function () use ($uid, $data, $phone) {
            Database::update('users', ['name' => $data['name'], 'phone' => $phone], ['id' => $uid]);
            Database::update('customer_profiles', ['birthday' => $data['birthday'] ?: null], ['user_id' => $uid]);
        });
        AuditLogger::log('account.profile_updated', 'user', $uid,
            ['name' => $user['name'], 'phone' => $user['phone'], 'birthday' => $profile['birthday']],
            ['name' => $data['name'], 'phone' => $phone, 'birthday' => $data['birthday'] ?: null], $uid);
        flash('success', 'Your profile has been updated.');
        return $this->redirect('/account/profile');
    }

    /** POST /account/password — verifies the current password; keeps this session signed in. */
    public function updatePassword(Request $request): Response
    {
        $user = $this->user();
        $uid = (int) $user['id'];
        $data = Validator::validate($request->only(['current_password', 'password', 'password_confirmation']), [
            'current_password' => 'required|max:128',
            'password' => AuthService::passwordRules(),
        ], ['password' => 'New password']);

        $limitKey = 'pwchange:' . $uid;
        if (RateLimiter::tooMany($limitKey, 5)) {
            throw new HttpException(429, 'Too many attempts. Please wait 15 minutes and try again.');
        }
        $hash = (string) Database::fetchColumn('SELECT password_hash FROM users WHERE id = :id', ['id' => $uid]);
        if ($hash === '' || !password_verify((string) $data['current_password'], $hash)) {
            RateLimiter::hit($limitKey, 900);
            throw new ValidationException(['current_password' => 'Your current password is incorrect.']);
        }
        if (hash_equals((string) $data['current_password'], (string) $data['password'])) {
            throw new ValidationException(['password' => 'Choose a password different from your current one.']);
        }
        RateLimiter::clear($limitKey);

        (new AuthService())->setPassword($uid, (string) $data['password']); // bumps session_version (signs out other devices)
        $fresh = Database::fetch('SELECT * FROM users WHERE id = :id', ['id' => $uid]);
        if ($fresh) {
            Auth::login($fresh, 'customer'); // keep this session valid under the new session_version
        }
        AuditLogger::log('account.password_changed', 'user', $uid, null, null, $uid);
        flash('success', 'Password changed. You have been signed out on your other devices.');
        return $this->redirect('/account/profile');
    }

    /** GET /account/notifications */
    public function notifications(Request $request): Response
    {
        $user = $this->user();
        $uid = (int) $user['id'];
        return $this->view('account/notifications', [
            'title' => 'Notifications & privacy',
            'noindex' => true,
            'user' => $user,
            'profile' => self::profileFor($uid),
            'feedbackCount' => (int) Database::fetchColumn('SELECT COUNT(*) FROM recommendation_feedback WHERE user_id = :u', ['u' => $uid]),
        ]);
    }

    /** POST /account/notifications */
    public function updateNotifications(Request $request): Response
    {
        $user = $this->user();
        $uid = (int) $user['id'];
        $old = self::profileFor($uid);
        $new = [
            'marketing_opt_in' => $request->bool('marketing_opt_in') ? 1 : 0,
            'notify_order_updates' => $request->bool('notify_order_updates') ? 1 : 0,
            'notify_gift_reminders' => $request->bool('notify_gift_reminders') ? 1 : 0,
            'notify_wishlist' => $request->bool('notify_wishlist') ? 1 : 0,
            'personalization_enabled' => $request->bool('personalization_enabled') ? 1 : 0,
        ];
        Database::update('customer_profiles', $new, ['user_id' => $uid]);

        if ($new['marketing_opt_in'] === 1 && (int) $old['marketing_opt_in'] === 0) {
            NewsletterService::subscribe((string) $user['email'], 'account', $uid);
        } elseif ($new['marketing_opt_in'] === 0 && (int) $old['marketing_opt_in'] === 1) {
            NewsletterService::unsubscribe((string) $user['email']);
        }
        $oldVals = array_intersect_key($old, $new);
        AuditLogger::log('account.preferences_updated', 'user', $uid, array_map('intval', $oldVals), $new, $uid);
        flash('success', 'Your preferences have been saved.');
        return $this->redirect('/account/notifications');
    }

    /** POST /account/notifications/clear-history — removes personalization signals for this customer. */
    public function clearHistory(Request $request): Response
    {
        $uid = (int) $this->user()['id'];
        $n = Database::query('DELETE FROM recommendation_feedback WHERE user_id = :u', ['u' => $uid])->rowCount();
        Database::query('DELETE FROM gift_finder_sessions WHERE user_id = :u', ['u' => $uid]);
        AuditLogger::log('account.reco_history_cleared', 'user', $uid, null, ['feedback_rows' => $n], $uid);
        flash('success', 'Your recommendation history has been cleared.');
        return $this->redirect('/account/notifications');
    }

    /** POST /account/delete-request */
    public function deleteRequest(Request $request): Response
    {
        $user = $this->user();
        $uid = (int) $user['id'];
        Validator::validate($request->only(['confirm', 'reason']), [
            'confirm' => 'accepted',
            'reason' => 'nullable|max:1000',
        ], ['confirm' => 'Confirmation']);
        $reason = trim(strip_tags($request->str('reason')));
        $removeRecipients = $request->bool('remove_recipients');
        $profile = self::profileFor($uid);

        $removed = 0;
        if ($removeRecipients) {
            // Cascades to the recipients' reminders and saved-idea lists.
            $removed = Database::query('DELETE FROM gift_recipients WHERE user_id = :u', ['u' => $uid])->rowCount();
        }

        if ($profile['deletion_requested_at']) {
            flash('info', 'We already have your deletion request from ' . local_date($profile['deletion_requested_at'], 'M j, Y')
                . '. Our team will contact you by email.' . ($removed ? ' Your saved gift recipients have been removed.' : ''));
            return $this->redirect('/account/profile');
        }

        $ticket = Database::transaction(function () use ($uid, $user, $reason) {
            Database::update('customer_profiles', ['deletion_requested_at' => Database::now()], ['user_id' => $uid]);
            return SupportController::openTicket(
                $user,
                'Account deletion request',
                'account_deletion',
                null,
                "Please delete my account and personal data.\n\n" . ($reason !== '' ? 'Reason: ' . $reason : 'No reason given.'),
                'high'
            );
        });
        AuditLogger::log('account.deletion_requested', 'user', $uid, null, [
            'ticket' => $ticket['ticket_number'], 'recipients_removed' => $removed,
        ], $uid);
        flash('success', 'Your deletion request has been received (ticket ' . $ticket['ticket_number'] . '). '
            . 'Our team will verify it and delete your account within 30 days. Records we must keep by law, such as invoices, are retained in anonymised form.'
            . ($removed ? ' Your saved gift recipients were removed immediately.' : ''));
        return $this->redirect('/account/profile');
    }

    /** Customer profile row (created on demand for older accounts). */
    public static function profileFor(int $userId): array
    {
        Database::query('INSERT IGNORE INTO customer_profiles (user_id) VALUES (:u)', ['u' => $userId]);
        return Database::fetch('SELECT * FROM customer_profiles WHERE user_id = :u', ['u' => $userId]) ?? [];
    }

    private function user(): array
    {
        $u = Auth::customer();
        if (!$u) {
            throw new HttpException(403);
        }
        return $u;
    }
}
