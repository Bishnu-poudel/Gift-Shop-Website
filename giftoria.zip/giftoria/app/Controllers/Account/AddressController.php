<?php
declare(strict_types=1);

namespace App\Controllers\Account;

use App\Controllers\Controller;
use App\Core\Auth;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;
use App\Core\Validator;
use App\Services\ShippingService;

/** Saved delivery addresses in Nepali format (province → district → municipality → ward). */
final class AddressController extends Controller
{
    public const MAX_ADDRESSES = 10;
    public const LABELS = ['Home', 'Office', 'Family', 'Friend', 'Other'];

    /** GET /account/addresses */
    public function index(Request $request): Response
    {
        $uid = $this->uid();
        return $this->view('account/addresses/index', [
            'title' => 'My addresses',
            'noindex' => true,
            'addresses' => $this->all($uid),
            'provinces' => config('nepal.provinces'),
            'max' => self::MAX_ADDRESSES,
        ]);
    }

    /** POST /account/addresses */
    public function store(Request $request): Response
    {
        $uid = $this->uid();
        $count = (int) Database::fetchColumn('SELECT COUNT(*) FROM addresses WHERE user_id = :u', ['u' => $uid]);
        if ($count >= self::MAX_ADDRESSES) {
            flash('error', 'You can save up to ' . self::MAX_ADDRESSES . ' addresses. Remove one to add another.');
            return $this->redirect('/account/addresses');
        }
        $data = $this->validated($request);
        $makeDefault = $count === 0 || $request->bool('is_default');

        Database::transaction(function () use ($uid, $data, $makeDefault) {
            if ($makeDefault) {
                Database::update('addresses', ['is_default' => 0], ['user_id' => $uid]);
            }
            Database::insert('addresses', $data + ['user_id' => $uid, 'is_default' => $makeDefault ? 1 : 0]);
        });
        flash('success', 'Address saved.');
        return $this->redirect('/account/addresses');
    }

    /** GET /account/addresses/{id}/edit */
    public function edit(Request $request, string $id): Response
    {
        $uid = $this->uid();
        return $this->view('account/addresses/edit', [
            'title' => 'Edit address',
            'noindex' => true,
            'address' => $this->owned((int) $id, $uid),
            'provinces' => config('nepal.provinces'),
        ]);
    }

    /** POST /account/addresses/{id} */
    public function update(Request $request, string $id): Response
    {
        $uid = $this->uid();
        $address = $this->owned((int) $id, $uid);
        $data = $this->validated($request);
        $makeDefault = $request->bool('is_default');

        Database::transaction(function () use ($uid, $address, $data, $makeDefault) {
            if ($makeDefault && !(int) $address['is_default']) {
                Database::update('addresses', ['is_default' => 0], ['user_id' => $uid]);
                $data['is_default'] = 1;
            }
            Database::update('addresses', $data, ['id' => (int) $address['id'], 'user_id' => $uid]);
        });
        flash('success', 'Address updated.');
        return $this->redirect('/account/addresses');
    }

    /** POST /account/addresses/{id}/delete */
    public function destroy(Request $request, string $id): Response
    {
        $uid = $this->uid();
        $address = $this->owned((int) $id, $uid);
        Database::transaction(function () use ($uid, $address) {
            Database::delete('addresses', ['id' => (int) $address['id'], 'user_id' => $uid]);
            if ((int) $address['is_default']) {
                $next = Database::fetchColumn('SELECT id FROM addresses WHERE user_id = :u ORDER BY created_at DESC, id DESC LIMIT 1', ['u' => $uid]);
                if ($next) {
                    Database::update('addresses', ['is_default' => 1], ['id' => (int) $next, 'user_id' => $uid]);
                }
            }
        });
        flash('success', 'Address removed.');
        return $this->redirect('/account/addresses');
    }

    /** POST /account/addresses/{id}/default */
    public function makeDefault(Request $request, string $id): Response
    {
        $uid = $this->uid();
        $address = $this->owned((int) $id, $uid);
        Database::transaction(function () use ($uid, $address) {
            Database::update('addresses', ['is_default' => 0], ['user_id' => $uid]);
            Database::update('addresses', ['is_default' => 1], ['id' => (int) $address['id'], 'user_id' => $uid]);
        });
        flash('success', 'Default address updated.');
        return $this->redirect('/account/addresses');
    }

    /** Validates and normalises the address form. */
    private function validated(Request $request): array
    {
        $in = [];
        foreach (['label', 'full_name', 'phone', 'province', 'district', 'municipality', 'ward', 'street', 'landmark'] as $k) {
            $in[$k] = trim(strip_tags($request->str($k)));
        }
        $provinces = array_keys((array) config('nepal.provinces'));
        $data = Validator::validate($in, [
            'label' => 'nullable|max:50',
            'full_name' => 'required|min:2|max:120',
            'phone' => 'required|max:20|phone',
            'province' => 'required|in:' . implode(',', $provinces),
            'district' => 'required|max:60',
            'municipality' => 'required|min:2|max:100',
            'ward' => 'nullable|integer|between:1,35',
            'street' => 'nullable|max:190',
            'landmark' => 'nullable|max:190',
        ], ['full_name' => 'Full name', 'municipality' => 'Municipality / rural municipality', 'ward' => 'Ward number']);

        if (ShippingService::provinceOf($data['district']) !== $data['province']) {
            throw new ValidationException(['district' => 'Please choose a district in ' . $data['province'] . ' Province.'], $in);
        }
        return [
            'label' => $data['label'] !== '' ? $data['label'] : null,
            'full_name' => $data['full_name'],
            'phone' => preg_replace('/[\s-]/', '', $data['phone']),
            'province' => $data['province'],
            'district' => $data['district'],
            'municipality' => $data['municipality'],
            'ward' => $data['ward'] !== '' ? (string) (int) $data['ward'] : null,
            'street' => $data['street'] !== '' ? $data['street'] : null,
            'landmark' => $data['landmark'] !== '' ? $data['landmark'] : null,
        ];
    }

    private function all(int $uid): array
    {
        return Database::fetchAll('SELECT * FROM addresses WHERE user_id = :u ORDER BY is_default DESC, created_at DESC, id DESC', ['u' => $uid]);
    }

    private function owned(int $id, int $uid): array
    {
        $a = Database::fetch('SELECT * FROM addresses WHERE id = :id AND user_id = :u', ['id' => $id, 'u' => $uid]);
        if (!$a) {
            throw new HttpException(404);
        }
        return $a;
    }

    private function uid(): int
    {
        $uid = Auth::customerId();
        if (!$uid) {
            throw new HttpException(403);
        }
        return $uid;
    }
}
