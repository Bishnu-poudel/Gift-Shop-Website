<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;
use App\Core\View;

abstract class Controller
{
    protected function view(string $view, array $data = [], ?string $layout = 'layouts/app'): Response
    {
        if ($layout === 'layouts/app') {
            \App\Services\Analytics::trackVisit();
        }
        return Response::html(View::render($view, $data, $layout));
    }

    protected function adminView(string $view, array $data = []): Response
    {
        return Response::html(View::render('admin/' . $view, $data, 'layouts/admin'));
    }

    protected function redirect(string $to): Response
    {
        return Response::redirect($to);
    }

    protected function back(string $fallback = '/'): Response
    {
        return Response::redirect(back_url($fallback));
    }

    protected function json(mixed $data, int $status = 200): Response
    {
        return Response::json($data, $status);
    }

    /** @throws \App\Core\ValidationException */
    protected function validate(Request $request, array $rules, array $labels = []): array
    {
        return Validator::validate($request->all(), $rules, $labels);
    }
}
