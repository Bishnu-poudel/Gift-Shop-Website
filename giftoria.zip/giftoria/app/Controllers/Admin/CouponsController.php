<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;
use App\Core\Validator;

/**
 * Coupon management. One coupon per order is enforced at checkout (no stacking);
 * validity rules themselves live in CouponService::evaluate().
 */
final class CouponsController extends Controller
{
    public const STATUSES = ['active', 'scheduled', 'expired', 'exhausted', 'inactive'];

    /** Computed coupon status: inactive, scheduled, expired, exhausted or active. */
    public static function statusOf(array $c): string
    {
        $now = gmdate('Y-m-d H:i:s');
        if (!(int) $c['is_active']) {
            return 'inactive';
        }
        if ($c['starts_at'] && $c['starts_at'] > $now) {
            return 'scheduled';
        }
        if ($c['ends_at'] && $c['ends_at'] < $now) {
            return 'expired';
        }
        if ($c['usage_limit'] !== null && (int) $c['used_count'] >= (int) $c['usage_limit']) {
            return 'exhausted';
        }
        return 'active';
    }

    public function index(Request $request): Response
    {
        $q = $request->str('q');
        $status = $request->str('status');
        $where = [];
        $params = [];
        if ($q !== '') {
            $params['q'] = '%' . $q . '%';
            $params['q2'] = '%' . $q . '%';
            $where[] = '(c.code LIKE :q OR c.description LIKE :q2)';
        }
        $live = '(c.starts_at IS NULL OR c.starts_at <= UTC_TIMESTAMP()) AND (c.ends_at IS NULL OR c.ends_at >= UTC_TIMESTAMP())';
        $notExhausted = '(c.usage_limit IS NULL OR c.used_count < c.usage_limit)';
        $statusSql = [
            'inactive' => 'c.is_active = 0',
            'scheduled' => 'c.is_active = 1 AND c.starts_at > UTC_TIMESTAMP()',
            'expired' => 'c.is_active = 1 AND (c.starts_at IS NULL OR c.starts_at <= UTC_TIMESTAMP()) AND c.ends_at < UTC_TIMESTAMP()',
            'exhausted' => "c.is_active = 1 AND $live AND NOT $notExhausted",
            'active' => "c.is_active = 1 AND $live AND $notExhausted",
        ];
        if (isset($statusSql[$status])) {
            $where[] = '(' . $statusSql[$status] . ')';
        }
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM coupons c $whereSql", $params);
        $p = Paginator::fromRequest($total, 25);
        $rows = Database::fetchAll(
            "SELECT c.*, COALESCE(r.redemptions, 0) AS redemptions, COALESCE(r.discount_total, 0) AS discount_total
             FROM coupons c
             LEFT JOIN (
                SELECT cr.coupon_id, COUNT(*) AS redemptions, SUM(cr.discount) AS discount_total
                FROM coupon_redemptions cr JOIN orders o ON o.id = cr.order_id
                WHERE o.status <> 'cancelled'
                GROUP BY cr.coupon_id
             ) r ON r.coupon_id = c.id
             $whereSql
             ORDER BY c.created_at DESC, c.id DESC
             LIMIT {$p->perPage} OFFSET {$p->offset}",
            $params
        );
        foreach ($rows as &$row) {
            $row['status'] = self::statusOf($row);
        }
        unset($row);

        $kpis = Database::fetch(
            "SELECT
                (SELECT COUNT(*) FROM coupons c WHERE c.is_active = 1 AND $live AND $notExhausted) AS active_count,
                (SELECT COUNT(*) FROM coupons c WHERE c.is_active = 1 AND c.starts_at > UTC_TIMESTAMP()) AS scheduled_count,
                (SELECT COUNT(*) FROM coupon_redemptions cr JOIN orders o ON o.id = cr.order_id WHERE o.status <> 'cancelled') AS redemptions,
                (SELECT COALESCE(SUM(cr.discount), 0) FROM coupon_redemptions cr JOIN orders o ON o.id = cr.order_id WHERE o.status <> 'cancelled') AS discount_total"
        ) ?? [];

        return $this->adminView('coupons/index', [
            'title' => 'Coupons',
            'coupons' => $rows,
            'paginator' => $p,
            'total' => $total,
            'filters' => ['q' => $q, 'status' => $status],
            'kpis' => $kpis,
        ]);
    }

    public function create(Request $request): Response
    {
        return $this->adminView('coupons/form', $this->formData(null) + ['title' => 'New coupon']);
    }

    public function store(Request $request): Response
    {
        Gate::authorize('coupons.manage');
        $data = $this->validated($request, null);
        $data['created_by'] = Auth::staffId();
        $id = Database::insert('coupons', $data);
        AuditLogger::log('coupon.created', 'coupon', $id, null, $data);
        flash('success', 'Coupon ' . $data['code'] . ' created.');
        return $this->redirect(admin_url('coupons'));
    }

    public function edit(Request $request, string $id): Response
    {
        $coupon = $this->find((int) $id);
        return $this->adminView('coupons/form', $this->formData($coupon) + ['title' => 'Edit coupon ' . $coupon['code']]);
    }

    public function update(Request $request, string $id): Response
    {
        Gate::authorize('coupons.manage');
        $coupon = $this->find((int) $id);
        $data = $this->validated($request, $coupon);
        Database::update('coupons', $data, ['id' => (int) $coupon['id']]);
        AuditLogger::log('coupon.updated', 'coupon', (int) $coupon['id'], array_intersect_key($coupon, $data), $data);
        flash('success', 'Coupon ' . $data['code'] . ' updated.');
        return $this->redirect(admin_url('coupons'));
    }

    public function deactivate(Request $request, string $id): Response
    {
        Gate::authorize('coupons.manage');
        $coupon = $this->find((int) $id);
        if ((int) $coupon['is_active'] === 1) {
            Database::update('coupons', ['is_active' => 0], ['id' => (int) $coupon['id']]);
            AuditLogger::log('coupon.deactivated', 'coupon', (int) $coupon['id'], ['is_active' => 1], ['is_active' => 0]);
        }
        flash('success', 'Coupon ' . $coupon['code'] . ' deactivated. Existing orders keep their discount.');
        return $this->redirect(admin_url('coupons'));
    }

    private function find(int $id): array
    {
        $c = Database::fetch('SELECT * FROM coupons WHERE id = :id', ['id' => $id]);
        if (!$c) {
            throw new HttpException(404);
        }
        return $c;
    }

    private function formData(?array $coupon): array
    {
        $redemptions = null;
        if ($coupon) {
            $redemptions = Database::fetch(
                "SELECT COUNT(*) AS n, COALESCE(SUM(cr.discount), 0) AS total
                 FROM coupon_redemptions cr JOIN orders o ON o.id = cr.order_id
                 WHERE cr.coupon_id = :c AND o.status <> 'cancelled'",
                ['c' => (int) $coupon['id']]
            );
        }
        return [
            'coupon' => $coupon,
            'redemptions' => $redemptions,
            'products' => Database::fetchAll("SELECT id, name, sku FROM products WHERE status <> 'inactive' ORDER BY name LIMIT 1000"),
            'categories' => Database::fetchAll('SELECT id, name, parent_id FROM categories ORDER BY sort_order, name'),
        ];
    }

    /** Validates the coupon form and returns the column data to store. */
    private function validated(Request $request, ?array $existing): array
    {
        $in = $request->all();
        $in['code'] = strtoupper(trim((string) ($in['code'] ?? '')));
        $ignore = $existing ? ',' . (int) $existing['id'] : '';
        $v = Validator::make($in, [
            'code' => ['required', 'min:3', 'max:40', 'regex:/^[A-Z0-9-]+$/', 'unique:coupons,code' . $ignore],
            'description' => ['nullable', 'string', 'max:255'],
            'type' => ['required', 'in:percent,fixed,free_shipping'],
            'value' => ['nullable', 'numeric', 'min:0', 'max:10000000'],
            'min_subtotal' => ['nullable', 'numeric', 'min:0', 'max:10000000'],
            'max_discount' => ['nullable', 'numeric', 'min:0', 'max:10000000'],
            'usage_limit' => ['nullable', 'integer', 'min:1', 'max:10000000'],
            'per_customer_limit' => ['nullable', 'integer', 'min:1', 'max:1000'],
            'applies_to' => ['required', 'in:all,products,categories'],
            'product_ids' => ['array'],
            'category_ids' => ['array'],
            'starts_at' => ['nullable', 'datetime'],
            'ends_at' => ['nullable', 'datetime'],
        ], ['code' => 'Coupon code', 'min_subtotal' => 'Minimum subtotal', 'per_customer_limit' => 'Per-customer limit']);

        $errors = $v->fails() ? $v->errors() : [];
        $d = $v->validated();

        $type = (string) $d['type'];
        $value = ($d['value'] ?? '') === '' || $d['value'] === null ? null : (float) $d['value'];
        if (!isset($errors['value'])) {
            if ($type === 'percent' && ($value === null || $value < 1 || $value > 100)) {
                $errors['value'] = 'A percentage discount must be between 1 and 100.';
            } elseif ($type === 'fixed' && ($value === null || $value <= 0)) {
                $errors['value'] = 'A fixed discount must be greater than zero.';
            }
        }
        if ($type === 'free_shipping') {
            $value = 0.0;
        }

        $productIds = $this->existingIds('products', (array) ($d['product_ids'] ?? []));
        $categoryIds = $this->existingIds('categories', (array) ($d['category_ids'] ?? []));
        if ($d['applies_to'] === 'products' && !$productIds) {
            $errors['product_ids'] = 'Choose at least one product for a product-specific coupon.';
        }
        if ($d['applies_to'] === 'categories' && !$categoryIds) {
            $errors['category_ids'] = 'Choose at least one category for a category-specific coupon.';
        }

        $starts = local_to_utc($d['starts_at'] ?: null);
        $ends = local_to_utc($d['ends_at'] ?: null);
        if ($starts && $ends && $ends <= $starts) {
            $errors['ends_at'] = 'The end date must be after the start date.';
        }

        if ($errors) {
            throw new ValidationException($errors, $in);
        }

        return [
            'code' => $in['code'],
            'description' => ($d['description'] ?? '') !== '' ? $d['description'] : null,
            'type' => $type,
            'value' => $value ?? 0.0,
            'min_subtotal' => ($d['min_subtotal'] ?? '') !== '' && $d['min_subtotal'] !== null ? (float) $d['min_subtotal'] : 0.0,
            'max_discount' => $type === 'percent' && ($d['max_discount'] ?? '') !== '' && $d['max_discount'] !== null ? (float) $d['max_discount'] : null,
            'usage_limit' => ($d['usage_limit'] ?? '') !== '' && $d['usage_limit'] !== null ? (int) $d['usage_limit'] : null,
            'per_customer_limit' => ($d['per_customer_limit'] ?? '') !== '' && $d['per_customer_limit'] !== null ? (int) $d['per_customer_limit'] : null,
            'applies_to' => $d['applies_to'],
            'product_ids' => $d['applies_to'] === 'products' ? implode(',', $productIds) : null,
            'category_ids' => $d['applies_to'] === 'categories' ? implode(',', $categoryIds) : null,
            'starts_at' => $starts,
            'ends_at' => $ends,
            'is_active' => $request->bool('is_active') ? 1 : 0,
        ];
    }

    /** @return int[] ids that exist in $table (whitelisted table names only) */
    private function existingIds(string $table, array $ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', array_filter($ids, 'is_scalar')), static fn ($i) => $i > 0)));
        if (!$ids || !in_array($table, ['products', 'categories'], true)) {
            return [];
        }
        $params = [];
        $in = Database::in('id', array_slice($ids, 0, 120), $params);
        $found = array_map('intval', Database::fetchCol("SELECT id FROM `$table` WHERE id IN $in", $params));
        return array_values(array_intersect($ids, $found));
    }
}
