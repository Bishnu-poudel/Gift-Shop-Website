<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Services\OrderService;
use App\Services\OrderStateMachine;
use DomainException;
use RuntimeException;

/** Return requests: requested → approved → received → refunded (or rejected). */
final class ReturnsController extends Controller
{
    public const STATUSES = ['requested', 'approved', 'rejected', 'received', 'refunded'];
    public const FLOW = [
        'requested' => ['approved', 'rejected'],
        'approved' => ['received', 'rejected'],
        'received' => ['refunded'],
        'rejected' => [],
        'refunded' => [],
    ];

    public function index(Request $request): Response
    {
        $status = $request->str('status');
        $status = in_array($status, self::STATUSES, true) ? $status : '';
        $where = $status !== '' ? 'WHERE rr.status = :s' : '';
        $params = $status !== '' ? ['s' => $status] : [];
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM return_requests rr $where", $params);
        $pager = Paginator::fromRequest($total, 25);
        $returns = Database::fetchAll(
            "SELECT rr.*, o.order_number, o.customer_name, o.email, o.status AS order_status, o.grand_total, o.refunded_total,
                    o.payment_status, h.name AS handled_by_name
             FROM return_requests rr
             JOIN orders o ON o.id = rr.order_id
             LEFT JOIN users h ON h.id = rr.handled_by
             $where
             ORDER BY FIELD(rr.status, 'requested', 'approved', 'received', 'refunded', 'rejected'), rr.id DESC
             LIMIT " . (int) $pager->perPage . ' OFFSET ' . (int) $pager->offset,
            $params
        );
        $counts = array_fill_keys(self::STATUSES, 0);
        foreach (Database::fetchAll('SELECT status, COUNT(*) AS n FROM return_requests GROUP BY status') as $row) {
            $counts[$row['status']] = (int) $row['n'];
        }
        return $this->adminView('returns/index', [
            'title' => 'Returns',
            'returns' => $returns,
            'status' => $status,
            'counts' => $counts,
            'paginator' => $pager,
        ]);
    }

    public function update(Request $request, string $id): Response
    {
        if (!Gate::any(['support.manage', 'refunds.manage'])) {
            AuditLogger::log('access.denied', 'permission', null, null, ['permission' => 'support.manage|refunds.manage']);
            throw new HttpException(403);
        }
        $rr = Database::fetch('SELECT * FROM return_requests WHERE id = :id', ['id' => (int) $id]);
        if (!$rr) {
            throw new HttpException(404, 'Return request not found.');
        }
        $data = $this->validate($request, [
            'status' => 'required|in:approved,rejected,received,refunded',
            'staff_note' => 'nullable|string|max:500',
        ]);
        $to = $data['status'];
        $note = ($data['staff_note'] ?? '') !== '' ? strip_tags($data['staff_note']) : null;
        $back = admin_url('returns');

        if (!in_array($to, self::FLOW[$rr['status']] ?? [], true)) {
            flash('error', 'A ' . $rr['status'] . ' return cannot be marked ' . $to . '.');
            return $this->redirect($back);
        }

        $orders = new OrderService();
        $order = $orders->find((int) $rr['order_id']);
        if (!$order) {
            throw new HttpException(404, 'Order not found.');
        }
        $staffId = Auth::staffId();
        $label = 'Return #' . (int) $rr['id'];

        try {
            if ($to === 'approved' && $order['status'] === 'delivered') {
                $order = $orders->transition((int) $order['id'], 'return_requested', $staffId, $label . ' approved' . ($note ? ': ' . $note : ''));
            }
            if ($to === 'received') {
                if ($order['status'] === 'delivered') {
                    $order = $orders->transition((int) $order['id'], 'return_requested', $staffId, $label . ' approved');
                }
                if (!OrderStateMachine::canOrder($order['status'], 'returned')) {
                    throw new RuntimeException('The order is "' . (OrderStateMachine::ORDER_LABELS[$order['status']] ?? $order['status']) . '" and cannot be marked returned.');
                }
                // transition() restocks the returned items.
                $order = $orders->transition((int) $order['id'], 'returned', $staffId, $label . ' received' . ($note ? ': ' . $note : ''));
            }
            if ($to === 'rejected' && $order['status'] === 'return_requested') {
                $otherOpen = (int) Database::fetchColumn(
                    "SELECT COUNT(*) FROM return_requests WHERE order_id = :o AND id <> :id AND status IN ('requested','approved')",
                    ['o' => (int) $order['id'], 'id' => (int) $rr['id']]
                );
                if ($otherOpen === 0) {
                    $order = $orders->transition((int) $order['id'], 'delivered', $staffId, $label . ' rejected' . ($note ? ': ' . $note : ''));
                }
            }
            if ($to === 'refunded') {
                $hasRefund = (bool) Database::fetchColumn("SELECT 1 FROM refunds WHERE order_id = :o AND status = 'completed' LIMIT 1", ['o' => (int) $order['id']]);
                if (!$hasRefund) {
                    throw new RuntimeException('Complete a refund for this order first (Refunds), then mark the return refunded.');
                }
            }
        } catch (DomainException|RuntimeException $e) {
            flash('error', $e->getMessage());
            return $this->redirect($back);
        }

        Database::update('return_requests', [
            'status' => $to,
            'staff_note' => $note ?? $rr['staff_note'],
            'handled_by' => $staffId,
        ], ['id' => (int) $rr['id']]);
        AuditLogger::log('return.' . $to, 'return_request', (int) $rr['id'], ['status' => $rr['status']], ['status' => $to, 'staff_note' => $note, 'order_id' => (int) $order['id']]);

        $msg = match ($to) {
            'approved' => $label . ' approved. Arrange pickup or drop-off with the customer.',
            'received' => $label . ' received, order marked returned and items restocked. Create a refund from the order page.',
            'rejected' => $label . ' rejected.',
            default => $label . ' marked refunded.',
        };
        flash('success', $msg);
        return $this->redirect($back);
    }
}
