<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;

/** Admin > Audit log. Strictly read-only. */
final class AuditController extends Controller
{
    public function index(Request $request): Response
    {
        $userId = $request->int('user');
        $action = $request->str('action');
        $entity = $request->str('entity');
        $from = $request->str('from');
        $to = $request->str('to');

        $where = [];
        $params = [];
        if ($userId > 0) {
            $where[] = 'a.user_id = :uid';
            $params['uid'] = $userId;
        }
        if ($action !== '') {
            $where[] = 'a.action LIKE :act';
            $params['act'] = addcslashes(mb_substr($action, 0, 80), '%_\\') . '%';
        }
        if ($entity !== '') {
            $where[] = 'a.entity_type = :ent';
            $params['ent'] = mb_substr($entity, 0, 60);
        }
        $isDate = static fn (string $d) => (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && strtotime($d) !== false;
        if ($from !== '' && $isDate($from)) {
            $where[] = 'a.created_at >= :dfrom';
            $params['dfrom'] = local_to_utc($from . ' 00:00:00');
        } else {
            $from = '';
        }
        if ($to !== '' && $isDate($to)) {
            $where[] = 'a.created_at <= :dto';
            $params['dto'] = local_to_utc($to . ' 23:59:59');
        } else {
            $to = '';
        }
        $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM audit_logs a $w", $params);
        $p = Paginator::fromRequest($total, 50);
        $rows = Database::fetchAll(
            "SELECT a.id, a.user_id, a.action, a.entity_type, a.entity_id, a.ip, a.created_at, u.name AS user_name, u.type AS user_type
             FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
             $w ORDER BY a.id DESC LIMIT " . (int) $p->perPage . ' OFFSET ' . (int) $p->offset,
            $params
        );

        return $this->adminView('audit/index', [
            'title' => 'Audit log',
            'rows' => $rows,
            'paginator' => $p,
            'total' => $total,
            'filters' => ['user' => $userId, 'action' => $action, 'entity' => $entity, 'from' => $from, 'to' => $to],
            'staffUsers' => Database::fetchAll("SELECT id, name, email FROM users WHERE type = 'staff' ORDER BY name"),
            'entityTypes' => Database::fetchCol('SELECT DISTINCT entity_type FROM audit_logs WHERE entity_type IS NOT NULL ORDER BY entity_type'),
            'actionPrefixes' => Database::fetchCol("SELECT DISTINCT SUBSTRING_INDEX(action, '.', 1) AS p FROM audit_logs ORDER BY p"),
        ]);
    }

    public function show(Request $request, string $id): Response
    {
        $log = Database::fetch(
            'SELECT a.*, u.name AS user_name, u.email AS user_email, u.type AS user_type
             FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE a.id = :id',
            ['id' => (int) $id]
        );
        if (!$log) {
            throw new HttpException(404);
        }
        return $this->adminView('audit/show', [
            'title' => 'Audit entry #' . (int) $log['id'],
            'log' => $log,
            'oldJson' => self::pretty($log['old_values']),
            'newJson' => self::pretty($log['new_values']),
        ]);
    }

    private static function pretty(?string $json): ?string
    {
        if ($json === null || $json === '') {
            return null;
        }
        $decoded = json_decode($json, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return $json;
        }
        return (string) json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
