<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\Gate;
use App\Core\Request;
use App\Core\Response;
use App\Repositories\Admin\OrderAdminRepository;
use App\Repositories\Admin\ReportRepository;
use App\Services\InventoryService;

/** Admin home: KPIs, revenue chart and operational lists. Every figure comes from stored data. */
final class DashboardController extends Controller
{
    public function index(Request $request): Response
    {
        $repo = new ReportRepository();
        $range = ReportRepository::range($request->str('from') ?: null, $request->str('to') ?: null, 30);
        $method = $request->str('payment_method');
        $method = isset(OrderAdminRepository::PAYMENT_METHODS[$method]) ? $method : null;
        $categoryId = $request->int('category_id') ?: null;
        $categories = $repo->categories();
        if ($categoryId && !in_array($categoryId, array_map('intval', array_column($categories, 'id')), true)) {
            $categoryId = null;
        }

        $group = $range['days'] > 120 ? 'month' : 'day';
        $series = $repo->revenueSeries($range, $group, $categoryId, $method);
        $growth = $repo->customerGrowth($range);
        $canSeeCost = Gate::any(['reports.view', 'products.manage']);
        $canAudit = Gate::allows('audit.view');

        return $this->adminView('dashboard/index', [
            'title' => 'Dashboard',
            'useCharts' => true,
            'range' => $range,
            'filters' => ['payment_method' => $method, 'category_id' => $categoryId],
            'categories' => $categories,
            'group' => $group,
            'sales' => $repo->salesSummary($range, $method),
            'today' => $repo->ordersToday(),
            'pending' => $repo->pendingFulfilment(),
            'lowStock' => (new InventoryService())->lowStock(8),
            'topProducts' => $repo->topProducts($range, 8, $categoryId),
            'topCategories' => $repo->topCategories($range, 6),
            'series' => $series,
            'growth' => $growth,
            'customers' => $repo->customerTotals(),
            'coupons' => $repo->couponPerformance($range, 6),
            'paymentStats' => $repo->paymentStats($range),
            'refunds' => $repo->refundSummary($range),
            'conversion' => $repo->conversion($range),
            'canSeeCost' => $canSeeCost,
            'canAudit' => $canAudit,
            'activity' => $canAudit ? $repo->recentAudit(10) : [],
            'recentOrders' => $canAudit ? [] : (Gate::allows('orders.view') ? $repo->recentOrders(8) : []),
        ]);
    }
}
