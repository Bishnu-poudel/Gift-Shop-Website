<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Logger;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\ValidationException;
use App\Services\AuthService;

/**
 * Staff authentication: login/logout, password reset, invitation acceptance and password change.
 * There is deliberately NO self-registration here: staff accounts are only created by an
 * authorised staff member in Admin > Staff (which also enforces role delegation rules).
 */
final class AdminAuthController extends Controller
{
    private const GENERIC_LOGIN_ERROR = 'Invalid credentials.';
    private const FORGOT_MESSAGE = 'If an active staff account exists for that email address, a password reset link has been sent. The link expires in 1 hour.';

    private function auth(): AuthService
    {
        return new AuthService();
    }

    private function minimal(string $view, array $data): Response
    {
        return $this->view('admin/auth/' . $view, $data, 'layouts/minimal');
    }

    // ---------------------------------------------------------------- login

    public function loginForm(Request $request): Response
    {
        return $this->minimal('login', ['title' => 'Staff sign in']);
    }

    public function login(Request $request): Response
    {
        $data = $this->validate($request, [
            'email' => 'required|email|max:190',
            'password' => 'required|max:128',
        ]);

        // Throttled inside attempt(); throws HttpException(429) when exceeded.
        $user = Auth::attempt((string) $data['email'], (string) $request->input('password', ''), 'staff', $request->ip());

        // Pending (invite not accepted) and inactive accounts get the same generic message: no enumeration.
        if (!$user || $user['status'] !== 'active' || $user['type'] !== 'staff') {
            if ($user) {
                // Correct password but account not active: still count it as a failed attempt.
                RateLimiter::hit('login:staff:' . hash('sha256', mb_strtolower(trim((string) $data['email'])) . '|' . $request->ip()), 900);
            }
            throw new ValidationException(['email' => self::GENERIC_LOGIN_ERROR], ['email' => $data['email']]);
        }

        Auth::login($user, 'staff');
        AuditLogger::log('staff.login', 'user', (int) $user['id'], null, null, (int) $user['id']);

        $intended = (string) Session::pull('admin_intended', '');
        $base = admin_url();
        if ($intended !== '' && ($intended === $base || str_starts_with($intended, $base . '/'))
            && !str_contains($intended, '/logout')) {
            return $this->redirect($intended);
        }
        return $this->redirect($base);
    }

    public function logout(Request $request): Response
    {
        $id = Auth::staffId();
        if ($id) {
            AuditLogger::log('staff.logout', 'user', $id, null, null, $id);
        }
        Auth::logout('staff');
        flash('success', 'You have been signed out.');
        return $this->redirect(admin_url('login'));
    }

    // ------------------------------------------------------- password reset

    public function forgotForm(Request $request): Response
    {
        return $this->minimal('forgot', ['title' => 'Reset staff password']);
    }

    public function forgot(Request $request): Response
    {
        RateLimiter::enforce('admin-forgot:' . $request->ip(), 5, 900);
        $data = $this->validate($request, ['email' => 'required|email|max:190']);
        try {
            $this->auth()->requestPasswordReset((string) $data['email'], 'staff');
        } catch (\Throwable $e) {
            // Never leak failures (or account existence) to the browser.
            Logger::error('Staff password reset request failed: ' . $e->getMessage());
        }
        flash('success', self::FORGOT_MESSAGE);
        return $this->redirect(admin_url('forgot-password'));
    }

    public function resetForm(Request $request, string $token): Response
    {
        $u = $this->auth()->consumeToken($token, 'reset', false);
        $valid = $u && $u['type'] === 'staff';
        return $this->minimal('reset', ['title' => 'Choose a new password', 'token' => $token, 'valid' => $valid]);
    }

    public function reset(Request $request, string $token): Response
    {
        RateLimiter::enforce('admin-token:' . $request->ip(), 20, 900);
        $data = $this->validate($request, ['password' => AuthService::passwordRules()]);
        $ok = false;
        try {
            $ok = $this->auth()->resetPassword($token, (string) $data['password'], 'staff');
        } catch (\RuntimeException $e) {
            throw new ValidationException(['password' => $e->getMessage()]);
        }
        if (!$ok) {
            flash('error', 'This password reset link is invalid or has expired. Please request a new one.');
            return $this->redirect(admin_url('forgot-password'));
        }
        // resetPassword() bumped session_version, so any existing staff session is now invalid.
        Auth::logout('staff');
        flash('success', 'Your password has been updated. Please sign in.');
        return $this->redirect(admin_url('login'));
    }

    // ----------------------------------------------------------- invitation

    private function inviteUser(string $token): ?array
    {
        $u = $this->auth()->consumeToken($token, 'invite', false);
        if (!$u || $u['type'] !== 'staff' || $u['status'] !== 'pending') {
            return null;
        }
        return $u;
    }

    public function inviteForm(Request $request, string $token): Response
    {
        $u = $this->inviteUser($token);
        return $this->minimal('invite', [
            'title' => 'Accept your invitation',
            'token' => $token,
            'valid' => $u !== null,
            'inviteName' => $u['name'] ?? '',
            'inviteEmail' => $u['email'] ?? '',
        ]);
    }

    public function acceptInvite(Request $request, string $token): Response
    {
        RateLimiter::enforce('admin-token:' . $request->ip(), 20, 900);
        $data = $this->validate($request, ['password' => AuthService::passwordRules()]);
        if (!$this->inviteUser($token)) {
            flash('error', 'This invitation link is invalid, has expired or was already used. Ask your administrator to resend it.');
            return $this->redirect(admin_url('login'));
        }

        $userId = Database::transaction(function () use ($token, $data) {
            $u = $this->auth()->consumeToken($token, 'invite'); // consume (single use)
            if (!$u || $u['type'] !== 'staff' || $u['status'] !== 'pending') {
                return null;
            }
            $id = (int) $u['id'];
            $this->auth()->setPassword($id, (string) $data['password']);
            Database::query(
                "UPDATE users SET email_verified_at = COALESCE(email_verified_at, UTC_TIMESTAMP()), status = 'active', must_change_password = 0 WHERE id = :id AND type = 'staff'",
                ['id' => $id]
            );
            return $id;
        });

        if (!$userId) {
            flash('error', 'This invitation link is invalid, has expired or was already used.');
            return $this->redirect(admin_url('login'));
        }
        AuditLogger::log('staff.invite_accepted', 'staff', $userId, null, ['status' => 'active'], $userId);
        Auth::logout('staff'); // make sure no other staff session lingers in this browser
        flash('success', 'Your account is ready. Please sign in with your new password.');
        return $this->redirect(admin_url('login'));
    }

    // ------------------------------------------------------ password change

    public function passwordForm(Request $request): Response
    {
        $staff = Auth::staff();
        return $this->adminView('auth/password', [
            'title' => 'Change password',
            'mustChange' => (int) ($staff['must_change_password'] ?? 0) === 1,
            'needsCurrent' => $this->needsCurrentPassword((int) $staff['id']),
        ]);
    }

    /**
     * The current password is required for every change. The only exception is an account that
     * has no password yet (cannot normally be logged in; kept for safety with seeded accounts).
     */
    private function needsCurrentPassword(int $userId): bool
    {
        $hash = Database::fetchColumn("SELECT password_hash FROM users WHERE id = :id AND type = 'staff'", ['id' => $userId]);
        return $hash !== null && $hash !== '';
    }

    public function updatePassword(Request $request): Response
    {
        $staff = Auth::staff();
        $id = (int) $staff['id'];
        RateLimiter::enforce('admin-pw-change:' . $id, 10, 900);

        $needsCurrent = $this->needsCurrentPassword($id);
        $rules = ['password' => AuthService::passwordRules()];
        if ($needsCurrent) {
            $rules['current_password'] = 'required|max:128';
        }
        $data = $this->validate($request, $rules, ['current_password' => 'Current password', 'password' => 'New password']);

        if ($needsCurrent) {
            $hash = (string) Database::fetchColumn('SELECT password_hash FROM users WHERE id = :id', ['id' => $id]);
            if (!password_verify((string) $request->input('current_password', ''), $hash)) {
                AuditLogger::log('staff.password_change_failed', 'user', $id);
                throw new ValidationException(['current_password' => 'Your current password is incorrect.']);
            }
            if (password_verify((string) $data['password'], $hash)) {
                throw new ValidationException(['password' => 'Choose a password different from your current one.']);
            }
        }

        try {
            $this->auth()->setPassword($id, (string) $data['password']);
        } catch (\RuntimeException $e) {
            throw new ValidationException(['password' => $e->getMessage()]);
        }
        // setPassword() bumped session_version (revoking other sessions): re-login this one.
        $fresh = Database::fetch("SELECT * FROM users WHERE id = :id AND type = 'staff'", ['id' => $id]);
        Auth::flushCache();
        if ($fresh) {
            Auth::login($fresh, 'staff');
        }
        AuditLogger::log('staff.password_changed', 'user', $id, null, ['other_sessions_revoked' => true], $id);
        flash('success', 'Password updated. Other sessions have been signed out.');
        return $this->redirect(admin_url());
    }
}
