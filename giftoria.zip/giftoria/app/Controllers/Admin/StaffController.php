<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\ValidationException;
use App\Services\AuthService;
use App\Services\MailService;

/**
 * Admin > Staff. Staff are created by invitation only (no password is ever chosen or shown by
 * the creator). Delegation rules:
 *  - roles offered/accepted are limited to Gate::canAssignRole(actor, role);
 *  - nobody can change their own roles, deactivate themselves or revoke their own sessions here;
 *  - only a Super Admin may modify a Super Admin account;
 *  - a non-Super Admin may only manage accounts whose permissions are a subset of their own
 *    (prevents e.g. changing a more privileged user's email and taking over via password reset).
 */
final class StaffController extends Controller
{
    private const STATUSES = ['active', 'pending', 'inactive'];

    private function actorId(): int
    {
        return (int) Auth::staffId();
    }

    private function findStaff(int $id): array
    {
        $row = Database::fetch(
            "SELECT u.id, u.name, u.email, u.phone, u.status, u.email_verified_at, u.must_change_password,
                    u.last_login_at, u.last_login_ip, u.created_at, u.updated_at,
                    sp.employee_id, sp.job_title, sp.department, sp.invited_by,
                    inv.name AS invited_by_name
             FROM users u
             LEFT JOIN staff_profiles sp ON sp.user_id = u.id
             LEFT JOIN users inv ON inv.id = sp.invited_by
             WHERE u.id = :id AND u.type = 'staff' AND u.status <> 'deleted'",
            ['id' => $id]
        );
        if (!$row) {
            throw new HttpException(404);
        }
        return $row;
    }

    /** @return array<int, array{id:int, name:string, slug:string}> */
    private function rolesOf(int $userId): array
    {
        return Database::fetchAll(
            'SELECT r.id, r.name, r.slug, r.is_active FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = :u ORDER BY r.name',
            ['u' => $userId]
        );
    }

    /** Super Admin role held (regardless of account status). */
    private function holdsSuperAdminRole(int $userId): bool
    {
        return (bool) Database::fetchColumn(
            'SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = :u AND r.slug = :s',
            ['u' => $userId, 's' => Gate::SUPER_ADMIN]
        );
    }

    /** Permissions granted by the target's roles (active or not), ignoring account status. */
    private function rolePermissionsOf(int $userId): array
    {
        return Database::fetchCol(
            'SELECT DISTINCT p.slug FROM user_roles ur
             JOIN role_permissions rp ON rp.role_id = ur.role_id
             JOIN permissions p ON p.id = rp.permission_id
             WHERE ur.user_id = :u',
            ['u' => $userId]
        );
    }

    /** Returns null when the actor may manage the target, else a human reason. */
    private function manageBlockReason(int $targetId): ?string
    {
        $actor = $this->actorId();
        if (Gate::isSuperAdmin($actor)) {
            return null;
        }
        if ($this->holdsSuperAdminRole($targetId)) {
            return 'Only a Super Admin can modify a Super Admin account.';
        }
        if (array_diff($this->rolePermissionsOf($targetId), Gate::permissionsFor($actor)) !== []) {
            return 'This staff member has permissions you do not hold, so you cannot modify their account.';
        }
        return null;
    }

    private function ensureCanManage(int $targetId): void
    {
        $reason = $this->manageBlockReason($targetId);
        if ($reason !== null) {
            AuditLogger::log('access.denied', 'staff', $targetId, null, ['reason' => $reason]);
            throw new HttpException(403, $reason);
        }
    }

    /** Active roles the actor may assign. */
    private function assignableRoles(): array
    {
        $actor = $this->actorId();
        $roles = Database::fetchAll('SELECT id, name, slug, description, is_system FROM roles WHERE is_active = 1 ORDER BY is_system DESC, name');
        return array_values(array_filter($roles, static fn ($r) => Gate::canAssignRole($actor, (int) $r['id'])));
    }

    /**
     * Server-side role validation. Requested roles must be active and assignable by the actor.
     * Roles the target already holds that the actor cannot assign are preserved untouched.
     * @return int[] final role ids
     */
    private function resolveRoles(array $requested, array $currentIds): array
    {
        $actor = $this->actorId();
        $requested = array_values(array_unique(array_filter(array_map('intval', $requested), static fn ($v) => $v > 0)));
        $activeIds = array_map('intval', Database::fetchCol('SELECT id FROM roles WHERE is_active = 1'));
        $final = [];
        foreach ($requested as $rid) {
            $alreadyHeld = in_array($rid, $currentIds, true);
            if (!$alreadyHeld && (!in_array($rid, $activeIds, true) || !Gate::canAssignRole($actor, $rid))) {
                AuditLogger::log('access.denied', 'role', $rid, null, ['reason' => 'role assignment not permitted']);
                throw new ValidationException(['roles' => 'You are not allowed to assign one or more of the selected roles.']);
            }
            if ($alreadyHeld && (!in_array($rid, $activeIds, true) || !Gate::canAssignRole($actor, $rid))) {
                continue; // added back below as preserved
            }
            $final[] = $rid;
        }
        foreach ($currentIds as $rid) {
            // Roles this actor cannot assign cannot be removed by them either; inactive roles are
            // not offered in the form, so they are kept as-is rather than silently dropped.
            if (!in_array($rid, $activeIds, true) || !Gate::canAssignRole($actor, $rid)) {
                $final[] = $rid;
            }
        }
        return array_values(array_unique($final));
    }

    private function roleNames(array $ids): array
    {
        if ($ids === []) {
            return [];
        }
        $params = [];
        $in = Database::in('r', $ids, $params);
        return Database::fetchCol("SELECT name FROM roles WHERE id IN $in ORDER BY name", $params);
    }

    private function emailTaken(string $email, ?int $ignoreId = null): bool
    {
        $sql = "SELECT 1 FROM users WHERE email = :e AND type = 'staff'";
        $params = ['e' => $email];
        if ($ignoreId) {
            $sql .= ' AND id <> :id';
            $params['id'] = $ignoreId;
        }
        return (bool) Database::fetchColumn($sql, $params);
    }

    private function profileRules(): array
    {
        return [
            'name' => 'required|string|max:120',
            'email' => 'required|email|max:190',
            'phone' => 'nullable|phone|max:20',
            'job_title' => 'nullable|string|max:100',
            'department' => 'nullable|string|max:100',
            'roles' => 'nullable|array',
        ];
    }

    private function nextEmployeeId(): string
    {
        $max = (int) Database::fetchColumn(
            "SELECT COALESCE(MAX(CAST(SUBSTRING(employee_id, 5) AS UNSIGNED)), 0) FROM staff_profiles WHERE employee_id LIKE 'EMP-%' FOR UPDATE"
        );
        return sprintf('EMP-%04d', $max + 1);
    }

    private function sendInvite(int $userId, string $email, string $name): array
    {
        $token = (new AuthService())->createToken($userId, 'invite');
        $link = admin_url('invite/' . $token);
        $actor = Auth::staff();
        $status = (new MailService())->send($email, 'staff_invitation', [
            'staff_name' => $name,
            'invite_url' => $link,
            'inviter' => $actor['name'] ?? 'An administrator',
        ]);
        return [$status, $link];
    }

    private function flashInviteResult(string $mailStatus, string $link): void
    {
        $msg = match ($mailStatus) {
            'sent' => 'Invitation email sent. The link is valid for 3 days.',
            'logged' => 'Invitation logged to the outbox (development mail mode: no email actually left the server).',
            'missing_template' => 'Account saved, but the "staff_invitation" email template is missing, so no invitation was sent.',
            default => 'Account saved, but the invitation email could not be delivered (status: ' . $mailStatus . '). Check the email outbox.',
        };
        flash(in_array($mailStatus, ['sent', 'logged'], true) ? 'success' : 'warning', $msg);
        if (config('app.env') === 'local') {
            Session::flash('invite_link', $link); // local convenience only; never in production
        }
    }

    // ---------------------------------------------------------------- pages

    public function index(Request $request): Response
    {
        $q = $request->str('q');
        $status = $request->str('status');
        $role = $request->int('role');
        $where = ["u.type = 'staff'", "u.status <> 'deleted'"];
        $params = [];
        if ($q !== '') {
            $where[] = '(u.name LIKE :q1 OR u.email LIKE :q2 OR sp.employee_id LIKE :q3)';
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $params += ['q1' => $like, 'q2' => $like, 'q3' => $like];
        }
        if (in_array($status, self::STATUSES, true)) {
            $where[] = 'u.status = :st';
            $params['st'] = $status;
        }
        if ($role > 0) {
            $where[] = 'EXISTS (SELECT 1 FROM user_roles ur2 WHERE ur2.user_id = u.id AND ur2.role_id = :role)';
            $params['role'] = $role;
        }
        $w = implode(' AND ', $where);
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM users u LEFT JOIN staff_profiles sp ON sp.user_id = u.id WHERE $w", $params);
        $p = Paginator::fromRequest($total, 25);
        $rows = Database::fetchAll(
            "SELECT u.id, u.name, u.email, u.status, u.last_login_at, u.must_change_password, u.created_at,
                    sp.employee_id, sp.job_title, sp.department,
                    (SELECT GROUP_CONCAT(r.name ORDER BY r.name SEPARATOR ', ') FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = u.id) AS role_names
             FROM users u LEFT JOIN staff_profiles sp ON sp.user_id = u.id
             WHERE $w ORDER BY u.name LIMIT " . (int) $p->perPage . ' OFFSET ' . (int) $p->offset,
            $params
        );
        return $this->adminView('staff/index', [
            'title' => 'Staff',
            'rows' => $rows,
            'paginator' => $p,
            'filters' => ['q' => $q, 'status' => $status, 'role' => $role],
            'allRoles' => Database::fetchAll('SELECT id, name FROM roles ORDER BY name'),
            'statuses' => self::STATUSES,
        ]);
    }

    public function create(Request $request): Response
    {
        return $this->adminView('staff/form', [
            'title' => 'Invite staff member',
            'member' => null,
            'assignable' => $this->assignableRoles(),
            'currentRoleIds' => [],
            'lockedRoles' => [],
            'isSelf' => false,
        ]);
    }

    public function store(Request $request): Response
    {
        Gate::authorize('staff.manage');
        $data = $this->validate($request, array_merge($this->profileRules(), ['roles' => 'required|array|min:1']));
        $email = mb_strtolower((string) $data['email']);
        if ($this->emailTaken($email)) {
            throw new ValidationException(['email' => 'A staff account with this email already exists.'], $request->all());
        }
        $roleIds = $this->resolveRoles($request->arr('roles'), []);
        if ($roleIds === []) {
            throw new ValidationException(['roles' => 'Select at least one role.'], $request->all());
        }
        $actor = $this->actorId();

        $attempts = 0;
        while (true) {
            try {
                [$userId, $employeeId] = Database::transaction(function () use ($data, $email, $roleIds, $actor) {
                    $employeeId = $this->nextEmployeeId();
                    $userId = Database::insert('users', [
                        'type' => 'staff',
                        'name' => $data['name'],
                        'email' => $email,
                        'phone' => $data['phone'] ?: null,
                        'password_hash' => null,
                        'status' => 'pending',
                        'must_change_password' => 1,
                    ]);
                    Database::insert('staff_profiles', [
                        'user_id' => $userId,
                        'employee_id' => $employeeId,
                        'job_title' => $data['job_title'] ?: null,
                        'department' => $data['department'] ?: null,
                        'invited_by' => $actor,
                    ]);
                    foreach ($roleIds as $rid) {
                        Database::insert('user_roles', ['user_id' => $userId, 'role_id' => $rid, 'assigned_by' => $actor]);
                    }
                    return [$userId, $employeeId];
                });
                break;
            } catch (\PDOException $e) {
                // Concurrent creation picked the same employee id: retry with the next number.
                if (++$attempts >= 3 || !str_contains($e->getMessage(), 'uq_staff_employee')) {
                    if (str_contains($e->getMessage(), 'uq_users_email_type')) {
                        throw new ValidationException(['email' => 'A staff account with this email already exists.'], $request->all());
                    }
                    throw $e;
                }
            }
        }

        AuditLogger::log('staff.created', 'staff', $userId, null, [
            'name' => $data['name'], 'email' => $email, 'employee_id' => $employeeId,
            'status' => 'pending', 'roles' => $this->roleNames($roleIds),
        ]);
        [$mailStatus, $link] = $this->sendInvite($userId, $email, (string) $data['name']);
        AuditLogger::log('staff.invite_sent', 'staff', $userId, null, ['mail_status' => $mailStatus]);
        $this->flashInviteResult($mailStatus, $link);
        return $this->redirect(admin_url('staff/' . $userId));
    }

    public function show(Request $request, string $id): Response
    {
        $member = $this->findStaff((int) $id);
        $uid = (int) $member['id'];
        $total = (int) Database::fetchColumn('SELECT COUNT(*) FROM audit_logs WHERE user_id = :u', ['u' => $uid]);
        $p = Paginator::fromRequest($total, 20);
        $activity = Database::fetchAll(
            'SELECT id, action, entity_type, entity_id, ip, created_at FROM audit_logs WHERE user_id = :u ORDER BY id DESC LIMIT ' . (int) $p->perPage . ' OFFSET ' . (int) $p->offset,
            ['u' => $uid]
        );
        $history = Database::fetchAll(
            "SELECT a.id, a.action, a.created_at, u.name AS actor_name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
             WHERE a.entity_type = 'staff' AND a.entity_id = :e ORDER BY a.id DESC LIMIT 15",
            ['e' => $uid]
        );
        return $this->adminView('staff/show', [
            'title' => $member['name'],
            'member' => $member,
            'roles' => $this->rolesOf($uid),
            'activity' => $activity,
            'history' => $history,
            'paginator' => $p,
            'isSelf' => $uid === $this->actorId(),
            'blockReason' => $uid === $this->actorId() ? null : $this->manageBlockReason($uid),
            'inviteLink' => config('app.env') === 'local' ? Session::getFlash('invite_link') : null,
        ]);
    }

    public function edit(Request $request, string $id): Response
    {
        $member = $this->findStaff((int) $id);
        $uid = (int) $member['id'];
        $isSelf = $uid === $this->actorId();
        if (!$isSelf) {
            $this->ensureCanManage($uid);
        }
        $current = $this->rolesOf($uid);
        $actor = $this->actorId();
        $locked = array_values(array_filter($current, static fn ($r) => (int) $r['is_active'] !== 1 || !Gate::canAssignRole($actor, (int) $r['id'])));
        return $this->adminView('staff/form', [
            'title' => 'Edit ' . $member['name'],
            'member' => $member,
            'assignable' => $this->assignableRoles(),
            'currentRoleIds' => array_map(static fn ($r) => (int) $r['id'], $current),
            'currentRoles' => $current,
            'lockedRoles' => $locked,
            'isSelf' => $isSelf,
        ]);
    }

    public function update(Request $request, string $id): Response
    {
        Gate::authorize('staff.manage');
        $member = $this->findStaff((int) $id);
        $uid = (int) $member['id'];
        $isSelf = $uid === $this->actorId();
        if (!$isSelf) {
            $this->ensureCanManage($uid);
        }
        $data = $this->validate($request, $this->profileRules());
        $email = mb_strtolower((string) $data['email']);
        if ($this->emailTaken($email, $uid)) {
            throw new ValidationException(['email' => 'A staff account with this email already exists.'], $request->all());
        }

        $currentIds = array_map(static fn ($r) => (int) $r['id'], $this->rolesOf($uid));
        $newIds = $currentIds;
        if (!$isSelf) {
            // An actor can never change their own roles: on self-edit the roles input is ignored entirely.
            $newIds = $this->resolveRoles($request->arr('roles'), $currentIds);
            if ($newIds === []) {
                throw new ValidationException(['roles' => 'A staff member needs at least one role.'], $request->all());
            }
        }

        $oldProfile = [
            'name' => $member['name'], 'email' => $member['email'], 'phone' => $member['phone'],
            'job_title' => $member['job_title'], 'department' => $member['department'],
        ];
        $newProfile = [
            'name' => $data['name'], 'email' => $email, 'phone' => $data['phone'] ?: null,
            'job_title' => $data['job_title'] ?: null, 'department' => $data['department'] ?: null,
        ];
        $actor = $this->actorId();

        Database::transaction(function () use ($uid, $newProfile, $currentIds, $newIds, $actor, $member) {
            Database::update('users', [
                'name' => $newProfile['name'], 'email' => $newProfile['email'], 'phone' => $newProfile['phone'],
            ], ['id' => $uid]);
            if ($member['employee_id'] === null) {
                Database::insert('staff_profiles', [
                    'user_id' => $uid, 'employee_id' => $this->nextEmployeeId(),
                    'job_title' => $newProfile['job_title'], 'department' => $newProfile['department'],
                ]);
            } else {
                Database::update('staff_profiles', ['job_title' => $newProfile['job_title'], 'department' => $newProfile['department']], ['user_id' => $uid]);
            }
            foreach (array_diff($currentIds, $newIds) as $rid) {
                Database::delete('user_roles', ['user_id' => $uid, 'role_id' => $rid]);
            }
            foreach (array_diff($newIds, $currentIds) as $rid) {
                Database::insert('user_roles', ['user_id' => $uid, 'role_id' => $rid, 'assigned_by' => $actor]);
            }
        });

        $old = [];
        $new = [];
        foreach ($newProfile as $k => $v) {
            if ((string) ($oldProfile[$k] ?? '') !== (string) ($v ?? '')) {
                $old[$k] = $oldProfile[$k];
                $new[$k] = $v;
            }
        }
        sort($currentIds);
        sort($newIds);
        if ($currentIds !== $newIds) {
            $old['roles'] = $this->roleNames($currentIds);
            $new['roles'] = $this->roleNames($newIds);
            // Role changes take effect on the next request (permissions are resolved per request).
        }
        if ($old !== [] || $new !== []) {
            AuditLogger::log(isset($new['roles']) ? 'staff.roles_updated' : 'staff.updated', 'staff', $uid, $old, $new);
        }
        if ($isSelf && $request->arr('roles') !== []) {
            flash('info', 'Profile saved. You cannot change your own roles; ask another administrator.');
        } else {
            flash('success', 'Staff member updated.');
        }
        return $this->redirect(admin_url('staff/' . $uid));
    }

    public function status(Request $request, string $id): Response
    {
        Gate::authorize('staff.manage');
        $member = $this->findStaff((int) $id);
        $uid = (int) $member['id'];
        if ($uid === $this->actorId()) {
            flash('error', 'You cannot change the status of your own account.');
            return $this->redirect(admin_url('staff/' . $uid));
        }
        $this->ensureCanManage($uid);
        $action = $request->str('action');
        if ($action === 'deactivate') {
            if ($member['status'] === 'inactive') {
                return $this->redirect(admin_url('staff/' . $uid));
            }
            Database::update('users', ['status' => 'inactive'], ['id' => $uid]);
            Auth::revokeSessions($uid);
            // Unused invitation / reset links must not reactivate access.
            Database::query("UPDATE user_tokens SET used_at = UTC_TIMESTAMP() WHERE user_id = :u AND used_at IS NULL AND type IN ('invite','reset')", ['u' => $uid]);
            AuditLogger::log('staff.deactivated', 'staff', $uid, ['status' => $member['status']], ['status' => 'inactive', 'sessions_revoked' => true]);
            flash('success', $member['name'] . ' has been deactivated and signed out everywhere.');
        } elseif ($action === 'activate') {
            if ($member['status'] !== 'inactive') {
                return $this->redirect(admin_url('staff/' . $uid));
            }
            // Accounts that never accepted their invitation go back to pending (no password yet).
            $hasPassword = (bool) Database::fetchColumn('SELECT password_hash IS NOT NULL FROM users WHERE id = :id', ['id' => $uid]);
            $newStatus = $hasPassword ? 'active' : 'pending';
            Database::update('users', ['status' => $newStatus], ['id' => $uid]);
            AuditLogger::log('staff.activated', 'staff', $uid, ['status' => 'inactive'], ['status' => $newStatus]);
            flash('success', $hasPassword ? $member['name'] . ' has been reactivated.' : 'Account set back to pending. Resend the invitation so they can set a password.');
        } else {
            throw new HttpException(400, 'Unknown action.');
        }
        return $this->redirect(admin_url('staff/' . $uid));
    }

    public function revokeSessions(Request $request, string $id): Response
    {
        Gate::authorize('staff.manage');
        $member = $this->findStaff((int) $id);
        $uid = (int) $member['id'];
        if ($uid === $this->actorId()) {
            flash('error', 'To end your own sessions, change your password or sign out.');
            return $this->redirect(admin_url('staff/' . $uid));
        }
        $this->ensureCanManage($uid);
        Auth::revokeSessions($uid);
        AuditLogger::log('staff.sessions_revoked', 'staff', $uid);
        flash('success', 'All sessions for ' . $member['name'] . ' have been signed out.');
        return $this->redirect(admin_url('staff/' . $uid));
    }

    public function resendInvite(Request $request, string $id): Response
    {
        Gate::authorize('staff.manage');
        $member = $this->findStaff((int) $id);
        $uid = (int) $member['id'];
        $this->ensureCanManage($uid);
        if ($member['status'] !== 'pending') {
            flash('error', 'Invitations can only be resent to accounts that have not been activated yet.');
            return $this->redirect(admin_url('staff/' . $uid));
        }
        // createToken() invalidates any previous unused invite link.
        [$mailStatus, $link] = $this->sendInvite($uid, (string) $member['email'], (string) $member['name']);
        AuditLogger::log('staff.invite_resent', 'staff', $uid, null, ['mail_status' => $mailStatus]);
        $this->flashInviteResult($mailStatus, $link);
        return $this->redirect(admin_url('staff/' . $uid));
    }

    public function forcePassword(Request $request, string $id): Response
    {
        Gate::authorize('staff.manage');
        $member = $this->findStaff((int) $id);
        $uid = (int) $member['id'];
        if ($uid === $this->actorId()) {
            flash('error', 'Use "Change password" to update your own password.');
            return $this->redirect(admin_url('staff/' . $uid));
        }
        $this->ensureCanManage($uid);
        $flag = $request->bool('required') ? 1 : 0;
        Database::update('users', ['must_change_password' => $flag], ['id' => $uid]);
        AuditLogger::log('staff.force_password_change', 'staff', $uid, ['must_change_password' => (int) $member['must_change_password']], ['must_change_password' => $flag]);
        flash('success', $flag ? 'They will be asked to set a new password on their next request.' : 'Password change requirement removed.');
        return $this->redirect(admin_url('staff/' . $uid));
    }
}
