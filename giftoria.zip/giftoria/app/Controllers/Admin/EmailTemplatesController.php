<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Services\MailService;

/**
 * Admin > Email templates and the email outbox.
 * Template HTML is sanitised server-side (no <script>, no on* handlers, no javascript: URLs).
 * Previews always render inside a sandboxed iframe (srcdoc, no allow-scripts).
 * Outbox bodies have one-time tokens (reset/invite/verify links, order access tokens) redacted,
 * so template editors cannot use the outbox to take over another account.
 */
final class EmailTemplatesController extends Controller
{
    public const OUTBOX_STATUSES = [
        'logged' => 'Logged · not sent (development mail mode)',
        'sent' => 'Sent · accepted by SMTP server',
        'failed' => 'Failed · not delivered',
    ];

    /** Removes scripts, event-handler attributes, javascript:/vbscript: URLs and embedded frames/objects. */
    public static function sanitize(string $html): string
    {
        $html = preg_replace('#<\s*(script|iframe|object|embed|applet|meta|base|link)\b[^>]*>.*?<\s*/\s*\1\s*>#is', '', $html) ?? '';
        $html = preg_replace('#<\s*/?\s*(script|iframe|object|embed|applet|meta|base|link)\b[^>]*>#is', '', $html) ?? '';
        // on* attributes (quoted or unquoted), e.g. onclick="..." onerror=alert(1)
        do {
            $before = $html;
            $html = preg_replace('#(<[^>]*?)[\s/]+on[a-z0-9_-]+\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)#is', '$1', $html) ?? '';
        } while ($html !== $before);
        // javascript:/vbscript:/data: (non-image) URLs in href/src/action/xlink:href/formaction
        $html = preg_replace_callback(
            '#\b(href|src|action|formaction|xlink:href)\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s>]+))#i',
            static function (array $m): string {
                $url = html_entity_decode($m[3] !== '' ? $m[3] : (($m[4] ?? '') !== '' ? $m[4] : ($m[5] ?? '')), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $norm = strtolower(preg_replace('/[\x00-\x20]+/', '', $url) ?? '');
                if (str_starts_with($norm, 'javascript:') || str_starts_with($norm, 'vbscript:')
                    || (str_starts_with($norm, 'data:') && !str_starts_with($norm, 'data:image/'))) {
                    return $m[1] . '="#"';
                }
                return $m[0];
            },
            $html
        ) ?? '';
        // CSS expressions / javascript: in inline styles
        $html = preg_replace('#expression\s*\(|javascript\s*:#i', '', $html) ?? '';
        return $html;
    }

    /** "customer_name, verify_url" or "{{customer_name}} {{verify_url}}" -> ['customer_name', 'verify_url'] */
    public static function variables(?string $raw): array
    {
        preg_match_all('/[A-Za-z_][A-Za-z0-9_]*/', (string) $raw, $m);
        $vars = array_values(array_unique($m[0]));
        foreach (['store_name', 'store_url', 'store_email', 'year'] as $global) {
            if (!in_array($global, $vars, true)) {
                $vars[] = $global;
            }
        }
        return $vars;
    }

    /** Sample values for previews (never real customer data). */
    public static function sampleVars(array $vars): array
    {
        $samples = [
            'customer_name' => 'Aasha Shrestha', 'staff_name' => 'Bikash Thapa', 'inviter' => 'Store Admin',
            'order_number' => 'GFT-240001', 'order_total' => 'NPR 3,450', 'order_status' => 'Shipped',
            'payment_method' => 'ESEWA', 'carrier' => 'Pathao', 'tracking_number' => 'PTH123456',
            'refund_amount' => 'NPR 1,200', 'store_name' => (string) setting('store_name', config('app.name')),
            'store_email' => (string) setting('store_email', ''), 'year' => gmdate('Y'),
            'items_table' => '<table width="100%" style="border-collapse:collapse"><tr><td style="padding:8px 0;border-bottom:1px solid #eee">Handmade pashmina shawl × 1</td><td style="padding:8px 0;border-bottom:1px solid #eee;text-align:right">NPR 3,450</td></tr></table>',
        ];
        $out = [];
        foreach ($vars as $v) {
            if (isset($samples[$v])) {
                $out[$v] = $samples[$v];
            } elseif (str_ends_with($v, '_url')) {
                $out[$v] = url('/example/' . $v);
            } else {
                $out[$v] = '[' . $v . ']';
            }
        }
        return $out;
    }

    /** Redacts 32+ hex-character tokens (reset/invite/verify links, order access tokens). */
    public static function redactTokens(string $html): string
    {
        return preg_replace('/\b[a-f0-9]{32,}\b/i', '[redacted-token]', $html) ?? '';
    }

    private function findTemplate(int $id): array
    {
        $t = Database::fetch('SELECT * FROM email_templates WHERE id = :id', ['id' => $id]);
        if (!$t) {
            throw new HttpException(404);
        }
        return $t;
    }

    // ------------------------------------------------------------ templates

    public function index(Request $request): Response
    {
        $templates = Database::fetchAll('SELECT id, template_key, name, subject, variables, updated_at FROM email_templates ORDER BY name');
        $counts = [];
        foreach (Database::fetchAll('SELECT status, COUNT(*) AS n FROM email_outbox GROUP BY status') as $r) {
            $counts[$r['status']] = (int) $r['n'];
        }
        return $this->adminView('emails/index', [
            'title' => 'Email templates',
            'templates' => $templates,
            'outboxCounts' => $counts,
            'mailMode' => (string) config('mail.mode', 'log'),
        ]);
    }

    public function edit(Request $request, string $id): Response
    {
        $t = $this->findTemplate((int) $id);
        $vars = self::variables($t['variables']);
        $samples = self::sampleVars($vars);
        return $this->adminView('emails/edit', [
            'title' => 'Edit email: ' . $t['name'],
            'template' => $t,
            'vars' => $vars,
            'samples' => $samples,
            'previewSubject' => MailService::render((string) $t['subject'], $samples, true),
            'previewHtml' => self::sanitize(MailService::render((string) $t['body_html'], $samples)),
        ]);
    }

    public function update(Request $request, string $id): Response
    {
        Gate::authorize('content.manage');
        $t = $this->findTemplate((int) $id);
        $data = $this->validate($request, [
            'subject' => 'required|string|max:190',
            'body_html' => 'required|string|max:200000',
        ], ['body_html' => 'Email body']);
        $subject = trim(strip_tags((string) $data['subject']));
        $body = self::sanitize((string) $data['body_html']);
        $stripped = $body !== (string) $data['body_html'];

        Database::update('email_templates', ['subject' => $subject, 'body_html' => $body], ['id' => (int) $t['id']]);
        $old = [];
        $new = [];
        if ($subject !== $t['subject']) {
            $old['subject'] = $t['subject'];
            $new['subject'] = $subject;
        }
        if ($body !== $t['body_html']) {
            $old['body_sha1'] = sha1((string) $t['body_html']);
            $old['body_length'] = strlen((string) $t['body_html']);
            $new['body_sha1'] = sha1($body);
            $new['body_length'] = strlen($body);
        }
        if ($new) {
            AuditLogger::log('email_template.updated', 'email_template', (int) $t['id'], $old + ['key' => $t['template_key']], $new + ['key' => $t['template_key']]);
        }
        flash($stripped ? 'warning' : 'success', $stripped
            ? 'Template saved. Scripts, event handlers or unsafe links were removed for security.'
            : 'Template saved.');
        return $this->redirect(admin_url('emails/' . (int) $t['id'] . '/edit'));
    }

    // --------------------------------------------------------------- outbox

    public function outbox(Request $request): Response
    {
        $status = $request->str('status');
        $q = $request->str('q');
        $where = [];
        $params = [];
        if (isset(self::OUTBOX_STATUSES[$status])) {
            $where[] = 'status = :st';
            $params['st'] = $status;
        }
        if ($q !== '') {
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $where[] = '(to_email LIKE :q1 OR subject LIKE :q2 OR template_key LIKE :q3)';
            $params += ['q1' => $like, 'q2' => $like, 'q3' => $like];
        }
        $w = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM email_outbox $w", $params);
        $p = Paginator::fromRequest($total, 30);
        $rows = Database::fetchAll(
            "SELECT id, to_email, subject, template_key, status, error, created_at FROM email_outbox $w ORDER BY id DESC LIMIT " . (int) $p->perPage . ' OFFSET ' . (int) $p->offset,
            $params
        );
        return $this->adminView('emails/outbox', [
            'title' => 'Email outbox',
            'rows' => $rows,
            'paginator' => $p,
            'filters' => ['status' => $status, 'q' => $q],
            'statuses' => self::OUTBOX_STATUSES,
            'mailMode' => (string) config('mail.mode', 'log'),
        ]);
    }

    public function outboxShow(Request $request, string $id): Response
    {
        $m = Database::fetch('SELECT * FROM email_outbox WHERE id = :id', ['id' => (int) $id]);
        if (!$m) {
            throw new HttpException(404);
        }
        $body = self::redactTokens(self::sanitize((string) $m['body_html']));
        return $this->adminView('emails/outbox-show', [
            'title' => 'Outbox message #' . (int) $m['id'],
            'message' => $m,
            'body' => $body,
            'statuses' => self::OUTBOX_STATUSES,
        ]);
    }
}
