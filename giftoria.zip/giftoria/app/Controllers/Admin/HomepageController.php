<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\Uploader;
use App\Core\ValidationException;
use App\Core\Validator;
use App\Repositories\TaxonomyRepository;
use App\Services\HomepageService;

/**
 * Homepage builder: order, visibility, text and type-specific config (config_json) of
 * homepage_sections. Banner content itself is managed through Campaigns.
 */
final class HomepageController extends Controller
{
    public const PRODUCT_SOURCES = [
        'bestseller' => 'Bestsellers',
        'new' => 'New arrivals',
        'featured' => 'Featured products',
        'personalized' => 'Personalizable gifts',
        'manual' => 'Hand-picked products',
        'category' => 'Category (slug)',
        'interest' => 'Interest (slug)',
        'recipient' => 'Recipient (slug)',
        'occasion' => 'Occasion (slug)',
        'last_minute' => 'Last-minute gifts (ships today)',
    ];

    /** Sources that need a taxonomy slug in "value", mapped to their table. */
    private const VALUE_TABLES = ['category' => 'categories', 'interest' => 'interests', 'recipient' => 'recipients', 'occasion' => 'occasions'];

    public const TYPE_LABELS = [
        'hero' => 'Hero banner', 'gift_finder' => 'Gift Finder', 'taxonomy_grid' => 'Taxonomy grid', 'budget_grid' => 'Shop by budget',
        'products' => 'Product carousel', 'collection' => 'Editorial collection', 'campaigns' => 'Campaign banners', 'story' => 'Brand story',
        'makers' => 'Featured makers', 'reviews' => 'Customer reviews', 'newsletter' => 'Newsletter sign-up', 'trust' => 'Trust badges',
    ];

    public function index(Request $request): Response
    {
        $sections = (new HomepageService())->sections(false);
        return $this->adminView('homepage/index', ['title' => 'Homepage', 'sections' => $sections]);
    }

    public function reorder(Request $request): Response
    {
        Gate::authorize('homepage.edit');
        $ids = array_values(array_unique(array_filter(array_map('intval', explode(',', $request->str('order'))), static fn ($i) => $i > 0)));
        $existing = array_map('intval', Database::fetchCol('SELECT id FROM homepage_sections ORDER BY sort_order, id'));
        if (!$ids || array_diff($ids, $existing)) {
            flash('error', 'The section order could not be saved. Please reload and try again.');
            return $this->redirect(admin_url('homepage'));
        }
        // Sections missing from the submitted list keep their relative order after the listed ones.
        $ordered = array_merge($ids, array_values(array_diff($existing, $ids)));
        Database::transaction(static function () use ($ordered): void {
            foreach ($ordered as $pos => $id) {
                Database::update('homepage_sections', ['sort_order' => ($pos + 1) * 10], ['id' => $id]);
            }
        });
        AuditLogger::log('homepage.reordered', 'homepage_section', null, ['order' => $existing], ['order' => $ordered]);
        flash('success', 'Homepage order saved.');
        return $this->redirect(admin_url('homepage'));
    }

    public function toggle(Request $request, string $id): Response
    {
        Gate::authorize('homepage.edit');
        $s = $this->find((int) $id);
        $new = (int) $s['is_enabled'] === 1 ? 0 : 1;
        Database::update('homepage_sections', ['is_enabled' => $new], ['id' => (int) $s['id']]);
        AuditLogger::log('homepage.section_toggled', 'homepage_section', (int) $s['id'], ['is_enabled' => (int) $s['is_enabled']], ['is_enabled' => $new]);
        flash('success', '“' . ($s['title'] ?: $s['section_key']) . '” is now ' . ($new ? 'visible' : 'hidden') . ' on the homepage.');
        return $this->redirect(admin_url('homepage'));
    }

    public function edit(Request $request, string $id): Response
    {
        $s = $this->find((int) $id);
        $tax = new TaxonomyRepository();
        return $this->adminView('homepage/edit', [
            'title' => 'Edit homepage section',
            'section' => $s,
            'products' => Database::fetchAll("SELECT id, name, sku FROM products WHERE status = 'active' ORDER BY name LIMIT 1000"),
            'slugOptions' => [
                'category' => Database::fetchAll('SELECT slug, name FROM categories WHERE is_active = 1 ORDER BY name'),
                'interest' => array_map(static fn ($r) => ['slug' => $r['slug'], 'name' => $r['name']], $tax->all('interests')),
                'recipient' => array_map(static fn ($r) => ['slug' => $r['slug'], 'name' => $r['name']], $tax->all('recipients')),
                'occasion' => array_map(static fn ($r) => ['slug' => $r['slug'], 'name' => $r['name']], $tax->all('occasions')),
            ],
        ]);
    }

    public function update(Request $request, string $id): Response
    {
        Gate::authorize('homepage.edit');
        $s = $this->find((int) $id);
        $v = Validator::make($request->all(), [
            'title' => ['nullable', 'string', 'max:190'],
            'subtitle' => ['nullable', 'string', 'max:500'],
        ]);
        $errors = $v->fails() ? $v->errors() : [];
        $d = $v->validated();

        [$config, $configErrors, $newImage] = $this->configFor($s, $request, $errors === []);
        $errors += $configErrors;
        if ($errors) {
            if ($newImage) {
                Uploader::delete($newImage);
            }
            throw new ValidationException($errors, $request->all());
        }

        $data = [
            'title' => ($d['title'] ?? '') !== '' ? $d['title'] : null,
            'subtitle' => ($d['subtitle'] ?? '') !== '' ? $d['subtitle'] : null,
            'config_json' => json_encode($config, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'is_enabled' => $request->bool('is_enabled') ? 1 : 0,
        ];
        Database::update('homepage_sections', $data, ['id' => (int) $s['id']]);
        $oldImage = $s['config']['image'] ?? null;
        if ($oldImage && ($config['image'] ?? null) !== $oldImage) {
            Uploader::delete((string) $oldImage);
        }
        AuditLogger::log('homepage.section_updated', 'homepage_section', (int) $s['id'],
            ['title' => $s['title'], 'subtitle' => $s['subtitle'], 'config' => $s['config'], 'is_enabled' => (int) $s['is_enabled']],
            ['title' => $data['title'], 'subtitle' => $data['subtitle'], 'config' => $config, 'is_enabled' => $data['is_enabled']]
        );
        flash('success', 'Section saved.');
        return $this->redirect(admin_url('homepage'));
    }

    private function find(int $id): array
    {
        $s = Database::fetch('SELECT * FROM homepage_sections WHERE id = :id', ['id' => $id]);
        if (!$s) {
            throw new HttpException(404);
        }
        $s['config'] = json_decode((string) $s['config_json'], true) ?: [];
        return $s;
    }

    /**
     * Builds and validates config for the section type. Unknown keys already stored are preserved.
     * @return array{0: array, 1: array<string,string>, 2: ?string} [config, errors, newly uploaded image]
     */
    private function configFor(array $s, Request $request, bool $allowUpload): array
    {
        $cfg = $s['config'];
        $errors = [];
        $newImage = null;
        $type = (string) $s['type'];

        $text = static function (string $key, int $max) use ($request, &$errors): string {
            $v = $request->str($key);
            if (mb_strlen($v) > $max) {
                $errors[$key] = 'This field may not exceed ' . $max . ' characters.';
            }
            return $v;
        };
        $link = static function (string $key) use ($request, &$errors): string {
            $v = $request->str($key);
            if ($v !== '' && (mb_strlen($v) > 255 || !CampaignsController::safeCtaUrl($v))) {
                $errors[$key] = 'Use a path starting with / (e.g. /shop) or a full https:// URL.';
            }
            return $v;
        };
        $image = function () use ($request, $cfg, $allowUpload, &$errors, &$newImage): ?string {
            $file = $request->file('image');
            if ($file && ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                if (!$allowUpload) {
                    return $cfg['image'] ?? null;
                }
                try {
                    $newImage = Uploader::image($file, 'homepage');
                    return $newImage;
                } catch (\RuntimeException $e) {
                    $errors['image'] = $e->getMessage();
                    return $cfg['image'] ?? null;
                }
            }
            if ($request->bool('remove_image')) {
                return null;
            }
            return $cfg['image'] ?? null;
        };

        switch ($type) {
            case 'hero':
                $cfg['eyebrow'] = $text('eyebrow', 80);
                $cfg['cta_label'] = $text('cta_label', 60);
                $cfg['cta_url'] = $link('cta_url');
                $cfg['secondary_label'] = $text('secondary_label', 60);
                $cfg['secondary_url'] = $link('secondary_url');
                if ($cfg['cta_label'] !== '' && $cfg['cta_url'] === '' && !isset($errors['cta_url'])) {
                    $errors['cta_url'] = 'Add a link for the main button.';
                }
                if ($cfg['secondary_label'] !== '' && $cfg['secondary_url'] === '' && !isset($errors['secondary_url'])) {
                    $errors['secondary_url'] = 'Add a link for the secondary button.';
                }
                $cfg['image'] = $image();
                break;

            case 'products':
            case 'collection':
                $source = $request->str('source');
                if (!isset(self::PRODUCT_SOURCES[$source])) {
                    $errors['source'] = 'Choose a product source.';
                    $source = 'bestseller';
                }
                $cfg['source'] = $source;
                $value = strtolower($request->str('value'));
                if (isset(self::VALUE_TABLES[$source])) {
                    $table = self::VALUE_TABLES[$source];
                    if ($value === '' || !Database::fetchColumn("SELECT 1 FROM `$table` WHERE slug = :s", ['s' => $value])) {
                        $errors['value'] = 'Enter an existing ' . $source . ' slug.';
                    }
                    $cfg['value'] = $value;
                } else {
                    $cfg['value'] = '';
                }
                $ids = array_values(array_unique(array_filter(array_map('intval', array_filter($request->arr('product_ids'), 'is_scalar')), static fn ($i) => $i > 0)));
                if ($ids) {
                    $params = [];
                    $in = Database::in('pid', array_slice($ids, 0, 24), $params);
                    $found = array_map('intval', Database::fetchCol("SELECT id FROM products WHERE id IN $in", $params));
                    $ids = array_values(array_intersect(array_slice($ids, 0, 24), $found));
                }
                if ($source === 'manual' && !$ids) {
                    $errors['product_ids'] = 'Pick at least one product for a hand-picked list.';
                }
                $cfg['product_ids'] = $source === 'manual' ? $ids : [];
                $limit = $request->int('limit', 8);
                if ($limit < 1 || $limit > 24) {
                    $errors['limit'] = 'Show between 1 and 24 products.';
                }
                $cfg['limit'] = max(1, min(24, $limit));
                if ($type === 'collection') {
                    $cfg['cta_label'] = $text('cta_label', 60);
                    $cfg['cta_url'] = $link('cta_url');
                    if ($cfg['cta_label'] !== '' && $cfg['cta_url'] === '' && !isset($errors['cta_url'])) {
                        $errors['cta_url'] = 'Add a link for the button.';
                    }
                    $cfg['image'] = $image();
                }
                break;

            case 'taxonomy_grid':
                $taxonomy = $request->str('taxonomy');
                if (!in_array($taxonomy, TaxonomyRepository::TYPES, true)) {
                    $errors['taxonomy'] = 'Choose recipients, occasions or interests.';
                    $taxonomy = 'recipients';
                }
                $cfg['taxonomy'] = $taxonomy;
                $slugs = array_values(array_unique(array_filter(array_map(
                    static fn ($x) => strtolower(trim($x)),
                    preg_split('/[\s,]+/', $request->str('slugs')) ?: []
                ))));
                if ($slugs) {
                    $known = Database::fetchCol("SELECT slug FROM `$taxonomy`");
                    $unknown = array_diff($slugs, $known);
                    if ($unknown) {
                        $errors['slugs'] = 'Unknown ' . $taxonomy . ' slug(s): ' . implode(', ', array_slice($unknown, 0, 8)) . '.';
                    }
                }
                $cfg['slugs'] = array_slice($slugs, 0, 30);
                $limit = $request->int('limit', 12);
                if ($limit < 1 || $limit > 30) {
                    $errors['limit'] = 'Show between 1 and 30 items.';
                }
                $cfg['limit'] = max(1, min(30, $limit));
                break;

            default:
                // Text-only / data-driven sections: only title & subtitle are editable.
                break;
        }
        return [$cfg, $errors, $newImage];
    }
}
