<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Cache;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;
use App\Services\SettingsService;
use App\Services\ShippingService;

/** Admin > Settings: store, checkout, delivery zones and a read-only payments overview. */
final class SettingsController extends Controller
{
    private const STORE_KEYS = ['store_name', 'store_email', 'store_phone', 'store_address', 'announcement_text', 'announcement_enabled', 'social_facebook', 'social_instagram'];
    private const CHECKOUT_KEYS = ['gift_wrap_fee', 'cod_max_order', 'review_auto_approve_verified', 'low_stock_alert_email'];

    private function values(array $keys): array
    {
        $out = [];
        foreach ($keys as $k) {
            $out[$k] = SettingsService::get($k, SettingsService::DEFAULTS[$k] ?? null);
        }
        return $out;
    }

    /** Saves changed settings, invalidates caches and writes one audit entry with the diff. */
    private function persist(array $values, string $group): int
    {
        $old = [];
        $new = [];
        foreach ($values as $k => $v) {
            $current = SettingsService::get($k, SettingsService::DEFAULTS[$k] ?? null);
            if (json_encode($current) === json_encode($v)) {
                continue;
            }
            SettingsService::set($k, $v, $group);
            $old[$k] = $current;
            $new[$k] = $v;
        }
        Cache::bump('settings');
        SettingsService::flush();
        if ($new !== []) {
            AuditLogger::log('settings.updated', 'settings', null, $old + ['group' => $group], $new + ['group' => $group]);
        }
        return count($new);
    }

    // ---------------------------------------------------------------- store

    public function store(Request $request): Response
    {
        return $this->adminView('settings/store', ['title' => 'Settings', 'tab' => 'store', 'values' => $this->values(self::STORE_KEYS)]);
    }

    public function saveStore(Request $request): Response
    {
        Gate::authorize('settings.manage');
        $https = 'regex:#^https://[^\s]+$#i';
        $data = $this->validate($request, [
            'store_name' => 'required|string|max:120',
            'store_email' => 'required|email|max:190',
            'store_phone' => 'nullable|string|max:40|regex:/^[0-9+()\-\s]{6,40}$/',
            'store_address' => 'nullable|string|max:255',
            'announcement_text' => 'nullable|string|max:255',
            'social_facebook' => 'nullable|url|max:255|' . $https,
            'social_instagram' => 'nullable|url|max:255|' . $https,
        ], ['social_facebook' => 'Facebook URL', 'social_instagram' => 'Instagram URL']);
        if ($request->bool('announcement_enabled') && trim((string) $data['announcement_text']) === '') {
            throw new ValidationException(['announcement_text' => 'Enter announcement text or turn the announcement off.'], $request->all());
        }
        $n = $this->persist([
            'store_name' => (string) $data['store_name'],
            'store_email' => mb_strtolower((string) $data['store_email']),
            'store_phone' => (string) ($data['store_phone'] ?? ''),
            'store_address' => (string) ($data['store_address'] ?? ''),
            'announcement_text' => (string) ($data['announcement_text'] ?? ''),
            'announcement_enabled' => $request->bool('announcement_enabled'),
            'social_facebook' => (string) ($data['social_facebook'] ?? ''),
            'social_instagram' => (string) ($data['social_instagram'] ?? ''),
        ], 'store');
        flash('success', $n ? 'Store settings saved.' : 'No changes to save.');
        return $this->redirect(admin_url('settings'));
    }

    // ------------------------------------------------------------- checkout

    public function checkout(Request $request): Response
    {
        return $this->adminView('settings/checkout', ['title' => 'Checkout settings', 'tab' => 'checkout', 'values' => $this->values(self::CHECKOUT_KEYS)]);
    }

    public function saveCheckout(Request $request): Response
    {
        Gate::authorize('settings.manage');
        $data = $this->validate($request, [
            'gift_wrap_fee' => 'required|numeric|min:0|max:100000',
            'cod_max_order' => 'required|numeric|min:0|max:10000000',
            'low_stock_alert_email' => 'nullable|email|max:190',
        ], ['cod_max_order' => 'COD maximum order', 'low_stock_alert_email' => 'Low-stock alert email']);
        $num = static function ($v): int|float {
            $f = round((float) $v, 2);
            return abs($f - round($f)) < 0.001 ? (int) round($f) : $f;
        };
        $n = $this->persist([
            'gift_wrap_fee' => $num($data['gift_wrap_fee']),
            'cod_max_order' => $num($data['cod_max_order']),
            'review_auto_approve_verified' => $request->bool('review_auto_approve_verified'),
            'low_stock_alert_email' => mb_strtolower((string) ($data['low_stock_alert_email'] ?? '')),
        ], 'checkout');
        flash('success', $n ? 'Checkout settings saved.' : 'No changes to save.');
        return $this->redirect(admin_url('settings/checkout'));
    }

    // ------------------------------------------------------------- payments

    public function payments(Request $request): Response
    {
        $c = (array) config('payments', []);
        $configured = static fn ($v) => is_string($v) ? trim($v) !== '' : !empty($v);
        $esewaKeyFromEnv = trim((string) env('ESEWA_SECRET_KEY', '')) !== '';
        $gateways = [
            [
                'name' => 'eSewa',
                'enabled' => !empty($c['esewa']['enabled']),
                'environment' => $c['esewa']['environment'] ?? 'test',
                'checks' => [
                    'Product code' => $configured($c['esewa']['product_code'] ?? ''),
                    'Secret key' => $configured($c['esewa']['secret_key'] ?? ''),
                ],
                'note' => (($c['esewa']['environment'] ?? 'test') === 'test' && !$esewaKeyFromEnv)
                    ? 'Using eSewa\'s publicly documented sandbox credentials.' : null,
            ],
            [
                'name' => 'Khalti',
                'enabled' => !empty($c['khalti']['enabled']),
                'environment' => $c['khalti']['environment'] ?? 'test',
                'checks' => ['Secret key' => $configured($c['khalti']['secret_key'] ?? '')],
                'note' => null,
            ],
            [
                'name' => 'Cash on delivery',
                'enabled' => !empty($c['cod']['enabled']),
                'environment' => null,
                'checks' => [],
                'note' => 'Maximum COD order: ' . money(setting('cod_max_order', 25000)) . ' (Checkout tab).',
            ],
        ];
        return $this->adminView('settings/payments', [
            'title' => 'Payment settings',
            'tab' => 'payments',
            'gateways' => $gateways,
            'simulator' => !empty($c['simulator']),
            'appEnv' => (string) config('app.env'),
        ]);
    }

    // ------------------------------------------------------- delivery zones

    public function zones(Request $request): Response
    {
        $zones = Database::fetchAll('SELECT * FROM delivery_zones ORDER BY sort_order, id');
        $assigned = [];
        foreach ($zones as $z) {
            foreach ($this->zoneDistricts($z) as $d) {
                $assigned[$d] = true;
            }
        }
        $unassigned = array_values(array_diff(array_keys(ShippingService::districts()), array_keys($assigned)));
        return $this->adminView('settings/zones', [
            'title' => 'Delivery zones',
            'tab' => 'zones',
            'zones' => $zones,
            'unassigned' => $unassigned,
            'hasDefault' => (bool) array_filter($zones, static fn ($z) => (int) $z['is_default'] === 1 && (int) $z['is_active'] === 1),
        ]);
    }

    private function zoneDistricts(array $zone): array
    {
        return array_values(array_filter(array_map('trim', explode(',', (string) ($zone['districts'] ?? '')))));
    }

    private function findZone(int $id): array
    {
        $z = Database::fetch('SELECT * FROM delivery_zones WHERE id = :id', ['id' => $id]);
        if (!$z) {
            throw new HttpException(404);
        }
        return $z;
    }

    private function zoneForm(?array $zone): Response
    {
        $taken = [];
        foreach (Database::fetchAll('SELECT id, name, districts FROM delivery_zones') as $z) {
            if ($zone && (int) $z['id'] === (int) $zone['id']) {
                continue;
            }
            foreach ($this->zoneDistricts($z) as $d) {
                $taken[$d] = $z['name'];
            }
        }
        return $this->adminView('settings/zone-form', [
            'title' => $zone ? 'Edit delivery zone' : 'New delivery zone',
            'tab' => 'zones',
            'zone' => $zone,
            'selected' => $zone ? $this->zoneDistricts($zone) : [],
            'provinces' => (array) config('nepal.provinces', []),
            'taken' => $taken,
        ]);
    }

    public function zoneCreate(Request $request): Response
    {
        return $this->zoneForm(null);
    }

    public function zoneEdit(Request $request, string $id): Response
    {
        return $this->zoneForm($this->findZone((int) $id));
    }

    /** Validates zone input and returns the row to save. */
    private function zoneData(Request $request, ?int $ignoreId): array
    {
        $data = $this->validate($request, [
            'name' => 'required|string|max:80',
            'districts' => 'nullable|array',
            'rate' => 'required|numeric|min:0|max:100000',
            'free_shipping_threshold' => 'nullable|numeric|min:0|max:10000000',
            'est_days_min' => 'required|integer|min:0|max:60',
            'est_days_max' => 'required|integer|min:0|max:60',
            'sort_order' => 'nullable|integer|min:-1000|max:1000',
        ], ['est_days_min' => 'Minimum days', 'est_days_max' => 'Maximum days', 'free_shipping_threshold' => 'Free shipping threshold']);

        $valid = ShippingService::districts();
        $districts = [];
        foreach ($request->arr('districts') as $d) {
            $d = is_scalar($d) ? trim((string) $d) : '';
            if (!isset($valid[$d])) {
                throw new ValidationException(['districts' => 'One or more selected districts are invalid.'], $request->all());
            }
            $districts[$d] = true;
        }
        $districts = array_keys($districts);
        $isDefault = $request->bool('is_default');
        if (!$districts && !$isDefault) {
            throw new ValidationException(['districts' => 'Select at least one district (or make this the default zone).'], $request->all());
        }
        if ((int) $data['est_days_max'] < (int) $data['est_days_min']) {
            throw new ValidationException(['est_days_max' => 'Maximum days must be greater than or equal to minimum days.'], $request->all());
        }
        // A district may belong to one zone only (otherwise lookup would depend on sort order).
        $conflicts = [];
        foreach (Database::fetchAll('SELECT id, name, districts FROM delivery_zones') as $z) {
            if ($ignoreId !== null && (int) $z['id'] === $ignoreId) {
                continue;
            }
            foreach (array_intersect($districts, $this->zoneDistricts($z)) as $d) {
                $conflicts[] = $d . ' (' . $z['name'] . ')';
            }
        }
        if ($conflicts) {
            throw new ValidationException(['districts' => 'Already assigned to another zone: ' . implode(', ', array_slice($conflicts, 0, 8)) . (count($conflicts) > 8 ? '…' : '')], $request->all());
        }
        $threshold = $data['free_shipping_threshold'];
        return [
            'name' => (string) $data['name'],
            'districts' => implode(', ', $districts),
            'is_default' => $isDefault ? 1 : 0,
            'is_valley' => $request->bool('is_valley') ? 1 : 0,
            'rate' => number_format((float) $data['rate'], 2, '.', ''),
            'free_shipping_threshold' => ($threshold === null || $threshold === '') ? null : number_format((float) $threshold, 2, '.', ''),
            'est_days_min' => (int) $data['est_days_min'],
            'est_days_max' => (int) $data['est_days_max'],
            'cod_available' => $request->bool('cod_available') ? 1 : 0,
            'is_active' => $request->bool('is_active') ? 1 : 0,
            'sort_order' => (int) ($data['sort_order'] ?? 0),
        ];
    }

    private function afterZoneChange(): void
    {
        Cache::bump('settings');
        SettingsService::flush();
    }

    public function zoneStore(Request $request): Response
    {
        Gate::authorize('settings.manage');
        $row = $this->zoneData($request, null);
        $id = Database::transaction(function () use ($row) {
            $id = Database::insert('delivery_zones', $row);
            if ($row['is_default'] === 1) {
                Database::query('UPDATE delivery_zones SET is_default = 0 WHERE id <> :id', ['id' => $id]);
            }
            return $id;
        });
        $this->afterZoneChange();
        AuditLogger::log('delivery_zone.created', 'delivery_zone', $id, null, $row);
        flash('success', 'Delivery zone created.');
        return $this->redirect(admin_url('settings/zones'));
    }

    public function zoneUpdate(Request $request, string $id): Response
    {
        Gate::authorize('settings.manage');
        $zone = $this->findZone((int) $id);
        $zid = (int) $zone['id'];
        $row = $this->zoneData($request, $zid);
        if ((int) $zone['is_default'] === 1 && $row['is_default'] === 0) {
            throw new ValidationException(['is_default' => 'Make another zone the default instead of removing the default flag here.'], $request->all());
        }
        Database::transaction(function () use ($row, $zid) {
            Database::update('delivery_zones', $row, ['id' => $zid]);
            if ($row['is_default'] === 1) {
                Database::query('UPDATE delivery_zones SET is_default = 0 WHERE id <> :id', ['id' => $zid]);
            }
        });
        $this->afterZoneChange();
        $old = [];
        $new = [];
        foreach ($row as $k => $v) {
            if ((string) ($zone[$k] ?? '') !== (string) ($v ?? '')) {
                $old[$k] = $zone[$k];
                $new[$k] = $v;
            }
        }
        if ($new) {
            AuditLogger::log('delivery_zone.updated', 'delivery_zone', $zid, $old, $new);
        }
        flash('success', 'Delivery zone saved.');
        return $this->redirect(admin_url('settings/zones'));
    }

    public function zoneDelete(Request $request, string $id): Response
    {
        Gate::authorize('settings.manage');
        $zone = $this->findZone((int) $id);
        if ((int) $zone['is_default'] === 1) {
            flash('error', 'The default zone cannot be deleted. Make another zone the default first.');
            return $this->redirect(admin_url('settings/zones'));
        }
        Database::delete('delivery_zones', ['id' => (int) $zone['id']]);
        $this->afterZoneChange();
        AuditLogger::log('delivery_zone.deleted', 'delivery_zone', (int) $zone['id'], $zone, null);
        flash('success', 'Delivery zone deleted. Existing orders keep their recorded shipping fee.');
        return $this->redirect(admin_url('settings/zones'));
    }
}
