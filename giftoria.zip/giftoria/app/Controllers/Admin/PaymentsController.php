<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\Database;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Repositories\Admin\OrderAdminRepository;

/** Read-only list of payment attempts. Gateway payloads and secrets are never shown here. */
final class PaymentsController extends Controller
{
    public const GATEWAYS = ['esewa' => 'eSewa', 'khalti' => 'Khalti', 'cod' => 'Cash on delivery', 'manual' => 'Manual'];

    public function index(Request $request): Response
    {
        $gateway = $request->str('gateway');
        $status = $request->str('status');
        $q = mb_substr($request->str('q'), 0, 100);
        $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', $request->str('from')) ? $request->str('from') : '';
        $to = preg_match('/^\d{4}-\d{2}-\d{2}$/', $request->str('to')) ? $request->str('to') : '';
        $filters = [
            'gateway' => isset(self::GATEWAYS[$gateway]) ? $gateway : '',
            'status' => in_array($status, OrderAdminRepository::PAYMENT_STATUSES, true) ? $status : '',
            'q' => $q,
            'from' => $from,
            'to' => $to,
        ];

        $w = ['1 = 1'];
        $p = [];
        if ($filters['gateway'] !== '') {
            $w[] = 'p.gateway = :g';
            $p['g'] = $filters['gateway'];
        }
        if ($filters['status'] !== '') {
            $w[] = 'p.status = :s';
            $p['s'] = $filters['status'];
        }
        if ($q !== '') {
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $w[] = '(p.attempt_ref LIKE :q1 OR o.order_number LIKE :q2 OR p.gateway_txn_id LIKE :q3)';
            $p += ['q1' => $like, 'q2' => $like, 'q3' => $like];
        }
        if ($from !== '') {
            $w[] = 'p.created_at >= :f';
            $p['f'] = local_to_utc($from . ' 00:00:00');
        }
        if ($to !== '') {
            $w[] = 'p.created_at < :t';
            $p['t'] = local_to_utc(date('Y-m-d', strtotime($to . ' +1 day')) . ' 00:00:00');
        }
        $where = implode(' AND ', $w);

        $summary = Database::fetch(
            "SELECT COUNT(*) AS n,
                    COALESCE(SUM(CASE WHEN p.status IN ('paid','partially_refunded','refunded','refund_pending') THEN p.amount ELSE 0 END), 0) AS captured,
                    COALESCE(SUM(p.status IN ('paid','partially_refunded','refunded','refund_pending')), 0) AS succeeded,
                    COALESCE(SUM(p.status = 'failed'), 0) AS failed
             FROM payments p JOIN orders o ON o.id = p.order_id WHERE $where",
            $p
        ) ?? ['n' => 0, 'captured' => 0, 'succeeded' => 0, 'failed' => 0];
        $total = (int) $summary['n'];
        $pager = Paginator::fromRequest($total, 30);
        $rows = Database::fetchAll(
            "SELECT p.id, p.order_id, p.gateway, p.attempt_ref, p.gateway_txn_id, p.amount, p.status, p.gateway_status,
                    p.verified_at, p.created_at, o.order_number, o.customer_name, o.status AS order_status
             FROM payments p JOIN orders o ON o.id = p.order_id
             WHERE $where ORDER BY p.id DESC LIMIT " . (int) $pager->perPage . ' OFFSET ' . (int) $pager->offset,
            $p
        );

        return $this->adminView('payments/index', [
            'title' => 'Payments',
            'filters' => $filters,
            'payments' => $rows,
            'summary' => $summary,
            'total' => $total,
            'paginator' => $pager,
            'gateways' => self::GATEWAYS,
        ]);
    }
}
