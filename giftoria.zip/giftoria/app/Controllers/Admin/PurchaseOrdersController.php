<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Cache;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;
use App\Repositories\Admin\CatalogAdminRepository;
use App\Services\InventoryService;
use RuntimeException;

/**
 * Admin > Purchase orders. Lifecycle: draft → ordered → partially_received → received, or cancelled
 * (from draft, or from ordered before anything is received). Receiving adds stock through
 * InventoryService in a single transaction and can never exceed the ordered quantity.
 */
final class PurchaseOrdersController extends Controller
{
    public const STATUSES = ['draft', 'ordered', 'partially_received', 'received', 'cancelled'];
    private const MAX_LINES = 100;

    private CatalogAdminRepository $repo;

    public function __construct()
    {
        $this->repo = new CatalogAdminRepository();
    }

    public function index(Request $request): Response
    {
        $status = $request->str('status');
        $filters = [
            'status' => in_array($status, self::STATUSES, true) ? $status : '',
            'supplier_id' => max(0, $request->int('supplier')),
            'q' => mb_substr($request->str('q'), 0, 40),
        ];
        $perPage = 25;
        $page = max(1, $request->int('page', 1));
        $result = $this->repo->purchaseOrders($filters, $perPage, ($page - 1) * $perPage);
        return $this->adminView('purchase-orders/index', [
            'title' => 'Purchase orders',
            'orders' => $result['items'],
            'total' => $result['total'],
            'paginator' => new Paginator($result['total'], $perPage, $page),
            'suppliers' => $this->repo->suppliers(),
            'statuses' => self::STATUSES,
            'filters' => $filters,
        ]);
    }

    public function create(Request $request): Response
    {
        $suppliers = array_values(array_filter($this->repo->suppliers(), static fn ($s) => (int) $s['is_active'] === 1));
        if (!$suppliers) {
            flash('warning', 'Add an active supplier before creating a purchase order.');
            return $this->redirect(admin_url('suppliers/create'));
        }
        return $this->adminView('purchase-orders/form', [
            'title' => 'New purchase order',
            'po' => null,
            'suppliers' => $suppliers,
            'items' => $this->repo->purchasableItems(),
            'presetSupplier' => $request->int('supplier'),
        ]);
    }

    public function store(Request $request): Response
    {
        [$header, $lines] = $this->validated($request, true);
        $staffId = Auth::staffId();
        $id = Database::transaction(function () use ($header, $lines, $staffId) {
            $id = Database::insert('purchase_orders', $header + [
                'po_number' => $this->generateNumber(),
                'status' => 'draft',
                'created_by' => $staffId,
            ]);
            $this->writeLines($id, $lines);
            return $id;
        });
        AuditLogger::log('purchase_order.create', 'purchase_order', $id, null, $header + ['lines' => count($lines)]);
        flash('success', 'Purchase order created as a draft. Mark it as ordered once it has been sent to the supplier.');
        return $this->redirect(admin_url('suppliers/purchase-orders/' . $id));
    }

    public function show(Request $request, string $id): Response
    {
        $po = $this->findOrFail((int) $id);
        $movements = Database::fetchAll(
            "SELECT m.*, u.name AS user_name, p.name AS product_name, v.name AS variant_name
             FROM inventory_movements m JOIN products p ON p.id = m.product_id
             LEFT JOIN users u ON u.id = m.user_id
             LEFT JOIN product_variants v ON v.id = m.variant_id AND m.variant_id <> 0
             WHERE m.reference_type = 'purchase_order' AND m.reference_id = :id
             ORDER BY m.created_at DESC, m.id DESC",
            ['id' => (int) $po['id']]
        );
        return $this->adminView('purchase-orders/show', [
            'title' => $po['po_number'],
            'po' => $po,
            'receipts' => $movements,
        ]);
    }

    public function edit(Request $request, string $id): Response
    {
        $po = $this->findOrFail((int) $id);
        if ($po['status'] !== 'draft') {
            flash('error', 'Only draft purchase orders can be edited.');
            return $this->redirect(admin_url('suppliers/purchase-orders/' . (int) $po['id']));
        }
        return $this->adminView('purchase-orders/form', [
            'title' => 'Edit ' . $po['po_number'],
            'po' => $po,
            'suppliers' => $this->repo->suppliers(),
            'items' => $this->repo->purchasableItems(),
            'presetSupplier' => 0,
        ]);
    }

    public function update(Request $request, string $id): Response
    {
        $po = $this->findOrFail((int) $id);
        $poId = (int) $po['id'];
        if ($po['status'] !== 'draft') {
            flash('error', 'Only draft purchase orders can be edited.');
            return $this->redirect(admin_url('suppliers/purchase-orders/' . $poId));
        }
        [$header, $lines] = $this->validated($request, (int) $request->int('supplier_id') !== (int) $po['supplier_id']);
        try {
            Database::transaction(function () use ($poId, $header, $lines) {
                $locked = Database::fetchColumn('SELECT status FROM purchase_orders WHERE id = :id FOR UPDATE', ['id' => $poId]);
                if ($locked !== 'draft') {
                    throw new RuntimeException('This purchase order is no longer a draft.');
                }
                Database::update('purchase_orders', $header, ['id' => $poId]);
                Database::delete('purchase_order_items', ['purchase_order_id' => $poId]);
                $this->writeLines($poId, $lines);
            });
        } catch (\PDOException $e) {
            throw $e; // database errors are not user messages
        } catch (RuntimeException $e) {
            flash('error', $e->getMessage());
            return $this->redirect(admin_url('suppliers/purchase-orders/' . $poId));
        }
        AuditLogger::log('purchase_order.update', 'purchase_order', $poId,
            ['supplier_id' => (int) $po['supplier_id'], 'expected_at' => $po['expected_at'], 'lines' => count($po['items'])],
            $header + ['lines' => count($lines)]
        );
        flash('success', 'Purchase order saved.');
        return $this->redirect(admin_url('suppliers/purchase-orders/' . $poId));
    }

    /** Draft → ordered, or cancel. */
    public function status(Request $request, string $id): Response
    {
        $po = $this->findOrFail((int) $id);
        $poId = (int) $po['id'];
        $to = $request->str('status');
        $from = $po['status'];
        $received = array_sum(array_map(static fn ($i) => (int) $i['quantity_received'], $po['items']));
        $allowed = match ($from) {
            'draft' => ['ordered', 'cancelled'],
            'ordered' => $received === 0 ? ['cancelled'] : [],
            default => [],
        };
        if (!in_array($to, $allowed, true)) {
            flash('error', 'A purchase order that is ' . status_label($from) . ' cannot be changed to ' . status_label($to) . '.');
            return $this->redirect(admin_url('suppliers/purchase-orders/' . $poId));
        }
        if ($to === 'ordered' && !$po['items']) {
            flash('error', 'Add at least one line before marking the order as sent.');
            return $this->redirect(admin_url('suppliers/purchase-orders/' . $poId));
        }
        $changed = Database::query(
            'UPDATE purchase_orders SET status = :to WHERE id = :id AND status = :from',
            ['to' => $to, 'id' => $poId, 'from' => $from]
        )->rowCount();
        if ($changed) {
            AuditLogger::log('purchase_order.status', 'purchase_order', $poId, ['status' => $from], ['status' => $to]);
            flash('success', $po['po_number'] . ' is now ' . mb_strtolower(status_label($to)) . '.');
        } else {
            flash('error', 'The purchase order changed in the meantime. Please review it and try again.');
        }
        return $this->redirect(admin_url('suppliers/purchase-orders/' . $poId));
    }

    /** Records received quantities per line and adds them to stock. */
    public function receive(Request $request, string $id): Response
    {
        $po = $this->findOrFail((int) $id);
        $poId = (int) $po['id'];
        $input = $request->arr('receive');
        $note = mb_substr($request->str('note'), 0, 200);
        $wanted = [];
        $errors = [];
        foreach ($po['items'] as $line) {
            $raw = $input[$line['id']] ?? '';
            $raw = is_scalar($raw) ? trim((string) $raw) : '';
            if ($raw === '' || $raw === '0') {
                continue;
            }
            if (filter_var($raw, FILTER_VALIDATE_INT) === false || (int) $raw < 0) {
                $errors['receive'] = 'Received quantities must be whole numbers of 0 or more.';
                continue;
            }
            $wanted[(int) $line['id']] = (int) $raw;
        }
        if ($errors) {
            throw new ValidationException($errors, ['receive' => $input, 'note' => $note]);
        }
        if (!$wanted) {
            flash('error', 'Enter the quantity received for at least one line.');
            return $this->redirect(admin_url('suppliers/purchase-orders/' . $poId));
        }

        $staffId = Auth::staffId();
        $inventory = new InventoryService();
        try {
            $result = Database::transaction(function () use ($poId, $wanted, $staffId, $inventory, $note) {
                $locked = Database::fetch('SELECT id, po_number, status FROM purchase_orders WHERE id = :id FOR UPDATE', ['id' => $poId]);
                if (!$locked || !in_array($locked['status'], ['ordered', 'partially_received'], true)) {
                    throw new RuntimeException('Stock can only be received for purchase orders that are ordered or partially received.');
                }
                $units = 0;
                foreach ($wanted as $lineId => $qty) {
                    $line = Database::fetch(
                        'SELECT * FROM purchase_order_items WHERE id = :id AND purchase_order_id = :po FOR UPDATE',
                        ['id' => $lineId, 'po' => $poId]
                    );
                    if (!$line) {
                        throw new RuntimeException('A line on this purchase order no longer exists.');
                    }
                    $remaining = (int) $line['quantity_ordered'] - (int) $line['quantity_received'];
                    if ($qty > $remaining) {
                        throw new RuntimeException('Cannot receive ' . $qty . ' unit(s) on a line with only ' . max(0, $remaining) . ' outstanding.');
                    }
                    Database::query(
                        'UPDATE purchase_order_items SET quantity_received = quantity_received + :q WHERE id = :id',
                        ['q' => $qty, 'id' => $lineId]
                    );
                    $inventory->change(
                        (int) $line['product_id'], (int) $line['variant_id'], $qty, 'receive', 'purchase_order', $poId, $staffId,
                        trim('Received on ' . $locked['po_number'] . ($note !== '' ? ' — ' . $note : ''))
                    );
                    $units += $qty;
                }
                $outstanding = (int) Database::fetchColumn(
                    'SELECT COALESCE(SUM(quantity_ordered - quantity_received), 0) FROM purchase_order_items WHERE purchase_order_id = :id',
                    ['id' => $poId]
                );
                $newStatus = $outstanding <= 0 ? 'received' : 'partially_received';
                Database::update('purchase_orders', ['status' => $newStatus], ['id' => $poId]);
                return ['units' => $units, 'from' => $locked['status'], 'to' => $newStatus];
            });
        } catch (\PDOException $e) {
            throw $e; // database errors are not user messages
        } catch (RuntimeException $e) {
            flash('error', $e->getMessage());
            return $this->redirect(admin_url('suppliers/purchase-orders/' . $poId));
        }

        AuditLogger::log('purchase_order.receive', 'purchase_order', $poId, ['status' => $result['from']], [
            'status' => $result['to'], 'units' => $result['units'], 'lines' => $wanted,
        ]);
        Cache::bump('catalog');
        flash('success', $result['units'] . ' unit(s) received and added to stock.' . ($result['to'] === 'received' ? ' The purchase order is complete.' : ''));
        return $this->redirect(admin_url('suppliers/purchase-orders/' . $poId));
    }

    /* ---------------------------------------------------------------- internals */

    private function findOrFail(int $id): array
    {
        $po = $this->repo->purchaseOrder($id);
        if (!$po) {
            throw new HttpException(404);
        }
        return $po;
    }

    /**
     * @return array{0: array, 1: array<int, array{product_id:int, variant_id:int, qty:int, cost:float}>}
     * @throws ValidationException
     */
    private function validated(Request $request, bool $requireActiveSupplier): array
    {
        $errors = [];
        $supplierId = $request->int('supplier_id');
        $supplier = $supplierId > 0 ? Database::fetch('SELECT id, is_active FROM suppliers WHERE id = :id', ['id' => $supplierId]) : null;
        if (!$supplier) {
            $errors['supplier_id'] = 'Choose a supplier.';
        } elseif ($requireActiveSupplier && !(int) $supplier['is_active']) {
            $errors['supplier_id'] = 'This supplier is inactive.';
        }
        $expected = $request->str('expected_at');
        if ($expected !== '') {
            $d = \DateTime::createFromFormat('Y-m-d', $expected);
            if (!$d || $d->format('Y-m-d') !== $expected) {
                $errors['expected_at'] = 'Expected date must be a valid date.';
            }
        }
        $notes = $request->str('notes');
        if (mb_strlen($notes) > 5000) {
            $errors['notes'] = 'Notes may not exceed 5000 characters.';
        }

        $items = $this->repo->purchasableItems();
        $lines = [];
        $seen = [];
        foreach ($request->arr('lines') as $row) {
            if (!is_array($row)) {
                continue;
            }
            $key = is_scalar($row['item'] ?? null) ? trim((string) $row['item']) : '';
            $qtyRaw = is_scalar($row['qty'] ?? null) ? trim((string) $row['qty']) : '';
            $costRaw = is_scalar($row['cost'] ?? null) ? trim((string) $row['cost']) : '';
            if ($key === '' && $qtyRaw === '' && $costRaw === '') {
                continue;
            }
            if ($key === '' || !isset($items[$key])) {
                $errors['lines'] = 'Choose a valid product for every line you fill in.';
                continue;
            }
            if (isset($seen[$key])) {
                $errors['lines'] = '"' . $items[$key]['label'] . '" appears on more than one line. Combine them into one line.';
                continue;
            }
            if (filter_var($qtyRaw, FILTER_VALIDATE_INT) === false || (int) $qtyRaw < 1 || (int) $qtyRaw > 1000000) {
                $errors['lines'] = 'Quantity must be a whole number of at least 1 on every line.';
                continue;
            }
            if ($costRaw === '') {
                $costRaw = (string) ($items[$key]['cost_price'] ?? '0');
            }
            if (!is_numeric($costRaw) || (float) $costRaw < 0 || (float) $costRaw > 99999999) {
                $errors['lines'] = 'Unit cost must be a number of 0 or more.';
                continue;
            }
            $seen[$key] = true;
            $lines[] = [
                'product_id' => (int) $items[$key]['product_id'],
                'variant_id' => (int) $items[$key]['variant_id'],
                'qty' => (int) $qtyRaw,
                'cost' => round((float) $costRaw, 2),
            ];
        }
        if (!$lines && !isset($errors['lines'])) {
            $errors['lines'] = 'Add at least one product line.';
        }
        if (count($lines) > self::MAX_LINES) {
            $errors['lines'] = 'A purchase order can have at most ' . self::MAX_LINES . ' lines.';
        }
        if ($errors) {
            $old = $request->all();
            unset($old['_token']);
            throw new ValidationException($errors, $old);
        }
        return [[
            'supplier_id' => $supplierId,
            'expected_at' => $expected !== '' ? $expected : null,
            'notes' => $notes !== '' ? $notes : null,
        ], $lines];
    }

    private function writeLines(int $poId, array $lines): void
    {
        foreach ($lines as $l) {
            Database::insert('purchase_order_items', [
                'purchase_order_id' => $poId,
                'product_id' => $l['product_id'],
                'variant_id' => $l['variant_id'],
                'quantity_ordered' => $l['qty'],
                'quantity_received' => 0,
                'unit_cost' => $l['cost'],
            ]);
        }
    }

    /** PO-YYMMDD-XXXX with a per-day sequence (store timezone). */
    private function generateNumber(): string
    {
        $prefix = 'PO-' . date('ymd', strtotime(local_today())) . '-';
        $last = Database::fetchColumn(
            'SELECT po_number FROM purchase_orders WHERE po_number LIKE :p ORDER BY po_number DESC LIMIT 1',
            ['p' => $prefix . '%']
        );
        $seq = $last ? ((int) substr((string) $last, strlen($prefix))) + 1 : 1;
        for ($i = 0; $i < 20; $i++, $seq++) {
            $candidate = $prefix . str_pad((string) $seq, 4, '0', STR_PAD_LEFT);
            if (!(int) Database::fetchColumn('SELECT COUNT(*) FROM purchase_orders WHERE po_number = :n', ['n' => $candidate])) {
                return $candidate;
            }
        }
        return $prefix . strtoupper(bin2hex(random_bytes(2)));
    }
}
