<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Cache;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\Uploader;
use App\Core\ValidationException;
use App\Core\Validator;
use App\Repositories\Admin\CatalogAdminRepository;
use RuntimeException;

/** Admin > Categories: tree list, create/edit, safe delete. */
final class CategoriesController extends Controller
{
    private CatalogAdminRepository $repo;

    public function __construct()
    {
        $this->repo = new CatalogAdminRepository();
    }

    public function index(Request $request): Response
    {
        return $this->adminView('categories/index', [
            'title' => 'Categories',
            'categories' => $this->repo->categoryTree(),
        ]);
    }

    public function create(Request $request): Response
    {
        return $this->adminView('categories/form', [
            'title' => 'New category',
            'category' => null,
            'parents' => $this->repo->categoryTree(),
            'blockedParents' => [],
            'presetParent' => $request->int('parent'),
        ]);
    }

    public function store(Request $request): Response
    {
        $data = $this->validated($request, 0);
        $image = $this->upload($request);
        if ($image !== null) {
            $data['image'] = $image;
        }
        $id = Database::insert('categories', $data);
        AuditLogger::log('category.create', 'category', $id, null, $data);
        Cache::bump('catalog');
        flash('success', 'Category "' . $data['name'] . '" created.');
        return $this->redirect(admin_url('categories'));
    }

    public function edit(Request $request, string $id): Response
    {
        $category = $this->findOrFail((int) $id);
        return $this->adminView('categories/form', [
            'title' => 'Edit category',
            'category' => $category,
            'parents' => $this->repo->categoryTree(),
            'blockedParents' => $this->repo->categoryDescendants((int) $category['id']),
            'presetParent' => 0,
            'productCount' => (int) Database::fetchColumn('SELECT COUNT(*) FROM products WHERE category_id = :id', ['id' => (int) $category['id']]),
        ]);
    }

    public function update(Request $request, string $id): Response
    {
        $old = $this->findOrFail((int) $id);
        $cid = (int) $old['id'];
        $data = $this->validated($request, $cid);
        $oldImage = $old['image'];
        $image = $this->upload($request);
        if ($image !== null) {
            $data['image'] = $image;
        } elseif ($request->bool('remove_image')) {
            $data['image'] = null;
        }
        Database::update('categories', $data, ['id' => $cid]);
        if (array_key_exists('image', $data) && $oldImage && $oldImage !== $data['image']) {
            Uploader::delete((string) $oldImage);
        }
        $changes = [];
        $before = [];
        foreach ($data as $k => $v) {
            if ((string) ($old[$k] ?? '') !== (string) ($v ?? '')) {
                $before[$k] = $old[$k] ?? null;
                $changes[$k] = $v;
            }
        }
        AuditLogger::log('category.update', 'category', $cid, $before ?: null, $changes ?: null);
        Cache::bump('catalog');
        flash('success', 'Category saved.');
        return $this->redirect(admin_url('categories'));
    }

    public function destroy(Request $request, string $id): Response
    {
        $category = $this->findOrFail((int) $id);
        $cid = (int) $category['id'];
        $products = (int) Database::fetchColumn('SELECT COUNT(*) FROM products WHERE category_id = :id', ['id' => $cid]);
        if ($products > 0) {
            flash('error', 'Cannot delete "' . $category['name'] . '": ' . $products . ' product(s) are assigned to it. Move them to another category first, or deactivate the category instead.');
            return $this->redirect(admin_url('categories'));
        }
        $children = (int) Database::fetchColumn('SELECT COUNT(*) FROM categories WHERE parent_id = :id', ['id' => $cid]);
        Database::delete('categories', ['id' => $cid]);
        if ($category['image']) {
            Uploader::delete((string) $category['image']);
        }
        AuditLogger::log('category.delete', 'category', $cid, ['name' => $category['name'], 'slug' => $category['slug'], 'parent_id' => $category['parent_id']], null);
        Cache::bump('catalog');
        flash('success', 'Category deleted.' . ($children ? ' Its ' . $children . ' subcategor' . ($children === 1 ? 'y was' : 'ies were') . ' moved to the top level.' : ''));
        return $this->redirect(admin_url('categories'));
    }

    /* ---------------------------------------------------------------- internals */

    private function findOrFail(int $id): array
    {
        $c = Database::fetch('SELECT * FROM categories WHERE id = :id', ['id' => $id]);
        if (!$c) {
            throw new HttpException(404);
        }
        return $c;
    }

    private function validated(Request $request, int $id): array
    {
        $v = Validator::make($request->all(), [
            'name' => 'required|max:120',
            'slug' => 'nullable|slug|max:140',
            'parent_id' => 'nullable|integer|exists:categories,id',
            'description' => 'nullable|max:5000',
            'sort_order' => 'nullable|integer|min:-10000|max:10000',
            'seo_title' => 'nullable|max:190',
            'seo_description' => 'nullable|max:300',
        ], ['parent_id' => 'Parent category', 'seo_title' => 'SEO title', 'seo_description' => 'SEO description']);
        $v->fails();
        $errors = $v->errors();
        $val = $v->validated();
        $slug = (string) ($val['slug'] ?? '');
        if ($slug !== '' && !isset($errors['slug']) && $this->repo->slugTaken('categories', $slug, $id)) {
            $errors['slug'] = 'Slug is already used by another category.';
        }
        $parent = ($val['parent_id'] ?? '') !== '' && $val['parent_id'] !== null ? (int) $val['parent_id'] : null;
        if ($parent !== null && $id > 0 && in_array($parent, $this->repo->categoryDescendants($id), true)) {
            $errors['parent_id'] = 'A category cannot be placed inside itself or one of its subcategories.';
        }
        if ($errors) {
            $old = $request->all();
            unset($old['_token']);
            throw new ValidationException($errors, $old);
        }
        $nullable = static fn ($x) => ($x === null || $x === '') ? null : $x;
        return [
            'name' => (string) $val['name'],
            'slug' => $slug !== '' ? $slug : $this->repo->uniqueSlug('categories', (string) $val['name'], $id),
            'parent_id' => $parent,
            'description' => $nullable($val['description']),
            'sort_order' => (int) ($val['sort_order'] ?? 0),
            'is_active' => $request->bool('is_active') ? 1 : 0,
            'seo_title' => $nullable($val['seo_title']),
            'seo_description' => $nullable($val['seo_description']),
        ];
    }

    private function upload(Request $request): ?string
    {
        $file = $request->file('image');
        if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        try {
            return Uploader::image($file, 'categories');
        } catch (RuntimeException $e) {
            $old = $request->all();
            unset($old['_token']);
            throw new ValidationException(['image' => $e->getMessage()], $old);
        }
    }
}
