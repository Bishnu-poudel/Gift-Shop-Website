<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Cache;
use App\Core\Database;
use App\Core\Gate;
use App\Core\Logger;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;
use App\Repositories\TaxonomyRepository;
use App\Services\Recommendation\RecommendationEngine;
use App\Services\Recommendation\Scorer;
use App\Services\SettingsService;

/**
 * Gift Finder rules: scoring weights, strict interest matching, feedback usage,
 * a test console that shows exactly why products rank, and feedback / search insights.
 */
final class RecommendationsController extends Controller
{
    public const WEIGHT_LABELS = [
        'recipient' => 'Recipient match',
        'interest' => 'Interest match',
        'occasion' => 'Occasion match',
        'age' => 'Age suitability',
        'budget' => 'Budget fit',
        'preferences' => 'Preferences (handmade, eco…)',
        'popularity' => 'Popularity & ratings',
    ];

    public function index(Request $request): Response
    {
        $tax = new TaxonomyRepository();
        $weights = $this->currentWeights();

        $console = null;
        $consoleError = null;
        if ($request->query('run')) {
            $input = [
                'recipient' => $request->str('recipient'),
                'occasion' => $request->str('occasion'),
                'interests' => array_values(array_filter($request->arr('interests'), 'is_string')),
                'custom_interest' => mb_substr($request->str('custom_interest'), 0, 80),
                'age' => $request->str('age'),
                'budget' => $request->int('budget'),
                'min_price' => $request->str('min_price'),
                'max_price' => $request->str('max_price'),
                'strict_interests' => $request->bool('strict_interests') ? 1 : 0,
            ];
            $engine = new RecommendationEngine($tax);
            try {
                $criteria = $engine->normalize($input);
                // No user/session: the console shows the neutral ranking without personal feedback.
                $result = $engine->recommend($criteria, 'relevance', 1, 20, null, null);
                $console = ['input' => $input, 'result' => $result];
            } catch (\Throwable $e) {
                Logger::error('Gift Finder test console failed: ' . $e->getMessage(), ['file' => $e->getFile(), 'line' => $e->getLine()]);
                $consoleError = 'The recommendation engine failed for these criteria. The error has been logged.';
            }
        }

        return $this->adminView('recommendations/index', [
            'title' => 'Gift Finder rules',
            'tab' => 'rules',
            'weights' => $weights,
            'requireInterest' => (bool) SettingsService::get('reco_require_interest_match', false),
            'feedbackEnabled' => (bool) SettingsService::get('reco_feedback_enabled', true),
            'recipients' => $tax->all('recipients'),
            'occasions' => $tax->all('occasions'),
            'interests' => $tax->all('interests'),
            'ageRanges' => $tax->ageRanges(),
            'budgets' => $tax->budgets(),
            'console' => $console,
            'consoleError' => $consoleError,
        ]);
    }

    public function saveWeights(Request $request): Response
    {
        Gate::authorize('recommendations.manage');
        $raw = $request->arr('weights');
        $errors = [];
        $new = [];
        foreach (array_keys(Scorer::DEFAULT_WEIGHTS) as $key) {
            $v = $raw[$key] ?? null;
            if (!is_scalar($v) || filter_var($v, FILTER_VALIDATE_INT) === false || (int) $v < 0 || (int) $v > 50) {
                $errors['weights'] = (self::WEIGHT_LABELS[$key] ?? $key) . ' must be a whole number between 0 and 50.';
                break;
            }
            $new[$key] = (int) $v;
        }
        if (!$errors && array_sum($new) === 0) {
            $errors['weights'] = 'At least one weight must be greater than zero.';
        }
        if ($errors) {
            throw new ValidationException($errors, $request->all());
        }
        $old = [
            'reco_weights' => $this->currentWeights(),
            'reco_require_interest_match' => (bool) SettingsService::get('reco_require_interest_match', false),
            'reco_feedback_enabled' => (bool) SettingsService::get('reco_feedback_enabled', true),
        ];
        $values = [
            'reco_weights' => $new,
            'reco_require_interest_match' => $request->bool('reco_require_interest_match'),
            'reco_feedback_enabled' => $request->bool('reco_feedback_enabled'),
        ];
        foreach ($values as $key => $value) {
            SettingsService::set($key, $value, 'recommendations');
        }
        Cache::bump('settings');
        SettingsService::flush();
        AuditLogger::log('settings.recommendations_updated', 'settings', null, $old, $values);
        flash('success', 'Gift Finder rules saved. New searches use them immediately.');
        return $this->redirect(admin_url('recommendations'));
    }

    public function insights(Request $request): Response
    {
        $feedback = Database::fetchAll(
            "SELECT action, COUNT(*) AS total,
                    SUM(created_at >= (UTC_TIMESTAMP() - INTERVAL 30 DAY)) AS last_30
             FROM recommendation_feedback GROUP BY action ORDER BY total DESC"
        );
        $hidden = Database::fetchAll(
            "SELECT p.id, p.name, p.sku, p.status, COUNT(*) AS hides,
                    (SELECT COUNT(*) FROM recommendation_feedback d WHERE d.product_id = p.id AND d.action = 'dislike') AS dislikes,
                    (SELECT COUNT(*) FROM recommendation_feedback l WHERE l.product_id = p.id AND l.action IN ('like','wishlist','more_like_this')) AS positives
             FROM recommendation_feedback rf JOIN products p ON p.id = rf.product_id
             WHERE rf.action = 'hide'
             GROUP BY p.id, p.name, p.sku, p.status ORDER BY hides DESC, p.id LIMIT 15"
        );
        $sessionStats = Database::fetch(
            "SELECT COUNT(*) AS total, SUM(result_count = 0) AS zero, AVG(result_count) AS avg_results
             FROM gift_finder_sessions WHERE created_at >= (UTC_TIMESTAMP() - INTERVAL 30 DAY)"
        ) ?? [];
        $zeroOnly = $request->bool('zero');
        $sessions = Database::fetchAll(
            'SELECT id, user_id, criteria_json, result_count, created_at FROM gift_finder_sessions'
            . ($zeroOnly ? ' WHERE result_count = 0' : '') . ' ORDER BY id DESC LIMIT 50'
        );
        foreach ($sessions as &$s) {
            $s['criteria'] = json_decode((string) $s['criteria_json'], true) ?: [];
        }
        unset($s);

        $tax = new TaxonomyRepository();
        $names = [];
        foreach (['recipients' => 'recipient', 'occasions' => 'occasion', 'interests' => 'interest'] as $t => $k) {
            foreach ($tax->all($t, false) as $row) {
                $names[$k][$row['slug']] = $row['name'];
            }
        }

        return $this->adminView('recommendations/insights', [
            'title' => 'Gift Finder insights',
            'tab' => 'insights',
            'feedback' => $feedback,
            'hidden' => $hidden,
            'sessionStats' => $sessionStats,
            'sessions' => $sessions,
            'zeroOnly' => $zeroOnly,
            'names' => $names,
            'feedbackEnabled' => (bool) SettingsService::get('reco_feedback_enabled', true),
        ]);
    }

    private function currentWeights(): array
    {
        $stored = (array) SettingsService::get('reco_weights', Scorer::DEFAULT_WEIGHTS);
        $out = [];
        foreach (Scorer::DEFAULT_WEIGHTS as $k => $default) {
            $out[$k] = isset($stored[$k]) && is_numeric($stored[$k]) ? (int) $stored[$k] : $default;
        }
        return $out;
    }
}
