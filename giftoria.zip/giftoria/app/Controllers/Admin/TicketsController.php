<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;
use App\Services\MailService;

/** Support tickets: queue, conversation thread (public replies + internal notes), status/priority/assignment. */
final class TicketsController extends Controller
{
    public const STATUSES = ['open', 'pending', 'resolved', 'closed'];
    public const PRIORITIES = ['low', 'normal', 'high', 'urgent'];

    public function index(Request $request): Response
    {
        $status = $request->str('status', 'active');
        $priority = $request->str('priority');
        $mine = $request->bool('mine');
        $q = $request->str('q');
        $where = [];
        $params = [];
        if ($status === 'active') {
            $where[] = "t.status IN ('open','pending')";
        } elseif (in_array($status, self::STATUSES, true)) {
            $params['st'] = $status;
            $where[] = 't.status = :st';
        }
        if (in_array($priority, self::PRIORITIES, true)) {
            $params['pr'] = $priority;
            $where[] = 't.priority = :pr';
        }
        if ($mine) {
            $params['me'] = (int) Auth::staffId();
            $where[] = 't.assigned_to = :me';
        } elseif ($request->str('assigned') === 'none') {
            $where[] = 't.assigned_to IS NULL';
        }
        if ($q !== '') {
            $params['q1'] = '%' . $q . '%';
            $params['q2'] = '%' . $q . '%';
            $params['q3'] = '%' . $q . '%';
            $params['q4'] = '%' . $q . '%';
            $where[] = '(t.ticket_number LIKE :q1 OR t.subject LIKE :q2 OR t.email LIKE :q3 OR t.name LIKE :q4)';
        }
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM support_tickets t $whereSql", $params);
        $p = Paginator::fromRequest($total, 25);
        $rows = Database::fetchAll(
            "SELECT t.*, a.name AS assignee_name,
                    (SELECT COUNT(*) FROM ticket_messages m WHERE m.ticket_id = t.id AND m.is_internal = 0) AS message_count,
                    (SELECT m2.author_type FROM ticket_messages m2 WHERE m2.ticket_id = t.id AND m2.is_internal = 0 ORDER BY m2.id DESC LIMIT 1) AS last_author
             FROM support_tickets t LEFT JOIN users a ON a.id = t.assigned_to
             $whereSql
             ORDER BY FIELD(t.status, 'open', 'pending', 'resolved', 'closed'),
                      FIELD(t.priority, 'urgent', 'high', 'normal', 'low'), t.updated_at DESC, t.id DESC
             LIMIT {$p->perPage} OFFSET {$p->offset}",
            $params
        );
        $counts = Database::fetch(
            "SELECT SUM(status = 'open') AS open_count, SUM(status = 'pending') AS pending_count,
                    SUM(status IN ('open','pending') AND priority IN ('high','urgent')) AS high_count,
                    SUM(status IN ('open','pending') AND assigned_to IS NULL) AS unassigned_count
             FROM support_tickets"
        ) ?? [];
        $mineCount = (int) Database::fetchColumn(
            "SELECT COUNT(*) FROM support_tickets WHERE assigned_to = :me AND status IN ('open','pending')",
            ['me' => (int) Auth::staffId()]
        );
        return $this->adminView('tickets/index', [
            'title' => 'Support tickets',
            'tickets' => $rows,
            'paginator' => $p,
            'filters' => ['status' => $status, 'priority' => $priority, 'mine' => $mine, 'q' => $q, 'assigned' => $request->str('assigned')],
            'counts' => $counts,
            'mineCount' => $mineCount,
        ]);
    }

    public function show(Request $request, string $id): Response
    {
        $ticket = $this->find((int) $id);
        $messages = Database::fetchAll(
            'SELECT m.*, u.name AS author_name FROM ticket_messages m LEFT JOIN users u ON u.id = m.user_id
             WHERE m.ticket_id = :t ORDER BY m.created_at, m.id',
            ['t' => (int) $ticket['id']]
        );
        $order = $ticket['order_id']
            ? Database::fetch('SELECT id, order_number, status, grand_total, created_at FROM orders WHERE id = :o', ['o' => (int) $ticket['order_id']])
            : null;
        $history = $ticket['user_id']
            ? Database::fetchAll(
                'SELECT id, ticket_number, subject, status, created_at FROM support_tickets WHERE user_id = :u AND id <> :id ORDER BY id DESC LIMIT 5',
                ['u' => (int) $ticket['user_id'], 'id' => (int) $ticket['id']]
            )
            : [];
        return $this->adminView('tickets/show', [
            'title' => 'Ticket ' . $ticket['ticket_number'],
            'ticket' => $ticket,
            'messages' => $messages,
            'order' => $order,
            'history' => $history,
            'assignees' => $this->assignees(),
        ]);
    }

    public function reply(Request $request, string $id): Response
    {
        Gate::authorize('support.manage');
        $ticket = $this->find((int) $id);
        $body = str_replace("\r\n", "\n", $request->str('body'));
        $internal = $request->bool('internal');
        $statusAfter = $request->str('status_after');
        $errors = [];
        if ($body === '') {
            $errors['body'] = 'Write a message.';
        } elseif (mb_strlen($body) > 5000) {
            $errors['body'] = 'The message may not exceed 5000 characters.';
        }
        if ($statusAfter !== '' && !in_array($statusAfter, self::STATUSES, true)) {
            $errors['status_after'] = 'Choose a valid status.';
        }
        if ($errors) {
            throw new ValidationException($errors, $request->all());
        }

        $messageId = Database::transaction(function () use ($ticket, $body, $internal, $statusAfter): int {
            $mid = Database::insert('ticket_messages', [
                'ticket_id' => (int) $ticket['id'],
                'user_id' => Auth::staffId(),
                'author_type' => 'staff',
                'body' => $body,
                'is_internal' => $internal ? 1 : 0,
            ]);
            $update = ['updated_at' => Database::now()];
            if ($statusAfter !== '' && $statusAfter !== $ticket['status']) {
                $update['status'] = $statusAfter;
            }
            if (!$ticket['assigned_to'] && !$internal) {
                $update['assigned_to'] = Auth::staffId(); // first responder picks up the ticket
            }
            Database::update('support_tickets', $update, ['id' => (int) $ticket['id']]);
            return $mid;
        });

        $mailResult = null;
        if (!$internal) {
            $mailResult = (new MailService())->send($ticket['email'], 'ticket_reply', [
                'customer_name' => $ticket['name'],
                'ticket_number' => $ticket['ticket_number'],
                'subject' => $ticket['subject'],
                'message' => $body,
                'ticket_url' => $this->customerTicketUrl($ticket),
            ]);
        }
        AuditLogger::log($internal ? 'ticket.note_added' : 'ticket.replied', 'support_ticket', (int) $ticket['id'], ['status' => $ticket['status']], [
            'message_id' => $messageId, 'internal' => $internal, 'status' => $statusAfter !== '' ? $statusAfter : $ticket['status'], 'email' => $mailResult,
        ]);

        if ($internal) {
            flash('success', 'Internal note added. The customer cannot see it.');
        } elseif (in_array($mailResult, ['sent', 'logged'], true)) {
            flash('success', 'Reply sent to ' . $ticket['email'] . ($mailResult === 'logged' ? ' (mail log mode: recorded in the outbox).' : '.'));
        } else {
            flash('warning', 'Reply saved, but the email notification was not delivered (' . $mailResult . ').' . ($ticket['user_id'] ? ' The customer can still read it in their account.' : ' This is a guest ticket, so please contact the customer another way.'));
        }
        return $this->redirect(admin_url('tickets/' . (int) $ticket['id']));
    }

    public function updateTicket(Request $request, string $id): Response
    {
        Gate::authorize('support.manage');
        $ticket = $this->find((int) $id);
        $status = $request->str('status');
        $priority = $request->str('priority');
        $assignedRaw = $request->str('assigned_to');
        $errors = [];
        if (!in_array($status, self::STATUSES, true)) {
            $errors['status'] = 'Choose a valid status.';
        }
        if (!in_array($priority, self::PRIORITIES, true)) {
            $errors['priority'] = 'Choose a valid priority.';
        }
        $assignedTo = null;
        if ($assignedRaw !== '') {
            $assignedTo = (int) $assignedRaw;
            if (!in_array($assignedTo, array_map(static fn ($a) => (int) $a['id'], $this->assignees()), true)) {
                $errors['assigned_to'] = 'The selected staff member cannot handle support tickets.';
            }
        }
        if ($errors) {
            throw new ValidationException($errors, $request->all());
        }
        $new = ['status' => $status, 'priority' => $priority, 'assigned_to' => $assignedTo];
        $old = ['status' => $ticket['status'], 'priority' => $ticket['priority'], 'assigned_to' => $ticket['assigned_to'] !== null ? (int) $ticket['assigned_to'] : null];
        if ($new !== $old) {
            Database::update('support_tickets', $new + ['updated_at' => Database::now()], ['id' => (int) $ticket['id']]);
            AuditLogger::log('ticket.updated', 'support_ticket', (int) $ticket['id'], $old, $new);
            flash('success', 'Ticket updated.');
        } else {
            flash('info', 'No changes to save.');
        }
        return $this->redirect(admin_url('tickets/' . (int) $ticket['id']));
    }

    private function find(int $id): array
    {
        $t = Database::fetch(
            'SELECT t.*, a.name AS assignee_name, c.name AS account_name, c.phone AS account_phone
             FROM support_tickets t LEFT JOIN users a ON a.id = t.assigned_to LEFT JOIN users c ON c.id = t.user_id
             WHERE t.id = :id',
            ['id' => $id]
        );
        if (!$t) {
            throw new HttpException(404);
        }
        return $t;
    }

    /** Active staff who hold support.manage (computed through the Gate, so role changes apply immediately). */
    private function assignees(): array
    {
        $staff = Database::fetchAll("SELECT id, name, email FROM users WHERE type = 'staff' AND status = 'active' ORDER BY name");
        return array_values(array_filter($staff, static fn ($u) => Gate::allows('support.manage', (int) $u['id'])));
    }

    private function customerTicketUrl(array $ticket): string
    {
        return $ticket['user_id']
            ? url('/account/support/' . rawurlencode((string) $ticket['ticket_number']))
            : url('/contact');
    }
}
