<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Cache;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;
use App\Repositories\Admin\CatalogAdminRepository;
use App\Services\InventoryService;
use RuntimeException;

/** Admin > Inventory: stock levels, adjustments (always via InventoryService) and movement history. */
final class InventoryController extends Controller
{
    public const MOVEMENT_TYPES = ['sale', 'release', 'adjustment', 'receive', 'return', 'damage', 'initial'];
    /** Reasons staff may choose for a delta adjustment. */
    private const REASONS = [
        'receive' => 'Received stock (+)',
        'return' => 'Customer return to stock (+)',
        'damage' => 'Damaged / write-off (−)',
        'adjustment' => 'Manual correction (±)',
    ];

    private CatalogAdminRepository $repo;
    private InventoryService $inventory;

    public function __construct()
    {
        $this->repo = new CatalogAdminRepository();
        $this->inventory = new InventoryService();
    }

    public function index(Request $request): Response
    {
        $filters = [
            'q' => mb_substr($request->str('q'), 0, 100),
            'low' => $request->bool('low'),
            'status' => in_array($request->str('status'), ['draft', 'active', 'inactive'], true) ? $request->str('status') : '',
        ];
        $perPage = 30;
        $page = max(1, $request->int('page', 1));
        $offset = ($page - 1) * $perPage;
        $result = $this->repo->stockLevels($filters, $perPage, $offset);
        $paginator = new Paginator($result['total'], $perPage, $page);
        $summary = Database::fetch(
            "SELECT COUNT(*) AS items, COALESCE(SUM(i.quantity), 0) AS units,
                    COALESCE(SUM(i.quantity <= i.low_stock_threshold AND i.quantity > 0), 0) AS low,
                    COALESCE(SUM(i.quantity <= 0), 0) AS out_of_stock,
                    COALESCE(SUM(i.damaged_quantity), 0) AS damaged
             FROM inventory i JOIN products p ON p.id = i.product_id"
        ) ?? [];

        return $this->adminView('inventory/index', [
            'title' => 'Inventory',
            'items' => $result['items'],
            'total' => $result['total'],
            'paginator' => $paginator,
            'filters' => $filters,
            'summary' => $summary,
        ]);
    }

    public function show(Request $request, string $id): Response
    {
        $item = $this->findOrFail((int) $id);
        $history = $this->repo->movements(['product_id' => (int) $item['product_id'], 'variant_id' => (int) $item['variant_id']], 15, 0);
        return $this->adminView('inventory/show', [
            'title' => 'Adjust stock: ' . $item['product_name'],
            'item' => $item,
            'reasons' => self::REASONS,
            'history' => $history['items'],
            'historyTotal' => $history['total'],
        ]);
    }

    public function adjust(Request $request, string $id): Response
    {
        $item = $this->findOrFail((int) $id);
        $pid = (int) $item['product_id'];
        $vid = (int) $item['variant_id'];
        $mode = $request->str('mode') === 'set' ? 'set' : 'delta';
        $note = mb_substr($request->str('note'), 0, 255);
        $staffId = Auth::staffId();
        $old = $request->all();
        unset($old['_token']);

        $before = (int) $item['quantity'];
        try {
            if ($mode === 'set') {
                $raw = $request->str('quantity');
                if (filter_var($raw, FILTER_VALIDATE_INT) === false || (int) $raw < 0 || (int) $raw > 10000000) {
                    throw new ValidationException(['quantity' => 'Counted quantity must be a whole number of 0 or more.'], $old);
                }
                $after = $this->inventory->setQuantity($pid, $vid, (int) $raw, $staffId, $note !== '' ? 'Stock count: ' . $note : 'Stock count');
                $type = 'adjustment';
            } else {
                $type = $request->str('reason');
                if (!isset(self::REASONS[$type])) {
                    throw new ValidationException(['reason' => 'Choose a reason for the change.'], $old);
                }
                $raw = $request->str('delta');
                if (filter_var($raw, FILTER_VALIDATE_INT) === false || (int) $raw === 0 || abs((int) $raw) > 10000000) {
                    throw new ValidationException(['delta' => 'Enter a non-zero whole number.'], $old);
                }
                $delta = (int) $raw;
                if (in_array($type, ['receive', 'return'], true)) {
                    $delta = abs($delta);
                } elseif ($type === 'damage') {
                    $delta = -abs($delta);
                }
                if (in_array($type, ['adjustment', 'damage'], true) && $note === '') {
                    throw new ValidationException(['note' => 'Add a short note explaining this change.'], $old);
                }
                // Manual changes may never take stock below zero, even for backorder products.
                $after = Database::transaction(function () use ($pid, $vid, $delta, $type, $staffId, $note) {
                    $current = (int) Database::fetchColumn(
                        'SELECT quantity FROM inventory WHERE product_id = :p AND variant_id = :v FOR UPDATE',
                        ['p' => $pid, 'v' => $vid]
                    );
                    if ($current + $delta < 0) {
                        throw new RuntimeException('Only ' . max(0, $current) . ' unit(s) are in stock; you cannot remove ' . abs($delta) . '.');
                    }
                    return $this->inventory->change($pid, $vid, $delta, $type, 'manual', null, $staffId, $note !== '' ? $note : null);
                });
            }
        } catch (ValidationException $e) {
            throw $e;
        } catch (\PDOException $e) {
            throw $e; // database errors are not user messages
        } catch (RuntimeException $e) {
            flash('error', $e->getMessage());
            return $this->redirect(admin_url('inventory/' . (int) $item['id']));
        }

        if ($after === $before) {
            flash('info', 'No change — the quantity is already ' . $after . '.');
        } else {
            AuditLogger::log('inventory.adjust', 'inventory', (int) $item['id'], ['quantity' => $before], [
                'quantity' => $after, 'type' => $type, 'mode' => $mode, 'note' => $note,
                'product_id' => $pid, 'variant_id' => $vid,
            ]);
            flash('success', 'Stock updated: ' . $before . ' → ' . $after . '.');
        }
        Cache::bump('catalog');
        return $this->redirect(admin_url('inventory/' . (int) $item['id']));
    }

    /** Threshold and location only; quantities are never edited here. */
    public function settings(Request $request, string $id): Response
    {
        $item = $this->findOrFail((int) $id);
        $data = $this->validate($request, [
            'low_stock_threshold' => 'required|integer|min:0|max:100000',
            'location' => 'nullable|max:80',
        ], ['low_stock_threshold' => 'Low-stock threshold']);
        $new = [
            'low_stock_threshold' => (int) $data['low_stock_threshold'],
            'location' => ($data['location'] ?? '') !== '' ? (string) $data['location'] : null,
        ];
        Database::update('inventory', $new, ['id' => (int) $item['id']]);
        AuditLogger::log('inventory.settings', 'inventory', (int) $item['id'], [
            'low_stock_threshold' => (int) $item['low_stock_threshold'], 'location' => $item['location'],
        ], $new);
        Cache::bump('catalog');
        flash('success', 'Threshold and location saved.');
        return $this->redirect(admin_url('inventory/' . (int) $item['id']));
    }

    public function movements(Request $request): Response
    {
        $type = $request->str('type');
        $from = $request->str('from');
        $to = $request->str('to');
        $filters = [
            'product_id' => max(0, $request->int('product')),
            'type' => in_array($type, self::MOVEMENT_TYPES, true) ? $type : '',
            'q' => mb_substr($request->str('q'), 0, 100),
        ];
        if ($this->isDate($from)) {
            $filters['from_utc'] = local_to_utc($from . ' 00:00:00');
        }
        if ($this->isDate($to)) {
            $filters['to_utc'] = local_to_utc(date('Y-m-d', strtotime($to . ' +1 day')) . ' 00:00:00');
        }
        $perPage = 40;
        $page = max(1, $request->int('page', 1));
        $result = $this->repo->movements($filters, $perPage, ($page - 1) * $perPage);

        return $this->adminView('inventory/movements', [
            'title' => 'Stock movements',
            'movements' => $result['items'],
            'total' => $result['total'],
            'paginator' => new Paginator($result['total'], $perPage, $page),
            'products' => $this->repo->productOptions(),
            'types' => self::MOVEMENT_TYPES,
            'filters' => [
                'product' => $filters['product_id'], 'type' => $filters['type'], 'q' => $filters['q'],
                'from' => $this->isDate($from) ? $from : '', 'to' => $this->isDate($to) ? $to : '',
            ],
        ]);
    }

    private function findOrFail(int $id): array
    {
        $item = $this->repo->inventoryItem($id);
        if (!$item) {
            throw new HttpException(404);
        }
        return $item;
    }

    private function isDate(string $d): bool
    {
        $dt = \DateTime::createFromFormat('Y-m-d', $d);
        return $dt !== false && $dt->format('Y-m-d') === $d;
    }
}
