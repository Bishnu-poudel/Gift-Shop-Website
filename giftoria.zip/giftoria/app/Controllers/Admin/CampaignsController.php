<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\Uploader;
use App\Core\ValidationException;
use App\Core\Validator;
use App\Services\CampaignService;

/**
 * Campaigns: homepage banners, seasonal promos and landing pages (/campaign/{slug}).
 * A campaign is "scheduled" purely by its start/end dates (see CampaignService::statusOf).
 * Staff holding only banners.manage may create and edit banner campaigns only.
 */
final class CampaignsController extends Controller
{
    public const TYPES = ['banner' => 'Banner', 'seasonal' => 'Seasonal promo', 'landing' => 'Landing page'];

    /** Campaign types the current staff member may manage. */
    public static function allowedTypes(): array
    {
        if (Gate::allows('campaigns.manage')) {
            return array_keys(self::TYPES);
        }
        return Gate::allows('banners.manage') ? ['banner'] : [];
    }

    /** Relative path ("/shop") or absolute https URL; rejects javascript:, protocol-relative and http. */
    public static function safeCtaUrl(string $url): bool
    {
        if ($url === '' || preg_match('/[\s<>"\'\\\\]/', $url)) {
            return false;
        }
        if (str_starts_with($url, '/')) {
            return !str_starts_with($url, '//');
        }
        return (bool) preg_match('#^https://[^/\s]+#i', $url) && filter_var($url, FILTER_VALIDATE_URL) !== false;
    }

    public function index(Request $request): Response
    {
        $q = $request->str('q');
        $type = $request->str('type');
        $status = $request->str('status');
        $where = [];
        $params = [];
        if ($q !== '') {
            $params['q'] = '%' . $q . '%';
            $params['q2'] = '%' . $q . '%';
            $where[] = '(c.name LIKE :q OR c.slug LIKE :q2)';
        }
        if (isset(self::TYPES[$type])) {
            $params['type'] = $type;
            $where[] = 'c.type = :type';
        }
        $statusSql = [
            'draft' => 'c.is_active = 0',
            'scheduled' => 'c.is_active = 1 AND c.starts_at > UTC_TIMESTAMP()',
            'ended' => 'c.is_active = 1 AND (c.starts_at IS NULL OR c.starts_at <= UTC_TIMESTAMP()) AND c.ends_at < UTC_TIMESTAMP()',
            'live' => 'c.is_active = 1 AND (c.starts_at IS NULL OR c.starts_at <= UTC_TIMESTAMP()) AND (c.ends_at IS NULL OR c.ends_at >= UTC_TIMESTAMP())',
        ];
        if (isset($statusSql[$status])) {
            $where[] = '(' . $statusSql[$status] . ')';
        }
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM campaigns c $whereSql", $params);
        $p = Paginator::fromRequest($total, 25);
        $rows = Database::fetchAll(
            "SELECT c.*, cp.code AS coupon_code FROM campaigns c LEFT JOIN coupons cp ON cp.id = c.coupon_id
             $whereSql ORDER BY c.sort_order, c.id DESC LIMIT {$p->perPage} OFFSET {$p->offset}",
            $params
        );
        foreach ($rows as &$row) {
            $row['status'] = CampaignService::statusOf($row);
        }
        unset($row);

        return $this->adminView('campaigns/index', [
            'title' => 'Campaigns',
            'campaigns' => $rows,
            'paginator' => $p,
            'filters' => ['q' => $q, 'type' => $type, 'status' => $status],
            'allowedTypes' => self::allowedTypes(),
        ]);
    }

    public function create(Request $request): Response
    {
        return $this->adminView('campaigns/form', $this->formData(null) + ['title' => 'New campaign']);
    }

    public function store(Request $request): Response
    {
        $this->authorizeAny();
        $data = $this->validated($request, null);
        $data['created_by'] = Auth::staffId();
        $id = Database::insert('campaigns', $data);
        AuditLogger::log('campaign.created', 'campaign', $id, null, $data);
        flash('success', 'Campaign "' . $data['name'] . '" saved.');
        return $this->redirect(admin_url('campaigns'));
    }

    public function edit(Request $request, string $id): Response
    {
        $campaign = $this->findEditable((int) $id);
        return $this->adminView('campaigns/form', $this->formData($campaign) + ['title' => 'Edit campaign']);
    }

    public function update(Request $request, string $id): Response
    {
        $this->authorizeAny();
        $campaign = $this->findEditable((int) $id);
        $data = $this->validated($request, $campaign);
        Database::update('campaigns', $data, ['id' => (int) $campaign['id']]);
        if (array_key_exists('image', $data) && $campaign['image'] && $campaign['image'] !== $data['image']) {
            Uploader::delete($campaign['image']);
        }
        AuditLogger::log('campaign.updated', 'campaign', (int) $campaign['id'], array_intersect_key($campaign, $data), $data);
        flash('success', 'Campaign "' . $data['name'] . '" updated.');
        return $this->redirect(admin_url('campaigns'));
    }

    public function deactivate(Request $request, string $id): Response
    {
        $this->authorizeAny();
        $campaign = $this->findEditable((int) $id);
        if ((int) $campaign['is_active'] === 1) {
            Database::update('campaigns', ['is_active' => 0], ['id' => (int) $campaign['id']]);
            AuditLogger::log('campaign.deactivated', 'campaign', (int) $campaign['id'], ['is_active' => 1], ['is_active' => 0]);
        }
        flash('success', 'Campaign moved back to draft. It is no longer shown on the storefront.');
        return $this->redirect(admin_url('campaigns'));
    }

    private function authorizeAny(): void
    {
        if (!Gate::any(['campaigns.manage', 'banners.manage'])) {
            Gate::authorize('campaigns.manage'); // logs the denial and throws 403
        }
    }

    private function findEditable(int $id): array
    {
        $c = Database::fetch('SELECT * FROM campaigns WHERE id = :id', ['id' => $id]);
        if (!$c) {
            throw new HttpException(404);
        }
        if (!in_array($c['type'], self::allowedTypes(), true)) {
            AuditLogger::log('access.denied', 'campaign', $id, null, ['permission' => 'campaigns.manage']);
            throw new HttpException(403);
        }
        return $c;
    }

    private function formData(?array $campaign): array
    {
        return [
            'campaign' => $campaign,
            'allowedTypes' => self::allowedTypes(),
            'coupons' => Database::fetchAll('SELECT id, code, type, value, is_active FROM coupons ORDER BY is_active DESC, code'),
            'products' => Database::fetchAll("SELECT id, name, sku FROM products WHERE status = 'active' ORDER BY name LIMIT 1000"),
        ];
    }

    private function validated(Request $request, ?array $existing): array
    {
        $in = $request->all();
        $in['slug'] = strtolower(trim((string) ($in['slug'] ?? '')));
        if ($in['slug'] === '' && trim((string) ($in['name'] ?? '')) !== '') {
            $in['slug'] = str_slug((string) $in['name']);
        }
        $ignore = $existing ? ',' . (int) $existing['id'] : '';
        $allowed = self::allowedTypes();
        $v = Validator::make($in, [
            'name' => ['required', 'string', 'max:120'],
            'slug' => ['required', 'slug', 'max:140', 'unique:campaigns,slug' . $ignore],
            'type' => ['required', 'in:' . implode(',', $allowed)],
            'headline' => ['nullable', 'string', 'max:190'],
            'subheadline' => ['nullable', 'string', 'max:300'],
            'body' => ['nullable', 'string', 'max:20000'],
            'cta_label' => ['nullable', 'string', 'max:60'],
            'cta_url' => ['nullable', 'string', 'max:255'],
            'coupon_id' => ['nullable', 'integer', 'exists:coupons,id'],
            'product_ids' => ['array', 'max:24'],
            'theme_color' => ['nullable', 'regex:/^#(?:[0-9a-fA-F]{3}){1,2}$/'],
            'starts_at' => ['nullable', 'datetime'],
            'ends_at' => ['nullable', 'datetime'],
            'sort_order' => ['nullable', 'integer', 'min:-1000', 'max:1000'],
        ], ['cta_url' => 'Button link', 'cta_label' => 'Button label', 'coupon_id' => 'Coupon', 'theme_color' => 'Theme colour']);

        $errors = $v->fails() ? $v->errors() : [];
        $d = $v->validated();

        $cta = (string) ($d['cta_url'] ?? '');
        if ($cta !== '' && !isset($errors['cta_url']) && !self::safeCtaUrl($cta)) {
            $errors['cta_url'] = 'Use a relative path starting with / (e.g. /shop) or a full https:// URL.';
        }
        if (($d['cta_label'] ?? '') !== '' && $cta === '') {
            $errors['cta_url'] = 'Add a link for the button.';
        }

        $starts = local_to_utc(($d['starts_at'] ?? '') ?: null);
        $ends = local_to_utc(($d['ends_at'] ?? '') ?: null);
        if ($starts && $ends && $ends <= $starts) {
            $errors['ends_at'] = 'The end date must be after the start date.';
        }

        $productIds = [];
        $raw = array_values(array_unique(array_filter(array_map('intval', array_filter((array) ($d['product_ids'] ?? []), 'is_scalar')), static fn ($i) => $i > 0)));
        if ($raw) {
            $params = [];
            $inSql = Database::in('pid', array_slice($raw, 0, 24), $params);
            $found = array_map('intval', Database::fetchCol("SELECT id FROM products WHERE id IN $inSql", $params));
            $productIds = array_values(array_intersect($raw, $found));
        }

        $image = null;
        $file = $request->file('image');
        if (!$errors && $file && ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            try {
                $image = Uploader::image($file, 'campaigns');
            } catch (\RuntimeException $e) {
                $errors['image'] = $e->getMessage();
            }
        }

        if ($errors) {
            if ($image) {
                Uploader::delete($image);
            }
            unset($in['image']);
            throw new ValidationException($errors, $in);
        }

        $nullIfEmpty = static fn ($v) => ($v === null || $v === '') ? null : $v;
        $out = [
            'name' => $d['name'],
            'slug' => $d['slug'],
            'type' => $d['type'],
            'headline' => $nullIfEmpty($d['headline'] ?? null),
            'subheadline' => $nullIfEmpty($d['subheadline'] ?? null),
            'body' => $nullIfEmpty(isset($d['body']) ? str_replace("\r\n", "\n", (string) $d['body']) : null),
            'cta_label' => $nullIfEmpty($d['cta_label'] ?? null),
            'cta_url' => $nullIfEmpty($cta),
            'coupon_id' => ($d['coupon_id'] ?? '') !== '' && $d['coupon_id'] !== null ? (int) $d['coupon_id'] : null,
            'product_ids' => $productIds ? implode(',', $productIds) : null,
            'theme_color' => $nullIfEmpty($d['theme_color'] ?? null),
            'starts_at' => $starts,
            'ends_at' => $ends,
            'is_active' => $request->bool('is_active') ? 1 : 0,
            'sort_order' => (int) ($d['sort_order'] ?? 0),
        ];
        if ($image) {
            $out['image'] = $image;
        } elseif ($existing && $request->bool('remove_image')) {
            $out['image'] = null;
        }
        return $out;
    }
}
