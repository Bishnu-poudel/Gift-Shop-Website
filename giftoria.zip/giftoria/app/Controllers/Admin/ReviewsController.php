<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Cache;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;
use App\Repositories\ProductRepository;

/** Review moderation and product Q&A. Only approved reviews count towards product ratings. */
final class ReviewsController extends Controller
{
    public function index(Request $request): Response
    {
        $status = $request->str('status');
        $rating = $request->int('rating');
        $verified = $request->str('verified');
        $q = $request->str('q');
        $where = [];
        $params = [];
        if (in_array($status, ['pending', 'approved', 'rejected'], true)) {
            $params['st'] = $status;
            $where[] = 'r.status = :st';
        }
        if ($rating >= 1 && $rating <= 5) {
            $params['rt'] = $rating;
            $where[] = 'r.rating = :rt';
        }
        if ($verified === '1' || $verified === '0') {
            $params['vf'] = (int) $verified;
            $where[] = 'r.is_verified = :vf';
        }
        if ($q !== '') {
            $params['q1'] = '%' . $q . '%';
            $params['q2'] = '%' . $q . '%';
            $params['q3'] = '%' . $q . '%';
            $where[] = '(p.name LIKE :q1 OR r.title LIKE :q2 OR r.body LIKE :q3)';
        }
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $from = 'FROM reviews r JOIN products p ON p.id = r.product_id JOIN users u ON u.id = r.user_id';
        $total = (int) Database::fetchColumn("SELECT COUNT(*) $from $whereSql", $params);
        $p = Paginator::fromRequest($total, 25);
        $rows = Database::fetchAll(
            "SELECT r.*, p.name AS product_name, p.slug AS product_slug, u.name AS customer_name, u.email AS customer_email,
                    m.name AS moderator_name
             $from LEFT JOIN users m ON m.id = r.moderated_by
             $whereSql
             ORDER BY FIELD(r.status, 'pending', 'approved', 'rejected'), r.created_at DESC, r.id DESC
             LIMIT {$p->perPage} OFFSET {$p->offset}",
            $params
        );
        return $this->adminView('reviews/index', [
            'title' => 'Reviews',
            'tab' => 'reviews',
            'reviews' => $rows,
            'paginator' => $p,
            'filters' => ['status' => $status, 'rating' => $rating, 'verified' => $verified, 'q' => $q],
            'counts' => $this->counts(),
        ]);
    }

    public function moderate(Request $request, string $id): Response
    {
        Gate::authorize('reviews.manage');
        $review = Database::fetch('SELECT * FROM reviews WHERE id = :id', ['id' => (int) $id]);
        if (!$review) {
            throw new HttpException(404);
        }
        $to = $request->str('status');
        if (!in_array($to, ['approved', 'rejected', 'pending'], true)) {
            throw new ValidationException(['status' => 'Choose approve or reject.'], $request->all());
        }
        if ($to !== $review['status']) {
            Database::update('reviews', ['status' => $to, 'moderated_by' => Auth::staffId()], ['id' => (int) $review['id']]);
            (new ProductRepository())->recordRatingSummary((int) $review['product_id']);
            Cache::bump('catalog');
            AuditLogger::log('review.' . $to, 'review', (int) $review['id'], ['status' => $review['status']], ['status' => $to, 'product_id' => (int) $review['product_id']]);
        }
        flash('success', 'Review ' . ($to === 'approved' ? 'approved and published' : ($to === 'rejected' ? 'rejected' : 'moved back to pending')) . '.');
        return $this->back(admin_url('reviews'));
    }

    public function questions(Request $request): Response
    {
        $status = $request->str('status');
        $q = $request->str('q');
        $where = [];
        $params = [];
        if (in_array($status, ['pending', 'published', 'rejected'], true)) {
            $params['st'] = $status;
            $where[] = 'pq.status = :st';
        }
        if ($q !== '') {
            $params['q1'] = '%' . $q . '%';
            $params['q2'] = '%' . $q . '%';
            $where[] = '(p.name LIKE :q1 OR pq.question LIKE :q2)';
        }
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $from = 'FROM product_questions pq JOIN products p ON p.id = pq.product_id';
        $total = (int) Database::fetchColumn("SELECT COUNT(*) $from $whereSql", $params);
        $p = Paginator::fromRequest($total, 20);
        $rows = Database::fetchAll(
            "SELECT pq.*, p.name AS product_name, p.slug AS product_slug, a.name AS answered_by_name
             $from LEFT JOIN users a ON a.id = pq.answered_by
             $whereSql
             ORDER BY FIELD(pq.status, 'pending', 'published', 'rejected'), pq.created_at DESC, pq.id DESC
             LIMIT {$p->perPage} OFFSET {$p->offset}",
            $params
        );
        return $this->adminView('reviews/questions', [
            'title' => 'Product questions',
            'tab' => 'questions',
            'questions' => $rows,
            'paginator' => $p,
            'filters' => ['status' => $status, 'q' => $q],
            'counts' => $this->counts(),
        ]);
    }

    public function answer(Request $request, string $id): Response
    {
        Gate::authorize('reviews.manage');
        $question = Database::fetch('SELECT * FROM product_questions WHERE id = :id', ['id' => (int) $id]);
        if (!$question) {
            throw new HttpException(404);
        }
        $status = $request->str('status');
        $answer = str_replace("\r\n", "\n", $request->str('answer'));
        $errors = [];
        if (!in_array($status, ['published', 'rejected', 'pending'], true)) {
            $errors['status'] = 'Choose publish or reject.';
        }
        if ($status === 'published' && $answer === '') {
            $errors['answer_' . (int) $question['id']] = 'Write an answer before publishing.';
        }
        if (mb_strlen($answer) > 5000) {
            $errors['answer_' . (int) $question['id']] = 'The answer may not exceed 5000 characters.';
        }
        if ($errors) {
            throw new ValidationException($errors, $request->all());
        }
        $data = ['status' => $status, 'answer' => $answer !== '' ? $answer : null];
        if ($answer !== '' && $answer !== (string) $question['answer']) {
            $data['answered_by'] = Auth::staffId();
        }
        Database::update('product_questions', $data, ['id' => (int) $question['id']]);
        Cache::bump('catalog');
        AuditLogger::log('product_question.' . $status, 'product_question', (int) $question['id'],
            ['status' => $question['status'], 'answer' => $question['answer']], $data);
        flash('success', $status === 'published' ? 'Answer published on the product page.' : ($status === 'rejected' ? 'Question rejected.' : 'Question saved as pending.'));
        return $this->back(admin_url('reviews/questions'));
    }

    private function counts(): array
    {
        return Database::fetch(
            "SELECT (SELECT COUNT(*) FROM reviews WHERE status = 'pending') AS pending_reviews,
                    (SELECT COUNT(*) FROM product_questions WHERE status = 'pending') AS pending_questions"
        ) ?? [];
    }
}
