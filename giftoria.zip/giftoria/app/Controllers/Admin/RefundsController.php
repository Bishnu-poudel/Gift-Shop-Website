<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Repositories\Admin\OrderAdminRepository;
use App\Services\MailService;
use App\Services\OrderService;
use App\Services\OrderStateMachine;
use DomainException;
use RuntimeException;

/**
 * Refund workflow: requested → approved → completed (or rejected).
 * eSewa/Khalti refunds are executed by finance in the merchant portal; this records them with the
 * portal's reference and updates order totals and payment status atomically.
 */
final class RefundsController extends Controller
{
    public const STATUSES = ['requested', 'approved', 'completed', 'rejected'];

    public function index(Request $request): Response
    {
        $status = $request->str('status');
        $status = in_array($status, self::STATUSES, true) ? $status : '';
        $q = mb_substr($request->str('q'), 0, 60);
        $w = ['1 = 1'];
        $p = [];
        if ($status !== '') {
            $w[] = 'r.status = :s';
            $p['s'] = $status;
        }
        if ($q !== '') {
            $w[] = 'o.order_number LIKE :q';
            $p['q'] = '%' . addcslashes($q, '%_\\') . '%';
        }
        $where = implode(' AND ', $w);
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM refunds r JOIN orders o ON o.id = r.order_id WHERE $where", $p);
        $pager = Paginator::fromRequest($total, 25);
        $refunds = Database::fetchAll(
            "SELECT r.*, o.order_number, o.customer_name, o.payment_method, o.grand_total, o.refunded_total, o.status AS order_status,
                    pay.gateway, pay.gateway_txn_id, rq.name AS requested_by_name, pr.name AS processed_by_name
             FROM refunds r
             JOIN orders o ON o.id = r.order_id
             LEFT JOIN payments pay ON pay.id = r.payment_id
             LEFT JOIN users rq ON rq.id = r.requested_by
             LEFT JOIN users pr ON pr.id = r.processed_by
             WHERE $where
             ORDER BY FIELD(r.status, 'requested', 'approved', 'completed', 'rejected'), r.id DESC
             LIMIT " . (int) $pager->perPage . ' OFFSET ' . (int) $pager->offset,
            $p
        );
        $counts = array_fill_keys(self::STATUSES, 0);
        foreach (Database::fetchAll('SELECT status, COUNT(*) AS n FROM refunds GROUP BY status') as $row) {
            $counts[$row['status']] = (int) $row['n'];
        }
        return $this->adminView('refunds/index', [
            'title' => 'Refunds',
            'refunds' => $refunds,
            'filters' => ['status' => $status, 'q' => $q],
            'counts' => $counts,
            'paginator' => $pager,
            'canManage' => Gate::allows('refunds.manage'),
        ]);
    }

    public function store(Request $request): Response
    {
        Gate::authorize('refunds.manage');
        $data = $this->validate($request, [
            'order_id' => 'nullable|integer',
            'order_number' => 'nullable|string|max:30',
            'amount' => 'required|numeric|min:0.01',
            'reason' => 'required|string|max:500',
        ]);
        $order = !empty($data['order_id'])
            ? Database::fetch('SELECT * FROM orders WHERE id = :id', ['id' => (int) $data['order_id']])
            : (!empty($data['order_number']) ? Database::fetch('SELECT * FROM orders WHERE order_number = :n', ['n' => strtoupper($data['order_number'])]) : null);
        if (!$order) {
            flash('error', 'Order not found.');
            return $this->back(admin_url('refunds'));
        }
        $amount = round((float) $data['amount'], 2);
        $repo = new OrderAdminRepository();
        try {
            $refundId = Database::transaction(function () use ($order, $amount, $data, $repo) {
                $locked = Database::fetch('SELECT * FROM orders WHERE id = :id FOR UPDATE', ['id' => (int) $order['id']]);
                $avail = $repo->refundable($locked);
                if ($avail['paid'] <= 0) {
                    throw new RuntimeException('This order has no captured payment to refund.');
                }
                if ($amount > $avail['available'] + 0.001) {
                    throw new RuntimeException('Amount exceeds the refundable balance of ' . money($avail['available']) . ' (paid ' . money($avail['paid']) . ', refunded ' . money($avail['refunded']) . ', open requests ' . money($avail['open']) . ').');
                }
                $paymentId = Database::fetchColumn(
                    "SELECT id FROM payments WHERE order_id = :o AND verified_at IS NOT NULL AND status IN ('paid','partially_refunded','refund_pending') ORDER BY id DESC LIMIT 1",
                    ['o' => (int) $locked['id']]
                );
                return Database::insert('refunds', [
                    'order_id' => (int) $locked['id'],
                    'payment_id' => $paymentId ? (int) $paymentId : null,
                    'amount' => $amount,
                    'reason' => strip_tags($data['reason']),
                    'status' => 'requested',
                    'requested_by' => Auth::staffId(),
                ]);
            });
        } catch (RuntimeException $e) {
            flash('error', $e->getMessage());
            return $this->back(admin_url('refunds'));
        }
        AuditLogger::log('refund.requested', 'refund', $refundId, null, ['order_id' => (int) $order['id'], 'amount' => $amount, 'reason' => $data['reason']]);
        flash('success', 'Refund request #' . $refundId . ' created for ' . money($amount) . '.');
        return $this->back(admin_url('refunds'));
    }

    private function refund(string $id): array
    {
        $r = Database::fetch('SELECT * FROM refunds WHERE id = :id', ['id' => (int) $id]);
        if (!$r) {
            throw new HttpException(404, 'Refund not found.');
        }
        return $r;
    }

    public function approve(Request $request, string $id): Response
    {
        Gate::authorize('refunds.manage');
        $refund = $this->refund($id);
        $changed = Database::transaction(function () use ($refund) {
            $locked = Database::fetch('SELECT * FROM refunds WHERE id = :id FOR UPDATE', ['id' => (int) $refund['id']]);
            if ($locked['status'] !== 'requested') {
                return false;
            }
            Database::update('refunds', ['status' => 'approved'], ['id' => (int) $refund['id']]);
            return true;
        });
        if (!$changed) {
            flash('error', 'Only requested refunds can be approved.');
            return $this->back(admin_url('refunds'));
        }
        AuditLogger::log('refund.approved', 'refund', (int) $refund['id'], ['status' => 'requested'], ['status' => 'approved']);
        flash('success', 'Refund #' . (int) $refund['id'] . ' approved. Process it in the gateway portal, then mark it completed with the portal reference.');
        return $this->back(admin_url('refunds'));
    }

    public function reject(Request $request, string $id): Response
    {
        Gate::authorize('refunds.manage');
        $refund = $this->refund($id);
        $note = mb_substr(strip_tags($request->str('note')), 0, 500);
        $orders = new OrderService();
        try {
            Database::transaction(function () use ($refund, $note, $orders) {
                $locked = Database::fetch('SELECT * FROM refunds WHERE id = :id FOR UPDATE', ['id' => (int) $refund['id']]);
                if (!in_array($locked['status'], ['requested', 'approved'], true)) {
                    throw new RuntimeException('Only open refunds can be rejected.');
                }
                Database::update('refunds', ['status' => 'rejected', 'processed_by' => Auth::staffId(), 'processed_at' => Database::now()], ['id' => (int) $refund['id']]);
                if ($note !== '') {
                    Database::insert('order_notes', ['order_id' => (int) $refund['order_id'], 'user_id' => Auth::staffId(), 'note' => 'Refund #' . (int) $refund['id'] . ' rejected: ' . $note, 'is_internal' => 1]);
                }
                // If nothing else is pending, restore the payment status that the refund request displaced.
                $order = Database::fetch('SELECT * FROM orders WHERE id = :id FOR UPDATE', ['id' => (int) $refund['order_id']]);
                $open = (int) Database::fetchColumn("SELECT COUNT(*) FROM refunds WHERE order_id = :o AND status IN ('requested','approved')", ['o' => (int) $refund['order_id']]);
                if ($order && $open === 0 && $order['payment_status'] === 'refund_pending') {
                    $orders->setPaymentStatus((int) $order['id'], (float) $order['refunded_total'] > 0 ? 'partially_refunded' : 'paid', 'Refund request rejected', Auth::staffId());
                }
            });
        } catch (RuntimeException|DomainException $e) {
            flash('error', $e->getMessage());
            return $this->back(admin_url('refunds'));
        }
        AuditLogger::log('refund.rejected', 'refund', (int) $refund['id'], ['status' => $refund['status']], ['status' => 'rejected', 'note' => $note]);
        flash('success', 'Refund #' . (int) $refund['id'] . ' rejected.');
        return $this->back(admin_url('refunds'));
    }

    public function complete(Request $request, string $id): Response
    {
        Gate::authorize('refunds.manage');
        $refund = $this->refund($id);
        $data = $this->validate($request, ['gateway_reference' => 'required|string|max:120'], ['gateway_reference' => 'Gateway / portal reference']);
        $reference = strip_tags($data['gateway_reference']);
        $orders = new OrderService();
        $staffId = Auth::staffId();

        try {
            $result = Database::transaction(function () use ($refund, $reference, $orders, $staffId) {
                $locked = Database::fetch('SELECT * FROM refunds WHERE id = :id FOR UPDATE', ['id' => (int) $refund['id']]);
                if ($locked['status'] !== 'approved') {
                    throw new RuntimeException('Only approved refunds can be marked completed.');
                }
                $order = Database::fetch('SELECT * FROM orders WHERE id = :id FOR UPDATE', ['id' => (int) $locked['order_id']]);
                $amount = (float) $locked['amount'];
                $remaining = round((float) $order['grand_total'] - (float) $order['refunded_total'], 2);
                if ($amount > $remaining + 0.001) {
                    throw new RuntimeException('Refund amount exceeds the remaining paid balance of ' . money($remaining) . '.');
                }
                $newRefunded = round((float) $order['refunded_total'] + $amount, 2);
                $full = $newRefunded >= (float) $order['grand_total'] - 0.005;

                Database::update('refunds', [
                    'status' => 'completed',
                    'gateway_reference' => $reference,
                    'processed_by' => $staffId,
                    'processed_at' => Database::now(),
                ], ['id' => (int) $locked['id']]);
                Database::update('orders', ['refunded_total' => $newRefunded], ['id' => (int) $order['id']]);
                $orders->setPaymentStatus((int) $order['id'], $full ? 'refunded' : 'partially_refunded', 'Refund #' . (int) $locked['id'] . ' completed (' . $reference . ')', $staffId);

                if ($locked['payment_id']) {
                    $payment = Database::fetch('SELECT id, status, amount FROM payments WHERE id = :id FOR UPDATE', ['id' => (int) $locked['payment_id']]);
                    if ($payment) {
                        $paymentRefunded = (float) Database::fetchColumn(
                            "SELECT COALESCE(SUM(amount), 0) FROM refunds WHERE payment_id = :p AND status = 'completed'",
                            ['p' => (int) $payment['id']]
                        );
                        $target = $paymentRefunded >= (float) $payment['amount'] - 0.005 ? 'refunded' : 'partially_refunded';
                        if ($payment['status'] !== $target && OrderStateMachine::canPayment($payment['status'], $target)) {
                            Database::update('payments', ['status' => $target], ['id' => (int) $payment['id']]);
                        }
                    }
                }
                if ($locked['return_request_id']) {
                    Database::query(
                        "UPDATE return_requests SET status = 'refunded', handled_by = :u WHERE id = :id AND status IN ('approved','received')",
                        ['u' => $staffId, 'id' => (int) $locked['return_request_id']]
                    );
                }
                return ['order_id' => (int) $order['id'], 'status' => $order['status'], 'full' => $full, 'amount' => $amount, 'refunded_total' => $newRefunded];
            });
        } catch (RuntimeException|DomainException $e) {
            flash('error', $e->getMessage());
            return $this->back(admin_url('refunds'));
        }

        AuditLogger::log('refund.completed', 'refund', (int) $refund['id'], ['status' => 'approved'], [
            'order_id' => $result['order_id'], 'amount' => $result['amount'], 'gateway_reference' => $reference, 'order_refunded_total' => $result['refunded_total'],
        ]);

        $emailed = false;
        if ($result['full'] && OrderStateMachine::canOrder($result['status'], 'refunded')) {
            try {
                $orders->transition($result['order_id'], 'refunded', $staffId, 'Fully refunded (refund #' . (int) $refund['id'] . ')');
                $emailed = true; // transition() sends the refund_update email
            } catch (DomainException|RuntimeException $e) {
                flash('warning', 'Refund recorded, but the order status could not be changed: ' . $e->getMessage());
            }
        }
        if (!$emailed) {
            $order = $orders->find($result['order_id']);
            if ($order) {
                (new MailService())->orderEmail('refund_update', $order);
            }
        }
        flash('success', 'Refund #' . (int) $refund['id'] . ' marked completed' . ($result['full'] ? ' — order fully refunded.' : '.') . ' The customer has been emailed.');
        return $this->back(admin_url('refunds'));
    }
}
