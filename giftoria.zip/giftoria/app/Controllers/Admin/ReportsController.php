<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\AuditLogger;
use App\Controllers\Controller;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Repositories\Admin\ReportRepository;

/** Sales reporting with CSV exports. Financial ledger export requires finance.export. */
final class ReportsController extends Controller
{
    public const TABS = [
        'sales' => 'Sales',
        'products' => 'Top products',
        'categories' => 'Categories',
        'coupons' => 'Coupons',
        'payments' => 'Payment methods',
    ];

    private function params(Request $request): array
    {
        $range = ReportRepository::range($request->str('from') ?: null, $request->str('to') ?: null, 30);
        $group = $request->str('group') === 'month' ? 'month' : 'day';
        return [$range, $group];
    }

    /** @return array{rows: array, extra: array} */
    private function data(string $tab, array $range, string $group): array
    {
        $repo = new ReportRepository();
        return match ($tab) {
            'sales' => ['rows' => $repo->salesReport($range, $group), 'extra' => ['series' => $repo->revenueSeries($range, $group)]],
            'products' => ['rows' => $repo->topProducts($range, 100), 'extra' => []],
            'categories' => ['rows' => $repo->topCategories($range, 100), 'extra' => []],
            'coupons' => ['rows' => $repo->couponPerformance($range, 100), 'extra' => []],
            'payments' => ['rows' => $repo->paymentMethodsReport($range), 'extra' => ['attempts' => $repo->paymentStats($range)]],
            default => throw new HttpException(404),
        };
    }

    public function index(Request $request): Response
    {
        $tab = $request->str('tab', 'sales');
        $tab = isset(self::TABS[$tab]) ? $tab : 'sales';
        [$range, $group] = $this->params($request);
        $data = $this->data($tab, $range, $group);
        return $this->adminView('reports/index', [
            'title' => 'Reports',
            'useCharts' => $tab === 'sales',
            'tab' => $tab,
            'range' => $range,
            'group' => $group,
            'rows' => $data['rows'],
            'extra' => $data['extra'],
            'canFinance' => Gate::allows('finance.export'),
        ]);
    }

    public function export(Request $request, string $type): Response
    {
        if (!isset(self::TABS[$type])) {
            throw new HttpException(404);
        }
        [$range, $group] = $this->params($request);
        $rows = $this->data($type, $range, $group)['rows'];
        [$headers, $out] = match ($type) {
            'sales' => [
                ['Period', 'Paid orders', 'Subtotal', 'Discounts', 'Shipping', 'Gift wrap', 'Gross', 'Refunded', 'Net', 'Item cost', 'Item margin', 'Items missing cost'],
                array_map(static fn ($r) => [$r['period'], (int) $r['orders'], $r['subtotal'], $r['discount'], $r['shipping'], $r['gift_wrap'], $r['gross'], $r['refunded'], $r['net'], $r['cost'], $r['item_margin'], (int) $r['missing_cost']], $rows),
            ],
            'products' => [
                ['Product', 'SKU', 'Units', 'Orders', 'Revenue', 'Item cost', 'Margin', 'Items missing cost'],
                array_map(static fn ($r) => [$r['name'], $r['sku'], (int) $r['units'], (int) $r['orders'], $r['revenue'], $r['cost'], round((float) $r['revenue'] - (float) $r['cost'], 2), (int) $r['missing_cost']], $rows),
            ],
            'categories' => [
                ['Category', 'Units', 'Orders', 'Revenue', 'Item cost', 'Margin', 'Items missing cost'],
                array_map(static fn ($r) => [$r['name'], (int) $r['units'], (int) $r['orders'], $r['revenue'], $r['cost'], round((float) $r['revenue'] - (float) $r['cost'], 2), (int) $r['missing_cost']], $rows),
            ],
            'coupons' => [
                ['Code', 'Type', 'Value', 'Active', 'Redemptions', 'Placed orders', 'Discount given', 'Order revenue'],
                array_map(static fn ($r) => [$r['code'], $r['type'], $r['value'], (int) $r['is_active'] ? 'yes' : 'no', (int) $r['uses'], (int) $r['placed'], $r['discount'], $r['revenue']], $rows),
            ],
            'payments' => [
                ['Payment method', 'Orders', 'Paid orders', 'Cancelled', 'Net paid revenue'],
                array_map(static fn ($r) => [$r['payment_method'], (int) $r['orders'], (int) $r['paid_orders'], (int) $r['cancelled'], $r['net']], $rows),
            ],
        };
        AuditLogger::log('report.export', 'report', null, null, ['type' => $type, 'from' => $range['from'], 'to' => $range['to'], 'rows' => count($out)]);
        return Response::download(ReportRepository::csv($headers, $out), "report-$type-{$range['from']}-to-{$range['to']}.csv");
    }

    public function exportFinance(Request $request): Response
    {
        Gate::authorize('finance.export');
        [$range] = $this->params($request);
        $rows = array_map(static fn ($r) => [
            local_date($r['at'], 'Y-m-d H:i:s'),
            $r['entry'],
            $r['order_number'],
            $r['gateway'],
            $r['reference'],
            $r['gateway_reference'],
            number_format((float) $r['amount'], 2, '.', ''),
            $r['status'],
        ], (new ReportRepository())->financeLedger($range));
        AuditLogger::log('report.finance_export', 'report', null, null, ['from' => $range['from'], 'to' => $range['to'], 'rows' => count($rows)]);
        return Response::download(
            ReportRepository::csv(['Date (NPT)', 'Entry', 'Order', 'Gateway', 'Reference', 'Gateway reference', 'Amount (NPR)', 'Current status'], $rows),
            "finance-ledger-{$range['from']}-to-{$range['to']}.csv"
        );
    }
}
