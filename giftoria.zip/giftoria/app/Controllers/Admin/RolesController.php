<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\ValidationException;

/**
 * Admin > Roles & permissions.
 *  - An actor may only grant permissions they hold (Gate::canGrantPermissions).
 *  - A non-Super Admin may only edit roles whose permissions they fully hold (Gate::canAssignRole),
 *    so nobody can rename/deactivate/strip a role more privileged than themselves.
 *  - Only a Super Admin may edit the 'super-admin' role; its permissions are implicit ('*').
 *  - System roles can be edited (not their slug) but never deleted; deactivate instead.
 */
final class RolesController extends Controller
{
    private function actorId(): int
    {
        return (int) Auth::staffId();
    }

    private function findRole(int $id): array
    {
        $role = Database::fetch('SELECT * FROM roles WHERE id = :id', ['id' => $id]);
        if (!$role) {
            throw new HttpException(404);
        }
        return $role;
    }

    private function isSuperRole(array $role): bool
    {
        return $role['slug'] === Gate::SUPER_ADMIN;
    }

    private function ensureCanEdit(array $role): void
    {
        $actor = $this->actorId();
        if ($this->isSuperRole($role) && !Gate::isSuperAdmin($actor)) {
            AuditLogger::log('access.denied', 'role', (int) $role['id'], null, ['reason' => 'super-admin role edit']);
            throw new HttpException(403, 'Only a Super Admin can edit the Super Admin role.');
        }
        if (!Gate::canAssignRole($actor, (int) $role['id'])) {
            AuditLogger::log('access.denied', 'role', (int) $role['id'], null, ['reason' => 'role exceeds actor permissions']);
            throw new HttpException(403, 'This role includes permissions you do not hold, so you cannot modify it.');
        }
    }

    /** @return array<string,int> slug => id of every permission in the database */
    private function permissionIds(): array
    {
        $out = [];
        foreach (Database::fetchAll('SELECT id, slug FROM permissions') as $p) {
            $out[$p['slug']] = (int) $p['id'];
        }
        return $out;
    }

    /** Permission matrix grouped like config('permissions.permissions'); unknown DB permissions go to "Other". */
    private function matrix(): array
    {
        $db = Database::fetchAll('SELECT slug, name, group_name FROM permissions ORDER BY group_name, slug');
        $bySlug = [];
        foreach ($db as $p) {
            $bySlug[$p['slug']] = $p;
        }
        $groups = [];
        foreach ((array) config('permissions.permissions', []) as $group => $perms) {
            foreach ($perms as $slug => $label) {
                if (isset($bySlug[$slug])) {
                    $groups[$group][$slug] = $label;
                    unset($bySlug[$slug]);
                }
            }
        }
        foreach ($bySlug as $slug => $p) {
            $groups[$p['group_name'] ?: 'Other'][$slug] = $p['name'];
        }
        return $groups;
    }

    private function rolePermissionSlugs(int $roleId): array
    {
        return Database::fetchCol(
            'SELECT p.slug FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = :r ORDER BY p.slug',
            ['r' => $roleId]
        );
    }

    private function formData(?array $role): array
    {
        $actor = $this->actorId();
        return [
            'role' => $role,
            'matrix' => $this->matrix(),
            'granted' => $role ? $this->rolePermissionSlugs((int) $role['id']) : [],
            'actorPerms' => Gate::isSuperAdmin($actor) ? array_keys($this->permissionIds()) : Gate::permissionsFor($actor),
            'isSuperRole' => $role !== null && $this->isSuperRole($role),
        ];
    }

    private function rules(?int $ignoreId, bool $slugLocked): array
    {
        $rules = [
            'name' => 'required|string|max:80',
            'description' => 'nullable|string|max:255',
            'permissions' => 'nullable|array',
        ];
        if (!$slugLocked) {
            $rules['slug'] = 'required|slug|max:80|unique:roles,slug' . ($ignoreId ? ',' . $ignoreId : '');
        }
        return $rules;
    }

    /** Validates requested permission slugs against the catalogue and the actor's own permissions. */
    private function resolvePermissions(array $requested): array
    {
        $known = $this->permissionIds();
        $slugs = array_values(array_unique(array_filter(array_map('strval', $requested), static fn ($s) => isset($known[$s]))));
        if (!Gate::canGrantPermissions($this->actorId(), $slugs)) {
            AuditLogger::log('access.denied', 'permission', null, null, ['reason' => 'grant beyond own permissions', 'requested' => array_values(array_diff($slugs, Gate::permissionsFor($this->actorId())))]);
            throw new ValidationException(['permissions' => 'You can only grant permissions that you hold yourself.'], Request::current()?->all() ?? []);
        }
        sort($slugs);
        return $slugs;
    }

    private function syncPermissions(int $roleId, array $slugs): void
    {
        $known = $this->permissionIds();
        Database::delete('role_permissions', ['role_id' => $roleId]);
        foreach ($slugs as $s) {
            Database::insert('role_permissions', ['role_id' => $roleId, 'permission_id' => $known[$s]]);
        }
    }

    // ---------------------------------------------------------------- pages

    public function index(Request $request): Response
    {
        $roles = Database::fetchAll(
            "SELECT r.*,
                    (SELECT COUNT(*) FROM role_permissions rp WHERE rp.role_id = r.id) AS perm_count,
                    (SELECT COUNT(*) FROM user_roles ur JOIN users u ON u.id = ur.user_id WHERE ur.role_id = r.id AND u.type = 'staff' AND u.status <> 'deleted') AS member_count
             FROM roles r ORDER BY r.is_system DESC, r.name"
        );
        $actor = $this->actorId();
        foreach ($roles as &$r) {
            $r['editable'] = Gate::canAssignRole($actor, (int) $r['id']) && (!$this->isSuperRole($r) || Gate::isSuperAdmin($actor));
        }
        unset($r);
        return $this->adminView('roles/index', [
            'title' => 'Roles & permissions',
            'roles' => $roles,
            'totalPermissions' => count($this->permissionIds()),
        ]);
    }

    public function create(Request $request): Response
    {
        return $this->adminView('roles/form', ['title' => 'New role'] + $this->formData(null));
    }

    public function store(Request $request): Response
    {
        Gate::authorize('roles.manage');
        $data = $this->validate($request, $this->rules(null, false));
        if ($data['slug'] === Gate::SUPER_ADMIN) {
            throw new ValidationException(['slug' => 'This slug is reserved.'], $request->all());
        }
        $slugs = $this->resolvePermissions($request->arr('permissions'));
        $active = $request->bool('is_active') ? 1 : 0;

        $id = Database::transaction(function () use ($data, $slugs, $active) {
            $id = Database::insert('roles', [
                'name' => $data['name'],
                'slug' => $data['slug'],
                'description' => $data['description'] ?: null,
                'is_system' => 0,
                'is_active' => $active,
            ]);
            $this->syncPermissions($id, $slugs);
            return $id;
        });
        AuditLogger::log('role.created', 'role', $id, null, [
            'name' => $data['name'], 'slug' => $data['slug'], 'is_active' => $active, 'permissions' => $slugs,
        ]);
        flash('success', 'Role created.');
        return $this->redirect(admin_url('roles'));
    }

    public function edit(Request $request, string $id): Response
    {
        $role = $this->findRole((int) $id);
        $this->ensureCanEdit($role);
        return $this->adminView('roles/form', ['title' => 'Edit role: ' . $role['name']] + $this->formData($role));
    }

    public function update(Request $request, string $id): Response
    {
        Gate::authorize('roles.manage');
        $role = $this->findRole((int) $id);
        $this->ensureCanEdit($role);
        $rid = (int) $role['id'];
        $isSuper = $this->isSuperRole($role);
        $slugLocked = (int) $role['is_system'] === 1 || $isSuper;
        $data = $this->validate($request, $this->rules($rid, $slugLocked));
        $newSlug = $slugLocked ? $role['slug'] : (string) $data['slug'];
        if (!$slugLocked && $newSlug === Gate::SUPER_ADMIN) {
            throw new ValidationException(['slug' => 'This slug is reserved.'], $request->all());
        }
        // The Super Admin role can never be deactivated (it would lock everyone out of privileged access).
        $active = $isSuper ? 1 : ($request->bool('is_active') ? 1 : 0);

        $oldPerms = $this->rolePermissionSlugs($rid);
        $newPerms = $isSuper ? $oldPerms : $this->resolvePermissions($request->arr('permissions'));

        Database::transaction(function () use ($rid, $data, $newSlug, $active, $isSuper, $newPerms) {
            Database::update('roles', [
                'name' => $data['name'],
                'slug' => $newSlug,
                'description' => $data['description'] ?: null,
                'is_active' => $active,
            ], ['id' => $rid]);
            if (!$isSuper) {
                $this->syncPermissions($rid, $newPerms);
            }
        });

        $old = [];
        $new = [];
        foreach (['name' => $data['name'], 'slug' => $newSlug, 'description' => $data['description'] ?: null, 'is_active' => $active] as $k => $v) {
            if ((string) ($role[$k] ?? '') !== (string) ($v ?? '')) {
                $old[$k] = $role[$k];
                $new[$k] = $v;
            }
        }
        $added = array_values(array_diff($newPerms, $oldPerms));
        $removed = array_values(array_diff($oldPerms, $newPerms));
        if ($added || $removed) {
            $old['permissions_removed'] = $removed;
            $new['permissions_added'] = $added;
        }
        if ($old || $new) {
            AuditLogger::log($added || $removed ? 'role.permissions_updated' : 'role.updated', 'role', $rid, $old, $new);
        }
        flash('success', 'Role saved. Changes apply to members on their next request.');
        return $this->redirect(admin_url('roles'));
    }

    public function toggle(Request $request, string $id): Response
    {
        Gate::authorize('roles.manage');
        $role = $this->findRole((int) $id);
        $this->ensureCanEdit($role);
        if ($this->isSuperRole($role)) {
            flash('error', 'The Super Admin role cannot be deactivated.');
            return $this->redirect(admin_url('roles'));
        }
        $new = (int) $role['is_active'] === 1 ? 0 : 1;
        Database::update('roles', ['is_active' => $new], ['id' => (int) $role['id']]);
        AuditLogger::log($new ? 'role.activated' : 'role.deactivated', 'role', (int) $role['id'], ['is_active' => (int) $role['is_active']], ['is_active' => $new]);
        flash('success', $new ? 'Role activated.' : 'Role deactivated. Its members lose these permissions immediately.');
        return $this->redirect(admin_url('roles'));
    }

    public function destroy(Request $request, string $id): Response
    {
        Gate::authorize('roles.manage');
        $role = $this->findRole((int) $id);
        $this->ensureCanEdit($role);
        if ((int) $role['is_system'] === 1 || $this->isSuperRole($role)) {
            flash('error', 'System roles cannot be deleted. Deactivate the role instead.');
            return $this->redirect(admin_url('roles'));
        }
        $members = (int) Database::fetchColumn('SELECT COUNT(*) FROM user_roles WHERE role_id = :r', ['r' => (int) $role['id']]);
        if ($members > 0) {
            flash('error', 'This role still has ' . $members . ' member(s). Reassign them or deactivate the role instead.');
            return $this->redirect(admin_url('roles'));
        }
        $perms = $this->rolePermissionSlugs((int) $role['id']);
        Database::delete('roles', ['id' => (int) $role['id']]); // role_permissions cascade
        AuditLogger::log('role.deleted', 'role', (int) $role['id'], [
            'name' => $role['name'], 'slug' => $role['slug'], 'permissions' => $perms,
        ], null);
        flash('success', 'Role deleted.');
        return $this->redirect(admin_url('roles'));
    }
}
