<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Logger;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;
use App\Core\View;
use App\Services\MailService;
use App\Services\NewsletterService;

/**
 * Newsletter subscribers, suppression list, email campaigns and the abandoned-cart overview.
 * Campaigns go only to subscribed, consented addresses that are not on the suppression list,
 * and the delivered count only includes messages MailService reports as 'sent' or 'logged'.
 */
final class NewsletterController extends Controller
{
    /** SQL condition (alias ns) for an address that may receive marketing email. */
    private const MAILABLE = "ns.status = 'subscribed' AND ns.consent_at IS NOT NULL
        AND NOT EXISTS (SELECT 1 FROM email_suppressions es WHERE es.email = ns.email)";

    // ---------------------------------------------------------------- subscribers

    public function index(Request $request): Response
    {
        $q = $request->str('q');
        $status = $request->str('status');
        $where = [];
        $params = [];
        if ($q !== '') {
            $params['q'] = '%' . mb_strtolower($q) . '%';
            $where[] = 'ns.email LIKE :q';
        }
        if (in_array($status, ['subscribed', 'unsubscribed'], true)) {
            $params['st'] = $status;
            $where[] = 'ns.status = :st';
        }
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM newsletter_subscriptions ns $whereSql", $params);
        $p = Paginator::fromRequest($total, 50);
        $rows = Database::fetchAll(
            "SELECT ns.id, ns.email, ns.user_id, ns.status, ns.source, ns.consent_at, ns.unsubscribed_at, ns.created_at,
                    (SELECT 1 FROM email_suppressions es WHERE es.email = ns.email) AS suppressed
             FROM newsletter_subscriptions ns $whereSql
             ORDER BY ns.created_at DESC, ns.id DESC LIMIT {$p->perPage} OFFSET {$p->offset}",
            $params
        );
        return $this->adminView('newsletter/index', [
            'title' => 'Newsletter',
            'tab' => 'subscribers',
            'subscribers' => $rows,
            'paginator' => $p,
            'filters' => ['q' => $q, 'status' => $status],
            'stats' => $this->stats(),
        ]);
    }

    public function export(Request $request): Response
    {
        Gate::authorize('newsletter.manage');
        $rows = Database::fetchAll(
            'SELECT ns.email, ns.source, ns.consent_at, ns.created_at FROM newsletter_subscriptions ns
             WHERE ' . self::MAILABLE . ' ORDER BY ns.created_at'
        );
        $fh = fopen('php://temp', 'r+');
        fputcsv($fh, ['email', 'source', 'consent_at_utc', 'subscribed_at_utc']);
        foreach ($rows as $r) {
            fputcsv($fh, array_map([self::class, 'csvSafe'], [$r['email'], $r['source'], $r['consent_at'], $r['created_at']]));
        }
        rewind($fh);
        $csv = (string) stream_get_contents($fh);
        fclose($fh);
        AuditLogger::log('newsletter.exported', 'newsletter', null, null, ['rows' => count($rows)]);
        return Response::download("\xEF\xBB\xBF" . $csv, 'newsletter-subscribers-' . gmdate('Ymd') . '.csv');
    }

    public function unsubscribe(Request $request): Response
    {
        Gate::authorize('newsletter.manage');
        $email = mb_strtolower($request->str('email'));
        $row = Database::fetch('SELECT id, status FROM newsletter_subscriptions WHERE email = :e', ['e' => $email]);
        if (!$row) {
            flash('error', 'That address is not on the subscriber list.');
            return $this->back(admin_url('newsletter'));
        }
        NewsletterService::unsubscribe($email);
        AuditLogger::log('newsletter.unsubscribed', 'newsletter_subscription', (int) $row['id'], ['status' => $row['status']], ['status' => 'unsubscribed', 'suppressed' => true]);
        flash('success', $email . ' was unsubscribed and added to the suppression list.');
        return $this->back(admin_url('newsletter'));
    }

    public function suppressions(Request $request): Response
    {
        $q = $request->str('q');
        $params = [];
        $whereSql = '';
        if ($q !== '') {
            $params['q'] = '%' . mb_strtolower($q) . '%';
            $whereSql = 'WHERE es.email LIKE :q';
        }
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM email_suppressions es $whereSql", $params);
        $p = Paginator::fromRequest($total, 50);
        $rows = Database::fetchAll(
            "SELECT es.email, es.reason, es.created_at FROM email_suppressions es $whereSql
             ORDER BY es.created_at DESC LIMIT {$p->perPage} OFFSET {$p->offset}",
            $params
        );
        return $this->adminView('newsletter/suppressions', [
            'title' => 'Suppression list',
            'tab' => 'suppressions',
            'rows' => $rows,
            'paginator' => $p,
            'q' => $q,
            'stats' => $this->stats(),
        ]);
    }

    public function abandonedCarts(Request $request): Response
    {
        $base = "FROM carts c JOIN users u ON u.id = c.user_id AND u.type = 'customer' AND u.status = 'active'
                 WHERE c.user_id IS NOT NULL AND c.updated_at < (UTC_TIMESTAMP() - INTERVAL 24 HOUR)
                   AND EXISTS (SELECT 1 FROM cart_items ci WHERE ci.cart_id = c.id AND ci.saved_for_later = 0)";
        $counts = Database::fetch(
            "SELECT COUNT(*) AS idle, SUM(c.reminder_sent_at IS NULL) AS pending, SUM(c.reminder_sent_at IS NOT NULL) AS reminded $base"
        ) ?? [];
        $total = (int) ($counts['idle'] ?? 0);
        $p = Paginator::fromRequest($total, 25);
        $rows = Database::fetchAll(
            "SELECT c.id, c.updated_at, c.reminder_sent_at, u.name, u.email,
                    (SELECT COALESCE(SUM(ci.quantity), 0) FROM cart_items ci WHERE ci.cart_id = c.id AND ci.saved_for_later = 0) AS items,
                    (SELECT COALESCE(SUM(ci2.quantity * COALESCE(p.sale_price, p.price)), 0) FROM cart_items ci2 JOIN products p ON p.id = ci2.product_id
                      WHERE ci2.cart_id = c.id AND ci2.saved_for_later = 0) AS value
             $base ORDER BY c.updated_at DESC LIMIT {$p->perPage} OFFSET {$p->offset}"
        );
        return $this->adminView('newsletter/abandoned', [
            'title' => 'Abandoned carts',
            'tab' => 'abandoned',
            'counts' => $counts,
            'carts' => $rows,
            'paginator' => $p,
            'stats' => $this->stats(),
        ]);
    }

    // ---------------------------------------------------------------- email campaigns

    public function campaigns(Request $request): Response
    {
        $total = (int) Database::fetchColumn('SELECT COUNT(*) FROM email_campaigns');
        $p = Paginator::fromRequest($total, 25);
        $rows = Database::fetchAll(
            "SELECT ec.*, u.name AS author FROM email_campaigns ec LEFT JOIN users u ON u.id = ec.created_by
             ORDER BY ec.created_at DESC, ec.id DESC LIMIT {$p->perPage} OFFSET {$p->offset}"
        );
        return $this->adminView('newsletter/campaigns', [
            'title' => 'Email campaigns',
            'tab' => 'campaigns',
            'campaigns' => $rows,
            'paginator' => $p,
            'stats' => $this->stats(),
            'audience' => $this->audienceCount(),
        ]);
    }

    public function createCampaign(Request $request): Response
    {
        return $this->adminView('newsletter/campaign-form', ['title' => 'New email campaign', 'tab' => 'campaigns', 'campaign' => null]);
    }

    public function storeCampaign(Request $request): Response
    {
        Gate::authorize('newsletter.manage');
        $data = $this->validatedCampaign($request);
        $data['segment'] = 'all_subscribers';
        $data['status'] = 'draft';
        $data['created_by'] = Auth::staffId();
        $id = Database::insert('email_campaigns', $data);
        AuditLogger::log('email_campaign.created', 'email_campaign', $id, null, ['name' => $data['name'], 'subject' => $data['subject']]);
        flash('success', 'Draft saved. Preview it and send yourself a test before sending.');
        return $this->redirect(admin_url('newsletter/campaigns/' . $id));
    }

    public function showCampaign(Request $request, string $id): Response
    {
        $c = $this->findCampaign((int) $id);
        return $this->adminView('newsletter/campaign-show', [
            'title' => 'Email campaign',
            'tab' => 'campaigns',
            'campaign' => $c,
            'previewHtml' => $this->previewDocument($c),
            'audience' => $this->audienceCount(),
            'staffEmail' => (string) (Auth::staff()['email'] ?? ''),
        ]);
    }

    public function editCampaign(Request $request, string $id): Response
    {
        $c = $this->findCampaign((int) $id);
        if ($c['status'] !== 'draft') {
            flash('error', 'Only draft campaigns can be edited.');
            return $this->redirect(admin_url('newsletter/campaigns/' . (int) $c['id']));
        }
        return $this->adminView('newsletter/campaign-form', ['title' => 'Edit email campaign', 'tab' => 'campaigns', 'campaign' => $c]);
    }

    public function updateCampaign(Request $request, string $id): Response
    {
        Gate::authorize('newsletter.manage');
        $c = $this->findCampaign((int) $id);
        if ($c['status'] !== 'draft') {
            flash('error', 'This campaign has already been sent and can no longer be changed.');
            return $this->redirect(admin_url('newsletter/campaigns/' . (int) $c['id']));
        }
        $data = $this->validatedCampaign($request);
        Database::update('email_campaigns', $data, ['id' => (int) $c['id'], 'status' => 'draft']);
        AuditLogger::log('email_campaign.updated', 'email_campaign', (int) $c['id'], ['name' => $c['name'], 'subject' => $c['subject']], ['name' => $data['name'], 'subject' => $data['subject']]);
        flash('success', 'Draft updated.');
        return $this->redirect(admin_url('newsletter/campaigns/' . (int) $c['id']));
    }

    public function sendTest(Request $request, string $id): Response
    {
        Gate::authorize('newsletter.manage');
        $c = $this->findCampaign((int) $id);
        $email = (string) (Auth::staff()['email'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'Your staff account has no valid email address.');
            return $this->redirect(admin_url('newsletter/campaigns/' . (int) $c['id']));
        }
        $result = (new MailService())->deliver($email, '[TEST] ' . $c['subject'], self::sanitizeHtml((string) $c['body_html']), 'newsletter_test', NewsletterService::unsubscribeUrl($email));
        AuditLogger::log('email_campaign.test_sent', 'email_campaign', (int) $c['id'], null, ['to' => $email, 'result' => $result]);
        match ($result) {
            'sent' => flash('success', 'Test email sent to ' . $email . '.'),
            'logged' => flash('info', 'Mail is in log mode: the test was written to storage/mail and the outbox, not delivered.'),
            default => flash('error', 'The test email could not be delivered (' . $result . '). Check the mail settings and the email outbox.'),
        };
        return $this->redirect(admin_url('newsletter/campaigns/' . (int) $c['id']));
    }

    public function send(Request $request, string $id): Response
    {
        Gate::authorize('newsletter.manage');
        $c = $this->findCampaign((int) $id);
        // Claim the campaign atomically so a double click or two staff members cannot send it twice.
        $claimed = Database::query(
            "UPDATE email_campaigns SET status = 'sending' WHERE id = :id AND status = 'draft'",
            ['id' => (int) $c['id']]
        )->rowCount();
        if ($claimed !== 1) {
            flash('error', 'This campaign is already sending or has been sent.');
            return $this->redirect(admin_url('newsletter/campaigns/' . (int) $c['id']));
        }

        @set_time_limit(0);
        ignore_user_abort(true);

        $recipients = Database::fetchCol('SELECT ns.email FROM newsletter_subscriptions ns WHERE ' . self::MAILABLE . ' ORDER BY ns.id');
        $body = self::sanitizeHtml((string) $c['body_html']);
        $mail = new MailService();
        $delivered = 0;
        $results = [];
        try {
            foreach ($recipients as $email) {
                $email = (string) $email;
                try {
                    $r = $mail->deliver($email, (string) $c['subject'], $body, 'newsletter', NewsletterService::unsubscribeUrl($email));
                } catch (\Throwable $e) {
                    Logger::error('Newsletter delivery error', ['campaign' => (int) $c['id'], 'error' => $e->getMessage()], 'mail');
                    $r = 'failed';
                }
                $results[$r] = ($results[$r] ?? 0) + 1;
                if ($r === 'sent' || $r === 'logged') {
                    $delivered++;
                }
            }
        } finally {
            Database::update('email_campaigns', [
                'status' => 'sent',
                'recipients_count' => count($recipients),
                'sent_count' => $delivered,
                'sent_at' => Database::now(),
            ], ['id' => (int) $c['id']]);
        }

        AuditLogger::log('email_campaign.sent', 'email_campaign', (int) $c['id'], ['status' => 'draft'], [
            'status' => 'sent', 'recipients' => count($recipients), 'delivered' => $delivered, 'results' => $results,
        ]);
        $failed = count($recipients) - $delivered;
        $msg = sprintf('Campaign processed for %d recipient(s): %d delivered%s.', count($recipients), $delivered, $failed > 0 ? ", $failed failed" : '');
        if (($results['logged'] ?? 0) > 0) {
            $msg .= ' Mail is in log mode, so messages were recorded in the outbox but not actually sent.';
        }
        flash($failed > 0 ? 'warning' : 'success', $msg);
        return $this->redirect(admin_url('newsletter/campaigns/' . (int) $c['id']));
    }

    // ---------------------------------------------------------------- helpers

    private function stats(): array
    {
        return Database::fetch(
            "SELECT
                (SELECT COUNT(*) FROM newsletter_subscriptions WHERE status = 'subscribed') AS subscribed,
                (SELECT COUNT(*) FROM newsletter_subscriptions ns WHERE " . self::MAILABLE . ") AS mailable,
                (SELECT COUNT(*) FROM newsletter_subscriptions WHERE status = 'unsubscribed') AS unsubscribed,
                (SELECT COUNT(*) FROM email_suppressions) AS suppressed,
                (SELECT COUNT(*) FROM newsletter_subscriptions WHERE created_at >= (UTC_TIMESTAMP() - INTERVAL 30 DAY)) AS new_30d"
        ) ?? [];
    }

    private function audienceCount(): int
    {
        return (int) Database::fetchColumn('SELECT COUNT(*) FROM newsletter_subscriptions ns WHERE ' . self::MAILABLE);
    }

    private function findCampaign(int $id): array
    {
        $c = Database::fetch('SELECT * FROM email_campaigns WHERE id = :id', ['id' => $id]);
        if (!$c) {
            throw new HttpException(404);
        }
        return $c;
    }

    private function validatedCampaign(Request $request): array
    {
        $d = Validator::validate($request->all(), [
            'name' => ['required', 'string', 'max:120'],
            'subject' => ['required', 'string', 'max:190'],
            'body_html' => ['required', 'string', 'max:200000'],
        ], ['body_html' => 'Email body']);
        $clean = self::sanitizeHtml((string) $d['body_html']);
        if (trim(strip_tags($clean, '<img>')) === '') {
            throw new \App\Core\ValidationException(['body_html' => 'The email body is empty after removing unsafe content.'], $request->all());
        }
        return [
            'name' => $d['name'],
            'subject' => str_replace(["\r", "\n"], ' ', (string) $d['subject']),
            'body_html' => $clean,
        ];
    }

    /** Full HTML document used in the sandboxed preview iframe (same layout as delivered mail when available). */
    private function previewDocument(array $c): string
    {
        $body = self::sanitizeHtml((string) $c['body_html']);
        if (is_file(BASE_PATH . '/resources/views/emails/layout.php')) {
            try {
                return View::render('emails/layout', ['subject' => $c['subject'], 'body' => $body, 'unsubscribeUrl' => url('/newsletter/unsubscribe/preview')], null);
            } catch (\Throwable) {
                // fall through to the plain wrapper
            }
        }
        return '<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:Arial,sans-serif;color:#1f1b16;max-width:600px;margin:24px auto;padding:0 16px;line-height:1.5}img{max-width:100%;height:auto}</style></head><body>'
            . $body . '<hr><p style="font-size:12px;color:#777">You are receiving this because you subscribed. Unsubscribe link is added automatically.</p></body></html>';
    }

    private static function csvSafe(mixed $v): string
    {
        $s = (string) ($v ?? '');
        return $s !== '' && in_array($s[0], ['=', '+', '-', '@', "\t", "\r"], true) ? "'" . $s : $s;
    }

    /**
     * Restricts campaign HTML to a safe subset: removes script/style/iframe/form etc. entirely,
     * unwraps unknown tags, drops on* and other non-allowlisted attributes, and rejects
     * javascript:/data:/vbscript: URLs. Runs server-side on save and again before sending.
     */
    public static function sanitizeHtml(string $html): string
    {
        $html = trim($html);
        if ($html === '') {
            return '';
        }
        $allowedTags = ['p', 'br', 'h1', 'h2', 'h3', 'h4', 'strong', 'b', 'em', 'i', 'u', 's', 'a', 'ul', 'ol', 'li', 'img',
            'table', 'thead', 'tbody', 'tfoot', 'tr', 'td', 'th', 'blockquote', 'hr', 'span', 'div', 'small', 'center', 'font', 'sup', 'sub', 'pre', 'code'];
        $dropTags = ['script', 'style', 'iframe', 'frame', 'frameset', 'object', 'embed', 'applet', 'form', 'input', 'button', 'textarea',
            'select', 'option', 'link', 'meta', 'base', 'svg', 'math', 'noscript', 'template', 'audio', 'video', 'canvas', 'head', 'title', 'xml'];
        $allowedAttrs = ['href', 'src', 'alt', 'title', 'width', 'height', 'align', 'valign', 'colspan', 'rowspan', 'style', 'target',
            'border', 'cellpadding', 'cellspacing', 'bgcolor', 'color', 'class', 'rel'];

        if (!class_exists(\DOMDocument::class)) {
            return self::sanitizeFallback($html, $allowedTags);
        }

        $doc = new \DOMDocument('1.0', 'UTF-8');
        $prev = libxml_use_internal_errors(true);
        $doc->loadHTML('<?xml encoding="utf-8"?><div>' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET);
        libxml_clear_errors();
        libxml_use_internal_errors($prev);
        $root = $doc->getElementsByTagName('div')->item(0);
        if (!$root) {
            return '';
        }

        $walk = static function (\DOMNode $node) use (&$walk, $allowedTags, $dropTags, $allowedAttrs): void {
            foreach (iterator_to_array($node->childNodes) as $child) {
                if ($child instanceof \DOMComment || $child instanceof \DOMProcessingInstruction || $child instanceof \DOMCdataSection) {
                    $node->removeChild($child);
                    continue;
                }
                if (!$child instanceof \DOMElement) {
                    continue;
                }
                $tag = strtolower($child->nodeName);
                if (in_array($tag, $dropTags, true)) {
                    $node->removeChild($child);
                    continue;
                }
                $walk($child);
                if (!in_array($tag, $allowedTags, true)) {
                    while ($child->firstChild) {
                        $node->insertBefore($child->firstChild, $child);
                    }
                    $node->removeChild($child);
                    continue;
                }
                foreach (iterator_to_array($child->attributes) as $attr) {
                    $name = strtolower($attr->nodeName);
                    $value = trim((string) $attr->nodeValue);
                    $keep = in_array($name, $allowedAttrs, true) && !str_starts_with($name, 'on');
                    if ($keep && in_array($name, ['href', 'src'], true)) {
                        $keep = self::safeUrl($value, $name === 'href');
                    }
                    if ($keep && $name === 'style') {
                        $keep = !preg_match('/expression|javascript:|vbscript:|url\s*\(|@import|behavior|-moz-binding/i', $value);
                    }
                    if (!$keep) {
                        $child->removeAttribute($attr->nodeName);
                    }
                }
                if ($tag === 'a' && $child->hasAttribute('target')) {
                    $child->setAttribute('target', '_blank');
                    $child->setAttribute('rel', 'noopener noreferrer');
                }
            }
        };
        $walk($root);

        $out = '';
        foreach (iterator_to_array($root->childNodes) as $child) {
            $out .= $doc->saveHTML($child);
        }
        return trim($out);
    }

    private static function safeUrl(string $url, bool $allowMailto): bool
    {
        $decoded = html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $compact = strtolower((string) preg_replace('/[\x00-\x20\x7f]+/', '', $decoded));
        if ($compact === '') {
            return false;
        }
        if (preg_match('#^https?://#', $compact)) {
            return true;
        }
        if ($allowMailto && str_starts_with($compact, 'mailto:')) {
            return true;
        }
        // Relative paths are allowed, but anything that looks like a scheme (javascript:, data:, vbscript:) is not.
        return !preg_match('#^[a-z][a-z0-9+.-]*:#', $compact) && !str_starts_with($compact, '//');
    }

    /** Regex fallback when ext-dom is unavailable. */
    private static function sanitizeFallback(string $html, array $allowedTags): string
    {
        $html = (string) preg_replace('#<(script|style|iframe|object|embed|form|svg|math|noscript|template)\b[^>]*>.*?</\1\s*>#is', '', $html);
        $html = strip_tags($html, '<' . implode('><', $allowedTags) . '>');
        $html = (string) preg_replace('/\s+on[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html);
        $html = (string) preg_replace('/\s+(href|src)\s*=\s*("|\')?\s*(javascript|vbscript|data):[^"\'>\s]*("|\')?/i', '', $html);
        return (string) preg_replace('/\s+style\s*=\s*("[^"]*(expression|javascript:|url\s*\()[^"]*"|\'[^\']*(expression|javascript:|url\s*\()[^\']*\')/i', '', $html);
    }
}
