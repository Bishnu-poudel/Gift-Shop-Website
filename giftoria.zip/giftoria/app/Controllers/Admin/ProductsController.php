<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Cache;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\Uploader;
use App\Core\ValidationException;
use App\Core\Validator;
use App\Repositories\Admin\CatalogAdminRepository;
use App\Repositories\ProductRepository;
use App\Services\InventoryService;
use RuntimeException;

/** Admin > Products: list, create/edit, publish/deactivate, images, variants, attributes. */
final class ProductsController extends Controller
{
    private const STATUSES = ['draft', 'active', 'inactive'];
    private const MAX_IMAGES = 20;
    private const FLAGS = [
        'has_small_parts', 'gender_neutral', 'is_personalizable', 'gift_wrap_available',
        'valley_only', 'allow_backorder', 'is_featured', 'is_bestseller',
    ];
    /** Fallback age presets (label => [min, max]) when no age_ranges rows exist. */
    private const AGE_PRESETS = [
        '0–12 months' => [0, 12], '1–3 years' => [12, 36], '3–5 years' => [36, 60], '5–8 years' => [60, 96],
        '8–12 years' => [96, 144], 'Teens (13–17)' => [156, 216], 'Adults (18+)' => [216, 1200], 'All ages' => [0, 1200],
    ];

    private CatalogAdminRepository $repo;
    private InventoryService $inventory;

    public function __construct()
    {
        $this->repo = new CatalogAdminRepository();
        $this->inventory = new InventoryService();
    }

    /* ================================================================ list */

    public function index(Request $request): Response
    {
        $filters = ['q' => mb_substr($request->str('q'), 0, 100)];
        $status = $request->str('status');
        if (in_array($status, self::STATUSES, true)) {
            $filters['status'] = $status;
        }
        $categoryId = $request->int('category');
        if ($categoryId > 0) {
            $slug = Database::fetchColumn('SELECT slug FROM categories WHERE id = :id', ['id' => $categoryId]);
            if ($slug) {
                $filters['category'] = $slug;
            }
        }
        $stock = $request->str('stock');
        if (in_array($stock, ['in', 'low', 'out'], true)) {
            $filters['ids'] = $this->repo->productIdsByStock($stock);
        }
        $sort = $request->str('sort', 'newest');
        if (!in_array($sort, ['newest', 'name', 'price_asc', 'price_desc', 'popular'], true)) {
            $sort = 'newest';
        }
        $page = max(1, $request->int('page', 1));
        $result = (new ProductRepository())->search($filters, $sort, $page, 25, admin: true);
        $paginator = new Paginator($result['total'], 25, $page);

        return $this->adminView('products/index', [
            'title' => 'Products',
            'products' => $result['items'],
            'total' => $result['total'],
            'paginator' => $paginator,
            'categories' => $this->repo->categoryTree(),
            'counts' => $this->repo->productStatusCounts(),
            'filters' => ['q' => $filters['q'], 'status' => $status, 'category' => $categoryId, 'stock' => $stock, 'sort' => $sort],
        ]);
    }

    /* ================================================================ create / edit */

    public function create(Request $request): Response
    {
        return $this->adminView('products/form', $this->formData(null) + ['title' => 'New product']);
    }

    public function store(Request $request): Response
    {
        $data = $this->validatedProduct($request, 0);
        $assign = $this->assignments($request);
        $attributes = $this->attributesInput($request);
        $initial = $this->initialStock($request);
        $staffId = Auth::staffId();

        $id = Database::transaction(function () use ($data, $assign, $attributes, $initial, $staffId) {
            $id = Database::insert('products', $data + ['created_by' => $staffId]);
            $this->writeAssignments($id, $assign);
            $this->writeAttributes($id, $attributes);
            Database::query('INSERT IGNORE INTO inventory (product_id, variant_id, quantity) VALUES (:p, 0, 0)', ['p' => $id]);
            if ($initial > 0) {
                $this->inventory->change($id, 0, $initial, 'initial', 'product', $id, $staffId, 'Initial stock');
            }
            return $id;
        });

        AuditLogger::log('product.create', 'product', $id, null, [
            'sku' => $data['sku'], 'name' => $data['name'], 'price' => $data['price'], 'sale_price' => $data['sale_price'],
            'status' => $data['status'], 'initial_stock' => $initial,
        ]);
        $imageErrors = $this->storeUploadedImages($request, $id, $data['name']);
        Cache::bump('catalog');

        flash('success', 'Product "' . $data['name'] . '" created.');
        if ($imageErrors) {
            flash('warning', 'Some images were not uploaded: ' . implode(' ', $imageErrors));
        }
        return $this->redirect(admin_url('products/' . $id . '/edit'));
    }

    public function edit(Request $request, string $id): Response
    {
        $product = $this->repo->productForEdit((int) $id);
        if (!$product) {
            throw new HttpException(404);
        }
        $tab = $request->str('tab', 'details');
        if (!in_array($tab, ['details', 'media', 'variants'], true)) {
            $tab = 'details';
        }
        return $this->adminView('products/form', $this->formData($product) + [
            'title' => 'Edit: ' . $product['name'],
            'tab' => $tab,
        ]);
    }

    public function update(Request $request, string $id): Response
    {
        $old = $this->findOrFail((int) $id);
        $pid = (int) $old['id'];
        $data = $this->validatedProduct($request, $pid);
        $assign = $this->assignments($request);
        $attributes = $this->attributesInput($request);

        Database::transaction(function () use ($pid, $data, $assign, $attributes) {
            Database::update('products', $data, ['id' => $pid]);
            $this->writeAssignments($pid, $assign);
            $this->writeAttributes($pid, $attributes);
        });

        [$oldVals, $newVals] = $this->diff($old, $data);
        AuditLogger::log('product.update', 'product', $pid, $oldVals ?: null, ($newVals ?: []) + [
            'recipients' => $assign['recipients'], 'occasions' => $assign['occasions'],
            'interests' => $assign['interests'], 'tags' => $assign['tags'],
        ]);
        Cache::bump('catalog');
        flash('success', 'Product saved.');
        return $this->redirect(admin_url('products/' . $pid . '/edit'));
    }

    /** Publish / deactivate / back to draft quick action. */
    public function status(Request $request, string $id): Response
    {
        $product = $this->findOrFail((int) $id);
        $to = $request->str('status');
        if (!in_array($to, self::STATUSES, true)) {
            flash('error', 'Unknown status.');
            return $this->back($this->adminPath('products'));
        }
        if ($to === $product['status']) {
            flash('info', 'Product is already ' . $to . '.');
            return $this->back($this->adminPath('products'));
        }
        if ($to === 'active') {
            $problems = [];
            if ((float) $product['price'] <= 0) {
                $problems[] = 'set a price above zero';
            }
            if (trim((string) $product['name']) === '' || trim((string) $product['sku']) === '') {
                $problems[] = 'add a name and SKU';
            }
            if ($problems) {
                flash('error', 'Before publishing, please ' . implode(' and ', $problems) . '.');
                return $this->back($this->adminPath('products'));
            }
        }
        Database::update('products', ['status' => $to], ['id' => (int) $product['id']]);
        AuditLogger::log('product.status', 'product', (int) $product['id'], ['status' => $product['status']], ['status' => $to]);
        Cache::bump('catalog');

        $msg = match ($to) {
            'active' => 'published — it is now visible in the store',
            'inactive' => 'deactivated — it is hidden from the store',
            default => 'moved back to draft',
        };
        flash('success', '"' . $product['name'] . '" ' . $msg . '.');
        if ($to === 'active' && !(int) Database::fetchColumn('SELECT COUNT(*) FROM product_images WHERE product_id = :id', ['id' => (int) $product['id']])) {
            flash('warning', 'This product has no images yet. Customers will see a placeholder.');
        }
        return $this->back($this->adminPath('products'));
    }

    /* ================================================================ images */

    public function uploadImages(Request $request, string $id): Response
    {
        $product = $this->findOrFail((int) $id);
        $files = array_filter($request->files('images'), static fn ($f) => ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE);
        if (!$files) {
            flash('error', 'Choose at least one image to upload.');
            return $this->redirect(admin_url('products/' . $product['id'] . '/edit?tab=media'));
        }
        $before = (int) Database::fetchColumn('SELECT COUNT(*) FROM product_images WHERE product_id = :id', ['id' => (int) $product['id']]);
        $errors = $this->storeUploadedImages($request, (int) $product['id'], (string) $product['name']);
        $after = (int) Database::fetchColumn('SELECT COUNT(*) FROM product_images WHERE product_id = :id', ['id' => (int) $product['id']]);
        if ($after > $before) {
            AuditLogger::log('product.images_upload', 'product', (int) $product['id'], null, ['added' => $after - $before]);
            Cache::bump('catalog');
            flash('success', ($after - $before) . ' image(s) uploaded.');
        }
        if ($errors) {
            flash('error', implode(' ', $errors));
        }
        return $this->redirect(admin_url('products/' . $product['id'] . '/edit?tab=media'));
    }

    /** Saves alt texts and the drag-and-drop order (first image = primary). */
    public function saveImages(Request $request, string $id): Response
    {
        $product = $this->findOrFail((int) $id);
        $pid = (int) $product['id'];
        $existing = array_map('intval', Database::fetchCol('SELECT id FROM product_images WHERE product_id = :id ORDER BY sort_order, id', ['id' => $pid]));
        $order = array_values(array_filter(array_map('intval', explode(',', $request->str('order'))), static fn ($i) => in_array($i, $existing, true)));
        foreach ($existing as $eid) {
            if (!in_array($eid, $order, true)) {
                $order[] = $eid;
            }
        }
        $alts = $request->arr('alt');
        Database::transaction(function () use ($order, $alts, $pid) {
            foreach ($order as $pos => $imageId) {
                $alt = isset($alts[$imageId]) && is_scalar($alts[$imageId]) ? mb_substr(trim((string) $alts[$imageId]), 0, 190) : null;
                Database::query(
                    'UPDATE product_images SET sort_order = :s, alt = :a WHERE id = :id AND product_id = :p',
                    ['s' => $pos, 'a' => $alt !== '' ? $alt : null, 'id' => $imageId, 'p' => $pid]
                );
            }
        });
        AuditLogger::log('product.images_update', 'product', $pid, null, ['order' => $order]);
        Cache::bump('catalog');
        flash('success', 'Image order and alt text saved.');
        return $this->redirect(admin_url('products/' . $pid . '/edit?tab=media'));
    }

    public function primaryImage(Request $request, string $id, string $imageId): Response
    {
        $product = $this->findOrFail((int) $id);
        $pid = (int) $product['id'];
        $ids = array_map('intval', Database::fetchCol('SELECT id FROM product_images WHERE product_id = :id ORDER BY sort_order, id', ['id' => $pid]));
        if (!in_array((int) $imageId, $ids, true)) {
            throw new HttpException(404);
        }
        $ids = array_merge([(int) $imageId], array_values(array_diff($ids, [(int) $imageId])));
        Database::transaction(function () use ($ids, $pid) {
            foreach ($ids as $pos => $iid) {
                Database::update('product_images', ['sort_order' => $pos], ['id' => $iid, 'product_id' => $pid]);
            }
        });
        AuditLogger::log('product.image_primary', 'product', $pid, null, ['image_id' => (int) $imageId]);
        Cache::bump('catalog');
        flash('success', 'Primary image updated.');
        return $this->redirect(admin_url('products/' . $pid . '/edit?tab=media'));
    }

    public function deleteImage(Request $request, string $id, string $imageId): Response
    {
        $product = $this->findOrFail((int) $id);
        $pid = (int) $product['id'];
        $image = Database::fetch('SELECT * FROM product_images WHERE id = :id AND product_id = :p', ['id' => (int) $imageId, 'p' => $pid]);
        if (!$image) {
            throw new HttpException(404);
        }
        Database::delete('product_images', ['id' => (int) $image['id']]);
        $stillUsed = (int) Database::fetchColumn('SELECT COUNT(*) FROM product_images WHERE path = :p', ['p' => $image['path']]);
        if ($stillUsed === 0) {
            Uploader::delete((string) $image['path']);
        }
        AuditLogger::log('product.image_delete', 'product', $pid, ['image_id' => (int) $image['id'], 'path' => $image['path']], null);
        Cache::bump('catalog');
        flash('success', 'Image deleted.');
        return $this->redirect(admin_url('products/' . $pid . '/edit?tab=media'));
    }

    /* ================================================================ variants */

    public function storeVariant(Request $request, string $id): Response
    {
        $product = $this->findOrFail((int) $id);
        $pid = (int) $product['id'];
        $input = [
            'nv_name' => $request->str('nv_name'),
            'nv_sku' => $request->str('nv_sku'),
            'nv_options' => $request->str('nv_options'),
            'nv_price_adjustment' => $request->str('nv_price_adjustment', '0'),
            'nv_sort_order' => $request->str('nv_sort_order', '0'),
            'nv_stock' => $request->str('nv_stock', '0'),
        ];
        $errors = $this->variantErrors($input, 'nv_', (float) $product['price'], 0);
        if ($input['nv_stock'] !== '' && (filter_var($input['nv_stock'], FILTER_VALIDATE_INT) === false || (int) $input['nv_stock'] < 0 || (int) $input['nv_stock'] > 1000000)) {
            $errors['nv_stock'] = 'Opening stock must be a whole number of 0 or more.';
        }
        [$options, $optError] = $this->parseOptions($input['nv_options']);
        if ($optError) {
            $errors['nv_options'] = $optError;
        }
        if ($errors) {
            throw new ValidationException($errors, $input + ['nv_active' => $request->bool('nv_active') ? '1' : '']);
        }
        $stock = (int) $input['nv_stock'];
        $staffId = Auth::staffId();
        $row = [
            'product_id' => $pid,
            'name' => $input['nv_name'],
            'sku' => $input['nv_sku'],
            'options_json' => $options ? json_encode($options, JSON_UNESCAPED_UNICODE) : null,
            'price_adjustment' => round((float) ($input['nv_price_adjustment'] ?: 0), 2),
            'is_active' => $request->bool('nv_active') ? 1 : 0,
            'sort_order' => (int) $input['nv_sort_order'],
        ];
        $vid = Database::transaction(function () use ($row, $pid, $stock, $staffId) {
            $vid = Database::insert('product_variants', $row);
            Database::query('INSERT IGNORE INTO inventory (product_id, variant_id, quantity) VALUES (:p, :v, 0)', ['p' => $pid, 'v' => $vid]);
            if ($stock > 0) {
                $this->inventory->change($pid, $vid, $stock, 'initial', 'product', $pid, $staffId, 'Initial variant stock');
            }
            return $vid;
        });
        AuditLogger::log('product.variant_create', 'product_variant', $vid, null, $row + ['initial_stock' => $stock]);
        Cache::bump('catalog');
        flash('success', 'Variant "' . $row['name'] . '" added.');
        return $this->redirect(admin_url('products/' . $pid . '/edit?tab=variants'));
    }

    public function updateVariant(Request $request, string $id, string $variantId): Response
    {
        $product = $this->findOrFail((int) $id);
        $pid = (int) $product['id'];
        $variant = Database::fetch('SELECT * FROM product_variants WHERE id = :id AND product_id = :p', ['id' => (int) $variantId, 'p' => $pid]);
        if (!$variant) {
            throw new HttpException(404);
        }
        $input = [
            'v_name' => $request->str('v_name'),
            'v_sku' => $request->str('v_sku'),
            'v_options' => $request->str('v_options'),
            'v_price_adjustment' => $request->str('v_price_adjustment', '0'),
            'v_sort_order' => $request->str('v_sort_order', '0'),
        ];
        $errors = $this->variantErrors($input, 'v_', (float) $product['price'], (int) $variant['id']);
        [$options, $optError] = $this->parseOptions($input['v_options']);
        if ($optError) {
            $errors['v_options'] = $optError;
        }
        if ($errors) {
            flash('error', 'Variant "' . $variant['name'] . '" was not saved: ' . implode(' ', $errors));
            return $this->redirect(admin_url('products/' . $pid . '/edit?tab=variants'));
        }
        $data = [
            'name' => $input['v_name'],
            'sku' => $input['v_sku'],
            'options_json' => $options ? json_encode($options, JSON_UNESCAPED_UNICODE) : null,
            'price_adjustment' => round((float) ($input['v_price_adjustment'] ?: 0), 2),
            'is_active' => $request->bool('v_active') ? 1 : 0,
            'sort_order' => (int) $input['v_sort_order'],
        ];
        Database::update('product_variants', $data, ['id' => (int) $variant['id']]);
        [$o, $n] = $this->diff($variant, $data);
        AuditLogger::log('product.variant_update', 'product_variant', (int) $variant['id'], $o ?: null, $n ?: null);
        Cache::bump('catalog');
        flash('success', 'Variant "' . $data['name'] . '" saved.');
        return $this->redirect(admin_url('products/' . $pid . '/edit?tab=variants'));
    }

    public function deleteVariant(Request $request, string $id, string $variantId): Response
    {
        $product = $this->findOrFail((int) $id);
        $pid = (int) $product['id'];
        $variant = Database::fetch('SELECT * FROM product_variants WHERE id = :id AND product_id = :p', ['id' => (int) $variantId, 'p' => $pid]);
        if (!$variant) {
            throw new HttpException(404);
        }
        $vid = (int) $variant['id'];
        $redirect = admin_url('products/' . $pid . '/edit?tab=variants');
        $stock = $this->inventory->available($pid, $vid);
        if ($stock !== 0) {
            flash('error', 'This variant still has ' . $stock . ' unit(s) in stock. Adjust its stock to 0 in Inventory first, or deactivate it instead.');
            return $this->redirect($redirect);
        }
        $orders = (int) Database::fetchColumn('SELECT COUNT(*) FROM order_items WHERE product_id = :p AND variant_id = :v', ['p' => $pid, 'v' => $vid]);
        $pos = (int) Database::fetchColumn('SELECT COUNT(*) FROM purchase_order_items WHERE product_id = :p AND variant_id = :v', ['p' => $pid, 'v' => $vid]);
        if ($orders > 0 || $pos > 0) {
            flash('error', 'This variant appears on past orders or purchase orders, so it cannot be deleted. Deactivate it instead.');
            return $this->redirect($redirect);
        }
        Database::transaction(function () use ($pid, $vid) {
            Database::delete('cart_items', ['product_id' => $pid, 'variant_id' => $vid]);
            Database::query('DELETE FROM inventory WHERE product_id = :p AND variant_id = :v AND quantity = 0', ['p' => $pid, 'v' => $vid]);
            Database::delete('product_variants', ['id' => $vid]);
        });
        AuditLogger::log('product.variant_delete', 'product_variant', $vid, ['name' => $variant['name'], 'sku' => $variant['sku']], null);
        Cache::bump('catalog');
        flash('success', 'Variant deleted.');
        return $this->redirect($redirect);
    }

    /* ================================================================ internals */

    private function adminPath(string $path): string
    {
        return '/' . trim((string) config('app.admin_path', 'admin'), '/') . '/' . $path;
    }

    private function findOrFail(int $id): array
    {
        $p = $this->repo->product($id);
        if (!$p) {
            throw new HttpException(404);
        }
        return $p;
    }

    private function formData(?array $product): array
    {
        $ageRanges = Database::fetchAll('SELECT label, min_months, max_months FROM age_ranges ORDER BY sort_order, min_months');
        $presets = [];
        foreach ($ageRanges as $r) {
            $presets[$r['label']] = [(int) $r['min_months'], (int) $r['max_months']];
        }
        if (!$presets) {
            $presets = self::AGE_PRESETS;
        }
        return [
            'product' => $product,
            'tab' => 'details',
            'categories' => $this->repo->categoryTree(),
            'makers' => $this->repo->makers(),
            'recipients' => $this->repo->recipients(),
            'occasions' => $this->repo->occasions(),
            'interests' => $this->repo->interests(),
            'generalTags' => $this->repo->tags('general'),
            'preferenceTags' => $this->repo->tags('preference'),
            'agePresets' => $presets,
            'maxImages' => self::MAX_IMAGES,
        ];
    }

    /**
     * Validates the main product form and returns the column => value array.
     * @throws ValidationException
     */
    private function validatedProduct(Request $request, int $id): array
    {
        $in = $request->all();
        // Age preset ("min-max") overrides the manual month fields.
        $preset = $request->str('age_preset');
        if ($preset !== '' && preg_match('/^(\d{1,4})-(\d{1,4})$/', $preset, $m)) {
            $in['age_min_months'] = $m[1];
            $in['age_max_months'] = $m[2];
        }
        $rules = [
            'sku' => 'required|max:60|regex:/^[A-Za-z0-9._-]+$/',
            'name' => 'required|min:2|max:190',
            'slug' => 'nullable|slug|max:200',
            'short_description' => 'nullable|max:500',
            'description' => 'nullable|max:20000',
            'price' => 'required|numeric|min:0|max:9999999',
            'sale_price' => 'nullable|numeric|min:0|max:9999999',
            'cost_price' => 'nullable|numeric|min:0|max:9999999',
            'category_id' => 'nullable|integer|exists:categories,id',
            'maker_id' => 'nullable|integer|exists:makers,id',
            'materials' => 'nullable|max:255',
            'dimensions' => 'nullable|max:120',
            'weight_grams' => 'nullable|integer|min:0|max:1000000',
            'age_min_months' => 'nullable|integer|min:0|max:1200',
            'age_max_months' => 'nullable|integer|min:0|max:1200',
            'safety_info' => 'nullable|max:5000',
            'personalization_label' => 'nullable|max:120',
            'personalization_max_chars' => 'nullable|integer|min:1|max:255',
            'delivery_restrictions' => 'nullable|max:255',
            'lead_time_days' => 'nullable|integer|min:0|max:120',
            'video_url' => 'nullable|url|max:255',
            'status' => 'required|in:draft,active,inactive',
            'seo_title' => 'nullable|max:190',
            'seo_description' => 'nullable|max:300',
        ];
        $labels = [
            'sku' => 'SKU', 'category_id' => 'Category', 'maker_id' => 'Maker', 'weight_grams' => 'Weight',
            'age_min_months' => 'Minimum age', 'age_max_months' => 'Maximum age', 'video_url' => 'Video URL',
            'seo_title' => 'SEO title', 'seo_description' => 'SEO description', 'lead_time_days' => 'Lead time',
            'personalization_max_chars' => 'Personalization max characters',
        ];
        $v = Validator::make($in, $rules, $labels);
        $v->fails();
        $errors = $v->errors();
        $val = $v->validated();
        $flags = [];
        foreach (self::FLAGS as $f) {
            $flags[$f] = $request->bool($f) ? 1 : 0;
        }

        // Cross-field rules
        $sku = (string) $val['sku'];
        if (!isset($errors['sku']) && $sku !== '' && $this->repo->skuTaken($sku, $id)) {
            $errors['sku'] = 'SKU is already used by another product or variant.';
        }
        $slug = (string) ($val['slug'] ?? '');
        if ($slug !== '' && !isset($errors['slug']) && $this->repo->slugTaken('products', $slug, $id)) {
            $errors['slug'] = 'Slug is already used by another product.';
        }
        $price = (float) ($val['price'] ?? 0);
        $sale = ($val['sale_price'] ?? '') !== '' && $val['sale_price'] !== null ? (float) $val['sale_price'] : null;
        if ($sale !== null && !isset($errors['sale_price']) && $sale >= $price) {
            $errors['sale_price'] = 'Sale price must be lower than the regular price.';
        }
        if ($val['status'] === 'active' && $price <= 0 && !isset($errors['price'])) {
            $errors['price'] = 'An active product needs a price above zero.';
        }
        $ageMin = ($val['age_min_months'] ?? '') !== '' && $val['age_min_months'] !== null ? (int) $val['age_min_months'] : null;
        $ageMax = ($val['age_max_months'] ?? '') !== '' && $val['age_max_months'] !== null ? (int) $val['age_max_months'] : null;
        if ($ageMin !== null && $ageMax !== null && $ageMin > $ageMax && !isset($errors['age_max_months'])) {
            $errors['age_max_months'] = 'Maximum age must be greater than or equal to the minimum age.';
        }
        if ($flags['has_small_parts'] && $ageMin !== null && $ageMin < 36) {
            $errors['has_small_parts'] = 'Products with small parts must have a minimum age of 3 years (36 months) or more.';
        }
        $video = (string) ($val['video_url'] ?? '');
        if ($video !== '' && !isset($errors['video_url']) && !preg_match('#^https://#i', $video)) {
            $errors['video_url'] = 'Video URL must start with https://.';
        }
        if ($flags['is_personalizable']) {
            if (trim((string) ($val['personalization_label'] ?? '')) === '') {
                $errors['personalization_label'] = 'Add a label for the personalization field (e.g. "Name to engrave").';
            }
            if (($val['personalization_max_chars'] ?? '') === '' || $val['personalization_max_chars'] === null) {
                $errors['personalization_max_chars'] = 'Set the maximum number of personalization characters.';
            }
        }
        if ($errors) {
            $old = $request->all();
            unset($old['_token']);
            throw new ValidationException($errors, $old);
        }

        $nullable = static fn ($v) => ($v === null || $v === '') ? null : $v;
        $name = (string) $val['name'];
        if ($slug === '') {
            $slug = $this->repo->uniqueSlug('products', $name, $id);
        }
        return [
            'sku' => $sku,
            'name' => $name,
            'slug' => $slug,
            'short_description' => $nullable($val['short_description']),
            'description' => $nullable($val['description']),
            'price' => round($price, 2),
            'sale_price' => $sale !== null ? round($sale, 2) : null,
            'cost_price' => $nullable($val['cost_price']) !== null ? round((float) $val['cost_price'], 2) : null,
            'category_id' => $nullable($val['category_id']) !== null ? (int) $val['category_id'] : null,
            'maker_id' => $nullable($val['maker_id']) !== null ? (int) $val['maker_id'] : null,
            'materials' => $nullable($val['materials']),
            'dimensions' => $nullable($val['dimensions']),
            'weight_grams' => $nullable($val['weight_grams']) !== null ? (int) $val['weight_grams'] : null,
            'age_min_months' => $ageMin,
            'age_max_months' => $ageMax,
            'safety_info' => $nullable($val['safety_info']),
            'personalization_label' => $nullable($val['personalization_label']),
            'personalization_max_chars' => $nullable($val['personalization_max_chars']) !== null ? (int) $val['personalization_max_chars'] : null,
            'delivery_restrictions' => $nullable($val['delivery_restrictions']),
            'lead_time_days' => (int) ($val['lead_time_days'] ?? 0),
            'video_url' => $video !== '' ? $video : null,
            'status' => (string) $val['status'],
            'seo_title' => $nullable($val['seo_title']),
            'seo_description' => $nullable($val['seo_description']),
        ] + $flags;
    }

    /** @return array{recipients:int[], occasions:int[], interests:int[], tags:int[]} */
    private function assignments(Request $request): array
    {
        return [
            'recipients' => $this->repo->existingIds('recipients', $request->arr('recipients')),
            'occasions' => $this->repo->existingIds('occasions', $request->arr('occasions')),
            'interests' => $this->repo->existingIds('interests', $request->arr('interests')),
            'tags' => $this->repo->existingIds('tags', array_merge($request->arr('tags'), $request->arr('pref_tags'))),
        ];
    }

    private function writeAssignments(int $productId, array $a): void
    {
        $this->repo->syncJoin('product_recipients', 'recipient_id', $productId, $a['recipients']);
        $this->repo->syncJoin('product_occasions', 'occasion_id', $productId, $a['occasions']);
        $this->repo->syncJoin('product_interests', 'interest_id', $productId, $a['interests']);
        $this->repo->syncJoin('product_tags', 'tag_id', $productId, $a['tags']);
    }

    /** @return array<int, array{name:string, value:string}> */
    private function attributesInput(Request $request): array
    {
        $names = $request->arr('attr_name');
        $values = $request->arr('attr_value');
        $out = [];
        $errors = [];
        foreach ($names as $i => $n) {
            $n = is_scalar($n) ? trim((string) $n) : '';
            $val = isset($values[$i]) && is_scalar($values[$i]) ? trim((string) $values[$i]) : '';
            if ($n === '' && $val === '') {
                continue;
            }
            if ($n === '' || $val === '') {
                $errors['attributes'] = 'Each attribute needs both a name and a value.';
                continue;
            }
            if (mb_strlen($n) > 80 || mb_strlen($val) > 255) {
                $errors['attributes'] = 'Attribute names are limited to 80 characters and values to 255.';
                continue;
            }
            $out[] = ['name' => $n, 'value' => $val];
        }
        if (count($out) > 40) {
            $errors['attributes'] = 'A product can have at most 40 attributes.';
        }
        if ($errors) {
            $old = $request->all();
            unset($old['_token']);
            throw new ValidationException($errors, $old);
        }
        return $out;
    }

    private function writeAttributes(int $productId, array $attributes): void
    {
        Database::delete('product_attributes', ['product_id' => $productId]);
        foreach ($attributes as $i => $a) {
            Database::insert('product_attributes', ['product_id' => $productId, 'name' => $a['name'], 'value' => $a['value'], 'sort_order' => $i]);
        }
    }

    private function initialStock(Request $request): int
    {
        $raw = $request->str('initial_stock');
        if ($raw === '') {
            return 0;
        }
        if (filter_var($raw, FILTER_VALIDATE_INT) === false || (int) $raw < 0 || (int) $raw > 1000000) {
            $old = $request->all();
            unset($old['_token']);
            throw new ValidationException(['initial_stock' => 'Opening stock must be a whole number of 0 or more.'], $old);
        }
        return (int) $raw;
    }

    /** Uploads files from images[] for a product; returns a list of error messages. */
    private function storeUploadedImages(Request $request, int $productId, string $defaultAlt): array
    {
        $files = array_values(array_filter($request->files('images'), static fn ($f) => ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE));
        if (!$files) {
            return [];
        }
        $count = (int) Database::fetchColumn('SELECT COUNT(*) FROM product_images WHERE product_id = :id', ['id' => $productId]);
        $next = (int) Database::fetchColumn('SELECT COALESCE(MAX(sort_order), -1) + 1 FROM product_images WHERE product_id = :id', ['id' => $productId]);
        $alt = mb_substr($request->str('image_alt') ?: $defaultAlt, 0, 190);
        $errors = [];
        foreach ($files as $file) {
            if ($count >= self::MAX_IMAGES) {
                $errors[] = 'A product can have at most ' . self::MAX_IMAGES . ' images.';
                break;
            }
            try {
                $path = Uploader::image($file, 'products');
                Database::insert('product_images', ['product_id' => $productId, 'path' => $path, 'alt' => $alt, 'sort_order' => $next++]);
                $count++;
            } catch (\PDOException $e) {
                throw $e; // database errors are not user messages
            } catch (RuntimeException $e) {
                $errors[] = mb_substr((string) ($file['name'] ?? 'File'), 0, 60) . ': ' . $e->getMessage();
            }
        }
        return $errors;
    }

    /** @return array<string,string> field => error */
    private function variantErrors(array $in, string $prefix, float $basePrice, int $variantId): array
    {
        $v = Validator::make($in, [
            $prefix . 'name' => 'required|max:120',
            $prefix . 'sku' => 'required|max:60|regex:/^[A-Za-z0-9._-]+$/',
            $prefix . 'price_adjustment' => 'nullable|numeric|min:-9999999|max:9999999',
            $prefix . 'sort_order' => 'nullable|integer|min:-1000|max:100000',
        ], [
            $prefix . 'name' => 'Variant name', $prefix . 'sku' => 'Variant SKU',
            $prefix . 'price_adjustment' => 'Price adjustment', $prefix . 'sort_order' => 'Sort order',
        ]);
        $v->fails();
        $errors = $v->errors();
        $sku = (string) $in[$prefix . 'sku'];
        if (!isset($errors[$prefix . 'sku']) && $this->repo->skuTaken($sku, 0, $variantId)) {
            $errors[$prefix . 'sku'] = 'Variant SKU is already used by a product or another variant.';
        }
        $adj = (float) ($in[$prefix . 'price_adjustment'] ?: 0);
        if (!isset($errors[$prefix . 'price_adjustment']) && $basePrice + $adj < 0) {
            $errors[$prefix . 'price_adjustment'] = 'Price adjustment cannot make the variant price negative.';
        }
        return $errors;
    }

    /**
     * Parses "Color: Pink; Size: S" (semicolons or new lines) into ['Color' => 'Pink', 'Size' => 'S'].
     * @return array{0: array<string,string>, 1: ?string}
     */
    private function parseOptions(string $raw): array
    {
        $raw = trim($raw);
        if ($raw === '') {
            return [[], null];
        }
        $out = [];
        foreach (preg_split('/[;\n]+/', $raw) ?: [] as $part) {
            $part = trim($part);
            if ($part === '') {
                continue;
            }
            if (!str_contains($part, ':')) {
                return [[], 'Options must look like "Color: Pink; Size: S".'];
            }
            [$k, $val] = array_map('trim', explode(':', $part, 2));
            if ($k === '' || $val === '') {
                return [[], 'Each option needs a name and a value, e.g. "Color: Pink".'];
            }
            if (mb_strlen($k) > 40 || mb_strlen($val) > 80) {
                return [[], 'Option names are limited to 40 characters and values to 80.'];
            }
            $out[$k] = $val;
        }
        if (count($out) > 8) {
            return [[], 'A variant can have at most 8 options.'];
        }
        return [$out, null];
    }

    /** Old/new values of changed columns (long texts are summarised). */
    private function diff(array $old, array $new): array
    {
        $o = [];
        $n = [];
        foreach ($new as $k => $v) {
            if (!array_key_exists($k, $old)) {
                continue;
            }
            $a = $old[$k];
            $same = is_numeric($a) && is_numeric($v) ? (float) $a === (float) $v : (string) ($a ?? '') === (string) ($v ?? '');
            if ($same) {
                continue;
            }
            if (in_array($k, ['description', 'safety_info', 'short_description'], true)) {
                $o[$k] = '[text changed]';
                $n[$k] = '[text changed]';
                continue;
            }
            $o[$k] = $a;
            $n[$k] = $v;
        }
        return [$o, $n];
    }
}
