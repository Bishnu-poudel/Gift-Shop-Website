<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Cache;
use App\Core\Database;
use App\Core\Gate;
use App\Core\Request;
use App\Core\Response;
use App\Core\Uploader;
use App\Core\ValidationException;
use App\Services\SettingsService;
use App\Services\TaxService;

/** Admin > Settings > Billing & tax: logo, PAN/VAT, legal name, VAT mode and bill numbering. */
final class BillingSettingsController extends Controller
{
    private const KEYS = ['business_legal_name', 'store_pan', 'store_vat_number', 'vat_registered', 'vat_rate', 'prices_include_vat', 'bill_prefix', 'bill_footer', 'store_logo', 'show_logo_in_header'];

    private function values(): array
    {
        $out = [];
        foreach (self::KEYS as $k) {
            $out[$k] = SettingsService::get($k, SettingsService::DEFAULTS[$k] ?? null);
        }
        return $out;
    }

    public function show(Request $request): Response
    {
        $fy = TaxService::fiscalYear();
        $last = (int) Database::fetchColumn('SELECT last_number FROM bill_sequences WHERE fiscal_year = :fy', ['fy' => $fy]);
        $prefix = (string) setting('bill_prefix', 'GFT');
        return $this->adminView('settings/billing', [
            'title' => 'Billing & tax',
            'tab' => 'billing',
            'values' => $this->values(),
            'fiscalYear' => $fy,
            'billsThisYear' => $last,
            'nextNumber' => sprintf('%s-%s-%06d', strtoupper($prefix), $fy, $last + 1),
        ]);
    }

    public function save(Request $request): Response
    {
        Gate::authorize('settings.manage');
        $data = $this->validate($request, [
            'business_legal_name' => 'nullable|max:150',
            'store_pan' => 'nullable|regex:/^\d{9}$/',
            'store_vat_number' => 'nullable|regex:/^\d{9}$/',
            'vat_rate' => 'required|numeric|min:0|max:100',
            'bill_prefix' => 'required|regex:/^[A-Za-z0-9]{2,10}$/',
            'bill_footer' => 'nullable|max:500',
        ], [
            'store_pan' => 'PAN (9 digits)', 'store_vat_number' => 'VAT number (9 digits)',
            'bill_prefix' => 'Bill prefix (2–10 letters/numbers)', 'business_legal_name' => 'Registered business name',
        ]);
        $vatRegistered = $request->bool('vat_registered');
        if ($vatRegistered && trim((string) $data['store_vat_number']) === '') {
            throw new ValidationException(['store_vat_number' => 'Enter your VAT number to issue VAT tax invoices, or untick "VAT registered".'], $request->all());
        }
        if (!$vatRegistered && trim((string) $data['store_pan']) === '') {
            throw new ValidationException(['store_pan' => 'Enter your PAN. Bills issued in Nepal must show the seller\'s PAN or VAT number.'], $request->all());
        }

        $values = [
            'business_legal_name' => strip_tags((string) ($data['business_legal_name'] ?? '')),
            'store_pan' => (string) ($data['store_pan'] ?? ''),
            'store_vat_number' => (string) ($data['store_vat_number'] ?? ''),
            'vat_registered' => $vatRegistered,
            'vat_rate' => round((float) $data['vat_rate'], 2),
            'prices_include_vat' => $request->input('prices_include_vat', '1') === '1',
            'bill_prefix' => strtoupper((string) $data['bill_prefix']),
            'bill_footer' => strip_tags((string) ($data['bill_footer'] ?? '')),
            'show_logo_in_header' => $request->bool('show_logo_in_header'),
        ];

        // Logo upload (PNG, JPG or WebP; validated and renamed by Uploader).
        $file = $request->file('store_logo');
        if ($file && ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            try {
                $path = Uploader::image($file, 'branding', 2_097_152);
            } catch (\RuntimeException $e) {
                throw new ValidationException(['store_logo' => $e->getMessage()], $request->all());
            }
            $old = (string) setting('store_logo', '');
            if ($old !== '' && str_starts_with($old, 'uploads/branding/')) {
                Uploader::delete($old);
            }
            $values['store_logo'] = $path;
        }

        $changed = $this->persist($values);
        flash('success', $changed ? 'Billing & tax settings saved. New bills use these details; bills already issued keep the details they were issued with.' : 'No changes to save.');
        return $this->redirect(admin_url('settings/billing'));
    }

    public function removeLogo(Request $request): Response
    {
        Gate::authorize('settings.manage');
        $old = (string) setting('store_logo', '');
        if ($old !== '') {
            if (str_starts_with($old, 'uploads/branding/')) {
                Uploader::delete($old);
            }
            $this->persist(['store_logo' => '']);
        }
        flash('success', 'Logo removed.');
        return $this->redirect(admin_url('settings/billing'));
    }

    private function persist(array $values): int
    {
        $old = [];
        $new = [];
        foreach ($values as $k => $v) {
            $current = SettingsService::get($k, SettingsService::DEFAULTS[$k] ?? null);
            if (json_encode($current) === json_encode($v)) {
                continue;
            }
            SettingsService::set($k, $v, 'billing');
            $old[$k] = $current;
            $new[$k] = $v;
        }
        Cache::bump('settings');
        Cache::bump('catalog');
        SettingsService::flush();
        if ($new) {
            AuditLogger::log('settings.billing_updated', 'settings', null, $old, $new);
        }
        return count($new);
    }
}
