<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Repositories\Admin\CatalogAdminRepository;

/** Admin > Suppliers CRUD. */
final class SuppliersController extends Controller
{
    private CatalogAdminRepository $repo;

    public function __construct()
    {
        $this->repo = new CatalogAdminRepository();
    }

    public function index(Request $request): Response
    {
        $q = mb_substr($request->str('q'), 0, 100);
        return $this->adminView('suppliers/index', [
            'title' => 'Suppliers',
            'suppliers' => $this->repo->suppliers($q),
            'q' => $q,
        ]);
    }

    public function create(Request $request): Response
    {
        return $this->adminView('suppliers/form', ['title' => 'New supplier', 'supplier' => null]);
    }

    public function store(Request $request): Response
    {
        $data = $this->validated($request);
        $id = Database::insert('suppliers', $data);
        AuditLogger::log('supplier.create', 'supplier', $id, null, $data);
        flash('success', 'Supplier "' . $data['name'] . '" added.');
        return $this->redirect(admin_url('suppliers'));
    }

    public function edit(Request $request, string $id): Response
    {
        $supplier = $this->findOrFail((int) $id);
        return $this->adminView('suppliers/form', [
            'title' => 'Edit supplier',
            'supplier' => $supplier,
            'poCount' => (int) Database::fetchColumn('SELECT COUNT(*) FROM purchase_orders WHERE supplier_id = :id', ['id' => (int) $supplier['id']]),
        ]);
    }

    public function update(Request $request, string $id): Response
    {
        $old = $this->findOrFail((int) $id);
        $data = $this->validated($request);
        Database::update('suppliers', $data, ['id' => (int) $old['id']]);
        $before = [];
        $after = [];
        foreach ($data as $k => $v) {
            if ((string) ($old[$k] ?? '') !== (string) ($v ?? '')) {
                $before[$k] = $old[$k];
                $after[$k] = $v;
            }
        }
        AuditLogger::log('supplier.update', 'supplier', (int) $old['id'], $before ?: null, $after ?: null);
        flash('success', 'Supplier saved.');
        return $this->redirect(admin_url('suppliers'));
    }

    public function destroy(Request $request, string $id): Response
    {
        $supplier = $this->findOrFail((int) $id);
        $sid = (int) $supplier['id'];
        $pos = (int) Database::fetchColumn('SELECT COUNT(*) FROM purchase_orders WHERE supplier_id = :id', ['id' => $sid]);
        if ($pos > 0) {
            if ((int) $supplier['is_active']) {
                Database::update('suppliers', ['is_active' => 0], ['id' => $sid]);
                AuditLogger::log('supplier.deactivate', 'supplier', $sid, ['is_active' => 1], ['is_active' => 0]);
            }
            flash('warning', '"' . $supplier['name'] . '" has ' . $pos . ' purchase order(s), so it was deactivated instead of deleted to keep the purchasing history.');
            return $this->redirect(admin_url('suppliers'));
        }
        Database::delete('suppliers', ['id' => $sid]);
        AuditLogger::log('supplier.delete', 'supplier', $sid, ['name' => $supplier['name'], 'email' => $supplier['email']], null);
        flash('success', 'Supplier deleted.');
        return $this->redirect(admin_url('suppliers'));
    }

    private function findOrFail(int $id): array
    {
        $s = Database::fetch('SELECT * FROM suppliers WHERE id = :id', ['id' => $id]);
        if (!$s) {
            throw new HttpException(404);
        }
        return $s;
    }

    private function validated(Request $request): array
    {
        $v = $this->validate($request, [
            'name' => 'required|max:120',
            'contact_name' => 'nullable|max:120',
            'email' => 'nullable|email',
            'phone' => 'nullable|max:30|regex:/^[0-9+\-\s()]{6,30}$/',
            'address' => 'nullable|max:255',
            'notes' => 'nullable|max:5000',
        ], ['contact_name' => 'Contact person']);
        $n = static fn ($x) => ($x === null || $x === '') ? null : (string) $x;
        return [
            'name' => (string) $v['name'],
            'contact_name' => $n($v['contact_name']),
            'email' => $n($v['email']) !== null ? mb_strtolower((string) $v['email']) : null,
            'phone' => $n($v['phone']),
            'address' => $n($v['address']),
            'notes' => $n($v['notes']),
            'is_active' => $request->bool('is_active') ? 1 : 0,
        ];
    }
}
