<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Cache;
use App\Core\Database;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\Uploader;
use App\Core\ValidationException;
use App\Core\Validator;
use App\Repositories\Admin\CatalogAdminRepository;
use RuntimeException;

/**
 * Admin > Gift taxonomy. One generic CRUD UI at /taxonomies/{type}.
 * The URL type is only ever used as a key into the TYPES whitelist below; table and column
 * identifiers come exclusively from this map, never from user input.
 */
final class TaxonomiesController extends Controller
{
    private const SORT = ['type' => 'number', 'label' => 'Sort order', 'rules' => 'nullable|integer|min:-10000|max:10000', 'default' => '0', 'not_null' => true, 'hint' => 'Lower numbers appear first.'];
    private const ACTIVE = ['type' => 'bool', 'label' => 'Active (visible in the store)', 'default' => true];
    private const SYNONYMS = ['type' => 'synonyms', 'label' => 'Synonyms', 'rules' => 'nullable|max:2000', 'hint' => 'Comma-separated words shoppers might type, e.g. "mum, mom, mummy".', 'span' => true];
    private const DESCRIPTION = ['type' => 'textarea', 'label' => 'Description', 'rules' => 'nullable|max:255', 'span' => true];
    private const IMAGE = ['type' => 'image', 'label' => 'Image'];

    public const TYPES = [
        'recipients' => [
            'table' => 'recipients', 'label' => 'Recipients', 'singular' => 'recipient', 'title' => 'name', 'slug' => true,
            'order' => 'sort_order, name', 'usage' => ['product_recipients', 'recipient_id'],
            'intro' => 'Who the gift is for. Age limits give the Gift Finder an implicit age context (e.g. Baby girl = 0–24 months).',
            'list' => ['image', 'name', 'slug', 'audience', 'ages', 'usage', 'sort_order', 'is_active'],
            'fields' => [
                'name' => ['type' => 'text', 'label' => 'Name', 'rules' => 'required|max:80'],
                'slug' => ['type' => 'slug', 'label' => 'Slug', 'rules' => 'nullable|slug|max:100'],
                'audience' => ['type' => 'select', 'label' => 'Audience', 'rules' => 'required|in:baby,child,teen,adult,any', 'default' => 'adult',
                    'options' => ['baby' => 'Baby', 'child' => 'Child', 'teen' => 'Teen', 'adult' => 'Adult', 'any' => 'Anyone']],
                'age_min_months' => ['type' => 'number', 'label' => 'Minimum age (months)', 'rules' => 'nullable|integer|min:0|max:1200'],
                'age_max_months' => ['type' => 'number', 'label' => 'Maximum age (months)', 'rules' => 'nullable|integer|min:0|max:1200'],
                'synonyms' => self::SYNONYMS,
                'description' => self::DESCRIPTION,
                'sort_order' => self::SORT,
                'image' => self::IMAGE,
                'is_active' => self::ACTIVE,
            ],
            'range' => ['age_min_months', 'age_max_months'],
        ],
        'occasions' => [
            'table' => 'occasions', 'label' => 'Occasions', 'singular' => 'occasion', 'title' => 'name', 'slug' => true,
            'order' => 'sort_order, name', 'usage' => ['product_occasions', 'occasion_id'],
            'intro' => 'Birthdays, festivals and life events. Seasonal occasions (Dashain, Tihar, Valentine\'s) can be featured in campaigns.',
            'list' => ['image', 'name', 'slug', 'is_seasonal', 'usage', 'sort_order', 'is_active'],
            'fields' => [
                'name' => ['type' => 'text', 'label' => 'Name', 'rules' => 'required|max:80'],
                'slug' => ['type' => 'slug', 'label' => 'Slug', 'rules' => 'nullable|slug|max:100'],
                'synonyms' => self::SYNONYMS,
                'description' => self::DESCRIPTION,
                'sort_order' => self::SORT,
                'image' => self::IMAGE,
                'is_seasonal' => ['type' => 'bool', 'label' => 'Seasonal occasion', 'default' => false],
                'is_active' => self::ACTIVE,
            ],
        ],
        'interests' => [
            'table' => 'interests', 'label' => 'Interests', 'singular' => 'interest', 'title' => 'name', 'slug' => true,
            'order' => 'sort_order, name', 'usage' => ['product_interests', 'interest_id'],
            'intro' => 'Hobbies and passions used to match gifts to personalities.',
            'list' => ['image', 'name', 'slug', 'usage', 'sort_order', 'is_active'],
            'fields' => [
                'name' => ['type' => 'text', 'label' => 'Name', 'rules' => 'required|max:80'],
                'slug' => ['type' => 'slug', 'label' => 'Slug', 'rules' => 'nullable|slug|max:100'],
                'synonyms' => self::SYNONYMS,
                'description' => self::DESCRIPTION,
                'sort_order' => self::SORT,
                'image' => self::IMAGE,
                'is_active' => self::ACTIVE,
            ],
        ],
        'age-ranges' => [
            'table' => 'age_ranges', 'label' => 'Age ranges', 'singular' => 'age range', 'title' => 'label', 'slug' => true,
            'order' => 'sort_order, min_months', 'usage' => null,
            'intro' => 'Age bands offered in filters and the Gift Finder. Ranges starting under 36 months apply strict small-parts safety rules.',
            'list' => ['label', 'slug', 'audience', 'months', 'sort_order'],
            'fields' => [
                'label' => ['type' => 'text', 'label' => 'Label', 'rules' => 'required|max:60'],
                'slug' => ['type' => 'slug', 'label' => 'Slug', 'rules' => 'nullable|slug|max:60'],
                'audience' => ['type' => 'select', 'label' => 'Audience', 'rules' => 'required|in:child,adult', 'default' => 'child',
                    'options' => ['child' => 'Child', 'adult' => 'Adult']],
                'sort_order' => self::SORT,
                'min_months' => ['type' => 'number', 'label' => 'Minimum age (months)', 'rules' => 'required|integer|min:0|max:1200', 'not_null' => true],
                'max_months' => ['type' => 'number', 'label' => 'Maximum age (months)', 'rules' => 'required|integer|min:0|max:1200', 'not_null' => true, 'hint' => 'Use 1200 for "and up".'],
            ],
            'range' => ['min_months', 'max_months'],
        ],
        'budgets' => [
            'table' => 'budget_ranges', 'label' => 'Budgets', 'singular' => 'budget range', 'title' => 'label', 'slug' => false,
            'order' => 'sort_order, min_amount', 'usage' => null,
            'intro' => 'Price bands shown in the Gift Finder and price filters.',
            'list' => ['label', 'amounts', 'sort_order', 'is_active'],
            'fields' => [
                'label' => ['type' => 'text', 'label' => 'Label', 'rules' => 'required|max:60', 'placeholder' => 'e.g. Under NPR 1,000'],
                'sort_order' => self::SORT,
                'min_amount' => ['type' => 'money', 'label' => 'Minimum amount (NPR)', 'rules' => 'required|numeric|min:0|max:99999999', 'default' => '0', 'not_null' => true],
                'max_amount' => ['type' => 'money', 'label' => 'Maximum amount (NPR)', 'rules' => 'nullable|numeric|min:0|max:99999999', 'hint' => 'Leave empty for "and above".'],
                'is_active' => self::ACTIVE,
            ],
            'range' => ['min_amount', 'max_amount'],
        ],
        'tags' => [
            'table' => 'tags', 'label' => 'Tags', 'singular' => 'tag', 'title' => 'name', 'slug' => true,
            'order' => 'type, name', 'usage' => ['product_tags', 'tag_id'],
            'intro' => 'General tags help search; preference tags (handmade, eco-friendly, luxury…) power Gift Finder step 6.',
            'list' => ['name', 'slug', 'type', 'usage'],
            'fields' => [
                'name' => ['type' => 'text', 'label' => 'Name', 'rules' => 'required|max:80'],
                'slug' => ['type' => 'slug', 'label' => 'Slug', 'rules' => 'nullable|slug|max:100'],
                'type' => ['type' => 'select', 'label' => 'Type', 'rules' => 'required|in:general,preference', 'default' => 'general',
                    'options' => ['general' => 'General', 'preference' => 'Preference (Gift Finder)']],
            ],
        ],
        'synonyms' => [
            'table' => 'search_synonyms', 'label' => 'Search synonyms', 'singular' => 'synonym', 'title' => 'phrase', 'slug' => false,
            'order' => 'phrase', 'usage' => null,
            'intro' => 'Map free-text phrases to taxonomy terms, e.g. "little princess" → recipient:baby-girl, interest:princess-toys.',
            'list' => ['phrase', 'maps_to'],
            'fields' => [
                'phrase' => ['type' => 'text', 'label' => 'Phrase', 'rules' => 'required|max:120', 'placeholder' => 'e.g. little princess', 'hint' => 'Stored in lowercase. Must be unique.'],
                'maps_to' => ['type' => 'maps', 'label' => 'Maps to', 'rules' => 'required|max:500', 'span' => true,
                    'placeholder' => 'recipient:baby-girl, interest:princess-toys, agemonths:12-36',
                    'hint' => 'Comma-separated type:value pairs. Types: recipient, occasion, interest, category, pref, agemonths (e.g. 12-36), flag (e.g. personalized).'],
            ],
        ],
        'makers' => [
            'table' => 'makers', 'label' => 'Makers', 'singular' => 'maker', 'title' => 'name', 'slug' => true,
            'order' => 'name', 'usage' => ['products', 'maker_id'],
            'intro' => 'Artisans and brands behind the products. Featured makers can be highlighted on the homepage.',
            'list' => ['image', 'name', 'slug', 'location', 'usage', 'is_featured'],
            'fields' => [
                'name' => ['type' => 'text', 'label' => 'Name', 'rules' => 'required|max:120'],
                'slug' => ['type' => 'slug', 'label' => 'Slug', 'rules' => 'nullable|slug|max:140'],
                'location' => ['type' => 'text', 'label' => 'Location', 'rules' => 'nullable|max:120', 'placeholder' => 'e.g. Patan, Lalitpur'],
                'story' => ['type' => 'textarea', 'label' => 'Story', 'rules' => 'nullable|max:5000', 'span' => true, 'rows' => 6],
                'image' => self::IMAGE,
                'is_featured' => ['type' => 'bool', 'label' => 'Featured maker', 'default' => false],
            ],
        ],
    ];

    private const MAP_TYPES = ['recipient', 'occasion', 'interest', 'category', 'pref', 'agemonths', 'flag'];

    public function home(Request $request): Response
    {
        return $this->redirect(admin_url('taxonomies/recipients'));
    }

    public function index(Request $request, string $type): Response
    {
        $cfg = $this->config($type);
        $table = Database::ident($cfg['table']);
        $params = [];
        $where = '';
        $q = mb_substr($request->str('q'), 0, 100);
        if ($q !== '') {
            $params['q'] = '%' . $q . '%';
            $where = 'WHERE t.' . Database::ident($cfg['title']) . ' LIKE :q';
        }
        $usageSql = '0';
        if ($cfg['usage']) {
            [$ut, $uc] = $cfg['usage'];
            $usageSql = '(SELECT COUNT(*) FROM ' . Database::ident($ut) . ' u WHERE u.' . Database::ident($uc) . ' = t.id)';
        }
        $order = implode(', ', array_map(static fn ($c) => 't.' . Database::ident(trim($c)), explode(',', $cfg['order'])));
        $rows = Database::fetchAll("SELECT t.*, $usageSql AS usage_count FROM $table t $where ORDER BY $order LIMIT 1000", $params);

        return $this->adminView('taxonomies/index', [
            'title' => $cfg['label'],
            'type' => $type,
            'cfg' => $cfg,
            'types' => self::TYPES,
            'rows' => $rows,
            'q' => $q,
        ]);
    }

    public function create(Request $request, string $type): Response
    {
        $cfg = $this->config($type);
        return $this->adminView('taxonomies/form', [
            'title' => 'New ' . $cfg['singular'],
            'type' => $type,
            'cfg' => $cfg,
            'types' => self::TYPES,
            'row' => null,
        ]);
    }

    public function store(Request $request, string $type): Response
    {
        $cfg = $this->config($type);
        $data = $this->validated($request, $cfg, null);
        $id = Database::insert($cfg['table'], $data);
        AuditLogger::log('taxonomy.create', $cfg['table'], $id, null, $data);
        Cache::bump('catalog');
        flash('success', ucfirst($cfg['singular']) . ' "' . $data[$cfg['title']] . '" created.');
        return $this->redirect(admin_url('taxonomies/' . $type));
    }

    public function edit(Request $request, string $type, string $id): Response
    {
        $cfg = $this->config($type);
        $row = $this->findOrFail($cfg, (int) $id);
        return $this->adminView('taxonomies/form', [
            'title' => 'Edit ' . $cfg['singular'],
            'type' => $type,
            'cfg' => $cfg,
            'types' => self::TYPES,
            'row' => $row,
            'usage' => $this->usage($cfg, (int) $row['id']),
        ]);
    }

    public function update(Request $request, string $type, string $id): Response
    {
        $cfg = $this->config($type);
        $old = $this->findOrFail($cfg, (int) $id);
        $data = $this->validated($request, $cfg, $old);
        Database::update($cfg['table'], $data, ['id' => (int) $old['id']]);
        if (array_key_exists('image', $data) && !empty($old['image']) && $old['image'] !== $data['image']) {
            Uploader::delete((string) $old['image']);
        }
        $before = [];
        $after = [];
        foreach ($data as $k => $v) {
            if ((string) ($old[$k] ?? '') !== (string) ($v ?? '')) {
                $before[$k] = $old[$k] ?? null;
                $after[$k] = $v;
            }
        }
        AuditLogger::log('taxonomy.update', $cfg['table'], (int) $old['id'], $before ?: null, $after ?: null);
        Cache::bump('catalog');
        flash('success', ucfirst($cfg['singular']) . ' saved.');
        return $this->redirect(admin_url('taxonomies/' . $type));
    }

    public function destroy(Request $request, string $type, string $id): Response
    {
        $cfg = $this->config($type);
        $row = $this->findOrFail($cfg, (int) $id);
        $usage = $this->usage($cfg, (int) $row['id']);
        // Join rows cascade (product_* tables) and products.maker_id is SET NULL by the foreign keys.
        Database::delete($cfg['table'], ['id' => (int) $row['id']]);
        if (!empty($row['image'])) {
            Uploader::delete((string) $row['image']);
        }
        AuditLogger::log('taxonomy.delete', $cfg['table'], (int) $row['id'], $row + ['product_links' => $usage], null);
        Cache::bump('catalog');
        flash('success', ucfirst($cfg['singular']) . ' "' . $row[$cfg['title']] . '" deleted' . ($usage ? ' and removed from ' . $usage . ' product(s).' : '.'));
        return $this->redirect(admin_url('taxonomies/' . $type));
    }

    /* ---------------------------------------------------------------- internals */

    private function config(string $type): array
    {
        if (!isset(self::TYPES[$type])) {
            throw new HttpException(404);
        }
        return self::TYPES[$type];
    }

    private function findOrFail(array $cfg, int $id): array
    {
        $row = Database::fetch('SELECT * FROM ' . Database::ident($cfg['table']) . ' WHERE id = :id', ['id' => $id]);
        if (!$row) {
            throw new HttpException(404);
        }
        return $row;
    }

    private function usage(array $cfg, int $id): int
    {
        if (!$cfg['usage']) {
            return 0;
        }
        [$ut, $uc] = $cfg['usage'];
        return (int) Database::fetchColumn('SELECT COUNT(*) FROM ' . Database::ident($ut) . ' WHERE ' . Database::ident($uc) . ' = :id', ['id' => $id]);
    }

    /** @throws ValidationException */
    private function validated(Request $request, array $cfg, ?array $old): array
    {
        $id = $old ? (int) $old['id'] : 0;
        $input = $request->all();
        $rules = [];
        $labels = [];
        foreach ($cfg['fields'] as $col => $f) {
            if (isset($f['rules'])) {
                $rules[$col] = $f['rules'];
                $labels[$col] = $f['label'];
            }
        }
        if (isset($input['phrase']) && is_string($input['phrase'])) {
            $input['phrase'] = mb_strtolower(trim(preg_replace('/\s+/', ' ', $input['phrase']) ?? ''));
        }
        $v = Validator::make($input, $rules, $labels);
        $v->fails();
        $errors = $v->errors();
        $val = $v->validated();

        $data = [];
        $titleCol = $cfg['title'];
        foreach ($cfg['fields'] as $col => $f) {
            $raw = $val[$col] ?? null;
            switch ($f['type']) {
                case 'bool':
                    $data[$col] = $request->bool($col) ? 1 : 0;
                    break;
                case 'number':
                    $data[$col] = ($raw === null || $raw === '') ? (!empty($f['not_null']) ? (int) ($f['default'] ?? 0) : null) : (int) $raw;
                    break;
                case 'money':
                    $data[$col] = ($raw === null || $raw === '') ? (!empty($f['not_null']) ? (float) ($f['default'] ?? 0) : null) : round((float) $raw, 2);
                    break;
                case 'synonyms':
                    $list = array_values(array_unique(array_filter(array_map(
                        static fn ($s) => mb_strtolower(trim($s)),
                        explode(',', (string) $raw)
                    ), static fn ($s) => $s !== '')));
                    $data[$col] = $list ? implode(', ', $list) : null;
                    break;
                case 'maps':
                    [$normalized, $mapError] = $this->normalizeMappings((string) $raw);
                    if ($mapError !== null && !isset($errors[$col])) {
                        $errors[$col] = $mapError;
                    }
                    $data[$col] = $normalized;
                    break;
                case 'image':
                    break; // handled below
                case 'slug':
                    $data[$col] = (string) ($raw ?? '');
                    break;
                default:
                    $data[$col] = ($raw === null || $raw === '') ? null : (string) $raw;
            }
        }

        // Unique slug / phrase
        if (!empty($cfg['slug'])) {
            if ($data['slug'] !== '' && !isset($errors['slug']) && (new CatalogAdminRepository())->slugTaken($cfg['table'], $data['slug'], $id)) {
                $errors['slug'] = 'Slug is already in use.';
            }
        }
        if ($cfg['table'] === 'search_synonyms' && !isset($errors['phrase']) && ($data['phrase'] ?? '') !== '') {
            $taken = (int) Database::fetchColumn('SELECT COUNT(*) FROM search_synonyms WHERE phrase = :p AND id <> :id', ['p' => $data['phrase'], 'id' => $id]);
            if ($taken) {
                $errors['phrase'] = 'This phrase already has a synonym mapping.';
            }
        }
        // min <= max
        if (!empty($cfg['range'])) {
            [$lo, $hi] = $cfg['range'];
            if ($data[$lo] !== null && $data[$hi] !== null && !isset($errors[$lo]) && !isset($errors[$hi]) && (float) $data[$lo] > (float) $data[$hi]) {
                $errors[$hi] = $cfg['fields'][$hi]['label'] . ' must be greater than or equal to ' . mb_strtolower($cfg['fields'][$lo]['label']) . '.';
            }
        }

        // Image upload / removal
        if (isset($cfg['fields']['image']) && !$errors) {
            $file = $request->file('image');
            if ($file && ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                try {
                    $data['image'] = Uploader::image($file, 'taxonomy');
                } catch (RuntimeException $e) {
                    $errors['image'] = $e->getMessage();
                }
            } elseif ($old && $request->bool('remove_image')) {
                $data['image'] = null;
            }
        }

        if ($errors) {
            $oldInput = $request->all();
            unset($oldInput['_token']);
            throw new ValidationException($errors, $oldInput);
        }
        if (!empty($cfg['slug']) && $data['slug'] === '') {
            $data['slug'] = (new CatalogAdminRepository())->uniqueSlug($cfg['table'], (string) $data[$titleCol], $id);
        }
        return $data;
    }

    /**
     * Validates "type:value" mappings and returns the normalised comma list.
     * @return array{0: string, 1: ?string}
     */
    private function normalizeMappings(string $raw): array
    {
        $items = array_values(array_filter(array_map('trim', explode(',', mb_strtolower($raw))), static fn ($s) => $s !== ''));
        if (!$items) {
            return ['', 'Add at least one mapping, e.g. recipient:mother.'];
        }
        $out = [];
        $lookups = [
            'recipient' => 'recipients', 'occasion' => 'occasions', 'interest' => 'interests', 'category' => 'categories', 'pref' => 'tags',
        ];
        foreach ($items as $item) {
            if (!str_contains($item, ':')) {
                return ['', '"' . $item . '" must be written as type:value.'];
            }
            [$t, $value] = array_map('trim', explode(':', $item, 2));
            if (!in_array($t, self::MAP_TYPES, true)) {
                return ['', '"' . $t . '" is not a valid type. Use one of: ' . implode(', ', self::MAP_TYPES) . '.'];
            }
            if ($t === 'agemonths') {
                if (!preg_match('/^(\d{1,4})-(\d{1,4})$/', $value, $m) || (int) $m[1] > (int) $m[2] || (int) $m[2] > 1200) {
                    return ['', 'agemonths must be a range in months like 12-36.'];
                }
            } elseif (!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $value)) {
                return ['', '"' . $item . '": the value must be a slug (lowercase letters, numbers and hyphens).'];
            }
            if (isset($lookups[$t])) {
                $tbl = Database::ident($lookups[$t]);
                $sql = "SELECT COUNT(*) FROM $tbl WHERE slug = :s" . ($t === 'pref' ? " AND type = 'preference'" : '');
                if (!(int) Database::fetchColumn($sql, ['s' => $value])) {
                    return ['', 'No ' . ($t === 'pref' ? 'preference tag' : $t) . ' with slug "' . $value . '" exists.'];
                }
            }
            $out[] = $t . ':' . $value;
        }
        $joined = implode(',', array_values(array_unique($out)));
        if (mb_strlen($joined) > 500) {
            return ['', 'Mappings may not exceed 500 characters.'];
        }
        return [$joined, null];
    }
}
