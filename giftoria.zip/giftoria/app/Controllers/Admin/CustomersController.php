<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Repositories\Admin\ReportRepository;

/** Customer accounts (users.type = 'customer'). Password hashes and tokens are never selected. */
final class CustomersController extends Controller
{
    private const COLUMNS = 'u.id, u.name, u.email, u.phone, u.status, u.email_verified_at, u.last_login_at, u.created_at';

    public function index(Request $request): Response
    {
        $q = mb_substr($request->str('q'), 0, 100);
        $status = $request->str('status');
        $status = in_array($status, ['active', 'pending', 'inactive', 'deleted'], true) ? $status : '';
        $sort = $request->str('sort');
        $order = match ($sort) {
            'spent' => 'total_spent DESC, u.id DESC',
            'orders' => 'order_count DESC, u.id DESC',
            'name' => 'u.name ASC',
            default => 'u.id DESC',
        };

        $w = ["u.type = 'customer'"];
        $p = [];
        if ($q !== '') {
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $w[] = '(u.name LIKE :q1 OR u.email LIKE :q2 OR u.phone LIKE :q3)';
            $p += ['q1' => $like, 'q2' => $like, 'q3' => $like];
        }
        if ($status !== '') {
            $w[] = 'u.status = :s';
            $p['s'] = $status;
        }
        $where = implode(' AND ', $w);
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM users u WHERE $where", $p);
        $pager = Paginator::fromRequest($total, 25);
        $customers = Database::fetchAll(
            'SELECT ' . self::COLUMNS . ', COALESCE(os.order_count, 0) AS order_count, COALESCE(os.total_spent, 0) AS total_spent, os.last_order_at
             FROM users u
             LEFT JOIN (
                 SELECT user_id, COUNT(*) AS order_count, MAX(created_at) AS last_order_at,
                        SUM(CASE WHEN payment_status IN ' . ReportRepository::PAID . ' THEN grand_total - refunded_total ELSE 0 END) AS total_spent
                 FROM orders WHERE user_id IS NOT NULL GROUP BY user_id
             ) os ON os.user_id = u.id
             WHERE ' . $where . ' ORDER BY ' . $order . ' LIMIT ' . (int) $pager->perPage . ' OFFSET ' . (int) $pager->offset,
            $p
        );
        return $this->adminView('customers/index', [
            'title' => 'Customers',
            'customers' => $customers,
            'filters' => ['q' => $q, 'status' => $status, 'sort' => in_array($sort, ['spent', 'orders', 'name'], true) ? $sort : ''],
            'total' => $total,
            'paginator' => $pager,
        ]);
    }

    private function customer(string $id): array
    {
        $c = Database::fetch('SELECT ' . self::COLUMNS . " FROM users u WHERE u.id = :id AND u.type = 'customer'", ['id' => (int) $id]);
        if (!$c) {
            throw new HttpException(404, 'Customer not found.');
        }
        return $c;
    }

    public function show(Request $request, string $id): Response
    {
        $c = $this->customer($id);
        $uid = (int) $c['id'];
        $stats = Database::fetch(
            'SELECT COUNT(*) AS orders, COALESCE(SUM(CASE WHEN payment_status IN ' . ReportRepository::PAID . ' THEN grand_total - refunded_total ELSE 0 END), 0) AS spent,
                    COALESCE(SUM(payment_status IN ' . ReportRepository::PAID . '), 0) AS paid_orders, MIN(created_at) AS first_order_at
             FROM orders WHERE user_id = :u',
            ['u' => $uid]
        ) ?? [];
        return $this->adminView('customers/show', [
            'title' => $c['name'],
            'customer' => $c,
            'profile' => Database::fetch(
                'SELECT birthday, marketing_opt_in, notify_order_updates, notify_gift_reminders, notify_wishlist, personalization_enabled, deletion_requested_at
                 FROM customer_profiles WHERE user_id = :u',
                ['u' => $uid]
            ),
            'newsletter' => Database::fetch('SELECT status, consent_at, unsubscribed_at FROM newsletter_subscriptions WHERE email = :e', ['e' => $c['email']]),
            'addresses' => Database::fetchAll('SELECT * FROM addresses WHERE user_id = :u ORDER BY is_default DESC, id', ['u' => $uid]),
            'orders' => Gate::allows('orders.view') ? Database::fetchAll(
                'SELECT id, order_number, status, payment_status, payment_method, grand_total, refunded_total, created_at
                 FROM orders WHERE user_id = :u ORDER BY id DESC LIMIT 25',
                ['u' => $uid]
            ) : [],
            'tickets' => Database::fetchAll(
                'SELECT id, ticket_number, subject, status, priority, created_at FROM support_tickets WHERE user_id = :u ORDER BY id DESC LIMIT 15',
                ['u' => $uid]
            ),
            'wishlistCount' => (int) Database::fetchColumn(
                'SELECT COUNT(*) FROM wishlist_items wi JOIN wishlists w ON w.id = wi.wishlist_id WHERE w.user_id = :u',
                ['u' => $uid]
            ),
            'recipientCount' => (int) Database::fetchColumn('SELECT COUNT(*) FROM gift_recipients WHERE user_id = :u', ['u' => $uid]),
            'stats' => $stats,
            'canEdit' => Gate::allows('customers.edit'),
        ]);
    }

    public function update(Request $request, string $id): Response
    {
        Gate::authorize('customers.edit');
        $c = $this->customer($id);
        $uid = (int) $c['id'];
        $back = admin_url('customers/' . $uid);

        if ($request->str('action') === 'revoke') {
            Auth::revokeSessions($uid);
            AuditLogger::log('customer.sessions_revoked', 'user', $uid);
            flash('success', 'All sessions for this customer have been signed out.');
            return $this->redirect($back);
        }

        $data = $this->validate($request, [
            'name' => 'required|string|min:2|max:120',
            'phone' => 'nullable|phone',
            'status' => 'required|in:active,inactive',
        ]);
        if ($c['status'] === 'deleted') {
            flash('error', 'Deleted accounts cannot be edited.');
            return $this->redirect($back);
        }
        $new = [
            'name' => strip_tags($data['name']),
            'phone' => ($data['phone'] ?? '') !== '' ? preg_replace('/[\s-]/', '', $data['phone']) : null,
            'status' => $data['status'],
        ];
        $old = array_intersect_key($c, $new);
        Database::update('users', $new, ['id' => $uid, 'type' => 'customer']);
        if ($new['status'] === 'inactive' && $c['status'] !== 'inactive') {
            Auth::revokeSessions($uid);
        }
        AuditLogger::log('customer.updated', 'user', $uid, $old, $new);
        flash('success', 'Customer updated.' . ($new['status'] === 'inactive' && $c['status'] !== 'inactive' ? ' The account is deactivated and signed out.' : ''));
        return $this->redirect($back);
    }
}
