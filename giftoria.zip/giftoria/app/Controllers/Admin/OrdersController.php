<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Core\AuditLogger;
use App\Core\Auth;
use App\Core\Database;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Paginator;
use App\Core\Request;
use App\Core\Response;
use App\Core\View;
use App\Repositories\Admin\OrderAdminRepository;
use App\Repositories\Admin\ReportRepository;
use App\Services\OrderService;
use App\Services\OrderStateMachine;
use App\Services\PaymentService;
use App\Services\ShippingService;
use DomainException;
use RuntimeException;

final class OrdersController extends Controller
{
    private const SHIPPABLE = ['confirmed', 'processing', 'packed', 'shipped', 'out_for_delivery', 'delivered'];

    private OrderAdminRepository $repo;

    public function __construct()
    {
        $this->repo = new OrderAdminRepository();
    }

    private function order(string $id): array
    {
        $order = $this->repo->find((int) $id);
        if (!$order) {
            throw new HttpException(404, 'Order not found.');
        }
        return $order;
    }

    private static function canSeeCost(): bool
    {
        return Gate::any(['reports.view', 'products.manage']);
    }

    // ------------------------------------------------------------------
    // Listing & export
    // ------------------------------------------------------------------

    public function index(Request $request): Response
    {
        $filters = OrderAdminRepository::filters($request->query());
        $total = $this->repo->count($filters);
        $p = Paginator::fromRequest($total, 25);
        return $this->adminView('orders/index', [
            'title' => 'Orders',
            'filters' => $filters,
            'orders' => $this->repo->list($filters, $p->perPage, $p->offset),
            'total' => $total,
            'paginator' => $p,
        ]);
    }

    public function export(Request $request): Response
    {
        $filters = OrderAdminRepository::filters($request->query());
        $rows = array_map(static function (array $o) {
            $o['created_at'] = local_date($o['created_at'], 'Y-m-d H:i');
            return $o;
        }, $this->repo->exportRows($filters));
        AuditLogger::log('orders.export', 'order', null, null, ['filters' => array_filter($filters), 'rows' => count($rows)]);
        $csv = ReportRepository::csv([
            'Order number', 'Placed (NPT)', 'Customer', 'Email', 'Phone', 'Status', 'Payment status', 'Payment method',
            'Subtotal', 'Discount', 'Shipping', 'Gift wrap', 'Grand total', 'Refunded', 'Coupon', 'Source', 'District', 'Municipality',
        ], $rows);
        return Response::download($csv, 'orders-' . local_today() . '.csv');
    }

    // ------------------------------------------------------------------
    // Detail
    // ------------------------------------------------------------------

    public function show(Request $request, string $id): Response
    {
        $order = $this->order($id);
        $oid = (int) $order['id'];
        $next = OrderStateMachine::nextOrderStates($order['status']);
        // Only offer transitions this staff member may perform.
        $next = array_values(array_filter($next, static function (string $s) {
            if ($s === 'cancelled') {
                return Gate::allows('orders.cancel');
            }
            if (in_array($s, ['refund_pending', 'refunded'], true)) {
                return Gate::allows('refunds.manage');
            }
            return Gate::allows('orders.edit_status');
        }));
        return $this->adminView('orders/show', [
            'title' => 'Order ' . $order['order_number'],
            'order' => $order,
            'items' => (new OrderService())->items($oid),
            'addresses' => $this->repo->addresses($oid),
            'history' => $this->repo->history($oid),
            'notes' => $this->repo->notes($oid),
            'shipments' => $this->repo->shipments($oid),
            'refunds' => $this->repo->refunds($oid),
            'returns' => $this->repo->returns($oid),
            'payments' => Gate::allows('payments.view') ? $this->repo->payments($oid) : null,
            'refundable' => $this->repo->refundable($order),
            'nextStates' => $next,
            'canSeeCost' => self::canSeeCost(),
            'canShip' => Gate::allows('orders.edit_status') && in_array($order['status'], self::SHIPPABLE, true),
            'payUrl' => (Gate::allows('orders.create') && $order['status'] === 'pending_payment' && in_array($order['payment_method'], ['esewa', 'khalti'], true))
                ? url('/checkout/pay/' . $order['order_number'], ['t' => $order['access_token']])
                : null,
            'customer' => $order['user_id'] ? Database::fetch("SELECT id, name, email FROM users WHERE id = :id AND type = 'customer'", ['id' => (int) $order['user_id']]) : null,
        ]);
    }

    public function invoice(Request $request, string $id): Response
    {
        $order = $this->order($id);
        return Response::html(\App\Services\BillService::render($order, 'admin', ['back_url' => admin_url('orders/' . (int) $order['id'])]));
    }

    // ------------------------------------------------------------------
    // Writes
    // ------------------------------------------------------------------

    public function updateStatus(Request $request, string $id): Response
    {
        $order = $this->order($id);
        $to = $request->str('status');
        $note = mb_substr($request->str('note'), 0, 500);
        if (!in_array($to, OrderStateMachine::nextOrderStates($order['status']), true)) {
            flash('error', 'That status change is not allowed from "' . (OrderStateMachine::ORDER_LABELS[$order['status']] ?? $order['status']) . '".');
            return $this->redirect(admin_url('orders/' . (int) $order['id']));
        }
        Gate::authorize(match (true) {
            $to === 'cancelled' => 'orders.cancel',
            in_array($to, ['refund_pending', 'refunded'], true) => 'refunds.manage',
            default => 'orders.edit_status',
        });
        try {
            (new OrderService())->transition((int) $order['id'], $to, Auth::staffId(), $note !== '' ? $note : null);
            flash('success', 'Order moved to ' . (OrderStateMachine::ORDER_LABELS[$to] ?? $to) . '.');
        } catch (DomainException|RuntimeException $e) {
            flash('error', $e->getMessage());
        }
        return $this->redirect(admin_url('orders/' . (int) $order['id']));
    }

    public function addNote(Request $request, string $id): Response
    {
        $order = $this->order($id);
        $data = $this->validate($request, ['note' => 'required|string|max:2000']);
        $noteId = Database::insert('order_notes', [
            'order_id' => (int) $order['id'],
            'user_id' => Auth::staffId(),
            'note' => strip_tags($data['note']),
            'is_internal' => 1,
        ]);
        AuditLogger::log('order.note_added', 'order', (int) $order['id'], null, ['note_id' => $noteId]);
        flash('success', 'Internal note added.');
        return $this->redirect(admin_url('orders/' . (int) $order['id']) . '#notes');
    }

    public function saveShipment(Request $request, string $id): Response
    {
        $order = $this->order($id);
        $back = admin_url('orders/' . (int) $order['id']) . '#shipment';
        if (!in_array($order['status'], self::SHIPPABLE, true)) {
            flash('error', 'Shipments can only be recorded for confirmed orders that are not cancelled or refunded.');
            return $this->redirect($back);
        }
        $data = $this->validate($request, [
            'carrier' => 'nullable|string|max:80',
            'tracking_number' => 'nullable|string|max:100',
            'tracking_url' => 'nullable|url|max:255',
            'shipment_id' => 'nullable|integer',
        ]);
        if (($data['carrier'] ?? '') === '' && ($data['tracking_number'] ?? '') === '') {
            flash('error', 'Enter a carrier or a tracking number.');
            return $this->redirect($back);
        }
        $markShipped = $request->bool('mark_shipped');
        $values = [
            'carrier' => $data['carrier'] ?: null,
            'tracking_number' => $data['tracking_number'] ?: null,
            'tracking_url' => $data['tracking_url'] ?: null,
        ];
        $existing = null;
        if (!empty($data['shipment_id'])) {
            $existing = Database::fetch('SELECT * FROM shipments WHERE id = :id AND order_id = :o', ['id' => (int) $data['shipment_id'], 'o' => (int) $order['id']]);
        }
        if ($markShipped && OrderStateMachine::canOrder($order['status'], 'shipped')) {
            $values['shipped_at'] = Database::now();
        }
        if ($existing) {
            Database::update('shipments', $values, ['id' => (int) $existing['id']]);
            $shipmentId = (int) $existing['id'];
            AuditLogger::log('order.shipment_updated', 'order', (int) $order['id'], array_intersect_key($existing, $values), $values + ['shipment_id' => $shipmentId]);
        } else {
            $shipmentId = Database::insert('shipments', $values + ['order_id' => (int) $order['id'], 'created_by' => Auth::staffId()]);
            AuditLogger::log('order.shipment_added', 'order', (int) $order['id'], null, $values + ['shipment_id' => $shipmentId]);
        }

        if ($markShipped) {
            if (!OrderStateMachine::canOrder($order['status'], 'shipped')) {
                flash('warning', 'Shipment saved, but the order cannot move to Shipped from "' . (OrderStateMachine::ORDER_LABELS[$order['status']] ?? $order['status']) . '".');
                return $this->redirect($back);
            }
            try {
                (new OrderService())->transition((int) $order['id'], 'shipped', Auth::staffId(), 'Shipped' . ($values['carrier'] ? ' via ' . $values['carrier'] : ''));
                flash('success', 'Shipment saved and order marked as shipped. The customer has been notified.');
            } catch (DomainException|RuntimeException $e) {
                flash('error', 'Shipment saved, but the status change failed: ' . $e->getMessage());
            }
            return $this->redirect($back);
        }
        flash('success', 'Shipment details saved.');
        return $this->redirect($back);
    }

    public function recheckPayment(Request $request, string $id): Response
    {
        $order = $this->order($id);
        $back = admin_url('orders/' . (int) $order['id']);
        if (!in_array($order['payment_method'], ['esewa', 'khalti'], true)) {
            flash('info', 'Only eSewa and Khalti payments can be re-checked with the gateway.');
            return $this->redirect($back);
        }
        try {
            $paid = (new PaymentService())->reverifyOrder((int) $order['id']);
            AuditLogger::log('payment.reverify', 'order', (int) $order['id'], ['payment_status' => $order['payment_status']], ['paid' => $paid]);
            flash($paid ? 'success' : 'info', $paid
                ? 'The gateway confirmed payment. The order is marked paid.'
                : 'No completed payment was confirmed by the gateway for this order.');
        } catch (\Throwable $e) {
            flash('error', 'Could not reach the payment gateway: ' . $e->getMessage());
        }
        return $this->redirect($back);
    }

    // ------------------------------------------------------------------
    // Manual orders
    // ------------------------------------------------------------------

    private static function enabledMethods(): array
    {
        $out = [];
        foreach (OrderAdminRepository::PAYMENT_METHODS as $k => $label) {
            if (config("payments.$k.enabled")) {
                $out[$k] = $label;
            }
        }
        return $out;
    }

    public function create(Request $request): Response
    {
        return $this->adminView('orders/create', [
            'title' => 'Create manual order',
            'products' => $this->repo->productOptions(),
            'provinces' => config('nepal.provinces'),
            'methods' => self::enabledMethods(),
            'token' => (string) old('checkout_token', random_token()),
            'canSeeCost' => self::canSeeCost(),
        ]);
    }

    public function store(Request $request): Response
    {
        $data = $this->validate($request, [
            'customer_name' => 'required|string|max:120',
            'email' => 'required|email',
            'phone' => 'required|phone',
            'payment_method' => 'required|in:' . implode(',', array_keys(self::enabledMethods()) ?: ['none']),
            'full_name' => 'nullable|string|max:120',
            'address_phone' => 'nullable|phone',
            'province' => 'required|string|max:60',
            'district' => 'required|string|max:60',
            'municipality' => 'required|string|max:100',
            'ward' => 'nullable|string|max:10',
            'street' => 'nullable|string|max:190',
            'landmark' => 'nullable|string|max:190',
            'coupon_code' => 'nullable|alpha_dash|max:40',
            'gift_message' => 'nullable|string|max:500',
            'customer_note' => 'nullable|string|max:500',
            'requested_delivery_date' => 'nullable|date',
            'checkout_token' => 'required|regex:/^[a-f0-9]{64}$/',
        ], ['address_phone' => 'Recipient phone']);

        $old = $request->all();
        unset($old['_token']);
        $fail = function (string $message) use ($old): Response {
            flash('error', $message);
            flash('old', $old);
            return $this->redirect(admin_url('orders/create'));
        };

        if (!ShippingService::isValidDistrict($data['district']) || ShippingService::provinceOf($data['district']) !== $data['province']) {
            return $fail('Choose a valid province and district.');
        }
        if (!empty($data['requested_delivery_date']) && $data['requested_delivery_date'] < local_today()) {
            return $fail('The requested delivery date cannot be in the past.');
        }

        $picks = [];
        foreach ($request->arr('items') as $item) {
            if (!is_array($item)) {
                continue;
            }
            $ref = (string) ($item['product'] ?? '');
            if (!preg_match('/^(\d+):(\d+)$/', $ref, $m)) {
                continue;
            }
            $picks[] = [
                'product_id' => (int) $m[1],
                'variant_id' => (int) $m[2],
                'quantity' => is_numeric($item['quantity'] ?? null) ? (int) $item['quantity'] : 0,
                'personalization' => is_scalar($item['personalization'] ?? null) ? mb_substr((string) $item['personalization'], 0, 255) : '',
            ];
        }

        try {
            $lines = $this->repo->buildLines($picks);
            $email = mb_strtolower($data['email']);
            $userId = Database::fetchColumn(
                "SELECT id FROM users WHERE email = :e AND type = 'customer' AND status <> 'deleted'",
                ['e' => $email]
            );
            $order = (new OrderService())->place([
                'customer_name' => strip_tags($data['customer_name']),
                'email' => $email,
                'phone' => $data['phone'],
                'payment_method' => $data['payment_method'],
                'shipping' => [
                    'full_name' => strip_tags($data['full_name'] ?: $data['customer_name']),
                    'phone' => $data['address_phone'] ?: $data['phone'],
                    'province' => $data['province'],
                    'district' => $data['district'],
                    'municipality' => strip_tags($data['municipality']),
                    'ward' => $data['ward'] ?? '',
                    'street' => strip_tags((string) ($data['street'] ?? '')),
                    'landmark' => strip_tags((string) ($data['landmark'] ?? '')),
                ],
                'billing' => null,
                'gift_wrap' => $request->bool('gift_wrap'),
                'gift_message' => strip_tags((string) ($data['gift_message'] ?? '')),
                'customer_note' => ($data['customer_note'] ?? '') !== '' ? strip_tags($data['customer_note']) : null,
                'requested_delivery_date' => $data['requested_delivery_date'] ?? null,
                'coupon_code' => ($data['coupon_code'] ?? '') !== '' ? $data['coupon_code'] : null,
                'checkout_token' => $data['checkout_token'],
                'user_id' => $userId ? (int) $userId : null,
                'source' => 'manual',
                'created_by' => Auth::staffId(),
            ], $lines);
        } catch (DomainException|RuntimeException $e) {
            return $fail($e->getMessage());
        }

        AuditLogger::log('order.manual_create', 'order', (int) $order['id'], null, [
            'order_number' => $order['order_number'],
            'payment_method' => $order['payment_method'],
            'grand_total' => $order['grand_total'],
            'items' => count($lines),
        ]);
        if (in_array($order['payment_method'], ['esewa', 'khalti'], true)) {
            flash('success', 'Order ' . $order['order_number'] . ' created. Share the payment link below with the customer; stock is held until the payment window expires.');
        } else {
            flash('success', 'Order ' . $order['order_number'] . ' created as cash on delivery and confirmed.');
        }
        return $this->redirect(admin_url('orders/' . (int) $order['id']));
    }
}
