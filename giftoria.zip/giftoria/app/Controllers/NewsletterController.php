<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Services\NewsletterService;

final class NewsletterController extends Controller
{
    public function subscribe(Request $request): Response
    {
        RateLimiter::enforce('newsletter:' . $request->ip(), 10, 3600);
        $data = $this->validate($request, ['email' => 'required|email']);
        NewsletterService::subscribe((string) $data['email'], substr(preg_replace('/[^a-z_]/', '', $request->str('source', 'site')) ?: 'site', 0, 40), Auth::customerId());
        $msg = 'Thanks for subscribing! You can unsubscribe at any time from any email.';
        if ($request->wantsJson()) {
            return $this->json(['message' => $msg]);
        }
        flash('success', $msg);
        return $this->back();
    }

    public function unsubscribe(Request $request, string $token): Response
    {
        $email = preg_match('/^[a-f0-9]{64}$/', $token) ? NewsletterService::unsubscribeByToken($token) : null;
        return $this->view('storefront/pages/unsubscribed', ['title' => 'Unsubscribed', 'noindex' => true, 'email' => $email]);
    }
}
