<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Database;
use App\Core\HttpException;
use App\Core\Logger;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Services\PaymentService;
use App\Services\Payments\EsewaGateway;
use App\Services\Payments\SimulatorHttpClient;
use RuntimeException;

/**
 * Gateway return URLs. These pages only *trigger* server-side verification; reaching them never
 * marks an order paid on its own.
 */
final class PaymentController extends Controller
{
    private function orderRedirect(int $orderId, string $flashType, string $message): Response
    {
        $order = Database::fetch('SELECT order_number, access_token FROM orders WHERE id = :id', ['id' => $orderId]);
        flash($flashType, $message);
        return $this->redirect('/order/' . $order['order_number'] . '?t=' . $order['access_token']);
    }

    private function message(string $status): array
    {
        return match ($status) {
            'paid' => ['success', 'Payment verified — thank you! Your order is confirmed.'],
            'pending' => ['info', 'Your payment is still being processed by the provider. We will confirm it shortly.'],
            'cancelled' => ['warning', 'The payment was cancelled. You can try again below.'],
            'expired' => ['warning', 'The payment session expired. You can try again below.'],
            default => ['error', 'We could not verify this payment. If money was deducted, it will be reconciled automatically — or contact us.'],
        };
    }

    public function esewaSuccess(Request $request, string $ref): Response
    {
        RateLimiter::enforce('pay-cb:' . $request->ip(), 60, 600);
        try {
            $r = (new PaymentService())->handleEsewaSuccess($ref, (string) $request->query('data', ''));
        } catch (RuntimeException $e) {
            Logger::warning('eSewa success callback rejected', ['ref' => $ref, 'error' => $e->getMessage()], 'payments');
            throw new HttpException(404);
        }
        [$type, $msg] = $this->message($r['status']);
        return $this->orderRedirect((int) $r['payment']['order_id'], $type, $msg);
    }

    public function esewaFailure(Request $request, string $ref): Response
    {
        RateLimiter::enforce('pay-cb:' . $request->ip(), 60, 600);
        try {
            $r = (new PaymentService())->handleEsewaFailure($ref);
        } catch (RuntimeException $e) {
            throw new HttpException(404);
        }
        [$type, $msg] = $r['status'] === 'paid' ? $this->message('paid') : ['warning', 'The eSewa payment was not completed. You can retry without placing a new order.'];
        return $this->orderRedirect((int) $r['payment']['order_id'], $type, $msg);
    }

    public function khaltiReturn(Request $request): Response
    {
        RateLimiter::enforce('pay-cb:' . $request->ip(), 60, 600);
        try {
            $r = (new PaymentService())->handleKhaltiReturn($request->query());
        } catch (RuntimeException $e) {
            Logger::warning('Khalti return rejected', ['error' => $e->getMessage()], 'payments');
            throw new HttpException(404);
        }
        [$type, $msg] = $this->message($r['status']);
        return $this->orderRedirect((int) $r['payment']['order_id'], $type, $msg);
    }

    /**
     * Local payment simulator (PAYMENT_SIMULATOR=true, never in production). Mimics the gateway's
     * hosted page; verification still runs through the gateway classes via SimulatorHttpClient.
     */
    public function simulator(Request $request, string $gateway, string $ref): Response
    {
        if (!config('payments.simulator')) {
            throw new HttpException(404);
        }
        $payment = $gateway === 'esewa'
            ? Database::fetch("SELECT * FROM payments WHERE attempt_ref = :r AND gateway = 'esewa'", ['r' => $ref])
            : Database::fetch("SELECT * FROM payments WHERE gateway_ref = :r AND gateway = 'khalti'", ['r' => $ref]);
        if (!$payment) {
            throw new HttpException(404);
        }
        if ($request->method === 'GET' || !$request->has('outcome')) {
            return $this->view('storefront/checkout/simulator', [
                'title' => 'Payment simulator', 'noindex' => true, 'gateway' => $gateway, 'payment' => $payment, 'ref' => $ref,
            ], 'layouts/blank');
        }
        $outcome = $request->str('outcome');
        $txn = strtoupper(substr(bin2hex(random_bytes(5)), 0, 10));
        if ($gateway === 'esewa') {
            $status = match ($outcome) { 'success' => 'COMPLETE', 'pending' => 'PENDING', default => 'CANCELED' };
            $amount = $request->str('tamper') === '1' ? (float) $payment['amount'] - 1 : (float) $payment['amount'];
            SimulatorHttpClient::store($ref, ['status' => $status, 'total_amount' => $amount, 'ref_id' => $txn]);
            if ($outcome !== 'success') {
                return $this->redirect('/payment/esewa/failure/' . $ref);
            }
            $data = [
                'transaction_code' => $txn, 'status' => 'COMPLETE', 'total_amount' => EsewaGateway::amount((float) $payment['amount']),
                'transaction_uuid' => $ref, 'product_code' => config('payments.esewa.product_code'),
                'signed_field_names' => 'transaction_code,status,total_amount,transaction_uuid,product_code,signed_field_names',
            ];
            $msg = [];
            foreach (explode(',', $data['signed_field_names']) as $f) {
                $msg[] = $f . '=' . $data[$f];
            }
            $data['signature'] = EsewaGateway::sign(implode(',', $msg), (string) config('payments.esewa.secret_key'));
            return $this->redirect('/payment/esewa/success/' . $ref . '?data=' . rawurlencode(base64_encode((string) json_encode($data))));
        }
        $state = SimulatorHttpClient::load($ref) ?? [];
        $status = match ($outcome) { 'success' => 'Completed', 'pending' => 'Pending', default => 'User canceled' };
        $state['status'] = $status;
        $state['transaction_id'] = $outcome === 'success' ? $txn : null;
        if ($request->str('tamper') === '1') {
            $state['total_amount'] = (int) $state['total_amount'] - 100;
        }
        SimulatorHttpClient::store($ref, $state);
        return $this->redirect('/payment/khalti/return?' . http_build_query([
            'pidx' => $ref, 'status' => $status, 'transaction_id' => $state['transaction_id'] ?? '',
            'purchase_order_id' => $payment['attempt_ref'], 'total_amount' => $state['total_amount'] ?? 0,
        ]));
    }
}
