<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\Logger;
use App\Services\Payments\CurlHttpClient;
use App\Services\Payments\EsewaGateway;
use App\Services\Payments\HttpClient;
use App\Services\Payments\KhaltiGateway;
use App\Services\Payments\SimulatorHttpClient;
use App\Services\Payments\VerificationResult;
use RuntimeException;

/**
 * Payment attempts, verification and idempotent state changes.
 *
 * Rules:
 *  - Reaching a success URL never marks anything paid. Only a server-side gateway verification
 *    (eSewa Status Check / Khalti Lookup) reporting success for the expected amount and reference does.
 *  - applyVerification() locks the payment row and the order row; repeated callbacks for the same
 *    attempt are no-ops, and (gateway, gateway_txn_id) is UNIQUE so a transaction applies once.
 *  - Stock is never touched by payment callbacks (it was reserved when the order was placed).
 */
final class PaymentService
{
    private HttpClient $http;

    public function __construct(?HttpClient $http = null)
    {
        $this->http = $http ?? (config('payments.simulator') ? new SimulatorHttpClient() : new CurlHttpClient());
    }

    public function esewa(): EsewaGateway
    {
        return new EsewaGateway(config('payments.esewa'), $this->http);
    }

    public function khalti(): KhaltiGateway
    {
        return new KhaltiGateway(config('payments.khalti'), $this->http);
    }

    public function findByRef(string $ref): ?array
    {
        return Database::fetch('SELECT * FROM payments WHERE attempt_ref = :r', ['r' => $ref]);
    }

    public function findByGatewayRef(string $gateway, string $ref): ?array
    {
        return Database::fetch('SELECT * FROM payments WHERE gateway = :g AND gateway_ref = :r', ['g' => $gateway, 'r' => $ref]);
    }

    public function event(int $paymentId, string $type, array $payload = []): void
    {
        Database::insert('payment_events', [
            'payment_id' => $paymentId,
            'event_type' => mb_substr($type, 0, 40),
            'payload_json' => $payload ? json_encode(Logger::redact($payload), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null,
        ]);
    }

    /** Whether a new payment attempt may be started for this order. */
    public function canPay(array $order): bool
    {
        return $order['status'] === 'pending_payment'
            && in_array($order['payment_status'], ['initiated', 'pending', 'failed', 'cancelled'], true)
            && ($order['expires_at'] === null || $order['expires_at'] > gmdate('Y-m-d H:i:s'))
            && in_array($order['payment_method'], ['esewa', 'khalti'], true);
    }

    /**
     * Creates a new attempt and returns how to send the customer to the gateway.
     * @return array{type: 'form', action: string, fields: array}|array{type: 'redirect', url: string}
     */
    public function start(array $order, ?string $gateway = null): array
    {
        $gateway ??= $order['payment_method'];
        if (!in_array($gateway, ['esewa', 'khalti'], true) || !config("payments.$gateway.enabled")) {
            throw new RuntimeException('This payment method is not available.');
        }
        if (!$this->canPay($order)) {
            throw new RuntimeException('This order can no longer be paid online.');
        }
        $attempts = (int) Database::fetchColumn('SELECT COUNT(*) FROM payments WHERE order_id = :o', ['o' => (int) $order['id']]);
        if ($attempts >= 10) {
            throw new RuntimeException('Too many payment attempts for this order. Please contact support.');
        }
        // Switching method on retry is allowed (e.g. eSewa failed, try Khalti).
        if ($gateway !== $order['payment_method']) {
            Database::update('orders', ['payment_method' => $gateway], ['id' => (int) $order['id']]);
            $order['payment_method'] = $gateway;
        }

        $ref = $order['order_number'] . '-' . ($attempts + 1); // alphanumeric + hyphens (eSewa requirement)
        $paymentId = Database::insert('payments', [
            'order_id' => (int) $order['id'],
            'gateway' => $gateway,
            'attempt_ref' => $ref,
            'amount' => $order['grand_total'],
            'status' => 'initiated',
        ]);
        $payment = Database::fetch('SELECT * FROM payments WHERE id = :id', ['id' => $paymentId]);
        $this->event($paymentId, 'initiated', ['amount' => $order['grand_total'], 'gateway' => $gateway]);
        if ($order['payment_status'] !== 'initiated') {
            (new OrderService())->setPaymentStatus((int) $order['id'], 'initiated', 'Payment retry started');
        }

        if ($gateway === 'esewa') {
            $fields = $this->esewa()->formFields(
                $payment,
                $order,
                url('/payment/esewa/success/' . $ref),
                url('/payment/esewa/failure/' . $ref)
            );
            $action = config('payments.simulator') ? url('/payment/simulator/esewa/' . $ref) : $this->esewa()->formUrl();
            return ['type' => 'form', 'action' => $action, 'fields' => $fields];
        }

        try {
            $res = $this->khalti()->initiate($payment, $order, url('/payment/khalti/return'));
        } catch (\Throwable $e) {
            Database::update('payments', ['status' => 'failed', 'gateway_status' => 'INITIATE_FAILED'], ['id' => $paymentId]);
            $this->event($paymentId, 'initiate_failed', ['error' => $e->getMessage()]);
            throw new RuntimeException('Khalti is unavailable right now. Please try again or choose another method.');
        }
        Database::update('payments', ['gateway_ref' => $res['pidx'], 'status' => 'pending'], ['id' => $paymentId]);
        $this->event($paymentId, 'gateway_initiated', ['pidx' => $res['pidx'], 'expires_at' => $res['expires_at']]);
        return ['type' => 'redirect', 'url' => $res['payment_url']];
    }

    public function verify(array $payment): VerificationResult
    {
        return match ($payment['gateway']) {
            'esewa' => $this->esewa()->verify($payment),
            'khalti' => $this->khalti()->verify($payment),
            default => new VerificationResult('error', null, null, 'UNSUPPORTED'),
        };
    }

    /**
     * Applies a verification result idempotently.
     * @return string resulting payment status
     */
    public function applyVerification(int $paymentId, VerificationResult $result, string $source): string
    {
        $outcome = Database::transaction(function () use ($paymentId, $result, $source) {
            $payment = Database::fetch('SELECT * FROM payments WHERE id = :id FOR UPDATE', ['id' => $paymentId]);
            if (!$payment) {
                throw new RuntimeException('Payment not found.');
            }
            $this->event($paymentId, 'verify:' . $source, ['result' => $result->status, 'gateway_status' => $result->gatewayStatus, 'raw' => $result->raw, 'message' => $result->message]);

            if ($payment['status'] === 'paid' && $result->status === 'paid') {
                $this->event($paymentId, 'duplicate_ignored', ['source' => $source]);
                return ['status' => 'paid', 'newly_paid' => false, 'order_id' => (int) $payment['order_id']];
            }
            if ($result->status === 'error') {
                return ['status' => $payment['status'], 'newly_paid' => false, 'order_id' => (int) $payment['order_id']];
            }

            if ($result->isPaid()) {
                // Has this gateway transaction already been applied to some other attempt?
                if ($result->gatewayTxnId) {
                    $dupe = Database::fetchColumn(
                        'SELECT id FROM payments WHERE gateway = :g AND gateway_txn_id = :t AND id <> :id',
                        ['g' => $payment['gateway'], 't' => $result->gatewayTxnId, 'id' => $paymentId]
                    );
                    if ($dupe) {
                        $this->event($paymentId, 'duplicate_txn_rejected', ['txn' => $result->gatewayTxnId, 'other_payment' => $dupe]);
                        return ['status' => $payment['status'], 'newly_paid' => false, 'order_id' => (int) $payment['order_id']];
                    }
                }
                OrderStateMachine::assertPayment($payment['status'], 'paid');
                Database::update('payments', [
                    'status' => 'paid',
                    'gateway_txn_id' => $result->gatewayTxnId,
                    'gateway_status' => $result->gatewayStatus,
                    'verified_at' => Database::now(),
                ], ['id' => $paymentId]);

                $order = Database::fetch('SELECT * FROM orders WHERE id = :id FOR UPDATE', ['id' => (int) $payment['order_id']]);
                $orders = new OrderService();
                if ($order['payment_status'] === 'paid') {
                    // A different attempt already paid this order: money was taken twice -> refund needed.
                    $this->event($paymentId, 'double_payment', ['order' => $order['order_number']]);
                    Database::insert('refunds', [
                        'order_id' => (int) $order['id'], 'payment_id' => $paymentId, 'amount' => $payment['amount'],
                        'reason' => 'Duplicate payment for an already-paid order', 'status' => 'requested',
                    ]);
                    return ['status' => 'paid', 'newly_paid' => false, 'order_id' => (int) $order['id']];
                }

                $orders->setPaymentStatus((int) $order['id'], 'paid', 'Verified via ' . $payment['gateway'] . ' (' . $source . ')');
                Database::update('orders', ['paid_at' => Database::now(), 'expires_at' => null], ['id' => (int) $order['id']]);
                if ($order['status'] === 'pending_payment') {
                    $orders->transition((int) $order['id'], 'confirmed', null, 'Payment verified');
                } elseif ($order['status'] === 'cancelled') {
                    // Late success after expiry: try to re-reserve stock and revive the order.
                    if ($orders->reReserveStock($order)) {
                        Database::update('orders', ['status' => 'confirmed', 'cancelled_at' => null], ['id' => (int) $order['id']]);
                        $orders->history((int) $order['id'], 'status', 'cancelled', 'confirmed', 'Late payment verified; order reinstated');
                    } else {
                        $orders->transition((int) $order['id'], 'refund_pending', null, 'Late payment but stock unavailable');
                        $orders->setPaymentStatus((int) $order['id'], 'refund_pending', 'Late payment, stock unavailable');
                        Database::insert('refunds', [
                            'order_id' => (int) $order['id'], 'payment_id' => $paymentId, 'amount' => $payment['amount'],
                            'reason' => 'Paid after expiry; items no longer in stock', 'status' => 'requested',
                        ]);
                    }
                }
                return ['status' => 'paid', 'newly_paid' => true, 'order_id' => (int) $order['id']];
            }

            // Non-paid outcomes
            $target = in_array($result->status, ['pending', 'failed', 'cancelled', 'expired', 'refunded', 'partially_refunded'], true) ? $result->status : $payment['status'];
            if ($payment['status'] !== $target && OrderStateMachine::canPayment($payment['status'], $target)) {
                Database::update('payments', ['status' => $target, 'gateway_status' => $result->gatewayStatus], ['id' => $paymentId]);
                $order = Database::fetch('SELECT * FROM orders WHERE id = :id FOR UPDATE', ['id' => (int) $payment['order_id']]);
                if ($order['status'] === 'pending_payment' && in_array($target, ['pending', 'failed', 'cancelled'], true)
                    && OrderStateMachine::canPayment($order['payment_status'], $target)) {
                    (new OrderService())->setPaymentStatus((int) $order['id'], $target, ucfirst($target) . ' at ' . $payment['gateway']);
                }
            }
            return ['status' => $target, 'newly_paid' => false, 'order_id' => (int) $payment['order_id']];
        });

        if ($outcome['newly_paid']) {
            $order = (new OrderService())->find($outcome['order_id']);
            AuditLogger::log('payment.verified', 'order', (int) $order['id'], null, ['payment_id' => $paymentId, 'source' => $source]);
            $mail = new MailService();
            $mail->orderEmail('order_confirmation', $order);
            $mail->orderEmail('payment_confirmation', $order);
        } elseif (in_array($outcome['status'], ['failed', 'cancelled'], true)) {
            $order = (new OrderService())->find($outcome['order_id']);
            if ($order && $order['status'] === 'pending_payment') {
                (new MailService())->orderEmail('payment_failed', $order);
            }
        }
        return $outcome['status'];
    }

    /** eSewa success redirect: decode/verify signature, then confirm with the Status Check API. */
    public function handleEsewaSuccess(string $ref, string $data): array
    {
        $payment = $this->findByRef($ref);
        if (!$payment || $payment['gateway'] !== 'esewa') {
            throw new RuntimeException('Unknown payment reference.');
        }
        $decoded = $this->esewa()->decodeCallback($data);
        $this->event((int) $payment['id'], 'callback:success', ['signature_valid' => $decoded['signature_valid'], 'data' => array_diff_key($decoded['data'], ['signature' => 1])]);
        if (($decoded['data']['transaction_uuid'] ?? $ref) !== $ref) {
            $this->event((int) $payment['id'], 'callback_ref_mismatch', ['got' => $decoded['data']['transaction_uuid'] ?? null]);
        }
        $status = $this->applyVerification((int) $payment['id'], $this->esewa()->verify($payment), 'esewa_return');
        return ['payment' => $this->findByRef($ref), 'status' => $status];
    }

    public function handleEsewaFailure(string $ref): array
    {
        $payment = $this->findByRef($ref);
        if (!$payment || $payment['gateway'] !== 'esewa') {
            throw new RuntimeException('Unknown payment reference.');
        }
        $this->event((int) $payment['id'], 'callback:failure');
        // eSewa also sends pending payments to failure_url, so ask the gateway instead of assuming.
        $result = $this->esewa()->verify($payment);
        $status = $this->applyVerification((int) $payment['id'], $result, 'esewa_failure');
        return ['payment' => $this->findByRef($ref), 'status' => $status];
    }

    /** Khalti return: query params are untrusted; verification uses the lookup API. */
    public function handleKhaltiReturn(array $query): array
    {
        $pidx = (string) ($query['pidx'] ?? '');
        $payment = $pidx !== '' ? $this->findByGatewayRef('khalti', $pidx) : null;
        if (!$payment) {
            throw new RuntimeException('Unknown payment reference.');
        }
        if (isset($query['purchase_order_id']) && $query['purchase_order_id'] !== $payment['attempt_ref']) {
            $this->event((int) $payment['id'], 'callback_ref_mismatch', ['got' => $query['purchase_order_id']]);
            throw new RuntimeException('Payment reference mismatch.');
        }
        $this->event((int) $payment['id'], 'callback:return', array_intersect_key($query, array_flip(['pidx', 'status', 'transaction_id', 'amount', 'total_amount', 'purchase_order_id'])));
        $status = $this->applyVerification((int) $payment['id'], $this->khalti()->verify($payment), 'khalti_return');
        return ['payment' => Database::fetch('SELECT * FROM payments WHERE id = :id', ['id' => (int) $payment['id']]), 'status' => $status];
    }

    /** Re-checks every open attempt of an order. Returns true if the order is now paid. */
    public function reverifyOrder(int $orderId): bool
    {
        $attempts = Database::fetchAll(
            "SELECT * FROM payments WHERE order_id = :o AND gateway IN ('esewa','khalti') AND status IN ('initiated','pending','failed','cancelled') ORDER BY id DESC LIMIT 5",
            ['o' => $orderId]
        );
        foreach ($attempts as $p) {
            if ($p['gateway'] === 'khalti' && empty($p['gateway_ref'])) {
                continue;
            }
            if ($this->applyVerification((int) $p['id'], $this->verify($p), 'reverify') === 'paid') {
                return true;
            }
        }
        return Database::fetchColumn('SELECT payment_status FROM orders WHERE id = :id', ['id' => $orderId]) === 'paid';
    }
}
