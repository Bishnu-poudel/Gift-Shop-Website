<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Database;
use App\Repositories\ProductRepository;
use App\Repositories\TaxonomyRepository;
use App\Services\Recommendation\Vocabulary;

/**
 * Storefront search: understands recipient/occasion/interest/price phrases, corrects typos,
 * merges explicit URL filters (which always win) and relaxes gracefully when nothing matches.
 */
final class SearchService
{
    public const FILTER_KEYS = ['q', 'category', 'recipient', 'occasion', 'interest', 'age', 'min_price', 'max_price', 'rating', 'in_stock', 'personalized', 'gift_wrap', 'maker', 'sort'];

    private ProductRepository $products;
    private TaxonomyRepository $tax;

    public function __construct(?ProductRepository $products = null, ?TaxonomyRepository $tax = null)
    {
        $this->products = $products ?? new ProductRepository();
        $this->tax = $tax ?? new TaxonomyRepository();
    }

    /** Clean the raw query-string filters (unknown values are dropped). */
    public function cleanFilters(array $in): array
    {
        $f = [];
        foreach (self::FILTER_KEYS as $k) {
            if (!isset($in[$k]) || $in[$k] === '' || $in[$k] === []) {
                continue;
            }
            $f[$k] = $in[$k];
        }
        $f['q'] = isset($f['q']) ? mb_substr(trim((string) $f['q']), 0, 120) : '';
        foreach (['min_price', 'max_price', 'rating'] as $k) {
            if (isset($f[$k]) && !is_numeric($f[$k])) {
                unset($f[$k]);
            }
        }
        if (isset($f['interest'])) {
            $f['interest'] = array_values(array_filter((array) $f['interest'], 'is_string'));
        }
        foreach (['category', 'recipient', 'occasion', 'age', 'maker'] as $k) {
            if (isset($f[$k]) && (!is_string($f[$k]) || !preg_match('/^[a-z0-9-]+$/', $f[$k]))) {
                unset($f[$k]);
            }
        }
        if (isset($f['sort']) && !isset(ProductRepository::SORTS[$f['sort']])) {
            unset($f['sort']);
        }
        return $f;
    }

    public function search(array $rawFilters, int $page = 1, int $perPage = 24): array
    {
        $f = $this->cleanFilters($rawFilters);
        $q = $f['q'];
        $parsed = $q !== '' ? Vocabulary::parser()->parse($q) : null;

        $repoFilters = [
            'category' => $f['category'] ?? ($parsed['categories'][0] ?? null),
            'recipient' => $f['recipient'] ?? $parsed['recipient'] ?? null,
            'occasion' => $f['occasion'] ?? $parsed['occasion'] ?? null,
            'interests' => $f['interest'] ?? ($parsed['interests'] ?? []),
            'prefs' => $parsed['prefs'] ?? [],
            'min_price' => $f['min_price'] ?? $parsed['min_price'] ?? null,
            'max_price' => $f['max_price'] ?? $parsed['max_price'] ?? null,
            'rating' => $f['rating'] ?? null,
            'in_stock' => !empty($f['in_stock']),
            'personalizable' => !empty($f['personalized']) || in_array('personalized', $parsed['flags'] ?? [], true),
            'gift_wrap' => !empty($f['gift_wrap']),
            'maker' => $f['maker'] ?? null,
            'q' => $parsed ? implode(' ', $parsed['keywords']) : '',
        ];
        if (in_array('personalized', $repoFilters['prefs'], true)) {
            // "personalized" is better expressed by the product flag than by a tag.
            $repoFilters['prefs'] = array_values(array_diff($repoFilters['prefs'], ['personalized']));
            $repoFilters['personalizable'] = true;
        }
        if (!empty($f['age']) && ($range = $this->tax->ageRange($f['age']))) {
            $repoFilters['age_min_months'] = (int) $range['min_months'];
            $repoFilters['age_max_months'] = (int) $range['max_months'];
        } elseif ($parsed && $parsed['age_min_months'] !== null) {
            $repoFilters['age_min_months'] = $parsed['age_min_months'];
            $repoFilters['age_max_months'] = $parsed['age_max_months'];
        }

        $sort = $f['sort'] ?? ($q !== '' ? 'relevance' : 'popular');
        $notice = null;
        $result = $this->products->search($repoFilters, $sort, $page, $perPage);

        // Graceful relaxation, explained to the shopper.
        if ($result['total'] === 0 && $repoFilters['q'] !== '' && ($repoFilters['recipient'] || $repoFilters['occasion'] || $repoFilters['interests'] || $repoFilters['category'])) {
            $dropped = $repoFilters['q'];
            $repoFilters['q'] = '';
            $result = $this->products->search($repoFilters, $sort === 'relevance' ? 'popular' : $sort, $page, $perPage);
            if ($result['total'] > 0) {
                $notice = 'No exact matches for “' . $dropped . '”, so here are the closest gifts.';
            }
        }
        if ($result['total'] === 0 && count($repoFilters['interests']) > 0 && empty($f['interest'])) {
            $repoFilters['interests'] = [];
            $result = $this->products->search($repoFilters, 'popular', $page, $perPage);
            if ($result['total'] > 0) {
                $notice = 'We broadened your search to show more gift ideas.';
            }
        }

        $didYouMean = null;
        if ($parsed && $parsed['corrections']) {
            $didYouMean = str_ireplace(array_keys($parsed['corrections']), array_values($parsed['corrections']), mb_strtolower($q));
        }
        $suggestions = [];
        if ($result['total'] === 0) {
            $suggestions = [
                'phrases' => $q !== '' ? Vocabulary::parser()->suggestPhrases($q) : [],
                'categories' => array_slice(array_filter($this->tax->categories(), static fn ($c) => $c['parent_id'] === null), 0, 6),
                'popular' => $this->products->flagged('bestseller', 4),
            ];
        }

        Analytics::increment('searches');
        return [
            'items' => $result['items'],
            'total' => $result['total'],
            'filters' => $f,
            'applied' => $repoFilters,
            'parsed' => $parsed,
            'sort' => $sort,
            'notice' => $notice,
            'did_you_mean' => $didYouMean,
            'suggestions' => $suggestions,
        ];
    }

    /** Live search dropdown: products + taxonomy shortcuts. */
    public function suggest(string $q): array
    {
        $q = trim(mb_substr($q, 0, 60));
        if (mb_strlen($q) < 2) {
            return ['products' => [], 'shortcuts' => []];
        }
        return Cache::remember('catalog', 'suggest:' . mb_strtolower($q), 120, function () use ($q) {
            $parser = Vocabulary::parser();
            $parsed = $parser->parse($q);
            $shortcuts = [];
            $labels = [];
            foreach (['recipients' => 'recipient', 'occasions' => 'occasion', 'interests' => 'interest'] as $t => $k) {
                foreach ($this->tax->all($t) as $row) {
                    $labels[$k][$row['slug']] = $row['name'];
                }
            }
            if ($parsed['recipient']) {
                $shortcuts[] = ['label' => 'Gifts for ' . ($labels['recipient'][$parsed['recipient']] ?? $parsed['recipient']), 'url' => url('/gifts/for/' . $parsed['recipient'])];
            }
            if ($parsed['occasion']) {
                $shortcuts[] = ['label' => ($labels['occasion'][$parsed['occasion']] ?? $parsed['occasion']) . ' gifts', 'url' => url('/gifts/occasion/' . $parsed['occasion'])];
            }
            foreach (array_slice($parsed['interests'], 0, 2) as $i) {
                $shortcuts[] = ['label' => ($labels['interest'][$i] ?? $i), 'url' => url('/gifts/interest/' . $i)];
            }
            $params = ['a' => '%' . $q . '%', 'b' => $q . '%'];
            $products = Database::fetchAll(
                "SELECT p.name, p.slug, COALESCE(p.sale_price, p.price) AS price,
                        (SELECT pi.path FROM product_images pi WHERE pi.product_id = p.id ORDER BY pi.sort_order, pi.id LIMIT 1) AS image
                 FROM products p WHERE p.status = 'active' AND p.name LIKE :a
                 ORDER BY (p.name LIKE :b) DESC, p.sales_count DESC LIMIT 6",
                $params
            );
            if (!$products && ($parsed['recipient'] || $parsed['interests'] || $parsed['occasion'])) {
                $r = $this->search(['q' => $q], 1, 6);
                $products = array_map(static fn ($p) => ['name' => $p['name'], 'slug' => $p['slug'], 'price' => $p['effective_price'], 'image' => $p['image']], $r['items']);
            }
            return [
                'products' => array_map(static fn ($p) => [
                    'name' => $p['name'], 'url' => url('/product/' . $p['slug']), 'price' => money($p['price']), 'image' => image_url($p['image']),
                ], $products),
                'shortcuts' => $shortcuts,
                'corrections' => $parsed['corrections'],
            ];
        });
    }
}
