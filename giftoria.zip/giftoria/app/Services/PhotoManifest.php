<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Database;

/**
 * Applies the CC0 demo photography listed in database/seeders/photos.json (created by
 * bin/fetch-photos.php) to catalogue rows. Rows only change when the current image is a generated
 * placeholder (SVG) or a previous demo photo — images uploaded by staff are never overwritten.
 */
final class PhotoManifest
{
    private static ?array $manifest = null;

    public static function all(): array
    {
        if (self::$manifest === null) {
            $file = BASE_PATH . '/database/seeders/photos.json';
            self::$manifest = is_file($file) ? (json_decode((string) file_get_contents($file), true) ?: []) : [];
        }
        return self::$manifest;
    }

    /** Relative public path for a manifest key, or null when no photo is available. */
    public static function path(string $key): ?string
    {
        $m = self::all()[$key] ?? null;
        return $m && is_file(BASE_PATH . '/public/' . $m['path']) ? $m['path'] : null;
    }

    private static function replaceable(?string $current): bool
    {
        return $current === null || $current === '' || str_ends_with($current, '.svg') || str_starts_with($current, 'assets/images/photos/');
    }

    /** @return int number of rows updated */
    public static function apply(): int
    {
        if (!self::all()) {
            return 0;
        }
        $n = 0;
        // Products: primary (sort 0) and secondary (sort 1) images.
        foreach (Database::fetchAll('SELECT id, sku FROM products') as $p) {
            foreach (['product' => 0, 'product2' => 1] as $prefix => $rank) {
                $path = self::path($prefix . ':' . $p['sku']);
                if (!$path) {
                    continue;
                }
                $imgs = Database::fetchAll('SELECT id, path FROM product_images WHERE product_id = :p ORDER BY sort_order, id', ['p' => (int) $p['id']]);
                $img = $imgs[$rank] ?? null;
                if ($img && self::replaceable($img['path']) && $img['path'] !== $path) {
                    Database::update('product_images', ['path' => $path], ['id' => (int) $img['id']]);
                    $n++;
                } elseif (!$img && $rank === 0) {
                    Database::insert('product_images', ['product_id' => (int) $p['id'], 'path' => $path, 'sort_order' => 0]);
                    $n++;
                }
            }
        }
        // Taxonomy tiles and makers.
        foreach (['recipient' => 'recipients', 'occasion' => 'occasions', 'interest' => 'interests', 'maker' => 'makers'] as $prefix => $table) {
            foreach (Database::fetchAll("SELECT id, slug, image FROM `$table`") as $row) {
                $path = self::path($prefix . ':' . $row['slug']);
                if ($path && self::replaceable($row['image']) && $row['image'] !== $path) {
                    Database::update($table, ['image' => $path], ['id' => (int) $row['id']]);
                    $n++;
                }
            }
        }
        // Homepage hero & collection images.
        foreach (['hero' => 'misc:hero', 'personalized' => 'misc:personalized', 'baby-kids' => 'misc:baby'] as $sectionKey => $key) {
            $path = self::path($key);
            $row = Database::fetch('SELECT id, config_json FROM homepage_sections WHERE section_key = :k', ['k' => $sectionKey]);
            if ($path && $row) {
                $cfg = json_decode((string) $row['config_json'], true) ?: [];
                if (self::replaceable($cfg['image'] ?? null) && ($cfg['image'] ?? '') !== $path) {
                    $cfg['image'] = $path;
                    Database::update('homepage_sections', ['config_json' => json_encode($cfg)], ['id' => (int) $row['id']]);
                    $n++;
                }
            }
        }
        // Seasonal campaign banner.
        if ($path = self::path('misc:campaign-tihar')) {
            foreach (Database::fetchAll("SELECT id, image FROM campaigns WHERE type = 'seasonal'") as $c) {
                if (self::replaceable($c['image']) && $c['image'] !== $path) {
                    Database::update('campaigns', ['image' => $path], ['id' => (int) $c['id']]);
                    $n++;
                }
            }
        }
        Cache::bump('catalog');
        return $n;
    }
}
