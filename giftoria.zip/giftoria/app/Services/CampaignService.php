<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

/** Campaigns are "scheduled" by start/end dates: a campaign is live only between them. */
final class CampaignService
{
    public static function statusOf(array $c): string
    {
        $now = gmdate('Y-m-d H:i:s');
        if (!(int) $c['is_active']) {
            return 'draft';
        }
        if ($c['starts_at'] && $c['starts_at'] > $now) {
            return 'scheduled';
        }
        if ($c['ends_at'] && $c['ends_at'] < $now) {
            return 'ended';
        }
        return 'live';
    }

    public function active(array $types, int $limit = 5): array
    {
        $params = [];
        $in = Database::in('t', $types, $params);
        return Database::fetchAll(
            "SELECT * FROM campaigns WHERE is_active = 1 AND type IN $in
               AND (starts_at IS NULL OR starts_at <= UTC_TIMESTAMP())
               AND (ends_at IS NULL OR ends_at >= UTC_TIMESTAMP())
             ORDER BY sort_order, id DESC LIMIT " . (int) $limit,
            $params
        );
    }

    public function findLiveBySlug(string $slug): ?array
    {
        return Database::fetch(
            'SELECT * FROM campaigns WHERE slug = :s AND is_active = 1
               AND (starts_at IS NULL OR starts_at <= UTC_TIMESTAMP()) AND (ends_at IS NULL OR ends_at >= UTC_TIMESTAMP())',
            ['s' => $slug]
        );
    }
}
