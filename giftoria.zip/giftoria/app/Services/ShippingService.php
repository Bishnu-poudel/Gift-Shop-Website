<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Database;

/** Delivery zones (admin-configurable), shipping fees and delivery estimates. */
final class ShippingService
{
    public const VALLEY_DISTRICTS = ['Kathmandu', 'Lalitpur', 'Bhaktapur'];

    public static function districts(): array
    {
        $out = [];
        foreach (config('nepal.provinces') as $province => $districts) {
            foreach ($districts as $d) {
                $out[$d] = $province;
            }
        }
        return $out;
    }

    public static function isValidDistrict(string $district): bool
    {
        return isset(self::districts()[$district]);
    }

    public static function provinceOf(string $district): ?string
    {
        return self::districts()[$district] ?? null;
    }

    public static function isValleyDistrict(string $district): bool
    {
        $zone = self::zoneForDistrict($district);
        return $zone ? (bool) $zone['is_valley'] : in_array($district, self::VALLEY_DISTRICTS, true);
    }

    public static function zones(): array
    {
        return Cache::remember('settings', 'zones', 600, static fn () => Database::fetchAll('SELECT * FROM delivery_zones WHERE is_active = 1 ORDER BY sort_order, id'));
    }

    /** Zone whose district list contains $district, else the default zone. */
    public static function zoneForDistrict(?string $district): ?array
    {
        $default = null;
        foreach (self::zones() as $z) {
            $list = array_map('trim', explode(',', (string) $z['districts']));
            if ($district !== null && in_array($district, $list, true)) {
                return $z;
            }
            if ((int) $z['is_default'] === 1) {
                $default = $z;
            }
        }
        return $default;
    }

    /** Shipping fee for a zone given the post-discount subtotal. Free-shipping coupons handled by PricingService. */
    public static function fee(?array $zone, float $subtotal): float
    {
        if (!$zone) {
            return 0.0;
        }
        if ($zone['free_shipping_threshold'] !== null && $subtotal >= (float) $zone['free_shipping_threshold']) {
            return 0.0;
        }
        return (float) $zone['rate'];
    }

    /**
     * Delivery estimate in store-local dates, skipping Saturdays (the public weekly holiday in Nepal).
     * Returns null when no zone is known (we never guess).
     * @return array{earliest: string, latest: string, label: string}|null
     */
    public static function estimate(int $leadDays, ?array $zone, ?string $fromDate = null): ?array
    {
        if (!$zone) {
            return null;
        }
        $start = new \DateTimeImmutable($fromDate ?? local_today());
        $earliest = self::addBusinessDays($start, $leadDays + (int) $zone['est_days_min']);
        $latest = self::addBusinessDays($start, $leadDays + (int) $zone['est_days_max']);
        $label = $earliest->format('Y-m-d') === $latest->format('Y-m-d')
            ? $earliest->format('D, M j')
            : $earliest->format('M j') . ' – ' . $latest->format('M j');
        return ['earliest' => $earliest->format('Y-m-d'), 'latest' => $latest->format('Y-m-d'), 'label' => $label];
    }

    private static function addBusinessDays(\DateTimeImmutable $d, int $days): \DateTimeImmutable
    {
        while ($days > 0) {
            $d = $d->modify('+1 day');
            if ($d->format('N') !== '6') {
                $days--;
            }
        }
        return $d;
    }
}
