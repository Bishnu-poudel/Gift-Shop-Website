<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Session;
use RuntimeException;

/**
 * Database-backed carts. Guests are identified by a random cookie token; logged-in customers
 * by user_id. Guest carts merge into the customer cart at login. Prices are never stored in the
 * cart: they are always recalculated from the products table (see PricingService).
 */
final class CartService
{
    private const COOKIE = 'giftoria_cart';
    private const MAX_QTY = 20;

    private ?array $cart = null;

    public function current(bool $create = false): ?array
    {
        if ($this->cart !== null) {
            return $this->cart;
        }
        $userId = Auth::customerId();
        $cart = null;
        if ($userId) {
            $cart = Database::fetch('SELECT * FROM carts WHERE user_id = :u ORDER BY id DESC LIMIT 1', ['u' => $userId]);
        } else {
            $token = $_COOKIE[self::COOKIE] ?? Session::get('cart_token');
            if (is_string($token) && preg_match('/^[a-f0-9]{64}$/', $token)) {
                $cart = Database::fetch('SELECT * FROM carts WHERE token = :t AND user_id IS NULL', ['t' => $token]);
            }
        }
        if (!$cart && $create) {
            $token = random_token();
            $id = Database::insert('carts', ['user_id' => $userId, 'token' => $token]);
            $cart = Database::fetch('SELECT * FROM carts WHERE id = :id', ['id' => $id]);
            if (!$userId) {
                Session::put('cart_token', $token);
                if (PHP_SAPI !== 'cli' && !headers_sent()) {
                    setcookie(self::COOKIE, $token, [
                        'expires' => time() + 60 * 60 * 24 * 30,
                        'path' => base_path_prefix() ?: '/',
                        'secure' => (bool) config('app.force_https'),
                        'httponly' => true,
                        'samesite' => 'Lax',
                    ]);
                }
            }
        }
        return $this->cart = $cart;
    }

    /** Raw cart lines joined with live product data. */
    public function lines(?array $cart = null, bool $includeSaved = false): array
    {
        $cart ??= $this->current();
        if (!$cart) {
            return [];
        }
        return Database::fetchAll(
            'SELECT ci.id, ci.product_id, ci.variant_id, ci.quantity, ci.personalization, ci.saved_for_later,
                    p.name, p.slug, p.sku, p.price, p.sale_price, p.status, p.category_id, p.allow_backorder, p.cost_price,
                    p.gift_wrap_available, p.is_personalizable, p.lead_time_days, p.valley_only, p.weight_grams,
                    v.name AS variant_name, v.sku AS variant_sku, v.price_adjustment, v.is_active AS variant_active,
                    COALESCE(inv.quantity, 0) AS stock,
                    (SELECT pi.path FROM product_images pi WHERE pi.product_id = p.id ORDER BY pi.sort_order, pi.id LIMIT 1) AS image
             FROM cart_items ci
             JOIN products p ON p.id = ci.product_id
             LEFT JOIN product_variants v ON v.id = ci.variant_id AND ci.variant_id > 0
             LEFT JOIN inventory inv ON inv.product_id = ci.product_id AND inv.variant_id = ci.variant_id
             WHERE ci.cart_id = :c' . ($includeSaved ? '' : ' AND ci.saved_for_later = 0') . '
             ORDER BY ci.id',
            ['c' => (int) $cart['id']]
        );
    }

    public function count(): int
    {
        $cart = $this->current();
        if (!$cart) {
            return 0;
        }
        return (int) Database::fetchColumn('SELECT COALESCE(SUM(quantity),0) FROM cart_items WHERE cart_id = :c AND saved_for_later = 0', ['c' => (int) $cart['id']]);
    }

    /** @throws RuntimeException with a customer-friendly message */
    public function add(int $productId, int $variantId, int $qty, ?string $personalization): void
    {
        $qty = max(1, min(self::MAX_QTY, $qty));
        $p = Database::fetch("SELECT * FROM products WHERE id = :id AND status = 'active'", ['id' => $productId]);
        if (!$p) {
            throw new RuntimeException('This product is no longer available.');
        }
        $hasVariants = (int) Database::fetchColumn('SELECT COUNT(*) FROM product_variants WHERE product_id = :id AND is_active = 1', ['id' => $productId]) > 0;
        if ($hasVariants && $variantId === 0) {
            throw new RuntimeException('Please choose an option first.');
        }
        if ($variantId > 0 && !Database::fetchColumn('SELECT 1 FROM product_variants WHERE id = :v AND product_id = :p AND is_active = 1', ['v' => $variantId, 'p' => $productId])) {
            throw new RuntimeException('The selected option is not available.');
        }
        $personalization = $personalization !== null ? trim(strip_tags($personalization)) : null;
        if ($personalization === '' || !(int) $p['is_personalizable']) {
            $personalization = null;
        }
        if ($personalization !== null && $p['personalization_max_chars'] && mb_strlen($personalization) > (int) $p['personalization_max_chars']) {
            throw new RuntimeException('Personalization text is limited to ' . (int) $p['personalization_max_chars'] . ' characters.');
        }
        $stock = (int) Database::fetchColumn('SELECT COALESCE(quantity,0) FROM inventory WHERE product_id = :p AND variant_id = :v', ['p' => $productId, 'v' => $variantId]);
        $cart = $this->current(true);
        $hash = $personalization !== null ? md5($personalization) : '';
        $existing = (int) Database::fetchColumn(
            'SELECT quantity FROM cart_items WHERE cart_id = :c AND product_id = :p AND variant_id = :v AND personalization_hash = :h',
            ['c' => (int) $cart['id'], 'p' => $productId, 'v' => $variantId, 'h' => $hash]
        );
        $newQty = min(self::MAX_QTY, $existing + $qty);
        if (!(int) $p['allow_backorder'] && $newQty > $stock) {
            throw new RuntimeException($stock > 0 ? "Only $stock left in stock." : 'Sorry, this item is out of stock.');
        }
        Database::query(
            'INSERT INTO cart_items (cart_id, product_id, variant_id, quantity, personalization, personalization_hash)
             VALUES (:c, :p, :v, :q, :pers, :h)
             ON DUPLICATE KEY UPDATE quantity = :q2, saved_for_later = 0',
            ['c' => (int) $cart['id'], 'p' => $productId, 'v' => $variantId, 'q' => $newQty, 'pers' => $personalization, 'h' => $hash, 'q2' => $newQty]
        );
        $this->touch();
        Analytics::increment('add_to_cart');
    }

    public function update(int $itemId, int $qty): void
    {
        $cart = $this->current();
        if (!$cart) {
            return;
        }
        if ($qty <= 0) {
            $this->remove($itemId);
            return;
        }
        $qty = min(self::MAX_QTY, $qty);
        $line = Database::fetch(
            'SELECT ci.*, p.allow_backorder, COALESCE(i.quantity,0) AS stock FROM cart_items ci JOIN products p ON p.id = ci.product_id
             LEFT JOIN inventory i ON i.product_id = ci.product_id AND i.variant_id = ci.variant_id
             WHERE ci.id = :id AND ci.cart_id = :c',
            ['id' => $itemId, 'c' => (int) $cart['id']]
        );
        if (!$line) {
            return;
        }
        if (!(int) $line['allow_backorder'] && $qty > (int) $line['stock']) {
            throw new RuntimeException((int) $line['stock'] > 0 ? 'Only ' . (int) $line['stock'] . ' left in stock.' : 'Sorry, this item is out of stock.');
        }
        Database::update('cart_items', ['quantity' => $qty], ['id' => $itemId, 'cart_id' => (int) $cart['id']]);
        $this->touch();
    }

    public function remove(int $itemId): void
    {
        $cart = $this->current();
        if ($cart) {
            Database::delete('cart_items', ['id' => $itemId, 'cart_id' => (int) $cart['id']]);
            $this->touch();
        }
    }

    public function saveForLater(int $itemId, bool $saved): void
    {
        $cart = $this->current();
        if ($cart) {
            Database::update('cart_items', ['saved_for_later' => $saved ? 1 : 0], ['id' => $itemId, 'cart_id' => (int) $cart['id']]);
        }
    }

    public function setCoupon(?string $code): void
    {
        $cart = $this->current(true);
        Database::update('carts', ['coupon_code' => $code ? strtoupper(trim($code)) : null], ['id' => (int) $cart['id']]);
        $this->cart = null;
    }

    public function setGiftOptions(bool $wrap, ?string $message): void
    {
        $cart = $this->current(true);
        $message = $message !== null ? mb_substr(trim(strip_tags($message)), 0, 500) : null;
        Database::update('carts', ['gift_wrap' => $wrap ? 1 : 0, 'gift_message' => $message ?: null], ['id' => (int) $cart['id']]);
        $this->cart = null;
    }

    public function clear(?array $cart = null): void
    {
        $cart ??= $this->current();
        if ($cart) {
            Database::query('DELETE FROM cart_items WHERE cart_id = :c AND saved_for_later = 0', ['c' => (int) $cart['id']]);
            Database::update('carts', ['coupon_code' => null, 'gift_wrap' => 0, 'gift_message' => null, 'reminder_sent_at' => null], ['id' => (int) $cart['id']]);
        }
        $this->cart = null;
    }

    /** Called right after a customer logs in: merges the guest cart into the user's cart. */
    public function mergeGuestCartInto(int $userId): void
    {
        $token = $_COOKIE[self::COOKIE] ?? Session::get('cart_token');
        if (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/', $token)) {
            return;
        }
        $guest = Database::fetch('SELECT * FROM carts WHERE token = :t AND user_id IS NULL', ['t' => $token]);
        if (!$guest) {
            return;
        }
        Database::transaction(function () use ($guest, $userId) {
            $userCart = Database::fetch('SELECT * FROM carts WHERE user_id = :u ORDER BY id DESC LIMIT 1', ['u' => $userId]);
            if (!$userCart) {
                Database::update('carts', ['user_id' => $userId], ['id' => (int) $guest['id']]);
                return;
            }
            foreach (Database::fetchAll('SELECT * FROM cart_items WHERE cart_id = :c', ['c' => (int) $guest['id']]) as $item) {
                Database::query(
                    'INSERT INTO cart_items (cart_id, product_id, variant_id, quantity, personalization, personalization_hash, saved_for_later)
                     VALUES (:c, :p, :v, :q, :pers, :h, :s)
                     ON DUPLICATE KEY UPDATE quantity = LEAST(:max, quantity + :q2)',
                    [
                        'c' => (int) $userCart['id'], 'p' => (int) $item['product_id'], 'v' => (int) $item['variant_id'],
                        'q' => (int) $item['quantity'], 'pers' => $item['personalization'], 'h' => $item['personalization_hash'],
                        's' => (int) $item['saved_for_later'], 'max' => self::MAX_QTY, 'q2' => (int) $item['quantity'],
                    ]
                );
            }
            if ($guest['coupon_code'] && !$userCart['coupon_code']) {
                Database::update('carts', ['coupon_code' => $guest['coupon_code']], ['id' => (int) $userCart['id']]);
            }
            Database::delete('carts', ['id' => (int) $guest['id']]);
        });
        Session::forget('cart_token');
        if (PHP_SAPI !== 'cli' && !headers_sent()) {
            setcookie(self::COOKIE, '', ['expires' => time() - 3600, 'path' => base_path_prefix() ?: '/']);
        }
        $this->cart = null;
    }

    private function touch(): void
    {
        $cart = $this->current();
        if ($cart) {
            Database::query('UPDATE carts SET updated_at = UTC_TIMESTAMP(), reminder_sent_at = NULL WHERE id = :id', ['id' => (int) $cart['id']]);
        }
    }

    public function reset(): void
    {
        $this->cart = null;
    }
}
