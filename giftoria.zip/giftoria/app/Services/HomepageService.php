<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Repositories\ProductRepository;
use App\Repositories\TaxonomyRepository;

/**
 * Homepage sections are rows in homepage_sections (order, enable flag, text, config JSON),
 * managed in Admin > Homepage. Each type maps to resources/views/storefront/home/<type>.php.
 *
 * Config JSON keys by type:
 *   hero:            image, cta_label, cta_url, secondary_label, secondary_url, eyebrow
 *   products:        source (bestseller|new|featured|personalized|manual|category|interest|recipient), value, product_ids[], limit
 *   taxonomy_grid:   taxonomy (recipients|occasions|interests), slugs[] (optional), limit
 *   budget_grid:     (uses budget_ranges)
 *   collection:      source/value like products + image, cta_label, cta_url (editorial split)
 *   campaigns:       (uses active campaigns of type seasonal/banner)
 *   story, reviews, newsletter, trust, gift_finder, makers: text-only / data-driven
 */
final class HomepageService
{
    public const TYPES = ['hero', 'gift_finder', 'taxonomy_grid', 'budget_grid', 'products', 'collection', 'campaigns', 'story', 'makers', 'reviews', 'newsletter', 'trust'];

    public function sections(bool $enabledOnly = true): array
    {
        $rows = Database::fetchAll('SELECT * FROM homepage_sections' . ($enabledOnly ? ' WHERE is_enabled = 1' : '') . ' ORDER BY sort_order, id');
        foreach ($rows as &$r) {
            $r['config'] = json_decode((string) $r['config_json'], true) ?: [];
        }
        return $rows;
    }

    /** Resolves the data each section needs. */
    public function hydrate(array $section): array
    {
        $cfg = $section['config'];
        $repo = new ProductRepository();
        $tax = new TaxonomyRepository();
        $limit = (int) ($cfg['limit'] ?? 8);
        switch ($section['type']) {
            case 'products':
            case 'collection':
                $section['products'] = $this->products($cfg, $limit, $repo);
                break;
            case 'taxonomy_grid':
                $type = in_array($cfg['taxonomy'] ?? '', TaxonomyRepository::TYPES, true) ? $cfg['taxonomy'] : 'recipients';
                $items = $tax->all($type);
                if (!empty($cfg['slugs'])) {
                    $order = array_flip($cfg['slugs']);
                    $items = array_values(array_filter($items, static fn ($i) => isset($order[$i['slug']])));
                    usort($items, static fn ($a, $b) => $order[$a['slug']] <=> $order[$b['slug']]);
                }
                $section['items'] = array_slice($items, 0, $limit ?: 12);
                $section['taxonomy'] = $type;
                break;
            case 'budget_grid':
                $section['items'] = $tax->budgets();
                break;
            case 'campaigns':
                $section['items'] = (new CampaignService())->active(['seasonal', 'banner'], 3);
                break;
            case 'reviews':
                $section['items'] = Database::fetchAll(
                    "SELECT r.rating, r.title, r.body, r.created_at, u.name, p.name AS product_name, p.slug
                     FROM reviews r JOIN users u ON u.id = r.user_id JOIN products p ON p.id = r.product_id
                     WHERE r.status = 'approved' AND r.rating >= 4 ORDER BY r.created_at DESC LIMIT 6"
                );
                break;
            case 'makers':
                $section['items'] = Database::fetchAll('SELECT * FROM makers WHERE is_featured = 1 ORDER BY name LIMIT 4');
                break;
            case 'gift_finder':
                $section['recipients'] = $tax->all('recipients');
                $section['occasions'] = $tax->all('occasions');
                $section['budgets'] = $tax->budgets();
                break;
        }
        return $section;
    }

    private function products(array $cfg, int $limit, ProductRepository $repo): array
    {
        $source = $cfg['source'] ?? 'bestseller';
        $value = (string) ($cfg['value'] ?? '');
        return match ($source) {
            'manual' => $repo->cardsByIds($cfg['product_ids'] ?? []),
            'category' => $repo->search(['category' => $value, 'in_stock' => true], 'popular', 1, $limit)['items'],
            'interest' => $repo->search(['interests' => [$value], 'in_stock' => true], 'popular', 1, $limit)['items'],
            'recipient' => $repo->search(['recipient' => $value, 'in_stock' => true], 'popular', 1, $limit)['items'],
            'occasion' => $repo->search(['occasion' => $value, 'in_stock' => true], 'popular', 1, $limit)['items'],
            'last_minute' => $repo->search(['in_stock' => true, 'ids' => Database::fetchCol("SELECT id FROM products WHERE status = 'active' AND lead_time_days = 0 AND valley_only = 0")], 'popular', 1, $limit)['items'],
            default => $repo->flagged($source, $limit),
        };
    }
}
