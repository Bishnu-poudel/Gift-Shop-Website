<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Database;
use App\Core\Gate;
use PDO;
use RuntimeException;

/**
 * Installation steps shared by the web installer (/install) and the CLI (bin/console.php).
 * Creating the first Super Admin is refused once a Super Admin exists or storage/installed.lock is present.
 */
final class Installer
{
    public static function lockFile(): string
    {
        return BASE_PATH . '/storage/installed.lock';
    }

    public static function isInstalled(): bool
    {
        if (is_file(self::lockFile())) {
            return true;
        }
        try {
            return (bool) Database::fetchColumn(
                "SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE r.slug = 'super-admin' LIMIT 1"
            );
        } catch (\Throwable) {
            return false;
        }
    }

    /** Creates the database if it does not exist (requires CREATE privilege, e.g. XAMPP root). */
    public static function ensureDatabase(): void
    {
        $c = config('database');
        if (!preg_match('/^[A-Za-z0-9_]+$/', (string) $c['database'])) {
            throw new RuntimeException('DB_DATABASE may only contain letters, numbers and underscores.');
        }
        $pdo = new PDO(sprintf('mysql:host=%s;port=%d;charset=utf8mb4', $c['host'], (int) $c['port']), $c['username'], $c['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . $c['database'] . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    }

    /** Runs pending SQL migrations in filename order. @return string[] applied files */
    public static function migrate(): array
    {
        $pdo = Database::pdo();
        $pdo->exec('CREATE TABLE IF NOT EXISTS schema_migrations (filename VARCHAR(190) PRIMARY KEY, applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
        $done = Database::fetchCol('SELECT filename FROM schema_migrations');
        $applied = [];
        $files = glob(BASE_PATH . '/database/migrations/*.sql') ?: [];
        sort($files);
        foreach ($files as $file) {
            $name = basename($file);
            if (in_array($name, $done, true)) {
                continue;
            }
            $sql = (string) file_get_contents($file);
            // Strip comments and split on statement terminators (migrations contain no procedures).
            $sql = preg_replace('/^\s*--.*$/m', '', $sql) ?? $sql;
            foreach (array_filter(array_map('trim', explode(";\n", str_replace("\r\n", "\n", $sql)))) as $stmt) {
                $stmt = rtrim($stmt, ";\n ");
                if ($stmt === '' || stripos($stmt, 'CREATE TABLE schema_migrations') !== false) {
                    continue;
                }
                $pdo->exec($stmt);
            }
            Database::insert('schema_migrations', ['filename' => $name]);
            $applied[] = $name;
        }
        return $applied;
    }

    public static function seedBase(): void
    {
        require_once BASE_PATH . '/database/seeders/BaseSeeder.php';
        require_once BASE_PATH . '/database/seeders/ArtSeeder.php';
        (new \Database\Seeders\BaseSeeder())->run();
        (new \Database\Seeders\ArtSeeder())->run();
        PhotoManifest::apply();
        Cache::clear();
        Cache::bump('catalog');
        Cache::bump('settings');
        SettingsService::flush();
    }

    /** @return array log lines (includes generated demo passwords, shown once) */
    public static function seedDemo(bool $withStaff = false): array
    {
        require_once BASE_PATH . '/database/seeders/DemoSeeder.php';
        $log = (new \Database\Seeders\DemoSeeder())->run($withStaff);
        $applied = PhotoManifest::apply();
        if ($applied) {
            $log[] = "Applied $applied CC0 demo photos (see CREDITS.md).";
        }
        Cache::clear();
        Cache::bump('catalog');
        return $log;
    }

    /** Creates the first Super Admin. Refuses if one already exists. */
    public static function createFirstAdmin(string $name, string $email, string $password): int
    {
        if (self::isInstalled()) {
            throw new RuntimeException('Installation is already complete. Additional staff must be created from Admin > Staff.');
        }
        if (mb_strlen($password) < 12) {
            throw new RuntimeException('The administrator password must be at least 12 characters.');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('Please provide a valid email address.');
        }
        $roleId = Database::fetchColumn('SELECT id FROM roles WHERE slug = :s', ['s' => Gate::SUPER_ADMIN]);
        if (!$roleId) {
            throw new RuntimeException('Roles are missing. Run the base seed first.');
        }
        $id = Database::transaction(function () use ($name, $email, $password, $roleId) {
            $id = Database::insert('users', [
                'type' => 'staff',
                'name' => $name,
                'email' => mb_strtolower(trim($email)),
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'status' => 'active',
                'email_verified_at' => Database::now(),
            ]);
            Database::insert('staff_profiles', ['user_id' => $id, 'employee_id' => 'EMP-0001', 'job_title' => 'Owner', 'department' => 'Management']);
            Database::insert('user_roles', ['user_id' => $id, 'role_id' => (int) $roleId]);
            return $id;
        });
        file_put_contents(self::lockFile(), 'Installed ' . gmdate('c') . "\n");
        \App\Core\AuditLogger::log('install.first_admin', 'user', $id, null, ['email' => $email], $id);
        return $id;
    }
}
