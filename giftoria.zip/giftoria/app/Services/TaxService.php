<?php
declare(strict_types=1);

namespace App\Services;

/**
 * VAT and bill helpers for Nepal (VAT Act 2052; standard rate 13%).
 *  - VAT-registered sellers show taxable amount + VAT on a Tax Invoice.
 *  - PAN-only (non-VAT) sellers issue a plain invoice with no VAT line.
 *  - Prices can be entered VAT-inclusive (default) or VAT-exclusive (VAT added at checkout).
 */
final class TaxService
{
    public static function config(): array
    {
        $registered = (bool) setting('vat_registered', false);
        return [
            'registered' => $registered,
            'rate' => $registered ? max(0.0, min(100.0, (float) setting('vat_rate', 13))) : 0.0,
            'inclusive' => (bool) setting('prices_include_vat', true),
        ];
    }

    /**
     * Splits an order into taxable amount and VAT.
     * @param float $chargeable subtotal − discount + delivery + gift wrap (as priced in the catalogue)
     * @return array{taxable: float, vat: float, total: float, rate: float, registered: bool, inclusive: bool}
     */
    public static function breakdown(float $chargeable, ?array $cfg = null): array
    {
        $cfg ??= self::config();
        $chargeable = round(max(0.0, $chargeable), 2);
        $rate = $cfg['rate'];
        if (!$cfg['registered'] || $rate <= 0) {
            return ['taxable' => $chargeable, 'vat' => 0.0, 'total' => $chargeable, 'rate' => 0.0, 'registered' => $cfg['registered'], 'inclusive' => $cfg['inclusive']];
        }
        if ($cfg['inclusive']) {
            $taxable = round($chargeable / (1 + $rate / 100), 2);
            return ['taxable' => $taxable, 'vat' => round($chargeable - $taxable, 2), 'total' => $chargeable, 'rate' => $rate, 'registered' => true, 'inclusive' => true];
        }
        $vat = round($chargeable * $rate / 100, 2);
        return ['taxable' => $chargeable, 'vat' => $vat, 'total' => round($chargeable + $vat, 2), 'rate' => $rate, 'registered' => true, 'inclusive' => false];
    }

    /**
     * Nepali fiscal year label (Shrawan 1 – Ashad end, ~16/17 July). E.g. 2026-10-12 → "2083/84".
     * Uses the AD date in Asia/Kathmandu; the boundary is approximated at 17 July.
     */
    public static function fiscalYear(?string $ymd = null): string
    {
        $d = new \DateTimeImmutable($ymd ?? local_today());
        $y = (int) $d->format('Y');
        $month = (int) $d->format('n');
        $startBs = ($month > 7 || ($month === 7 && (int) $d->format('j') >= 17)) ? $y + 57 : $y + 56;
        return $startBs . '/' . substr((string) ($startBs + 1), -2);
    }

    /** "Rupees One Lakh Twenty Thousand Fifty and Paisa Twenty Five Only" (Indian numbering). */
    public static function amountInWords(float $amount): string
    {
        $rupees = (int) floor(round($amount, 2));
        $paisa = (int) round((round($amount, 2) - $rupees) * 100);
        $words = 'Rupees ' . ($rupees === 0 ? 'Zero' : self::words($rupees));
        if ($paisa > 0) {
            $words .= ' and Paisa ' . self::words($paisa);
        }
        return $words . ' Only';
    }

    private static function words(int $n): string
    {
        $ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
        $tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
        $two = static fn (int $x) => $x < 20 ? $ones[$x] : trim($tens[intdiv($x, 10)] . ' ' . $ones[$x % 10]);
        $three = static fn (int $x) => trim(($x >= 100 ? $ones[intdiv($x, 100)] . ' Hundred ' : '') . $two($x % 100));
        $parts = [];
        foreach ([[10000000, 'Crore'], [100000, 'Lakh'], [1000, 'Thousand']] as [$div, $label]) {
            if ($n >= $div) {
                $chunk = intdiv($n, $div);
                $parts[] = ($chunk >= 100 ? self::words($chunk) : $two($chunk)) . ' ' . $label;
                $n %= $div;
            }
        }
        if ($n > 0) {
            $parts[] = $three($n);
        }
        return implode(' ', $parts);
    }

    /** Seller details captured onto each bill so later setting changes don't alter issued bills. */
    public static function sellerSnapshot(): array
    {
        $cfg = self::config();
        return [
            'name' => (string) setting('store_name', config('app.name')),
            'legal_name' => (string) (setting('business_legal_name') ?: setting('store_name', config('app.name'))),
            'address' => (string) setting('store_address', ''),
            'phone' => (string) setting('store_phone', ''),
            'email' => (string) setting('store_email', ''),
            'pan' => (string) setting('store_pan', ''),
            'vat_number' => (string) setting('store_vat_number', ''),
            'vat_registered' => $cfg['registered'],
            'logo' => (string) setting('store_logo', ''),
            'footer' => (string) setting('bill_footer', ''),
        ];
    }
}
