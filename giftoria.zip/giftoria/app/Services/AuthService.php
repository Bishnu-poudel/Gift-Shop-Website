<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Database;
use RuntimeException;

/**
 * Registration, email verification, password reset and staff invitations.
 * Tokens are random 32-byte values; only their SHA-256 hash is stored. Responses never reveal
 * whether an email is registered (no account enumeration).
 */
final class AuthService
{
    public const TOKEN_TTL = ['verify' => 86400 * 2, 'reset' => 3600, 'invite' => 86400 * 3];

    /** Public registration: ALWAYS creates a customer account with no roles. */
    public function registerCustomer(string $name, string $email, string $password, bool $marketing): ?int
    {
        $email = mb_strtolower(trim($email));
        if (Database::fetchColumn("SELECT 1 FROM users WHERE email = :e AND type = 'customer'", ['e' => $email])) {
            // Existing account: tell the owner by email instead of revealing it on screen.
            $u = Database::fetch("SELECT * FROM users WHERE email = :e AND type = 'customer'", ['e' => $email]);
            (new MailService())->send($email, 'account_exists', ['customer_name' => $u['name'], 'login_url' => url('/login'), 'reset_url' => url('/forgot-password')]);
            return null;
        }
        $id = Database::transaction(function () use ($name, $email, $password, $marketing) {
            $id = Database::insert('users', [
                'type' => 'customer',
                'name' => $name,
                'email' => $email,
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'status' => 'pending', // until the email is verified
            ]);
            Database::insert('customer_profiles', ['user_id' => $id, 'marketing_opt_in' => $marketing ? 1 : 0]);
            Database::insert('wishlists', ['user_id' => $id, 'name' => 'My Wishlist']);
            if ($marketing) {
                NewsletterService::subscribe($email, 'registration', $id);
            }
            return $id;
        });
        $this->sendVerification($id);
        return $id;
    }

    public function createToken(int $userId, string $type): string
    {
        $token = random_token();
        Database::query('UPDATE user_tokens SET used_at = UTC_TIMESTAMP() WHERE user_id = :u AND type = :t AND used_at IS NULL', ['u' => $userId, 't' => $type]);
        Database::insert('user_tokens', [
            'user_id' => $userId,
            'type' => $type,
            'token_hash' => hash('sha256', $token),
            'expires_at' => gmdate('Y-m-d H:i:s', time() + self::TOKEN_TTL[$type]),
        ]);
        return $token;
    }

    /** Validates and consumes a token. @return array|null the user row */
    public function consumeToken(string $token, string $type, bool $consume = true): ?array
    {
        if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
            return null;
        }
        $row = Database::fetch(
            'SELECT t.id AS token_id, u.* FROM user_tokens t JOIN users u ON u.id = t.user_id
             WHERE t.token_hash = :h AND t.type = :t AND t.used_at IS NULL AND t.expires_at > UTC_TIMESTAMP()',
            ['h' => hash('sha256', $token), 't' => $type]
        );
        if ($row && $consume) {
            Database::update('user_tokens', ['used_at' => Database::now()], ['id' => (int) $row['token_id']]);
        }
        return $row ?: null;
    }

    public function sendVerification(int $userId): void
    {
        $u = Database::fetch('SELECT * FROM users WHERE id = :id', ['id' => $userId]);
        if (!$u || $u['email_verified_at']) {
            return;
        }
        $token = $this->createToken($userId, 'verify');
        (new MailService())->send($u['email'], 'account_verification', [
            'customer_name' => $u['name'],
            'verify_url' => url('/verify-email/' . $token),
        ]);
    }

    public function verifyEmail(string $token): ?array
    {
        $u = $this->consumeToken($token, 'verify');
        if (!$u) {
            return null;
        }
        Database::query(
            "UPDATE users SET email_verified_at = COALESCE(email_verified_at, UTC_TIMESTAMP()), status = IF(status = 'pending', 'active', status) WHERE id = :id",
            ['id' => (int) $u['id']]
        );
        return Database::fetch('SELECT * FROM users WHERE id = :id', ['id' => (int) $u['id']]);
    }

    /** Always succeeds from the caller's perspective (no enumeration). */
    public function requestPasswordReset(string $email, string $type = 'customer'): void
    {
        // Pending staff must activate through their invitation link, not a password reset.
        $statuses = $type === 'staff' ? "('active')" : "('active','pending')";
        $u = Database::fetch("SELECT * FROM users WHERE email = :e AND type = :t AND status IN $statuses", ['e' => mb_strtolower(trim($email)), 't' => $type]);
        if (!$u) {
            return;
        }
        $token = $this->createToken((int) $u['id'], 'reset');
        $link = $type === 'staff' ? admin_url('reset-password/' . $token) : url('/reset-password/' . $token);
        (new MailService())->send($u['email'], 'password_reset', ['customer_name' => $u['name'], 'reset_url' => $link]);
    }

    public function resetPassword(string $token, string $password, string $type = 'customer'): bool
    {
        $u = $this->consumeToken($token, 'reset', false);
        if (!$u || $u['type'] !== $type) {
            return false;
        }
        $this->consumeToken($token, 'reset');
        $this->setPassword((int) $u['id'], $password);
        // A successful reset proves mailbox ownership.
        Database::query("UPDATE users SET email_verified_at = COALESCE(email_verified_at, UTC_TIMESTAMP()), status = IF(status = 'pending', 'active', status) WHERE id = :id", ['id' => (int) $u['id']]);
        AuditLogger::log('auth.password_reset', 'user', (int) $u['id'], null, null, (int) $u['id']);
        return true;
    }

    /** Sets a password and revokes all other sessions. */
    public function setPassword(int $userId, string $password): void
    {
        if (mb_strlen($password) < 8) {
            throw new RuntimeException('Password must be at least 8 characters.');
        }
        Database::query(
            'UPDATE users SET password_hash = :h, must_change_password = 0, session_version = session_version + 1 WHERE id = :id',
            ['h' => password_hash($password, PASSWORD_DEFAULT), 'id' => $userId]
        );
    }

    public static function passwordRules(): string
    {
        return 'required|min:8|max:128|confirmed';
    }
}
