<?php
declare(strict_types=1);

namespace App\Services;

use DomainException;

/** Permitted order and payment state transitions, enforced server-side. */
final class OrderStateMachine
{
    public const ORDER = [
        'pending_payment' => ['confirmed', 'cancelled'],
        'confirmed' => ['processing', 'cancelled'],
        'processing' => ['packed', 'cancelled'],
        'packed' => ['shipped', 'cancelled'],
        'shipped' => ['out_for_delivery', 'delivered', 'returned'],
        'out_for_delivery' => ['delivered', 'returned'],
        'delivered' => ['return_requested'],
        'return_requested' => ['returned', 'delivered'],
        'returned' => ['refund_pending', 'refunded'],
        'cancelled' => ['refund_pending'],
        'refund_pending' => ['refunded'],
        'refunded' => [],
    ];

    /**
     * A verified gateway success may arrive after an attempt was marked failed/cancelled/expired
     * (money did move), so those states may still move to 'paid' — but only via verification.
     */
    public const PAYMENT = [
        'initiated' => ['pending', 'paid', 'failed', 'cancelled', 'expired'],
        'pending' => ['paid', 'failed', 'cancelled', 'expired'],
        'failed' => ['paid', 'pending', 'initiated'],
        'cancelled' => ['paid'],
        'expired' => ['paid'],
        'paid' => ['refund_pending', 'partially_refunded', 'refunded'],
        'refund_pending' => ['partially_refunded', 'refunded', 'paid'],
        'partially_refunded' => ['refund_pending', 'refunded'],
        'refunded' => [],
    ];

    public const ORDER_LABELS = [
        'pending_payment' => 'Pending payment', 'confirmed' => 'Confirmed', 'processing' => 'Processing',
        'packed' => 'Packed', 'shipped' => 'Shipped', 'out_for_delivery' => 'Out for delivery',
        'delivered' => 'Delivered', 'cancelled' => 'Cancelled', 'return_requested' => 'Return requested',
        'returned' => 'Returned', 'refund_pending' => 'Refund pending', 'refunded' => 'Refunded',
    ];

    public static function canOrder(string $from, string $to): bool
    {
        return in_array($to, self::ORDER[$from] ?? [], true);
    }

    public static function canPayment(string $from, string $to): bool
    {
        return $from === $to || in_array($to, self::PAYMENT[$from] ?? [], true);
    }

    public static function assertOrder(string $from, string $to): void
    {
        if (!self::canOrder($from, $to)) {
            throw new DomainException(sprintf('Order cannot move from "%s" to "%s".', self::ORDER_LABELS[$from] ?? $from, self::ORDER_LABELS[$to] ?? $to));
        }
    }

    public static function assertPayment(string $from, string $to): void
    {
        if (!self::canPayment($from, $to)) {
            throw new DomainException(sprintf('Payment cannot move from "%s" to "%s".', $from, $to));
        }
    }

    public static function nextOrderStates(string $from): array
    {
        return self::ORDER[$from] ?? [];
    }
}
