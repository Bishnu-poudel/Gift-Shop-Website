<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Logger;
use App\Repositories\TaxonomyRepository;
use DateTimeImmutable;

/**
 * Gift Center reminders and upcoming occasions.
 * Dates are calendar dates in the store timezone (Asia/Kathmandu); "today" comes from local_today().
 * Reminder emails are opt-in: they are only sent when customer_profiles.notify_gift_reminders = 1.
 */
final class ReminderService
{
    /**
     * Next occurrence (Y-m-d, on or after $today) of an event date, or null if it is a past one-off event.
     * Yearly events on Feb 29 fall on Feb 28 in non-leap years.
     */
    public static function nextOccurrence(string $eventDate, bool $recurring, ?string $today = null): ?string
    {
        $today ??= local_today();
        if (!preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $eventDate, $m)) {
            return null;
        }
        if (!$recurring) {
            return $eventDate >= $today ? $eventDate : null;
        }
        $year = (int) substr($today, 0, 4);
        foreach ([$year, $year + 1] as $y) {
            $month = (int) $m[2];
            $day = (int) $m[3];
            if ($month === 2 && $day === 29 && !checkdate(2, 29, $y)) {
                $day = 28;
            }
            $candidate = sprintf('%04d-%02d-%02d', $y, $month, $day);
            if ($candidate >= $today) {
                return $candidate;
            }
        }
        return null;
    }

    public static function daysBetween(string $from, string $to): int
    {
        return (int) (new DateTimeImmutable($from))->diff(new DateTimeImmutable($to))->format('%r%a');
    }

    /** Age in whole months on $onDate for a birthday (Y-m-d), or null. */
    public static function ageInMonths(?string $birthday, ?string $onDate = null): ?int
    {
        if (!$birthday || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $birthday)) {
            return null;
        }
        $d = (new DateTimeImmutable($birthday))->diff(new DateTimeImmutable($onDate ?? local_today()));
        return $d->invert ? null : $d->y * 12 + $d->m;
    }

    /**
     * Gift Finder results URL prefilled from a saved recipient (and optional occasion).
     * Only taxonomy values that still exist are passed through.
     */
    public static function finderUrl(?array $recipient, ?string $occasionSlug = null): string
    {
        $tax = new TaxonomyRepository();
        $q = [];
        if ($recipient) {
            $recipients = $tax->keyed('recipients');
            if (!empty($recipient['recipient_slug']) && isset($recipients[$recipient['recipient_slug']])) {
                $q['recipient'] = $recipient['recipient_slug'];
            }
            $ageSlug = (string) ($recipient['age_range_slug'] ?? '');
            if ($ageSlug === '' || !$tax->ageRange($ageSlug)) {
                $ageSlug = '';
                // Derive the age range from the birthday when none was chosen.
                $months = self::ageInMonths($recipient['birthday'] ?? null);
                if ($months !== null) {
                    foreach ($tax->ageRanges() as $r) {
                        if ($months >= (int) $r['min_months'] && $months <= (int) $r['max_months']) {
                            $ageSlug = (string) $r['slug'];
                            break;
                        }
                    }
                }
            }
            if ($ageSlug !== '') {
                $q['age'] = $ageSlug;
            }
            $interests = $tax->keyed('interests');
            $ints = array_values(array_filter(self::csv($recipient['interests'] ?? null), static fn ($s) => isset($interests[$s])));
            if ($ints) {
                $q['interests'] = $ints;
            }
            $prefSlugs = array_column($tax->preferenceTags(), 'slug');
            $prefs = array_values(array_intersect(self::csv($recipient['preferences'] ?? null), $prefSlugs));
            if ($prefs) {
                $q['prefs'] = $prefs;
            }
        }
        if ($occasionSlug && $tax->findBySlug('occasions', $occasionSlug)) {
            $q['occasion'] = $occasionSlug;
        }
        return url('/gift-finder/results', $q);
    }

    /** @return string[] */
    public static function csv(?string $value): array
    {
        if ($value === null || trim($value) === '') {
            return [];
        }
        return array_values(array_unique(array_filter(array_map('trim', explode(',', $value)), static fn ($s) => $s !== '')));
    }

    /**
     * Upcoming occasions for a customer within $days (inclusive), from active reminders and recipients' birthdays.
     * @return list<array{date: string, days_until: int, title: string, type: string, recipient: ?array, reminder_id: ?int,
     *                    occasion_slug: ?string, finder_url: string}>
     */
    public function upcoming(int $userId, int $days = 60): array
    {
        $today = local_today();
        $until = (new DateTimeImmutable($today))->modify('+' . max(0, $days) . ' days')->format('Y-m-d');
        $recipients = [];
        foreach (Database::fetchAll('SELECT * FROM gift_recipients WHERE user_id = :u', ['u' => $userId]) as $r) {
            $recipients[(int) $r['id']] = $r;
        }
        $hasBirthdayOccasion = (bool) (new TaxonomyRepository())->findBySlug('occasions', 'birthday');

        $out = [];
        $seen = [];
        $reminders = Database::fetchAll('SELECT * FROM gift_reminders WHERE user_id = :u AND is_active = 1', ['u' => $userId]);
        foreach ($reminders as $rem) {
            $next = self::nextOccurrence((string) $rem['event_date'], (bool) $rem['recurring_yearly'], $today);
            if ($next === null || $next > $until) {
                continue;
            }
            $recipient = $rem['gift_recipient_id'] ? ($recipients[(int) $rem['gift_recipient_id']] ?? null) : null;
            $out[] = [
                'date' => $next,
                'days_until' => self::daysBetween($today, $next),
                'title' => (string) $rem['title'],
                'type' => 'reminder',
                'recipient' => $recipient,
                'reminder_id' => (int) $rem['id'],
                'occasion_slug' => $rem['occasion_slug'] ?: null,
                'finder_url' => self::finderUrl($recipient, $rem['occasion_slug'] ?: null),
            ];
            if ($recipient) {
                $seen[(int) $recipient['id'] . '|' . $next] = true;
            }
        }
        foreach ($recipients as $r) {
            if (!$r['birthday']) {
                continue;
            }
            $next = self::nextOccurrence((string) $r['birthday'], true, $today);
            if ($next === null || $next > $until || isset($seen[(int) $r['id'] . '|' . $next])) {
                continue;
            }
            $turning = (int) substr($next, 0, 4) - (int) substr((string) $r['birthday'], 0, 4);
            $out[] = [
                'date' => $next,
                'days_until' => self::daysBetween($today, $next),
                'title' => $r['name'] . '’s birthday' . ($turning > 0 && $turning < 120 ? ' (turning ' . $turning . ')' : ''),
                'type' => 'birthday',
                'recipient' => $r,
                'reminder_id' => null,
                'occasion_slug' => $hasBirthdayOccasion ? 'birthday' : null,
                'finder_url' => self::finderUrl($r, $hasBirthdayOccasion ? 'birthday' : null),
            ];
        }
        usort($out, static fn ($a, $b) => [$a['date'], $a['title']] <=> [$b['date'], $b['title']]);
        return $out;
    }

    /**
     * Sends reminder emails that are due today. A reminder is due when today is on/after
     * (next occurrence − remind_days_before) and not after the occurrence itself, and it has not
     * already been sent for that occurrence (last_sent_for). Running daily, this fires on the exact
     * day; if the cron missed a day it still catches up before the event. Returns the number sent.
     */
    public function sendDue(): int
    {
        $today = local_today();
        $rows = Database::fetchAll(
            "SELECT gr.*, u.email, u.name AS customer_name, rc.name AS recipient_name, rc.recipient_slug, rc.birthday AS recipient_birthday,
                    rc.age_range_slug, rc.interests, rc.preferences
             FROM gift_reminders gr
             JOIN users u ON u.id = gr.user_id AND u.type = 'customer' AND u.status = 'active'
             JOIN customer_profiles cp ON cp.user_id = gr.user_id AND cp.notify_gift_reminders = 1
             LEFT JOIN gift_recipients rc ON rc.id = gr.gift_recipient_id AND rc.user_id = gr.user_id
             WHERE gr.is_active = 1
             ORDER BY gr.id"
        );
        $mail = new MailService();
        $sent = 0;
        foreach ($rows as $r) {
            try {
                $next = self::nextOccurrence((string) $r['event_date'], (bool) $r['recurring_yearly'], $today);
                if ($next === null) {
                    continue;
                }
                $sendOn = (new DateTimeImmutable($next))->modify('-' . max(0, (int) $r['remind_days_before']) . ' days')->format('Y-m-d');
                if ($sendOn > $today || ($r['last_sent_for'] !== null && (string) $r['last_sent_for'] === $next)) {
                    continue;
                }
                $recipient = $r['gift_recipient_id'] && $r['recipient_name'] !== null ? [
                    'recipient_slug' => $r['recipient_slug'],
                    'birthday' => $r['recipient_birthday'],
                    'age_range_slug' => $r['age_range_slug'],
                    'interests' => $r['interests'],
                    'preferences' => $r['preferences'],
                ] : null;
                // Mark first so a mail-transport failure can never cause repeated sends on every run.
                $claimed = Database::query(
                    'UPDATE gift_reminders SET last_sent_for = :occ WHERE id = :id AND (last_sent_for IS NULL OR last_sent_for <> :occ2)',
                    ['occ' => $next, 'id' => (int) $r['id'], 'occ2' => $next]
                )->rowCount();
                if ($claimed === 0) {
                    continue;
                }
                $status = $mail->send((string) $r['email'], 'gift_reminder', [
                    'customer_name' => (string) $r['customer_name'],
                    'reminder_title' => (string) $r['title'],
                    'event_date' => (new DateTimeImmutable($next))->format('l, F j, Y'),
                    'recipient_name' => (string) ($r['recipient_name'] ?? ''),
                    'finder_url' => self::finderUrl($recipient, $r['occasion_slug'] ?: null),
                    'unsubscribe_url' => url('/account/notifications'),
                ], url('/account/notifications'));
                if (in_array($status, ['logged', 'sent'], true)) {
                    $sent++;
                }
            } catch (\Throwable $e) {
                Logger::error('Gift reminder failed', ['reminder' => (int) $r['id'], 'error' => $e->getMessage()]);
            }
        }
        return $sent;
    }
}
