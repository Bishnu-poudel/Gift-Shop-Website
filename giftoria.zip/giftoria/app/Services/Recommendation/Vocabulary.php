<?php
declare(strict_types=1);

namespace App\Services\Recommendation;

use App\Core\Cache;
use App\Repositories\ProductRepository;
use App\Repositories\TaxonomyRepository;

/** Builds the phrase => mappings dictionary from taxonomy names, their synonyms and search_synonyms. */
final class Vocabulary
{
    public static function parser(): QueryParser
    {
        [$vocab, $words] = Cache::remember('catalog', 'vocabulary', 600, static function () {
            $tax = new TaxonomyRepository();
            $vocab = [];
            $add = static function (string $phrase, string $map) use (&$vocab) {
                $phrase = trim(mb_strtolower($phrase));
                if ($phrase !== '') {
                    $vocab[$phrase][] = $map;
                }
            };
            foreach (['recipients' => 'recipient', 'occasions' => 'occasion', 'interests' => 'interest'] as $table => $type) {
                foreach ($tax->all($table) as $row) {
                    $add($row['name'], $type . ':' . $row['slug']);
                    foreach (array_filter(array_map('trim', explode(',', (string) $row['synonyms']))) as $syn) {
                        $add($syn, $type . ':' . $row['slug']);
                    }
                }
            }
            foreach ($tax->categories() as $c) {
                $add($c['name'], 'category:' . $c['slug']);
            }
            foreach ($tax->preferenceTags() as $t) {
                $add($t['name'], 'pref:' . $t['slug']);
            }
            foreach ($tax->synonyms() as $s) {
                foreach (array_filter(array_map('trim', explode(',', (string) $s['maps_to']))) as $map) {
                    $add($s['phrase'], $map);
                }
            }
            return [$vocab, (new ProductRepository())->vocabulary()];
        });
        return new QueryParser($vocab, $words);
    }
}
