<?php
declare(strict_types=1);

namespace App\Services\Recommendation;

/**
 * Turns natural-language gift queries into structured criteria.
 *   "princess gifts under NPR 2,000"  -> interests:[princess-toys], max_price:2000
 *   "gift for toddler girl"          -> recipient:baby-girl, age 12-36 months
 *   "educatonal toys"                -> interests:[educational-toys] (typo corrected)
 *
 * The vocabulary is injected (phrase => list of "type:value" mappings) so the parser is
 * pure and unit-testable. Types: recipient, occasion, interest, category, pref, agemonths, flag.
 */
final class QueryParser
{
    private const STOPWORDS = [
        'gift', 'gifts', 'for', 'a', 'an', 'the', 'my', 'to', 'of', 'with', 'and', 'unique', 'best', 'idea', 'ideas',
        'present', 'presents', 'something', 'buy', 'shop', 'i', 'need', 'want', 'who', 'love', 'loves', 'like', 'likes',
        'her', 'him', 'them', 'our', 'your', 'some', 'good', 'nice', 'great', 'cool', 'perfect', 'special', 'in', 'on',
        'is', 'are', 'that', 'this', 'from', 'npr', 'rs', 'rupee', 'rupees', 'price', 'budget', 'cheap', 'affordable', 'thing', 'things',
    ];

    /** @var array<string, array{tokens: string[], maps: string[]}> */
    private array $phrases = [];
    /** @var string[] single normalized words known to the vocabulary */
    private array $words = [];

    /**
     * @param array<string, string[]> $vocabulary phrase => ["recipient:baby-girl", ...]
     * @param string[] $extraWords additional correct words (product names) for typo tolerance
     */
    public function __construct(array $vocabulary, array $extraWords = [])
    {
        foreach ($vocabulary as $phrase => $maps) {
            $tokens = self::tokens((string) $phrase);
            if (!$tokens) {
                continue;
            }
            $key = implode(' ', $tokens);
            $this->phrases[$key] = [
                'tokens' => $tokens,
                'maps' => array_values(array_unique(array_merge($this->phrases[$key]['maps'] ?? [], $maps))),
            ];
            foreach ($tokens as $t) {
                $this->words[$t] = true;
            }
        }
        foreach ($extraWords as $w) {
            foreach (self::tokens((string) $w) as $t) {
                $this->words[$t] = true;
            }
        }
        // Longest phrases first so "first birthday" wins over "birthday".
        uasort($this->phrases, static fn ($a, $b) => count($b['tokens']) <=> count($a['tokens']));
    }

    /** Lowercases, strips punctuation and applies light singularization. */
    public static function tokens(string $text): array
    {
        $text = mb_strtolower($text);
        $text = str_replace(["'s", '’s', '&'], ['', '', ' and '], $text);
        $parts = preg_split('/[^\p{L}\p{N}]+/u', $text) ?: [];
        $out = [];
        foreach ($parts as $p) {
            if ($p !== '') {
                $out[] = self::singular($p);
            }
        }
        return $out;
    }

    public static function singular(string $w): string
    {
        $len = mb_strlen($w);
        if ($len <= 3 || is_numeric($w)) {
            return $w;
        }
        if (str_ends_with($w, 'ies') && $len > 4) {
            return mb_substr($w, 0, -3) . 'y';
        }
        if (preg_match('/(ss|us|is)$/', $w)) {
            return $w;
        }
        if (preg_match('/(ches|shes|xes|sses)$/', $w)) {
            return mb_substr($w, 0, -2);
        }
        if (str_ends_with($w, 's')) {
            return mb_substr($w, 0, -1);
        }
        return $w;
    }

    /**
     * @return array{recipient:?string, occasion:?string, interests:string[], categories:string[], prefs:string[],
     *   flags:string[], age_min_months:?int, age_max_months:?int, min_price:?float, max_price:?float,
     *   keywords:string[], corrections:array<string,string>, matched:string[]}
     */
    public function parse(string $query): array
    {
        $result = [
            'recipient' => null, 'occasion' => null, 'interests' => [], 'categories' => [], 'prefs' => [], 'flags' => [],
            'age_min_months' => null, 'age_max_months' => null, 'min_price' => null, 'max_price' => null,
            'keywords' => [], 'corrections' => [], 'matched' => [],
        ];
        $text = mb_strtolower(trim($query));
        $text = $this->extractPrices($text, $result);
        $tokens = self::tokens($text);

        // Typo correction for tokens unknown to the vocabulary.
        foreach ($tokens as $i => $t) {
            if (isset($this->words[$t]) || in_array($t, self::STOPWORDS, true) || mb_strlen($t) < 4 || is_numeric($t)) {
                continue;
            }
            $fix = $this->closestWord($t);
            if ($fix !== null) {
                $result['corrections'][$t] = $fix;
                $tokens[$i] = $fix;
            }
        }

        // Greedy longest-phrase matching.
        $used = array_fill(0, count($tokens), false);
        foreach ($this->phrases as $key => $phrase) {
            $n = count($phrase['tokens']);
            for ($i = 0; $i + $n <= count($tokens); $i++) {
                if (array_slice($tokens, $i, $n) !== $phrase['tokens']) {
                    continue;
                }
                $free = true;
                for ($k = $i; $k < $i + $n; $k++) {
                    $free = $free && !$used[$k];
                }
                if (!$free) {
                    continue;
                }
                for ($k = $i; $k < $i + $n; $k++) {
                    $used[$k] = true;
                }
                $result['matched'][] = $key;
                foreach ($phrase['maps'] as $map) {
                    $this->apply($map, $result);
                }
            }
        }

        foreach ($tokens as $i => $t) {
            if (!$used[$i] && !in_array($t, self::STOPWORDS, true) && !is_numeric($t) && mb_strlen($t) >= 2) {
                $result['keywords'][] = $t;
            }
        }
        $result['interests'] = array_values(array_unique($result['interests']));
        $result['categories'] = array_values(array_unique($result['categories']));
        $result['prefs'] = array_values(array_unique($result['prefs']));
        $result['flags'] = array_values(array_unique($result['flags']));
        $result['keywords'] = array_values(array_unique($result['keywords']));
        return $result;
    }

    private function apply(string $map, array &$r): void
    {
        [$type, $value] = array_pad(explode(':', $map, 2), 2, '');
        switch ($type) {
            case 'recipient':
                $r['recipient'] ??= $value;
                break;
            case 'occasion':
                $r['occasion'] ??= $value;
                break;
            case 'interest':
                $r['interests'][] = $value;
                break;
            case 'category':
                $r['categories'][] = $value;
                break;
            case 'pref':
                $r['prefs'][] = $value;
                break;
            case 'flag':
                $r['flags'][] = $value;
                break;
            case 'agemonths':
                [$a, $b] = array_map('intval', array_pad(explode('-', $value, 2), 2, '1200'));
                if ($r['age_min_months'] === null) {
                    $r['age_min_months'] = $a;
                    $r['age_max_months'] = $b;
                }
                break;
        }
    }

    private function extractPrices(string $text, array &$r): string
    {
        $num = '(?:npr|rs\.?|रु\.?)?\s*([\d,]+(?:\.\d+)?)\s*(k)?\s*(?:npr|rs|rupees?)?';
        $toFloat = static function (string $n, ?string $k): float {
            $v = (float) str_replace(',', '', $n);
            return $k ? $v * 1000 : $v;
        };
        if (preg_match('/(?:between|from)\s+' . $num . '\s*(?:and|to|-|–)\s*' . $num . '/u', $text, $m)) {
            $r['min_price'] = $toFloat($m[1], $m[2] ?? null);
            $r['max_price'] = $toFloat($m[3], $m[4] ?? null);
            return str_replace($m[0], ' ', $text);
        }
        if (preg_match('/(?:npr|rs\.?)\s*([\d,]+)\s*(?:-|–|to)\s*(?:npr|rs\.?)?\s*([\d,]+)/u', $text, $m)) {
            $r['min_price'] = $toFloat($m[1], null);
            $r['max_price'] = $toFloat($m[2], null);
            return str_replace($m[0], ' ', $text);
        }
        if (preg_match('/(?:under|below|less than|up ?to|within|max(?:imum)?|cheaper than|<)\s*' . $num . '/u', $text, $m)) {
            $r['max_price'] = $toFloat($m[1], $m[2] ?? null);
            $text = str_replace($m[0], ' ', $text);
        }
        if (preg_match('/(?:over|above|more than|at least|min(?:imum)?|>)\s*' . $num . '/u', $text, $m)) {
            $r['min_price'] = $toFloat($m[1], $m[2] ?? null);
            $text = str_replace($m[0], ' ', $text);
        }
        return $text;
    }

    /** Closest known word by Levenshtein distance (1 for short words, 2 for 7+ letters). */
    public function closestWord(string $word): ?string
    {
        $max = mb_strlen($word) >= 7 ? 2 : 1;
        $best = null;
        $bestDist = PHP_INT_MAX;
        foreach (array_keys($this->words) as $candidate) {
            if (abs(strlen($candidate) - strlen($word)) > $max || mb_strlen((string) $candidate) < 3) {
                continue;
            }
            $d = levenshtein($word, (string) $candidate);
            if ($d <= $max && ($d < $bestDist || ($d === $bestDist && strcmp((string) $candidate, (string) $best) < 0))) {
                $best = (string) $candidate;
                $bestDist = $d;
            }
        }
        return $best;
    }

    /** Suggest known phrases similar to an unmatched query (for no-result pages). */
    public function suggestPhrases(string $text, int $limit = 5): array
    {
        $tokens = self::tokens($text);
        $scores = [];
        foreach ($this->phrases as $key => $phrase) {
            $score = 0;
            foreach ($tokens as $t) {
                foreach ($phrase['tokens'] as $pt) {
                    if ($t === $pt) {
                        $score += 3;
                    } elseif (mb_strlen($t) >= 4 && (str_starts_with($pt, mb_substr($t, 0, 4)) || levenshtein($t, $pt) <= 2)) {
                        $score += 1;
                    }
                }
            }
            if ($score > 0) {
                $scores[$key] = $score;
            }
        }
        arsort($scores);
        return array_slice(array_keys($scores), 0, $limit);
    }
}
