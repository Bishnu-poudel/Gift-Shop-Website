<?php
declare(strict_types=1);

namespace App\Services\Recommendation;

/**
 * Transparent, rule-based relevance scoring (no machine learning).
 *
 * Each component earns up to its configured weight. Components the shopper did not ask about
 * are left out of the denominator, and products missing optional metadata (e.g. no occasion tags)
 * receive half credit instead of zero, so the final 0-100 score is not unfairly penalised.
 *
 * Product input keys: recipient_slugs[], interest_slugs[], occasion_slugs[], tag_slugs[],
 *   age_min_months, age_max_months, effective_price, sales_count, rating_avg, rating_count, category_id, name, description
 * Criteria keys: recipient, interests[], occasion, age_min_months, age_max_months, min_price, max_price,
 *   prefs[], keywords[], similar (['category_id'=>, 'interest_slugs'=>[]]|null)
 * Context keys: max_sales (int), liked_ids[], disliked_ids[], liked_categories[]
 */
final class Scorer
{
    public const DEFAULT_WEIGHTS = [
        'recipient' => 25, 'interest' => 25, 'occasion' => 15, 'age' => 15,
        'budget' => 10, 'preferences' => 5, 'popularity' => 5,
    ];

    private array $weights;

    public function __construct(array $weights = [])
    {
        $this->weights = array_map('floatval', array_merge(self::DEFAULT_WEIGHTS, array_intersect_key($weights, self::DEFAULT_WEIGHTS)));
    }

    /** @return array{score: float, breakdown: array<string,float>, reasons: string[], matched_interests: string[]} */
    public function score(array $p, array $c, array $ctx = [], array $labels = []): array
    {
        $earned = 0.0;
        $possible = 0.0;
        $breakdown = [];
        $reasons = [];
        $label = static fn (string $type, string $slug) => $labels[$type][$slug] ?? ucwords(str_replace('-', ' ', $slug));

        // Recipient
        if (!empty($c['recipient']) && $c['recipient'] !== 'anyone-else') {
            $w = $this->weights['recipient'];
            $possible += $w;
            $recipients = $p['recipient_slugs'] ?? [];
            if (in_array($c['recipient'], $recipients, true)) {
                $pts = $w;
                $reasons[] = 'Chosen for ' . $label('recipient', $c['recipient']);
            } elseif (in_array('anyone-else', $recipients, true)) {
                $pts = $w * 0.6;
                $reasons[] = 'A crowd-pleaser for anyone';
            } elseif ($recipients === []) {
                $pts = $w * 0.5;
            } else {
                $pts = 0.0;
            }
            $earned += $pts;
            $breakdown['recipient'] = $pts;
        }

        // Interests (partial credit per matched interest, plus keyword hits from custom interests)
        $matchedInterests = [];
        $wantInterests = array_values(array_unique($c['interests'] ?? []));
        $keywords = $c['keywords'] ?? [];
        if ($wantInterests || $keywords) {
            $w = $this->weights['interest'];
            $possible += $w;
            $have = $p['interest_slugs'] ?? [];
            $matchedInterests = array_values(array_intersect($wantInterests, $have));
            $wanted = count($wantInterests) + ($keywords ? 1 : 0);
            $hits = count($matchedInterests);
            if ($keywords) {
                $haystack = mb_strtolower(($p['name'] ?? '') . ' ' . ($p['short_description'] ?? '') . ' ' . implode(' ', $p['tag_names'] ?? []));
                foreach ($keywords as $k) {
                    if ($k !== '' && str_contains($haystack, mb_strtolower($k))) {
                        $hits++;
                        $reasons[] = 'Matches “' . $k . '”';
                        break;
                    }
                }
            }
            // Matching any one interest earns most of the credit; more matches earn the rest.
            $pts = $hits === 0 ? ($have === [] ? $w * 0.3 : 0.0) : $w * min(1.0, 0.7 + 0.3 * (($hits - 1) / max(1, $wanted - 1)));
            if ($wanted === 1 && $hits >= 1) {
                $pts = $w;
            }
            $earned += $pts;
            $breakdown['interest'] = round($pts, 2);
            if ($matchedInterests) {
                $reasons[] = 'Matches ' . implode(', ', array_map(static fn ($s) => $label('interest', $s), $matchedInterests));
            }
        }

        // Occasion
        if (!empty($c['occasion'])) {
            $w = $this->weights['occasion'];
            $possible += $w;
            $occ = $p['occasion_slugs'] ?? [];
            if (in_array($c['occasion'], $occ, true)) {
                $pts = $w;
                $reasons[] = 'Great for ' . $label('occasion', $c['occasion']);
            } else {
                $pts = $occ === [] ? $w * 0.5 : $w * 0.15;
            }
            $earned += $pts;
            $breakdown['occasion'] = $pts;
        }

        // Age suitability (how well the product's range covers the requested range)
        if (isset($c['age_min_months']) && $c['age_min_months'] !== null) {
            $w = $this->weights['age'];
            $possible += $w;
            $pMin = $p['age_min_months'] ?? null;
            $pMax = $p['age_max_months'] ?? null;
            if ($pMin === null && $pMax === null) {
                $pts = $w * 0.5;
            } else {
                $cMin = (int) $c['age_min_months'];
                $cMax = (int) ($c['age_max_months'] ?? 1200);
                $lo = max($cMin, (int) ($pMin ?? 0));
                $hi = min($cMax, (int) ($pMax ?? 1200));
                $span = max(1, $cMax - $cMin);
                $coverage = max(0, $hi - $lo) / $span;
                $pts = $w * (0.6 + 0.4 * min(1.0, $coverage));
                if ($pMin !== null && (int) $pMin <= $cMin) {
                    $reasons[] = 'Age-appropriate (' . self::ageText($pMin, $pMax) . ')';
                }
            }
            $earned += $pts;
            $breakdown['age'] = round($pts, 2);
        }

        // Budget fit (hard-filtered already; reward sitting comfortably inside the range)
        $hasMin = isset($c['min_price']) && $c['min_price'] !== null;
        $hasMax = isset($c['max_price']) && $c['max_price'] !== null;
        if ($hasMin || $hasMax) {
            $w = $this->weights['budget'];
            $possible += $w;
            $price = (float) ($p['effective_price'] ?? 0);
            $min = $hasMin ? (float) $c['min_price'] : 0.0;
            $max = $hasMax ? (float) $c['max_price'] : max($price, $min) * 2;
            $inside = $price >= $min && $price <= $max;
            $pts = $inside ? $w : 0.0;
            if ($inside && $hasMax) {
                $reasons[] = 'Within your ' . ($hasMin ? 'NPR ' . number_format($min) . '–' : 'under NPR ') . number_format($max) . ' budget';
            }
            $earned += $pts;
            $breakdown['budget'] = $pts;
        }

        // Preferences (handmade, eco-friendly, personalized...)
        $prefs = $c['prefs'] ?? [];
        if ($prefs) {
            $w = $this->weights['preferences'];
            $possible += $w;
            $hit = array_values(array_intersect($prefs, $p['tag_slugs'] ?? []));
            if (in_array('personalized', $prefs, true) && !empty($p['is_personalizable']) && !in_array('personalized', $hit, true)) {
                $hit[] = 'personalized';
            }
            $pts = $w * (count($hit) / count($prefs));
            $earned += $pts;
            $breakdown['preferences'] = round($pts, 2);
            if ($hit) {
                $reasons[] = implode(' · ', array_map(static fn ($s) => $label('pref', $s), $hit));
            }
        }

        // Popularity / verified review quality (always applicable)
        $w = $this->weights['popularity'];
        $possible += $w;
        $maxSales = max(1, (int) ($ctx['max_sales'] ?? 1));
        $salesPart = min(1.0, log(1 + (int) ($p['sales_count'] ?? 0)) / log(1 + $maxSales));
        $ratingPart = ((int) ($p['rating_count'] ?? 0)) >= 3 ? ((float) $p['rating_avg']) / 5 : 0.5;
        $pts = $w * (0.6 * $salesPart + 0.4 * $ratingPart);
        $earned += $pts;
        $breakdown['popularity'] = round($pts, 2);

        $score = $possible > 0 ? ($earned / $possible) * 100 : 0.0;

        // Adjustments from feedback and "more like this" (applied after normalisation, clamped 0-100)
        $id = (int) ($p['id'] ?? 0);
        if (in_array($id, $ctx['disliked_ids'] ?? [], true)) {
            $score -= 25;
            $breakdown['feedback'] = -25;
        } elseif (in_array($id, $ctx['liked_ids'] ?? [], true)) {
            $score += 5;
            $breakdown['feedback'] = 5;
        } elseif (in_array((int) ($p['category_id'] ?? 0), $ctx['liked_categories'] ?? [], true)) {
            $score += 2;
            $breakdown['feedback'] = 2;
        }
        if (!empty($c['similar'])) {
            $sim = 0.0;
            if ((int) ($p['category_id'] ?? 0) === (int) ($c['similar']['category_id'] ?? -1)) {
                $sim += 6;
            }
            $shared = count(array_intersect($c['similar']['interest_slugs'] ?? [], $p['interest_slugs'] ?? []));
            $sim += min(9, $shared * 3);
            if ($sim > 0) {
                $score += $sim;
                $breakdown['similar'] = $sim;
                $reasons[] = 'Similar to an item you liked';
            }
        }
        $score = max(0.0, min(100.0, $score));

        return [
            'score' => round($score, 1),
            'breakdown' => $breakdown,
            'reasons' => array_values(array_unique($reasons)),
            'matched_interests' => $matchedInterests,
        ];
    }

    public static function ageText(?int $min, ?int $max): string
    {
        $fmt = static fn (int $m) => $m < 24 ? $m . 'm' : intdiv($m, 12) . 'y';
        if ($max === null || $max >= 1200) {
            return $fmt((int) $min) . '+';
        }
        return $fmt((int) $min) . '–' . $fmt($max);
    }

    public function weights(): array
    {
        return $this->weights;
    }
}
