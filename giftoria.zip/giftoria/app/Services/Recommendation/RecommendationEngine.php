<?php
declare(strict_types=1);

namespace App\Services\Recommendation;

use App\Core\Database;
use App\Repositories\ProductRepository;
use App\Repositories\TaxonomyRepository;
use App\Services\SettingsService;
use App\Services\ShippingService;

/**
 * Gift Finder engine: database-backed hard filtering followed by transparent scoring.
 *
 * 1. Hard constraints (SQL): active, in stock (or backorder), recipient compatibility, age suitability
 *    with toddler safety rules, budget, delivery-area restrictions, hidden-by-user items.
 * 2. Score each candidate with Scorer (weights configurable in Admin > Gift Finder rules).
 * 3. Post-filter on requested delivery date when it can be calculated, then sort with stable tie-breakers.
 */
final class RecommendationEngine
{
    private TaxonomyRepository $tax;

    public function __construct(?TaxonomyRepository $tax = null)
    {
        $this->tax = $tax ?? new TaxonomyRepository();
    }

    /** Validates raw input (query string / form) into a clean criteria array. */
    public function normalize(array $in): array
    {
        $recipients = $this->tax->keyed('recipients');
        $occasions = $this->tax->keyed('occasions');
        $interests = $this->tax->keyed('interests');
        $prefSlugs = array_column($this->tax->preferenceTags(), 'slug');

        $c = [
            'recipient' => null, 'occasion' => null, 'interests' => [], 'custom_interest' => '', 'keywords' => [],
            'age' => null, 'age_min_months' => null, 'age_max_months' => null,
            'budget' => null, 'min_price' => null, 'max_price' => null,
            'prefs' => [], 'gift_wrap' => false, 'district' => null, 'delivery_date' => null,
            'strict_interests' => false, 'similar_to' => null, 'similar' => null, 'corrections' => [],
        ];
        $r = (string) ($in['recipient'] ?? '');
        if (isset($recipients[$r])) {
            $c['recipient'] = $r;
        }
        $o = (string) ($in['occasion'] ?? '');
        if (isset($occasions[$o])) {
            $c['occasion'] = $o;
        }
        foreach ((array) ($in['interests'] ?? []) as $i) {
            if (is_string($i) && isset($interests[$i])) {
                $c['interests'][] = $i;
            }
        }
        foreach ((array) ($in['prefs'] ?? []) as $p) {
            if (is_string($p) && in_array($p, $prefSlugs, true)) {
                $c['prefs'][] = $p;
            }
        }

        // Custom free-text interest: map to known interests (synonyms + typo tolerance), else keywords.
        $custom = trim(mb_substr((string) ($in['custom_interest'] ?? ''), 0, 80));
        if ($custom !== '') {
            $c['custom_interest'] = $custom;
            $parsed = Vocabulary::parser()->parse($custom);
            $c['interests'] = array_merge($c['interests'], $parsed['interests']);
            $c['prefs'] = array_merge($c['prefs'], array_intersect($parsed['prefs'], $prefSlugs));
            $c['keywords'] = $parsed['keywords'];
            $c['corrections'] = $parsed['corrections'];
        }
        $c['interests'] = array_values(array_unique($c['interests']));
        $c['prefs'] = array_values(array_unique($c['prefs']));

        // Age: explicit range, else the recipient's implied range (e.g. baby girl = 0-24 months).
        $age = (string) ($in['age'] ?? '');
        if ($age !== '' && ($range = $this->tax->ageRange($age))) {
            $c['age'] = $age;
            $c['age_min_months'] = (int) $range['min_months'];
            $c['age_max_months'] = (int) $range['max_months'];
        } elseif ($c['recipient'] && $recipients[$c['recipient']]['age_min_months'] !== null) {
            $c['age_min_months'] = (int) $recipients[$c['recipient']]['age_min_months'];
            $c['age_max_months'] = $recipients[$c['recipient']]['age_max_months'] !== null ? (int) $recipients[$c['recipient']]['age_max_months'] : null;
        }

        // Budget: predefined range id or custom min/max.
        $budgetId = (int) ($in['budget'] ?? 0);
        if ($budgetId > 0) {
            foreach ($this->tax->budgets() as $b) {
                if ((int) $b['id'] === $budgetId) {
                    $c['budget'] = $budgetId;
                    $c['min_price'] = (float) $b['min_amount'];
                    $c['max_price'] = $b['max_amount'] !== null ? (float) $b['max_amount'] : null;
                }
            }
        }
        if ($c['budget'] === null) {
            $min = $in['min_price'] ?? '';
            $max = $in['max_price'] ?? '';
            $c['min_price'] = is_numeric($min) && $min >= 0 ? (float) $min : null;
            $c['max_price'] = is_numeric($max) && $max > 0 ? (float) $max : null;
            if ($c['min_price'] !== null && $c['max_price'] !== null && $c['min_price'] > $c['max_price']) {
                [$c['min_price'], $c['max_price']] = [$c['max_price'], $c['min_price']];
            }
        }

        $c['gift_wrap'] = !empty($in['gift_wrap']);
        $c['strict_interests'] = !empty($in['strict_interests']) || (bool) SettingsService::get('reco_require_interest_match', false);
        $district = (string) ($in['district'] ?? '');
        if ($district !== '' && ShippingService::isValidDistrict($district)) {
            $c['district'] = $district;
        }
        $date = (string) ($in['delivery_date'] ?? '');
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) && strtotime($date) !== false) {
            $c['delivery_date'] = $date;
        }
        $sim = (int) ($in['similar_to'] ?? 0);
        if ($sim > 0) {
            $row = Database::fetch('SELECT id, category_id FROM products WHERE id = :id AND status = \'active\'', ['id' => $sim]);
            if ($row) {
                $c['similar_to'] = $sim;
                $c['similar'] = [
                    'category_id' => (int) $row['category_id'],
                    'interest_slugs' => Database::fetchCol('SELECT it.slug FROM product_interests pi JOIN interests it ON it.id = pi.interest_id WHERE pi.product_id = :id', ['id' => $sim]),
                ];
            }
        }
        return $c;
    }

    /**
     * @return array{items: array, total: int, criteria: array, relaxed: string[], suggestions: array}
     */
    public function recommend(array $criteria, string $sort = 'relevance', int $page = 1, int $perPage = 24, ?int $userId = null, ?string $sessionKey = null): array
    {
        $relaxed = [];
        $candidates = $this->candidates($criteria, $userId, $sessionKey);

        // If nothing passes, relax soft-ish constraints step by step and say so (never relax age safety).
        if ($candidates === [] && $criteria['strict_interests']) {
            $criteria['strict_interests'] = false;
            $relaxed[] = 'Showing items beyond your selected interests because none matched exactly.';
            $candidates = $this->candidates($criteria, $userId, $sessionKey);
        }
        if ($candidates === [] && $criteria['max_price'] !== null) {
            $original = $criteria;
            $criteria['max_price'] = $criteria['max_price'] * 1.5;
            $candidates = $this->candidates($criteria, $userId, $sessionKey);
            if ($candidates) {
                $relaxed[] = 'Nothing fit your exact budget, so we included items up to ' . money($criteria['max_price']) . '.';
            } else {
                $criteria = $original;
            }
        }

        $weights = (array) SettingsService::get('reco_weights', Scorer::DEFAULT_WEIGHTS);
        $scorer = new Scorer($weights);
        $ctx = $this->feedbackContext($userId, $sessionKey);
        $ctx['max_sales'] = (int) Database::fetchColumn("SELECT MAX(sales_count) FROM products WHERE status = 'active'");
        $labels = $this->labels();

        $zone = $criteria['district'] ? ShippingService::zoneForDistrict($criteria['district']) : null;
        $scored = [];
        foreach ($candidates as $p) {
            $estimate = ShippingService::estimate((int) $p['lead_time_days'], $zone);
            if ($criteria['delivery_date'] && $estimate && $estimate['earliest'] > $criteria['delivery_date']) {
                continue; // cannot arrive in time
            }
            $s = $scorer->score($p, $criteria, $ctx, $labels);
            $p['score'] = $s['score'];
            $p['score_breakdown'] = $s['breakdown'];
            $p['reasons'] = $s['reasons'];
            $p['delivery_estimate'] = $estimate;
            if ($criteria['gift_wrap'] && !(int) $p['gift_wrap_available']) {
                continue;
            }
            $scored[] = $p;
        }

        usort($scored, static function (array $a, array $b) use ($sort): int {
            $cmp = match ($sort) {
                'price_asc' => (float) $a['effective_price'] <=> (float) $b['effective_price'],
                'price_desc' => (float) $b['effective_price'] <=> (float) $a['effective_price'],
                'popular' => (int) $b['sales_count'] <=> (int) $a['sales_count'],
                'newest' => strcmp((string) $b['created_at'], (string) $a['created_at']),
                'rating' => [(float) $b['rating_avg'], (int) $b['rating_count']] <=> [(float) $a['rating_avg'], (int) $a['rating_count']],
                default => (float) $b['score'] <=> (float) $a['score'],
            };
            // Stable tie-breakers: popularity, then product id.
            return $cmp ?: ((int) $b['sales_count'] <=> (int) $a['sales_count']) ?: ((int) $a['id'] <=> (int) $b['id']);
        });

        $total = count($scored);
        $items = array_slice($scored, (max(1, $page) - 1) * $perPage, $perPage);
        $suggestions = $total === 0 ? $this->suggestions($criteria) : [];

        // A custom interest we could not map to anything: say so instead of silently ignoring it.
        if ($criteria['custom_interest'] !== '' && $criteria['keywords'] && $total > 0) {
            $hit = false;
            foreach ($scored as $p) {
                foreach ($p['reasons'] as $reason) {
                    if (str_starts_with($reason, 'Matches “')) {
                        $hit = true;
                        break 2;
                    }
                }
            }
            if (!$hit) {
                $phrases = Vocabulary::parser()->suggestPhrases($criteria['custom_interest'], 3);
                $relaxed[] = 'We could not find gifts matching “' . $criteria['custom_interest'] . '”, so these are the best matches for your other answers.'
                    . ($phrases ? ' Did you mean: ' . implode(', ', $phrases) . '?' : '');
            }
        }

        return ['items' => $items, 'total' => $total, 'criteria' => $criteria, 'relaxed' => $relaxed, 'suggestions' => $suggestions];
    }

    /** Hard-constraint candidate query with taxonomy slugs aggregated for scoring. */
    public function candidates(array $c, ?int $userId = null, ?string $sessionKey = null): array
    {
        $params = [];
        $where = ["p.status = 'active'", '(p.allow_backorder = 1 OR COALESCE(stock.qty, 0) > 0)'];

        if ($c['recipient'] && $c['recipient'] !== 'anyone-else') {
            $params['rec'] = $c['recipient'];
            $where[] = "EXISTS (SELECT 1 FROM product_recipients pr JOIN recipients r ON r.id = pr.recipient_id
                                WHERE pr.product_id = p.id AND r.slug IN (:rec, 'anyone-else'))";
        }
        if ($c['age_min_months'] !== null) {
            $where[] = ProductRepository::ageCondition((int) $c['age_min_months'], $c['age_max_months'] !== null ? (int) $c['age_max_months'] : null, $params);
        }
        if ($c['min_price'] !== null) {
            $params['minp'] = $c['min_price'];
            $where[] = 'COALESCE(p.sale_price, p.price) >= :minp';
        }
        if ($c['max_price'] !== null) {
            $params['maxp'] = $c['max_price'];
            $where[] = 'COALESCE(p.sale_price, p.price) <= :maxp';
        }
        if ($c['strict_interests'] && $c['interests']) {
            $in = Database::in('si', $c['interests'], $params);
            $where[] = "EXISTS (SELECT 1 FROM product_interests sp JOIN interests sit ON sit.id = sp.interest_id WHERE sp.product_id = p.id AND sit.slug IN $in)";
        }
        if ($c['district'] && !ShippingService::isValleyDistrict($c['district'])) {
            $where[] = 'p.valley_only = 0';
        }
        if ($c['similar_to']) {
            $params['self'] = (int) $c['similar_to'];
            $where[] = 'p.id <> :self';
        }
        // Items the shopper hid are never shown again to them.
        if ($userId || $sessionKey) {
            $hideCond = [];
            if ($userId) {
                $params['hu'] = $userId;
                $hideCond[] = 'rf.user_id = :hu';
            }
            if ($sessionKey) {
                $params['hs'] = $sessionKey;
                $hideCond[] = 'rf.session_key = :hs';
            }
            $where[] = "p.id NOT IN (SELECT rf.product_id FROM recommendation_feedback rf WHERE rf.action = 'hide' AND (" . implode(' OR ', $hideCond) . '))';
        }

        $sql = 'SELECT ' . ProductRepository::CARD_SELECT . ",
                (SELECT GROUP_CONCAT(r2.slug) FROM product_recipients pr2 JOIN recipients r2 ON r2.id = pr2.recipient_id WHERE pr2.product_id = p.id) AS recipient_csv,
                (SELECT GROUP_CONCAT(i2.slug) FROM product_interests pi2 JOIN interests i2 ON i2.id = pi2.interest_id WHERE pi2.product_id = p.id) AS interest_csv,
                (SELECT GROUP_CONCAT(o2.slug) FROM product_occasions po2 JOIN occasions o2 ON o2.id = po2.occasion_id WHERE po2.product_id = p.id) AS occasion_csv,
                (SELECT GROUP_CONCAT(t2.slug) FROM product_tags pt2 JOIN tags t2 ON t2.id = pt2.tag_id WHERE pt2.product_id = p.id) AS tag_csv,
                (SELECT GROUP_CONCAT(t3.name SEPARATOR '|') FROM product_tags pt3 JOIN tags t3 ON t3.id = pt3.tag_id WHERE pt3.product_id = p.id) AS tag_names_csv
            FROM products p
            LEFT JOIN (SELECT product_id, SUM(quantity) AS qty FROM inventory GROUP BY product_id) stock ON stock.product_id = p.id
            WHERE " . implode(' AND ', $where) . '
            LIMIT 1000';

        $rows = Database::fetchAll($sql, $params);
        foreach ($rows as &$row) {
            $row['recipient_slugs'] = self::csv($row['recipient_csv']);
            $row['interest_slugs'] = self::csv($row['interest_csv']);
            $row['occasion_slugs'] = self::csv($row['occasion_csv']);
            $row['tag_slugs'] = self::csv($row['tag_csv']);
            $row['tag_names'] = $row['tag_names_csv'] ? explode('|', (string) $row['tag_names_csv']) : [];
            $row['age_min_months'] = $row['age_min_months'] !== null ? (int) $row['age_min_months'] : null;
            $row['age_max_months'] = $row['age_max_months'] !== null ? (int) $row['age_max_months'] : null;
            unset($row['recipient_csv'], $row['interest_csv'], $row['occasion_csv'], $row['tag_csv'], $row['tag_names_csv']);
        }
        return $rows;
    }

    private static function csv(?string $v): array
    {
        return $v ? array_values(array_filter(explode(',', $v))) : [];
    }

    private function labels(): array
    {
        $out = [];
        foreach (['recipients' => 'recipient', 'occasions' => 'occasion', 'interests' => 'interest'] as $t => $k) {
            foreach ($this->tax->all($t) as $row) {
                $out[$k][$row['slug']] = $row['name'];
            }
        }
        foreach ($this->tax->preferenceTags() as $t) {
            $out['pref'][$t['slug']] = $t['name'];
        }
        return $out;
    }

    /** Like/dislike signals for this shopper (only if personalization is allowed). */
    private function feedbackContext(?int $userId, ?string $sessionKey): array
    {
        $ctx = ['liked_ids' => [], 'disliked_ids' => [], 'liked_categories' => []];
        if (!SettingsService::get('reco_feedback_enabled', true)) {
            return $ctx;
        }
        if ($userId) {
            $allowed = Database::fetchColumn('SELECT personalization_enabled FROM customer_profiles WHERE user_id = :u', ['u' => $userId]);
            if ($allowed !== null && (int) $allowed === 0) {
                return $ctx;
            }
        }
        $cond = [];
        $params = [];
        if ($userId) {
            $cond[] = 'rf.user_id = :u';
            $params['u'] = $userId;
        }
        if ($sessionKey) {
            $cond[] = 'rf.session_key = :s';
            $params['s'] = $sessionKey;
        }
        if (!$cond) {
            return $ctx;
        }
        $rows = Database::fetchAll(
            'SELECT rf.product_id, rf.action, p.category_id FROM recommendation_feedback rf JOIN products p ON p.id = rf.product_id
             WHERE (' . implode(' OR ', $cond) . ') AND rf.created_at >= (UTC_TIMESTAMP() - INTERVAL 180 DAY)
             ORDER BY rf.id DESC LIMIT 300',
            $params
        );
        foreach ($rows as $r) {
            $pid = (int) $r['product_id'];
            if (in_array($r['action'], ['like', 'wishlist', 'more_like_this'], true)) {
                $ctx['liked_ids'][] = $pid;
                $ctx['liked_categories'][] = (int) $r['category_id'];
            } elseif ($r['action'] === 'dislike') {
                $ctx['disliked_ids'][] = $pid;
            }
        }
        $ctx['liked_ids'] = array_values(array_unique(array_diff($ctx['liked_ids'], $ctx['disliked_ids'])));
        $ctx['liked_categories'] = array_values(array_unique($ctx['liked_categories']));
        return $ctx;
    }

    /** Helpful alternatives when nothing matches. */
    public function suggestions(array $c): array
    {
        $out = ['phrases' => [], 'interests' => [], 'popular' => []];
        if ($c['custom_interest'] !== '') {
            $out['phrases'] = Vocabulary::parser()->suggestPhrases($c['custom_interest']);
        }
        // Interests that DO have products for this recipient/age.
        $params = [];
        $where = ["p.status = 'active'"];
        if ($c['recipient'] && $c['recipient'] !== 'anyone-else') {
            $params['rec'] = $c['recipient'];
            $where[] = 'EXISTS (SELECT 1 FROM product_recipients pr JOIN recipients r ON r.id = pr.recipient_id WHERE pr.product_id = p.id AND r.slug = :rec)';
        }
        if ($c['age_min_months'] !== null) {
            $where[] = ProductRepository::ageCondition((int) $c['age_min_months'], $c['age_max_months'], $params);
        }
        $out['interests'] = Database::fetchAll(
            'SELECT it.name, it.slug, COUNT(*) AS n FROM product_interests pi JOIN interests it ON it.id = pi.interest_id
             JOIN products p ON p.id = pi.product_id WHERE ' . implode(' AND ', $where) . '
             GROUP BY it.id ORDER BY n DESC LIMIT 8',
            $params
        );
        $out['popular'] = (new ProductRepository())->flagged('bestseller', 4);
        return $out;
    }

    /** Persists the finder run for analytics/history (no personal data beyond user id). */
    public function logSession(array $criteria, int $resultCount, ?int $userId, string $sessionKey): void
    {
        $keep = array_intersect_key($criteria, array_flip(['recipient', 'occasion', 'interests', 'custom_interest', 'age', 'min_price', 'max_price', 'prefs', 'gift_wrap', 'district', 'delivery_date']));
        Database::insert('gift_finder_sessions', [
            'user_id' => $userId,
            'session_key' => $sessionKey,
            'criteria_json' => json_encode($keep, JSON_UNESCAPED_UNICODE),
            'result_count' => $resultCount,
        ]);
    }

    /** Records feedback. Returns false for unknown products/actions. */
    public function recordFeedback(int $productId, string $action, ?int $userId, string $sessionKey, array $context = []): bool
    {
        if (!in_array($action, ['like', 'dislike', 'hide', 'more_like_this', 'wishlist'], true)) {
            return false;
        }
        if (!Database::fetchColumn("SELECT 1 FROM products WHERE id = :id AND status = 'active'", ['id' => $productId])) {
            return false;
        }
        // like/dislike are mutually exclusive: replace the previous opinion.
        if (in_array($action, ['like', 'dislike'], true)) {
            $params = ['p' => $productId, 's' => $sessionKey];
            $userCond = '';
            if ($userId) {
                $params['u'] = $userId;
                $userCond = ' OR user_id = :u';
            }
            Database::query("DELETE FROM recommendation_feedback WHERE product_id = :p AND action IN ('like','dislike') AND (session_key = :s$userCond)", $params);
        }
        Database::insert('recommendation_feedback', [
            'user_id' => $userId,
            'session_key' => $sessionKey,
            'product_id' => $productId,
            'action' => $action,
            'context_json' => $context ? json_encode(array_slice($context, 0, 10), JSON_UNESCAPED_UNICODE) : null,
        ]);
        return true;
    }
}
