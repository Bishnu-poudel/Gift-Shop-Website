<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

final class WishlistService
{
    /** Default wishlist id for a customer (created on demand). */
    public function defaultId(int $userId): int
    {
        $id = Database::fetchColumn('SELECT id FROM wishlists WHERE user_id = :u AND gift_recipient_id IS NULL ORDER BY id LIMIT 1', ['u' => $userId]);
        return $id ? (int) $id : Database::insert('wishlists', ['user_id' => $userId, 'name' => 'My Wishlist']);
    }

    /** Wishlist owned by the user (or null). */
    public function owned(int $wishlistId, int $userId): ?array
    {
        return Database::fetch('SELECT * FROM wishlists WHERE id = :id AND user_id = :u', ['id' => $wishlistId, 'u' => $userId]);
    }

    /** Toggle a product; returns true if now saved. */
    public function toggle(int $userId, int $productId, ?int $wishlistId = null): bool
    {
        $wishlistId = $wishlistId && $this->owned($wishlistId, $userId) ? $wishlistId : $this->defaultId($userId);
        if (!Database::fetchColumn("SELECT 1 FROM products WHERE id = :id AND status = 'active'", ['id' => $productId])) {
            return false;
        }
        $exists = Database::fetchColumn('SELECT id FROM wishlist_items WHERE wishlist_id = :w AND product_id = :p', ['w' => $wishlistId, 'p' => $productId]);
        if ($exists) {
            Database::delete('wishlist_items', ['id' => (int) $exists]);
            return false;
        }
        Database::insert('wishlist_items', ['wishlist_id' => $wishlistId, 'product_id' => $productId]);
        return true;
    }

    /** Product ids saved in any of the user's wishlists (for heart icons). */
    public function savedProductIds(?int $userId): array
    {
        if (!$userId) {
            return [];
        }
        return array_map('intval', Database::fetchCol(
            'SELECT DISTINCT wi.product_id FROM wishlist_items wi JOIN wishlists w ON w.id = wi.wishlist_id WHERE w.user_id = :u',
            ['u' => $userId]
        ));
    }

    public function items(int $wishlistId): array
    {
        return Database::fetchAll(
            'SELECT ' . \App\Repositories\ProductRepository::CARD_SELECT . ', wi.id AS wishlist_item_id, wi.created_at AS saved_at
             FROM wishlist_items wi JOIN products p ON p.id = wi.product_id
             WHERE wi.wishlist_id = :w ORDER BY wi.id DESC',
            ['w' => $wishlistId]
        );
    }
}
