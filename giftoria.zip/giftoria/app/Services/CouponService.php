<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

/**
 * Coupon validation and discount calculation. Only one coupon per order (no stacking).
 * validate() is used for previews; OrderService re-validates under a row lock when placing the order.
 */
final class CouponService
{
    public function findByCode(string $code, bool $lock = false): ?array
    {
        return Database::fetch('SELECT * FROM coupons WHERE code = :c' . ($lock ? ' FOR UPDATE' : ''), ['c' => strtoupper(trim($code))]);
    }

    /**
     * @param array $lines cart lines with product_id, category_id, line_total
     * @return array{ok: bool, message: string, discount: float, free_shipping: bool, coupon: ?array}
     */
    public function evaluate(?array $coupon, array $lines, float $subtotal, ?int $userId, ?string $email): array
    {
        $fail = static fn (string $m) => ['ok' => false, 'message' => $m, 'discount' => 0.0, 'free_shipping' => false, 'coupon' => null];
        if (!$coupon || !(int) $coupon['is_active']) {
            return $fail('This coupon code is not valid.');
        }
        $now = gmdate('Y-m-d H:i:s');
        if ($coupon['starts_at'] && $coupon['starts_at'] > $now) {
            return $fail('This coupon is not active yet.');
        }
        if ($coupon['ends_at'] && $coupon['ends_at'] < $now) {
            return $fail('This coupon has expired.');
        }
        if ($coupon['usage_limit'] !== null && (int) $coupon['used_count'] >= (int) $coupon['usage_limit']) {
            return $fail('This coupon has reached its usage limit.');
        }
        if ($coupon['per_customer_limit'] !== null && ($userId || $email)) {
            $params = ['c' => (int) $coupon['id'], 'e' => (string) $email];
            $userCond = '';
            if ($userId) {
                $params['u'] = $userId;
                $userCond = ' OR cr.user_id = :u';
            }
            $used = (int) Database::fetchColumn(
                "SELECT COUNT(*) FROM coupon_redemptions cr JOIN orders o ON o.id = cr.order_id
                 WHERE cr.coupon_id = :c AND o.status <> 'cancelled' AND (cr.email = :e$userCond)",
                $params
            );
            if ($used >= (int) $coupon['per_customer_limit']) {
                return $fail('You have already used this coupon.');
            }
        }
        if ($subtotal < (float) $coupon['min_subtotal']) {
            return $fail('Spend at least ' . money($coupon['min_subtotal']) . ' to use this coupon.');
        }

        // Eligible base for product/category-scoped coupons
        $eligible = $subtotal;
        if ($coupon['applies_to'] !== 'all') {
            $ids = array_map('intval', array_filter(explode(',', (string) ($coupon['applies_to'] === 'products' ? $coupon['product_ids'] : $coupon['category_ids']))));
            $eligible = 0.0;
            foreach ($lines as $l) {
                $key = $coupon['applies_to'] === 'products' ? (int) $l['product_id'] : (int) ($l['category_id'] ?? 0);
                if (in_array($key, $ids, true)) {
                    $eligible += (float) $l['line_total'];
                }
            }
            if ($eligible <= 0) {
                return $fail('This coupon does not apply to the items in your bag.');
            }
        }

        $discount = 0.0;
        $free = false;
        switch ($coupon['type']) {
            case 'percent':
                $discount = round($eligible * min(100, (float) $coupon['value']) / 100, 2);
                break;
            case 'fixed':
                $discount = min($eligible, (float) $coupon['value']);
                break;
            case 'free_shipping':
                $free = true;
                break;
        }
        if ($coupon['max_discount'] !== null && $discount > (float) $coupon['max_discount']) {
            $discount = (float) $coupon['max_discount'];
        }
        $discount = min($discount, $subtotal);
        return ['ok' => true, 'message' => 'Coupon applied.', 'discount' => $discount, 'free_shipping' => $free, 'coupon' => $coupon];
    }
}
