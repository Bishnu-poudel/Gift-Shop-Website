<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

/** Admin-editable key/value settings (site_settings). Values are JSON-decoded when possible. */
final class SettingsService
{
    private static ?array $cache = null;

    public const DEFAULTS = [
        'store_name' => 'Giftoria',
        'store_email' => 'hello@giftoria.local',
        'store_phone' => '+977-1-5900000',
        'store_address' => 'Jhamsikhel, Lalitpur 44600, Nepal',
        'announcement_text' => 'Free delivery inside Kathmandu Valley on orders above NPR 3,000 · Gift wrapping available',
        'announcement_enabled' => true,
        'gift_wrap_fee' => 150,
        'cod_max_order' => 25000,
        'low_stock_alert_email' => '',
        'social_facebook' => '',
        'social_instagram' => '',
        // Billing & tax (Admin > Settings > Billing & tax)
        'business_legal_name' => '',
        'store_pan' => '',
        'store_vat_number' => '',
        'vat_registered' => false,
        'vat_rate' => 13,
        'prices_include_vat' => true,
        'bill_prefix' => 'GFT',
        'bill_footer' => 'Thank you for shopping with us. Goods once sold are exchangeable within 7 days of delivery as per our returns policy.',
        'store_logo' => '',
        'show_logo_in_header' => true,
        'reco_weights' => [
            'recipient' => 25, 'interest' => 25, 'occasion' => 15, 'age' => 15,
            'budget' => 10, 'preferences' => 5, 'popularity' => 5,
        ],
        'reco_require_interest_match' => false,
        'reco_feedback_enabled' => true,
        'review_auto_approve_verified' => false,
    ];

    public static function all(): array
    {
        if (self::$cache === null) {
            self::$cache = self::DEFAULTS;
            try {
                foreach (Database::fetchAll('SELECT setting_key, value FROM site_settings') as $row) {
                    $decoded = json_decode((string) $row['value'], true);
                    self::$cache[$row['setting_key']] = json_last_error() === JSON_ERROR_NONE ? $decoded : $row['value'];
                }
            } catch (\Throwable) {
                // DB not installed yet: defaults only.
            }
        }
        return self::$cache;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $all = self::all();
        return array_key_exists($key, $all) ? $all[$key] : $default;
    }

    public static function set(string $key, mixed $value, string $group = 'general'): void
    {
        Database::query(
            'INSERT INTO site_settings (setting_key, value, group_name) VALUES (:k, :v, :g)
             ON DUPLICATE KEY UPDATE value = VALUES(value), group_name = VALUES(group_name)',
            ['k' => $key, 'v' => json_encode($value, JSON_UNESCAPED_UNICODE), 'g' => $group]
        );
        self::$cache = null;
    }

    public static function flush(): void
    {
        self::$cache = null;
    }
}
