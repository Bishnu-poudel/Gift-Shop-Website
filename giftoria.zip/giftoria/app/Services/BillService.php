<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\View;

/**
 * Bills (invoices). A bill number is issued when the order is placed — before payment — so the
 * customer can review and download the bill on the payment page. Its title follows the order state:
 *   - awaiting payment  → "Proforma invoice" (not a tax invoice; payment pending)
 *   - confirmed / paid  → "Tax invoice" (VAT-registered seller) or "Invoice" (PAN-only seller)
 *   - cancelled         → marked CANCELLED (the number is kept; bills are never deleted or reused)
 * Seller details are snapshotted on the order so later settings changes don't alter issued bills.
 */
final class BillService
{
    /** Issues the next bill number for the current fiscal year. Must run inside a transaction. */
    public static function assignNumber(int $orderId): string
    {
        return Database::transaction(static function () use ($orderId) {
            $existing = Database::fetchColumn('SELECT bill_number FROM orders WHERE id = :id FOR UPDATE', ['id' => $orderId]);
            if ($existing) {
                return (string) $existing;
            }
            $fy = TaxService::fiscalYear();
            Database::query('INSERT IGNORE INTO bill_sequences (fiscal_year, last_number) VALUES (:fy, 0)', ['fy' => $fy]);
            $last = (int) Database::fetchColumn('SELECT last_number FROM bill_sequences WHERE fiscal_year = :fy FOR UPDATE', ['fy' => $fy]);
            $next = $last + 1;
            Database::update('bill_sequences', ['last_number' => $next], ['fiscal_year' => $fy]);
            $prefix = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) setting('bill_prefix', 'GFT')) ?: 'INV');
            $number = sprintf('%s-%s-%06d', $prefix, $fy, $next);
            Database::update('orders', ['bill_number' => $number, 'bill_issued_at' => Database::now()], ['id' => $orderId]);
            return $number;
        });
    }

    /** Document title shown on the bill for the order's current state. */
    public static function title(array $order, array $seller): string
    {
        if (in_array($order['status'], ['cancelled'], true)) {
            return 'Cancelled invoice';
        }
        if ($order['status'] === 'pending_payment') {
            return 'Proforma invoice';
        }
        return !empty($seller['vat_registered']) ? 'Tax invoice' : 'Invoice';
    }

    public static function seller(array $order): array
    {
        $snap = $order['seller_snapshot'] ? json_decode((string) $order['seller_snapshot'], true) : null;
        $seller = is_array($snap) ? $snap : TaxService::sellerSnapshot();
        // The logo is presentation, not a tax detail: always use the current one if the snapshot has none.
        if (empty($seller['logo'])) {
            $seller['logo'] = (string) setting('store_logo', '');
        }
        return $seller;
    }

    /**
     * Renders the printable bill. $audience: customer|guest|admin (admin view adds internal ids only).
     * @param array{back_url?: string, pay_url?: ?string} $links
     */
    public static function render(array $order, string $audience = 'customer', array $links = []): string
    {
        $orders = new OrderService();
        if (!$order['bill_number']) {
            // Orders placed before billing was introduced get a number the first time a bill is viewed.
            self::assignNumber((int) $order['id']);
            $order = $orders->find((int) $order['id']);
        }
        $seller = self::seller($order);
        return View::render('bill/document', [
            'order' => $order,
            'items' => $orders->items((int) $order['id']),
            'shipping' => $orders->address((int) $order['id'], 'shipping'),
            'billing' => $orders->address((int) $order['id'], 'billing'),
            'seller' => $seller,
            'docTitle' => self::title($order, $seller),
            'words' => TaxService::amountInWords((float) $order['grand_total']),
            'fiscalYear' => self::fiscalYearOf((string) $order['bill_number']),
            'audience' => $audience,
            'backUrl' => $links['back_url'] ?? null,
            'payUrl' => $links['pay_url'] ?? null,
        ], null);
    }

    private static function fiscalYearOf(string $billNumber): string
    {
        return preg_match('#-(\d{4}/\d{2})-#', $billNumber, $m) ? $m[1] : TaxService::fiscalYear();
    }
}
