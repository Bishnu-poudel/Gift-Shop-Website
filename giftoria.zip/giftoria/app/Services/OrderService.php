<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\AuditLogger;
use App\Core\Database;
use App\Core\Logger;
use DomainException;
use RuntimeException;

/**
 * Order lifecycle. Order creation is one transaction: totals are recomputed, stock is locked and
 * deducted (so the last unit can only be sold once), the coupon row is locked and re-checked.
 * Unpaid online orders hold their stock until PAYMENT_TIMEOUT_MINUTES, then are cancelled and the
 * stock released exactly once (guarded by orders.stock_released).
 */
final class OrderService
{
    private InventoryService $inventory;
    private PricingService $pricing;
    private CouponService $coupons;

    public function __construct(?InventoryService $inventory = null, ?PricingService $pricing = null, ?CouponService $coupons = null)
    {
        $this->inventory = $inventory ?? new InventoryService();
        $this->pricing = $pricing ?? new PricingService();
        $this->coupons = $coupons ?? new CouponService();
    }

    public static function generateNumber(): string
    {
        do {
            $n = 'GFT-' . gmdate('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
        } while (Database::fetchColumn('SELECT 1 FROM orders WHERE order_number = :n', ['n' => $n]));
        return $n;
    }

    public static function availablePaymentMethods(?array $zone, float $total): array
    {
        $methods = [];
        if (config('payments.esewa.enabled')) {
            $methods['esewa'] = 'eSewa';
        }
        if (config('payments.khalti.enabled')) {
            $methods['khalti'] = 'Khalti';
        }
        if (config('payments.cod.enabled') && $zone && (int) $zone['cod_available'] && $total <= (float) setting('cod_max_order', 25000)) {
            $methods['cod'] = 'Cash on delivery';
        }
        return $methods;
    }

    /**
     * @param array $data validated checkout data: customer_name, email, phone, payment_method, shipping (address array),
     *   billing (address array|null), gift_wrap, gift_message, customer_note, requested_delivery_date, coupon_code,
     *   checkout_token, user_id, source ('web'|'manual'), created_by
     * @param array $lines CartService::lines() rows (or equivalent for manual orders)
     * @throws RuntimeException|DomainException
     */
    public function place(array $data, array $lines): array
    {
        if ($lines === []) {
            throw new RuntimeException('Your bag is empty.');
        }
        // Idempotency: a resubmitted checkout returns the order already created for that token.
        if (!empty($data['checkout_token'])) {
            $existing = Database::fetch('SELECT * FROM orders WHERE checkout_token = :t', ['t' => $data['checkout_token']]);
            if ($existing) {
                return $existing;
            }
        }

        $orderId = Database::transaction(function () use ($data, $lines) {
            $district = $data['shipping']['district'];
            $totals = $this->pricing->calculate($lines, [
                'coupon_code' => $data['coupon_code'] ?? null,
                'gift_wrap' => !empty($data['gift_wrap']),
                'district' => $district,
                'user_id' => $data['user_id'] ?? null,
                'email' => $data['email'],
            ]);
            if ($totals['issues']) {
                throw new RuntimeException($totals['issues'][0]['message']);
            }
            if (!$totals['shipping_known']) {
                throw new RuntimeException('We do not deliver to the selected district yet.');
            }
            $methods = self::availablePaymentMethods($totals['zone'], $totals['grand_total']);
            if (!isset($methods[$data['payment_method']])) {
                throw new RuntimeException('The selected payment method is not available for this order.');
            }

            // Lock and re-check the coupon so usage limits cannot be exceeded concurrently.
            $coupon = null;
            if ($totals['coupon_code']) {
                $coupon = $this->coupons->findByCode($totals['coupon_code'], true);
                $check = $this->coupons->evaluate($coupon, $totals['lines'], $totals['subtotal'], $data['user_id'] ?? null, $data['email']);
                if (!$check['ok']) {
                    throw new RuntimeException($check['message']);
                }
            } elseif (!empty($data['coupon_code'])) {
                throw new RuntimeException($totals['coupon']['message'] ?? 'This coupon code is not valid.');
            }

            $isCod = $data['payment_method'] === 'cod';
            $orderId = Database::insert('orders', [
                'order_number' => self::generateNumber(),
                'user_id' => $data['user_id'] ?? null,
                'customer_name' => $data['customer_name'],
                'email' => mb_strtolower($data['email']),
                'phone' => $data['phone'],
                'status' => $isCod ? 'confirmed' : 'pending_payment',
                'payment_status' => $isCod ? 'pending' : 'initiated',
                'payment_method' => $data['payment_method'],
                'subtotal' => $totals['subtotal'],
                'discount_total' => $totals['discount'],
                'shipping_total' => $totals['shipping'],
                'gift_wrap_total' => $totals['gift_wrap'],
                'grand_total' => $totals['grand_total'],
                'vat_registered' => $totals['tax']['registered'] ? 1 : 0,
                'vat_rate' => $totals['tax']['rate'],
                'prices_include_vat' => $totals['tax']['inclusive'] ? 1 : 0,
                'taxable_amount' => $totals['tax']['taxable'],
                'vat_amount' => $totals['tax']['vat'],
                'buyer_pan' => !empty($data['buyer_pan']) ? $data['buyer_pan'] : null,
                'buyer_company' => !empty($data['buyer_company']) ? $data['buyer_company'] : null,
                'seller_snapshot' => json_encode(TaxService::sellerSnapshot(), JSON_UNESCAPED_UNICODE),
                'coupon_id' => $coupon['id'] ?? null,
                'coupon_code' => $totals['coupon_code'],
                'delivery_zone_id' => $totals['zone']['id'] ?? null,
                'gift_wrap' => $totals['gift_wrap'] > 0 ? 1 : 0,
                'gift_message' => $data['gift_message'] ?: null,
                'customer_note' => $data['customer_note'] ?? null,
                'requested_delivery_date' => $data['requested_delivery_date'] ?: null,
                'checkout_token' => $data['checkout_token'] ?? null,
                'access_token' => random_token(),
                'source' => $data['source'] ?? 'web',
                'created_by' => $data['created_by'] ?? null,
                'expires_at' => $isCod ? null : gmdate('Y-m-d H:i:s', time() + 60 * (int) config('app.payment_timeout_minutes', 90)),
            ]);

            foreach ($totals['lines'] as $l) {
                $this->inventory->change((int) $l['product_id'], (int) $l['variant_id'], -(int) $l['quantity'], 'sale', 'order', $orderId, $data['created_by'] ?? null);
                Database::insert('order_items', [
                    'order_id' => $orderId,
                    'product_id' => (int) $l['product_id'],
                    'variant_id' => (int) $l['variant_id'],
                    'sku' => $l['variant_sku'] ?? $l['sku'],
                    'name' => $l['name'],
                    'variant_name' => $l['variant_name'] ?? null,
                    'unit_price' => $l['unit_price'],
                    'unit_cost' => $l['cost_price'] ?? null,
                    'quantity' => (int) $l['quantity'],
                    'line_total' => $l['line_total'],
                    'personalization' => $l['personalization'] ?? null,
                ]);
            }

            foreach (['shipping' => $data['shipping'], 'billing' => $data['billing'] ?? null] as $type => $addr) {
                if (!$addr) {
                    continue;
                }
                Database::insert('order_addresses', [
                    'order_id' => $orderId, 'type' => $type,
                    'full_name' => $addr['full_name'], 'phone' => $addr['phone'], 'province' => $addr['province'],
                    'district' => $addr['district'], 'municipality' => $addr['municipality'], 'ward' => $addr['ward'] ?: null,
                    'street' => $addr['street'] ?: null, 'landmark' => $addr['landmark'] ?: null,
                ]);
            }

            if ($coupon) {
                Database::insert('coupon_redemptions', [
                    'coupon_id' => (int) $coupon['id'], 'order_id' => $orderId, 'user_id' => $data['user_id'] ?? null,
                    'email' => mb_strtolower($data['email']), 'discount' => $totals['discount'],
                ]);
                Database::query('UPDATE coupons SET used_count = used_count + 1 WHERE id = :id', ['id' => (int) $coupon['id']]);
            }

            // The bill is issued with the order (before payment) so it can be reviewed on the payment page.
            BillService::assignNumber($orderId);
            $this->history($orderId, 'status', null, $isCod ? 'confirmed' : 'pending_payment', 'Order placed', $data['created_by'] ?? null);
            if ($isCod) {
                $this->onConfirmed($orderId);
            }
            return $orderId;
        });

        $order = $this->find($orderId);
        Analytics::increment('orders');
        if ($order['payment_method'] === 'cod') {
            (new MailService())->orderEmail('order_confirmation', $order);
        }
        return $order;
    }

    public function find(int $id): ?array
    {
        return Database::fetch('SELECT * FROM orders WHERE id = :id', ['id' => $id]);
    }

    public function findByNumber(string $number): ?array
    {
        return Database::fetch('SELECT * FROM orders WHERE order_number = :n', ['n' => $number]);
    }

    public function items(int $orderId): array
    {
        return Database::fetchAll(
            'SELECT oi.*, p.slug, (SELECT pi.path FROM product_images pi WHERE pi.product_id = oi.product_id ORDER BY pi.sort_order, pi.id LIMIT 1) AS image
             FROM order_items oi LEFT JOIN products p ON p.id = oi.product_id WHERE oi.order_id = :id ORDER BY oi.id',
            ['id' => $orderId]
        );
    }

    public function address(int $orderId, string $type = 'shipping'): ?array
    {
        return Database::fetch('SELECT * FROM order_addresses WHERE order_id = :id AND type = :t', ['id' => $orderId, 't' => $type]);
    }

    public function history(int $orderId, string $field, ?string $from, string $to, ?string $note = null, ?int $userId = null): void
    {
        Database::insert('order_status_history', [
            'order_id' => $orderId, 'field' => $field, 'from_status' => $from, 'to_status' => $to,
            'note' => $note !== null ? mb_substr($note, 0, 500) : null, 'user_id' => $userId,
        ]);
    }

    /**
     * Moves an order to a new status with server-side transition rules and side effects.
     * @throws DomainException when the transition is not permitted
     */
    public function transition(int $orderId, string $to, ?int $userId = null, ?string $note = null): array
    {
        $result = Database::transaction(function () use ($orderId, $to, $userId, $note) {
            $order = Database::fetch('SELECT * FROM orders WHERE id = :id FOR UPDATE', ['id' => $orderId]);
            if (!$order) {
                throw new DomainException('Order not found.');
            }
            $from = $order['status'];
            OrderStateMachine::assertOrder($from, $to);
            $update = ['status' => $to];
            if ($to === 'cancelled') {
                $update['cancelled_at'] = Database::now();
            }
            if ($to === 'delivered' && $from !== 'return_requested') {
                $update['delivered_at'] = Database::now();
            }
            Database::update('orders', $update, ['id' => $orderId]);
            $this->history($orderId, 'status', $from, $to, $note, $userId);

            if ($to === 'confirmed') {
                $this->onConfirmed($orderId);
            }
            if ($to === 'cancelled') {
                $this->releaseStock($order, $userId, 'Order cancelled');
                if ($order['coupon_id']) {
                    Database::query('UPDATE coupons SET used_count = GREATEST(used_count - 1, 0) WHERE id = :id', ['id' => (int) $order['coupon_id']]);
                }
                if ($order['payment_status'] === 'paid') {
                    $this->setPaymentStatus($orderId, 'refund_pending', 'Cancelled after payment — refund required', $userId);
                    Database::insert('refunds', [
                        'order_id' => $orderId,
                        'payment_id' => Database::fetchColumn("SELECT id FROM payments WHERE order_id = :o AND status = 'refund_pending' ORDER BY id DESC LIMIT 1", ['o' => $orderId])
                            ?: Database::fetchColumn("SELECT id FROM payments WHERE order_id = :o AND verified_at IS NOT NULL ORDER BY id DESC LIMIT 1", ['o' => $orderId]),
                        'amount' => $order['grand_total'],
                        'reason' => 'Order cancelled after payment',
                        'status' => 'requested',
                        'requested_by' => $userId,
                    ]);
                    Database::update('orders', ['status' => 'refund_pending'], ['id' => $orderId]);
                    $this->history($orderId, 'status', 'cancelled', 'refund_pending', 'Awaiting refund', $userId);
                } elseif (in_array($order['payment_status'], ['initiated', 'pending'], true) && $order['payment_method'] !== 'cod') {
                    $this->setPaymentStatus($orderId, 'cancelled', 'Order cancelled before payment', $userId);
                } elseif ($order['payment_method'] === 'cod' && $order['payment_status'] === 'pending') {
                    $this->setPaymentStatus($orderId, 'cancelled', 'COD order cancelled', $userId);
                }
            }
            if ($to === 'delivered' && $order['payment_method'] === 'cod' && $order['payment_status'] === 'pending') {
                $this->setPaymentStatus($orderId, 'paid', 'Cash collected on delivery', $userId);
                Database::update('orders', ['paid_at' => Database::now()], ['id' => $orderId]);
                Database::insert('payments', [
                    'order_id' => $orderId, 'gateway' => 'cod', 'attempt_ref' => $order['order_number'] . '-COD',
                    'amount' => $order['grand_total'], 'status' => 'paid', 'gateway_status' => 'COLLECTED', 'verified_at' => Database::now(),
                ]);
            }
            if ($to === 'returned') {
                foreach (Database::fetchAll('SELECT * FROM order_items WHERE order_id = :o', ['o' => $orderId]) as $item) {
                    if ($item['product_id']) {
                        $this->inventory->change((int) $item['product_id'], (int) $item['variant_id'], (int) $item['quantity'], 'return', 'order', $orderId, $userId, 'Customer return');
                    }
                }
            }
            return ['from' => $from, 'order' => $order];
        });

        AuditLogger::log('order.status', 'order', $orderId, ['status' => $result['from']], ['status' => $to, 'note' => $note], $userId);
        $order = $this->find($orderId);
        $mail = new MailService();
        match ($to) {
            'shipped' => $mail->orderEmail('order_shipped', $order),
            'delivered' => $result['from'] !== 'return_requested' ? $mail->orderEmail('order_delivered', $order) : null,
            'cancelled' => $mail->orderEmail('order_cancelled', $order),
            'refunded' => $mail->orderEmail('refund_update', $order),
            default => null,
        };
        return $order;
    }

    public function setPaymentStatus(int $orderId, string $to, ?string $note = null, ?int $userId = null): void
    {
        $order = Database::fetch('SELECT id, payment_status FROM orders WHERE id = :id FOR UPDATE', ['id' => $orderId]);
        if (!$order || $order['payment_status'] === $to) {
            return;
        }
        OrderStateMachine::assertPayment($order['payment_status'], $to);
        Database::update('orders', ['payment_status' => $to], ['id' => $orderId]);
        $this->history($orderId, 'payment_status', $order['payment_status'], $to, $note, $userId);
    }

    /** Side effects when an order becomes confirmed (popularity counters). */
    private function onConfirmed(int $orderId): void
    {
        Database::query(
            'UPDATE products p JOIN (SELECT product_id, SUM(quantity) q FROM order_items WHERE order_id = :o GROUP BY product_id) x
             ON x.product_id = p.id SET p.sales_count = p.sales_count + x.q',
            ['o' => $orderId]
        );
    }

    /** Returns reserved stock to inventory exactly once per order. Call inside a transaction. */
    public function releaseStock(array $order, ?int $userId, string $note): void
    {
        $locked = Database::fetch('SELECT stock_released FROM orders WHERE id = :id FOR UPDATE', ['id' => (int) $order['id']]);
        if (!$locked || (int) $locked['stock_released'] === 1) {
            return;
        }
        foreach (Database::fetchAll('SELECT * FROM order_items WHERE order_id = :o', ['o' => (int) $order['id']]) as $item) {
            if ($item['product_id']) {
                $this->inventory->change((int) $item['product_id'], (int) $item['variant_id'], (int) $item['quantity'], 'release', 'order', (int) $order['id'], $userId, $note);
            }
        }
        Database::update('orders', ['stock_released' => 1], ['id' => (int) $order['id']]);
    }

    /**
     * Re-reserves stock for an order whose stock was released (late payment success).
     * Returns false if stock is no longer available (staff must refund or source stock).
     */
    public function reReserveStock(array $order): bool
    {
        if ((int) $order['stock_released'] !== 1) {
            return true;
        }
        return Database::transaction(function () use ($order) {
            $items = Database::fetchAll('SELECT * FROM order_items WHERE order_id = :o AND product_id IS NOT NULL', ['o' => (int) $order['id']]);
            // Check everything first (with row locks) so we never apply a partial re-reservation.
            foreach ($items as $item) {
                $row = Database::fetch(
                    'SELECT i.quantity, p.allow_backorder FROM inventory i JOIN products p ON p.id = i.product_id
                     WHERE i.product_id = :p AND i.variant_id = :v FOR UPDATE',
                    ['p' => (int) $item['product_id'], 'v' => (int) $item['variant_id']]
                );
                if (!$row || (!(int) $row['allow_backorder'] && (int) $row['quantity'] < (int) $item['quantity'])) {
                    return false;
                }
            }
            foreach ($items as $item) {
                $this->inventory->change((int) $item['product_id'], (int) $item['variant_id'], -(int) $item['quantity'], 'sale', 'order', (int) $order['id'], null, 'Re-reserved after late payment');
            }
            Database::update('orders', ['stock_released' => 0], ['id' => (int) $order['id']]);
            return true;
        });
    }

    /**
     * Cancels unpaid online orders past their payment window. Before expiring, attempts with a
     * gateway reference are re-verified (when $verify is true) so a completed payment is never lost.
     */
    public function expireStale(bool $verify = true, int $limit = 50): int
    {
        $orders = Database::fetchAll(
            "SELECT * FROM orders WHERE status = 'pending_payment' AND expires_at IS NOT NULL AND expires_at < UTC_TIMESTAMP() ORDER BY id LIMIT " . (int) $limit
        );
        $count = 0;
        $payments = new PaymentService();
        foreach ($orders as $order) {
            try {
                if ($verify && $payments->reverifyOrder((int) $order['id'])) {
                    continue; // turned out to be paid
                }
                Database::transaction(function () use ($order) {
                    $locked = Database::fetch('SELECT * FROM orders WHERE id = :id FOR UPDATE', ['id' => (int) $order['id']]);
                    if (!$locked || $locked['status'] !== 'pending_payment') {
                        return;
                    }
                    Database::update('orders', ['status' => 'cancelled', 'cancelled_at' => Database::now()], ['id' => (int) $order['id']]);
                    $this->history((int) $order['id'], 'status', 'pending_payment', 'cancelled', 'Payment window expired');
                    if (OrderStateMachine::canPayment($locked['payment_status'], 'expired')) {
                        $this->setPaymentStatus((int) $order['id'], 'expired', 'Payment window expired');
                    }
                    Database::query("UPDATE payments SET status = 'expired' WHERE order_id = :o AND status IN ('initiated','pending')", ['o' => (int) $order['id']]);
                    $this->releaseStock($locked, null, 'Payment window expired');
                    if ($locked['coupon_id']) {
                        Database::query('UPDATE coupons SET used_count = GREATEST(used_count - 1, 0) WHERE id = :id', ['id' => (int) $locked['coupon_id']]);
                    }
                });
                $count++;
            } catch (\Throwable $e) {
                Logger::error('Order expiry failed', ['order' => $order['order_number'], 'error' => $e->getMessage()]);
            }
        }
        return $count;
    }

    /** Order visible to the current visitor: owner, or guest holding the access token. */
    public function findForViewer(string $number, ?int $userId, ?string $token): ?array
    {
        $order = $this->findByNumber($number);
        if (!$order) {
            return null;
        }
        if ($userId && (int) $order['user_id'] === $userId) {
            return $order;
        }
        if ($token && hash_equals((string) $order['access_token'], $token)) {
            return $order;
        }
        return null;
    }
}
