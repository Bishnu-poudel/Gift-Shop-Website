<?php
declare(strict_types=1);

namespace App\Services;

use App\Helpers\Icons;

/**
 * Generates original, license-free SVG illustrations used as demo product/tile imagery.
 * Replace with licensed product photography before launch (Admin > Products > Images).
 */
final class PlaceholderArt
{
    private const PALETTES = [
        ['#f3e3d3', '#e8c9ae', '#b4532a', '#fffaf3'],
        ['#e5ebdf', '#c9d6bf', '#5f705a', '#fbfdf8'],
        ['#f4ead6', '#e6d1a6', '#9a6a12', '#fffcf4'],
        ['#ecdde4', '#d9bfcb', '#5b3a4a', '#fff9fb'],
        ['#e2ebf4', '#c3d4e6', '#35577a', '#f8fbff'],
        ['#f6e4d9', '#ebc6b1', '#8f3f1e', '#fffaf6'],
        ['#e9e3d8', '#d4c8b4', '#4a4239', '#fdfbf7'],
    ];

    public static function svg(string $seed, string $motif, int $w = 960, int $h = 1200, ?string $label = null): string
    {
        $hash = crc32($seed);
        $p = self::PALETTES[$hash % count(self::PALETTES)];
        $rand = static function (int $i, int $min, int $max) use ($hash): int {
            return $min + (int) (abs(crc32($hash . ':' . $i)) % max(1, $max - $min));
        };
        $cx = $w / 2;
        $cy = $h * 0.47;
        $r = min($w, $h) * 0.34;
        $iconScale = ($r * 1.15) / 24;
        $ix = $cx - 12 * $iconScale;
        $iy = $cy - 12 * $iconScale;
        $dots = '';
        for ($i = 0; $i < 14; $i++) {
            $dots .= sprintf('<circle cx="%d" cy="%d" r="%d" fill="%s" opacity="%.2f"/>', $rand($i, 0, $w), $rand($i + 50, 0, $h), $rand($i + 100, 4, 16), $p[1], 0.35 + ($rand($i + 7, 0, 40) / 100));
        }
        $arc = sprintf('<path d="M %d %d Q %d %d %d %d" stroke="%s" stroke-width="3" fill="none" opacity=".5"/>',
            $rand(1, 0, (int) ($w * 0.3)), $rand(2, (int) ($h * 0.75), $h), $rand(3, (int) ($w * 0.3), (int) ($w * 0.7)), $rand(4, (int) ($h * 0.5), (int) ($h * 0.8)), $rand(5, (int) ($w * 0.7), $w), $rand(6, (int) ($h * 0.75), $h), $p[2]);
        $paths = Icons::paths($motif);
        $text = '';
        if ($label !== null) {
            $text = sprintf('<text x="%d" y="%d" text-anchor="middle" font-family="Georgia, serif" font-size="%d" fill="%s">%s</text>',
                $cx, (int) ($h * 0.9), (int) ($w * 0.065), $p[2], htmlspecialchars($label, ENT_XML1));
        }
        return '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
            . sprintf('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d">', $w, $h, $w, $h)
            . sprintf('<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="%s"/><stop offset="1" stop-color="%s"/></linearGradient></defs>', $p[3], $p[0])
            . sprintf('<rect width="%d" height="%d" fill="url(#g)"/>', $w, $h)
            . $dots . $arc
            . sprintf('<circle cx="%d" cy="%d" r="%d" fill="%s"/>', $cx, $cy, (int) ($r * 1.18), $p[0])
            . sprintf('<circle cx="%d" cy="%d" r="%d" fill="%s" opacity=".55"/>', $cx, $cy, (int) $r, $p[1])
            . sprintf('<g transform="translate(%.1f %.1f) scale(%.3f)" fill="none" stroke="%s" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round">%s</g>', $ix, $iy, $iconScale, $p[2], $paths)
            . $text
            . '</svg>';
    }

    public static function write(string $relPath, string $seed, string $motif, int $w = 960, int $h = 1200, ?string $label = null): string
    {
        $full = BASE_PATH . '/public/' . ltrim($relPath, '/');
        if (!is_dir(dirname($full))) {
            mkdir(dirname($full), 0755, true);
        }
        file_put_contents($full, self::svg($seed, $motif, $w, $h, $label));
        return $relPath;
    }
}
