<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Logger;
use App\Core\SmtpTransport;
use App\Core\View;

/**
 * Template-driven email. Templates live in email_templates (editable in Admin > Email templates)
 * and use {{variable}} placeholders (HTML-escaped) or {{{variable}}} for HTML we generate ourselves.
 *
 * Every message is written to email_outbox with an honest status:
 *   logged = MAIL_MODE=log (development; nothing left the server)
 *   sent   = the SMTP server accepted the message (250 after DATA)
 *   failed = delivery error (see error column)
 */
final class MailService
{
    // Gift reminders have their own opt-in (customer_profiles.notify_gift_reminders), so a newsletter
    // unsubscribe does not silence them.
    public const MARKETING = ['wishlist_reminder', 'abandoned_cart', 'newsletter'];

    /**
     * Never throws: email problems must not break checkout, payments or admin actions.
     * @return string logged|sent|failed|suppressed|missing_template|opted_out
     */
    public function send(string $to, string $templateKey, array $vars = [], ?string $unsubscribeUrl = null): string
    {
        try {
            return $this->sendTemplate($to, $templateKey, $vars, $unsubscribeUrl);
        } catch (\Throwable $e) {
            Logger::error('Email send failed', ['template' => $templateKey, 'error' => $e->getMessage()], 'mail');
            return 'failed';
        }
    }

    private function sendTemplate(string $to, string $templateKey, array $vars, ?string $unsubscribeUrl): string
    {
        $to = mb_strtolower(trim($to));
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return 'failed';
        }
        if (in_array($templateKey, self::MARKETING, true)
            && Database::fetchColumn('SELECT 1 FROM email_suppressions WHERE email = :e', ['e' => $to])) {
            return 'suppressed';
        }
        $tpl = Database::fetch('SELECT * FROM email_templates WHERE template_key = :k', ['k' => $templateKey]);
        if (!$tpl) {
            Logger::warning('Missing email template', ['key' => $templateKey]);
            return 'missing_template';
        }
        $vars += [
            'store_name' => setting('store_name', config('app.name')),
            'store_url' => url('/'),
            'store_email' => setting('store_email'),
            'year' => gmdate('Y'),
        ];
        $subject = self::render((string) $tpl['subject'], $vars, true);
        $body = self::render((string) $tpl['body_html'], $vars);
        return $this->deliver($to, $subject, $body, $templateKey, $unsubscribeUrl);
    }

    /** Sends raw (already rendered) HTML, e.g. an email campaign. */
    public function deliver(string $to, string $subject, string $bodyHtml, ?string $templateKey = null, ?string $unsubscribeUrl = null): string
    {
        try {
            $html = View::render('emails/layout', ['subject' => $subject, 'body' => $bodyHtml, 'unsubscribeUrl' => $unsubscribeUrl], null);
        } catch (\Throwable $e) {
            Logger::error('Email render failed: ' . $e->getMessage(), [], 'mail');
            return 'failed';
        }
        $text = trim(html_entity_decode(strip_tags(preg_replace('/<(br|\/p|\/h\d|\/tr|\/li)[^>]*>/i', "\n", $bodyHtml) ?? ''), ENT_QUOTES, 'UTF-8'));
        $status = 'logged';
        $error = null;

        if (config('mail.mode') === 'smtp') {
            try {
                (new SmtpTransport(
                    (string) config('mail.host'),
                    (int) config('mail.port'),
                    (string) config('mail.username'),
                    (string) config('mail.password'),
                    (string) config('mail.encryption'),
                ))->send((string) config('mail.from_address'), (string) config('mail.from_name'), $to, $subject, $html, $text);
                $status = 'sent';
            } catch (\Throwable $e) {
                $status = 'failed';
                $error = mb_substr($e->getMessage(), 0, 500);
                Logger::error('Email delivery failed', ['to' => $to, 'template' => $templateKey, 'error' => $error], 'mail');
            }
        } else {
            $dir = BASE_PATH . '/storage/mail';
            @file_put_contents($dir . '/' . gmdate('Ymd-His') . '-' . substr(md5($to . microtime()), 0, 6) . '.html', $html);
        }

        try {
            Database::insert('email_outbox', [
                'to_email' => $to, 'subject' => mb_substr($subject, 0, 190), 'body_html' => $html,
                'template_key' => $templateKey, 'status' => $status, 'error' => $error,
            ]);
        } catch (\Throwable $e) {
            Logger::error('Outbox write failed: ' . $e->getMessage(), [], 'mail');
        }
        return $status;
    }

    public static function render(string $template, array $vars, bool $plain = false): string
    {
        $out = preg_replace_callback('/\{\{\{\s*(\w+)\s*\}\}\}/', static fn ($m) => (string) ($vars[$m[1]] ?? ''), $template) ?? $template;
        return preg_replace_callback('/\{\{\s*(\w+)\s*\}\}/', static function ($m) use ($vars, $plain) {
            $v = (string) ($vars[$m[1]] ?? '');
            return $plain ? $v : htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
        }, $out) ?? $out;
    }

    /** Order-related transactional email with standard variables. Respects order-update preferences for non-essential mails. */
    public function orderEmail(string $templateKey, array $order): string
    {
        try {
            return $this->buildOrderEmail($templateKey, $order);
        } catch (\Throwable $e) {
            Logger::error('Order email failed', ['template' => $templateKey, 'order' => $order['order_number'] ?? null, 'error' => $e->getMessage()], 'mail');
            return 'failed';
        }
    }

    private function buildOrderEmail(string $templateKey, array $order): string
    {
        if ($order['user_id'] && in_array($templateKey, ['order_shipped', 'order_delivered'], true)) {
            $pref = Database::fetchColumn('SELECT notify_order_updates FROM customer_profiles WHERE user_id = :u', ['u' => (int) $order['user_id']]);
            if ($pref !== null && (int) $pref === 0) {
                return 'opted_out';
            }
        }
        $items = Database::fetchAll('SELECT name, variant_name, quantity, line_total FROM order_items WHERE order_id = :o', ['o' => (int) $order['id']]);
        $rows = '';
        foreach ($items as $i) {
            $rows .= '<tr><td style="padding:8px 0;border-bottom:1px solid #eee">' . e($i['name']) . ($i['variant_name'] ? ' — ' . e($i['variant_name']) : '')
                . ' × ' . (int) $i['quantity'] . '</td><td style="padding:8px 0;border-bottom:1px solid #eee;text-align:right">' . e(money($i['line_total'])) . '</td></tr>';
        }
        $itemsTable = '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse">' . $rows
            . ((float) ($order['vat_amount'] ?? 0) > 0 ? '<tr><td style="padding:4px 0;color:#7a6f63;font-size:13px">VAT ' . e(rtrim(rtrim(number_format((float) $order['vat_rate'], 2), '0'), '.')) . '%' . ((int) $order['prices_include_vat'] ? ' (included)' : '') . '</td><td style="padding:4px 0;text-align:right;color:#7a6f63;font-size:13px">' . e(money($order['vat_amount'])) . '</td></tr>' : '')
            . '<tr><td style="padding:8px 0"><strong>Total</strong></td><td style="padding:8px 0;text-align:right"><strong>' . e(money($order['grand_total'])) . '</strong></td></tr></table>'
            . (!empty($order['bill_number']) ? '<p style="margin:12px 0 0;font-size:13px">Bill no. ' . e($order['bill_number']) . ' · <a href="' . e(url('/order/' . $order['order_number'] . '/bill', ['t' => $order['access_token']])) . '" style="color:#b4532a">View / download your bill</a></p>' : '');
        $shipment = Database::fetch('SELECT * FROM shipments WHERE order_id = :o ORDER BY id DESC LIMIT 1', ['o' => (int) $order['id']]);
        $link = $order['user_id']
            ? url('/account/orders/' . $order['order_number'])
            : url('/order/' . $order['order_number'], ['t' => $order['access_token']]);
        return $this->send($order['email'], $templateKey, [
            'customer_name' => $order['customer_name'],
            'order_number' => $order['order_number'],
            'order_total' => money($order['grand_total']),
            'order_status' => OrderStateMachine::ORDER_LABELS[$order['status']] ?? $order['status'],
            'payment_method' => strtoupper($order['payment_method']),
            'order_url' => $link,
            'pay_url' => url('/checkout/pay/' . $order['order_number'], ['t' => $order['access_token']]),
            'items_table' => $itemsTable,
            'carrier' => $shipment['carrier'] ?? '',
            'tracking_number' => $shipment['tracking_number'] ?? '',
            'tracking_url' => $shipment['tracking_url'] ?? '',
            'refund_amount' => money($order['refunded_total'] ?? 0),
        ]);
    }
}
