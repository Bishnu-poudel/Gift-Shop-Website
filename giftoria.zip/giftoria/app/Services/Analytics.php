<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;
use App\Core\Session;

/** Measured daily counters (visits, product views, add-to-cart, checkouts, orders). No third-party tracking. */
final class Analytics
{
    public static function increment(string $metric, int $by = 1): void
    {
        try {
            Database::query(
                'INSERT INTO analytics_daily (day, metric, value) VALUES (:d, :m, :v) ON DUPLICATE KEY UPDATE value = value + :v2',
                ['d' => local_today(), 'm' => $metric, 'v' => $by, 'v2' => $by]
            );
        } catch (\Throwable) {
            // analytics must never break the storefront
        }
    }

    /** Counts one visit per session per day. */
    public static function trackVisit(): void
    {
        $today = local_today();
        if (Session::get('_visit_day') !== $today) {
            Session::put('_visit_day', $today);
            self::increment('visits');
        }
    }
}
