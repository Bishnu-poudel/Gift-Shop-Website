<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Gate;
use App\Repositories\TaxonomyRepository;

/** Storefront mega-menu data and admin sidebar (filtered by permission). */
final class NavigationService
{
    public static function storefront(): array
    {
        try {
            $tax = new TaxonomyRepository();
            $recipients = $tax->all('recipients');
            return [
                'recipients' => [
                    'Little ones' => array_values(array_filter($recipients, static fn ($r) => in_array($r['audience'], ['baby', 'child', 'teen'], true))),
                    'Family' => array_values(array_filter($recipients, static fn ($r) => in_array($r['slug'], ['mother', 'father', 'sister', 'brother', 'grandparent', 'wife', 'husband'], true))),
                    'Everyone else' => array_values(array_filter($recipients, static fn ($r) => in_array($r['slug'], ['girlfriend', 'boyfriend', 'friend', 'colleague', 'teacher', 'couple', 'pet-lover', 'anyone-else'], true))),
                ],
                'occasions' => $tax->all('occasions'),
                'interests' => $tax->all('interests'),
                'categories' => $tax->categoryTree(),
            ];
        } catch (\Throwable) {
            return ['recipients' => [], 'occasions' => [], 'interests' => [], 'categories' => []];
        }
    }

    /** @return array<string, array<int, array{label: string, path: string, icon: string, perm: string|array}>> */
    public static function adminMenu(): array
    {
        $menu = [
            'Overview' => [
                ['label' => 'Dashboard', 'path' => '', 'icon' => 'home', 'perm' => 'dashboard.view'],
                ['label' => 'Reports', 'path' => 'reports', 'icon' => 'chart', 'perm' => 'reports.view'],
            ],
            'Sales' => [
                ['label' => 'Orders', 'path' => 'orders', 'icon' => 'bag', 'perm' => 'orders.view'],
                ['label' => 'Payments', 'path' => 'payments', 'icon' => 'wallet', 'perm' => 'payments.view'],
                ['label' => 'Refunds', 'path' => 'refunds', 'icon' => 'undo', 'perm' => ['refunds.manage', 'payments.view']],
                ['label' => 'Returns', 'path' => 'returns', 'icon' => 'package', 'perm' => ['support.manage', 'refunds.manage']],
                ['label' => 'Customers', 'path' => 'customers', 'icon' => 'users', 'perm' => 'customers.view'],
            ],
            'Catalog' => [
                ['label' => 'Products', 'path' => 'products', 'icon' => 'gift', 'perm' => 'products.manage'],
                ['label' => 'Categories', 'path' => 'categories', 'icon' => 'layout', 'perm' => 'categories.manage'],
                ['label' => 'Gift taxonomy', 'path' => 'taxonomies/recipients', 'icon' => 'tag', 'perm' => 'categories.manage'],
                ['label' => 'Inventory', 'path' => 'inventory', 'icon' => 'boxes', 'perm' => 'inventory.manage'],
                ['label' => 'Suppliers & POs', 'path' => 'suppliers', 'icon' => 'truck', 'perm' => 'suppliers.manage'],
            ],
            'Marketing' => [
                ['label' => 'Homepage', 'path' => 'homepage', 'icon' => 'layout', 'perm' => 'homepage.edit'],
                ['label' => 'Campaigns', 'path' => 'campaigns', 'icon' => 'megaphone', 'perm' => ['campaigns.manage', 'banners.manage']],
                ['label' => 'Coupons', 'path' => 'coupons', 'icon' => 'tag', 'perm' => 'coupons.manage'],
                ['label' => 'Newsletter', 'path' => 'newsletter', 'icon' => 'mail', 'perm' => 'newsletter.manage'],
                ['label' => 'Gift Finder rules', 'path' => 'recommendations', 'icon' => 'sparkles', 'perm' => 'recommendations.manage'],
            ],
            'Customers' => [
                ['label' => 'Reviews & Q&A', 'path' => 'reviews', 'icon' => 'star', 'perm' => 'reviews.manage'],
                ['label' => 'Support tickets', 'path' => 'tickets', 'icon' => 'message', 'perm' => 'support.manage'],
            ],
            'System' => [
                ['label' => 'Staff', 'path' => 'staff', 'icon' => 'user', 'perm' => 'staff.manage'],
                ['label' => 'Roles & permissions', 'path' => 'roles', 'icon' => 'shield', 'perm' => 'roles.manage'],
                ['label' => 'Settings', 'path' => 'settings', 'icon' => 'settings', 'perm' => 'settings.manage'],
                ['label' => 'Email templates', 'path' => 'emails', 'icon' => 'file', 'perm' => 'content.manage'],
                ['label' => 'Audit log', 'path' => 'audit', 'icon' => 'clipboard', 'perm' => 'audit.view'],
            ],
        ];
        $out = [];
        foreach ($menu as $section => $items) {
            $visible = array_values(array_filter($items, static fn ($i) => Gate::any((array) $i['perm'])));
            if ($visible) {
                $out[$section] = $visible;
            }
        }
        return $out;
    }
}
