<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Cache;
use App\Core\Database;
use RuntimeException;

/**
 * All stock changes go through here. Each change locks the inventory row (SELECT ... FOR UPDATE)
 * inside a transaction and writes an inventory_movements row, so every unit is traceable to a
 * user, order or operation. Stock can never go negative unless the product allows backorders.
 */
final class InventoryService
{
    private function lockRow(int $productId, int $variantId): array
    {
        $row = Database::fetch(
            'SELECT * FROM inventory WHERE product_id = :p AND variant_id = :v FOR UPDATE',
            ['p' => $productId, 'v' => $variantId]
        );
        if (!$row) {
            Database::query(
                'INSERT IGNORE INTO inventory (product_id, variant_id, quantity) VALUES (:p, :v, 0)',
                ['p' => $productId, 'v' => $variantId]
            );
            $row = Database::fetch('SELECT * FROM inventory WHERE product_id = :p AND variant_id = :v FOR UPDATE', ['p' => $productId, 'v' => $variantId]);
        }
        return $row;
    }

    /** Changes quantity by $delta. Must be called inside Database::transaction(). */
    public function change(int $productId, int $variantId, int $delta, string $type, ?string $refType = null, ?int $refId = null, ?int $userId = null, ?string $note = null, bool $allowNegative = false): int
    {
        return Database::transaction(function () use ($productId, $variantId, $delta, $type, $refType, $refId, $userId, $note, $allowNegative) {
            $row = $this->lockRow($productId, $variantId);
            $new = (int) $row['quantity'] + $delta;
            if ($new < 0 && !$allowNegative) {
                $backorder = (int) Database::fetchColumn('SELECT allow_backorder FROM products WHERE id = :id', ['id' => $productId]);
                if (!$backorder) {
                    throw new RuntimeException('Insufficient stock.');
                }
            }
            Database::update('inventory', ['quantity' => $new], ['id' => (int) $row['id']]);
            if ($type === 'damage') {
                Database::query('UPDATE inventory SET damaged_quantity = damaged_quantity + :d WHERE id = :id', ['d' => abs($delta), 'id' => (int) $row['id']]);
            }
            Database::insert('inventory_movements', [
                'product_id' => $productId,
                'variant_id' => $variantId,
                'change_qty' => $delta,
                'balance_after' => $new,
                'type' => $type,
                'reference_type' => $refType,
                'reference_id' => $refId,
                'user_id' => $userId,
                'note' => $note !== null ? mb_substr($note, 0, 255) : null,
            ]);
            Cache::bump('catalog');
            return $new;
        });
    }

    /** Sets an absolute quantity (stock count), recording the difference as an adjustment. */
    public function setQuantity(int $productId, int $variantId, int $quantity, ?int $userId, string $note = 'Stock count'): int
    {
        if ($quantity < 0) {
            throw new RuntimeException('Quantity cannot be negative.');
        }
        return Database::transaction(function () use ($productId, $variantId, $quantity, $userId, $note) {
            $row = $this->lockRow($productId, $variantId);
            $delta = $quantity - (int) $row['quantity'];
            if ($delta === 0) {
                return $quantity;
            }
            return $this->change($productId, $variantId, $delta, 'adjustment', 'manual', null, $userId, $note);
        });
    }

    public function available(int $productId, int $variantId = 0): int
    {
        return (int) Database::fetchColumn('SELECT COALESCE(quantity,0) FROM inventory WHERE product_id = :p AND variant_id = :v', ['p' => $productId, 'v' => $variantId]);
    }

    public function lowStock(int $limit = 20): array
    {
        return Database::fetchAll(
            "SELECT i.*, p.name, p.sku, p.slug, v.name AS variant_name FROM inventory i
             JOIN products p ON p.id = i.product_id AND p.status = 'active'
             LEFT JOIN product_variants v ON v.id = i.variant_id
             WHERE i.quantity <= i.low_stock_threshold
             ORDER BY i.quantity ASC LIMIT " . (int) $limit
        );
    }
}
