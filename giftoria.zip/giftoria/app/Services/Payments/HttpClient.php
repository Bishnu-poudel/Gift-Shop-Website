<?php
declare(strict_types=1);

namespace App\Services\Payments;

interface HttpClient
{
    /** @return array{status: int, body: string} */
    public function request(string $method, string $url, array $headers = [], ?string $body = null): array;
}
