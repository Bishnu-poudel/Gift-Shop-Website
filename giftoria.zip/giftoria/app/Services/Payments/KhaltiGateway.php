<?php
declare(strict_types=1);

namespace App\Services\Payments;

use RuntimeException;

/**
 * Khalti Web Checkout KPG-2 (https://docs.khalti.com/khalti-epayment/).
 *  - POST {base}epayment/initiate/  with "Authorization: Key <secret>"  -> pidx, payment_url
 *  - Customer returns to return_url with pidx/status query params (untrusted).
 *  - POST {base}epayment/lookup/ {pidx} is the authoritative status. Amounts are in paisa.
 */
final class KhaltiGateway
{
    public function __construct(private array $config, private HttpClient $http)
    {
    }

    private function headers(): array
    {
        if ($this->config['secret_key'] === '' && !config('payments.simulator')) {
            throw new RuntimeException('Khalti is not configured (KHALTI_SECRET_KEY).');
        }
        return ['Authorization' => 'Key ' . $this->config['secret_key'], 'Content-Type' => 'application/json', 'Accept' => 'application/json'];
    }

    public static function toPaisa(float $npr): int
    {
        return (int) round($npr * 100);
    }

    /** @return array{pidx: string, payment_url: string, expires_at: ?string} */
    public function initiate(array $payment, array $order, string $returnUrl): array
    {
        $payload = [
            'return_url' => $returnUrl,
            'website_url' => url('/'),
            'amount' => self::toPaisa((float) $payment['amount']),
            'purchase_order_id' => $payment['attempt_ref'],
            'purchase_order_name' => 'Order ' . $order['order_number'],
            'customer_info' => array_filter([
                'name' => $order['customer_name'],
                'email' => $order['email'],
                'phone' => preg_replace('/\D/', '', (string) $order['phone']),
            ]),
        ];
        $res = $this->http->request('POST', $this->config['base_url'] . 'epayment/initiate/', $this->headers(), json_encode($payload));
        $body = json_decode($res['body'], true);
        if ($res['status'] !== 200 || !is_array($body) || empty($body['pidx']) || empty($body['payment_url'])) {
            $detail = is_array($body) ? (string) ($body['detail'] ?? json_encode($body)) : 'HTTP ' . $res['status'];
            throw new RuntimeException('Khalti could not start the payment: ' . mb_substr($detail, 0, 200));
        }
        return ['pidx' => (string) $body['pidx'], 'payment_url' => (string) $body['payment_url'], 'expires_at' => $body['expires_at'] ?? null];
    }

    public function verify(array $payment): VerificationResult
    {
        if (empty($payment['gateway_ref'])) {
            return new VerificationResult('failed', null, null, 'NO_PIDX', [], 'Payment was never initiated with Khalti.');
        }
        try {
            $res = $this->http->request('POST', $this->config['base_url'] . 'epayment/lookup/', $this->headers(), json_encode(['pidx' => $payment['gateway_ref']]));
        } catch (\Throwable $e) {
            return new VerificationResult('error', null, null, 'UNREACHABLE', [], $e->getMessage());
        }
        $body = json_decode($res['body'], true);
        if (!is_array($body) || !isset($body['status'])) {
            return new VerificationResult('error', null, null, 'BAD_RESPONSE', ['http_status' => $res['status']], 'Unexpected response from Khalti.');
        }
        $gwStatus = (string) $body['status'];
        $amount = isset($body['total_amount']) ? ((int) $body['total_amount']) / 100 : null;
        $raw = array_intersect_key($body, array_flip(['pidx', 'total_amount', 'status', 'transaction_id', 'fee', 'refunded']));
        if (($body['pidx'] ?? $payment['gateway_ref']) !== $payment['gateway_ref']) {
            return new VerificationResult('error', null, $amount, $gwStatus, $raw, 'pidx mismatch.');
        }
        $status = match ($gwStatus) {
            'Completed' => 'paid',
            'Pending', 'Initiated' => 'pending',
            'User canceled' => 'cancelled',
            'Expired' => 'expired',
            'Refunded' => 'refunded',
            'Partially Refunded' => 'partially_refunded',
            default => 'error',
        };
        if ($status === 'paid' && ((int) ($body['total_amount'] ?? -1)) !== self::toPaisa((float) $payment['amount'])) {
            return new VerificationResult('error', $body['transaction_id'] ?? null, $amount, $gwStatus, $raw, 'Paid amount does not match the order total.');
        }
        return new VerificationResult($status, isset($body['transaction_id']) ? (string) $body['transaction_id'] : null, $amount, $gwStatus, $raw);
    }
}
