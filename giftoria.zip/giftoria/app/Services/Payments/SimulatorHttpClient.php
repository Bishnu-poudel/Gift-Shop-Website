<?php
declare(strict_types=1);

namespace App\Services\Payments;

/**
 * LOCAL DEVELOPMENT ONLY (PAYMENT_SIMULATOR=true and APP_ENV != production).
 * Answers eSewa status-check and Khalti lookup calls from files written by the simulator page,
 * so the real verification logic in the gateways runs unchanged without internet access.
 */
final class SimulatorHttpClient implements HttpClient
{
    public static function dir(): string
    {
        return BASE_PATH . '/storage/cache/payment-simulator';
    }

    public static function store(string $ref, array $state): void
    {
        if (!is_dir(self::dir())) {
            mkdir(self::dir(), 0755, true);
        }
        file_put_contents(self::dir() . '/' . preg_replace('/[^A-Za-z0-9_-]/', '', $ref) . '.json', json_encode($state));
    }

    public static function load(string $ref): ?array
    {
        $f = self::dir() . '/' . preg_replace('/[^A-Za-z0-9_-]/', '', $ref) . '.json';
        return is_file($f) ? json_decode((string) file_get_contents($f), true) : null;
    }

    public function request(string $method, string $url, array $headers = [], ?string $body = null): array
    {
        if (str_contains($url, 'transaction/status')) {
            parse_str((string) parse_url($url, PHP_URL_QUERY), $q);
            $state = self::load((string) ($q['transaction_uuid'] ?? ''));
            return ['status' => 200, 'body' => json_encode([
                'product_code' => $q['product_code'] ?? '',
                'transaction_uuid' => $q['transaction_uuid'] ?? '',
                'total_amount' => $state['total_amount'] ?? (float) ($q['total_amount'] ?? 0),
                'status' => $state['status'] ?? 'NOT_FOUND',
                'ref_id' => $state['ref_id'] ?? null,
            ])];
        }
        if (str_contains($url, 'epayment/initiate')) {
            $data = json_decode((string) $body, true) ?: [];
            $pidx = 'SIM' . bin2hex(random_bytes(8));
            self::store($pidx, ['status' => 'Initiated', 'total_amount' => (int) ($data['amount'] ?? 0), 'purchase_order_id' => $data['purchase_order_id'] ?? '']);
            return ['status' => 200, 'body' => json_encode([
                'pidx' => $pidx,
                'payment_url' => url('/payment/simulator/khalti/' . $pidx),
                'expires_at' => gmdate('c', time() + 1800),
                'expires_in' => 1800,
            ])];
        }
        if (str_contains($url, 'epayment/lookup')) {
            $data = json_decode((string) $body, true) ?: [];
            $state = self::load((string) ($data['pidx'] ?? ''));
            if (!$state) {
                return ['status' => 404, 'body' => json_encode(['detail' => 'Not found.', 'error_key' => 'validation_error'])];
            }
            return ['status' => 200, 'body' => json_encode([
                'pidx' => $data['pidx'],
                'total_amount' => $state['total_amount'],
                'status' => $state['status'],
                'transaction_id' => $state['transaction_id'] ?? null,
                'fee' => 0,
                'refunded' => false,
            ])];
        }
        return ['status' => 404, 'body' => '{}'];
    }
}
