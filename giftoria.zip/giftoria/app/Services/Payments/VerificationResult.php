<?php
declare(strict_types=1);

namespace App\Services\Payments;

/** Normalized outcome of a server-side gateway status check. */
final class VerificationResult
{
    /**
     * @param string $status one of paid|pending|failed|cancelled|expired|refunded|partially_refunded|error
     */
    public function __construct(
        public string $status,
        public ?string $gatewayTxnId,
        public ?float $amount,
        public string $gatewayStatus,
        public array $raw = [],
        public string $message = '',
    ) {
    }

    public function isPaid(): bool
    {
        return $this->status === 'paid';
    }
}
