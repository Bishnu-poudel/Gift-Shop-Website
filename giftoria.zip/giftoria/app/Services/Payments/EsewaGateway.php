<?php
declare(strict_types=1);

namespace App\Services\Payments;

use RuntimeException;

/**
 * eSewa ePay v2 (https://developer.esewa.com.np/pages/Epay).
 *  - Initiation: browser POSTs a signed form to the ePay form URL.
 *  - Signature: base64(HMAC-SHA256("total_amount=..,transaction_uuid=..,product_code=..", secret)).
 *  - Return: success_url receives ?data=<base64 JSON> (signed). We check that signature, but the order
 *    is only marked paid after the server-side Status Check API reports COMPLETE for the expected amount.
 */
final class EsewaGateway
{
    public function __construct(private array $config, private HttpClient $http)
    {
    }

    public static function sign(string $message, string $secret): string
    {
        return base64_encode(hash_hmac('sha256', $message, $secret, true));
    }

    public static function amount(float $v): string
    {
        // eSewa compares amounts as strings in the signature; use a stable representation.
        return rtrim(rtrim(number_format($v, 2, '.', ''), '0'), '.');
    }

    /** Form fields for the auto-submitting redirect form. */
    public function formFields(array $payment, array $order, string $successUrl, string $failureUrl): array
    {
        if ($this->config['product_code'] === '' || $this->config['secret_key'] === '') {
            throw new RuntimeException('eSewa is not configured (ESEWA_PRODUCT_CODE / ESEWA_SECRET_KEY).');
        }
        $total = self::amount((float) $payment['amount']);
        $fields = [
            'amount' => $total,
            'tax_amount' => '0',
            'product_service_charge' => '0',
            'product_delivery_charge' => '0',
            'total_amount' => $total,
            'transaction_uuid' => $payment['attempt_ref'],
            'product_code' => $this->config['product_code'],
            'success_url' => $successUrl,
            'failure_url' => $failureUrl,
            'signed_field_names' => 'total_amount,transaction_uuid,product_code',
        ];
        $message = 'total_amount=' . $fields['total_amount'] . ',transaction_uuid=' . $fields['transaction_uuid'] . ',product_code=' . $fields['product_code'];
        $fields['signature'] = self::sign($message, $this->config['secret_key']);
        return $fields;
    }

    public function formUrl(): string
    {
        return $this->config['form_url'];
    }

    /**
     * Decodes the ?data= payload and checks its signature over signed_field_names.
     * @return array{data: array, signature_valid: bool}
     */
    public function decodeCallback(string $encoded): array
    {
        $json = base64_decode(strtr($encoded, ' ', '+'), true);
        $data = $json !== false ? json_decode($json, true) : null;
        if (!is_array($data)) {
            return ['data' => [], 'signature_valid' => false];
        }
        $valid = false;
        if (!empty($data['signed_field_names']) && isset($data['signature'])) {
            $parts = [];
            foreach (explode(',', (string) $data['signed_field_names']) as $field) {
                $parts[] = $field . '=' . ($data[$field] ?? '');
            }
            $expected = self::sign(implode(',', $parts), $this->config['secret_key']);
            $valid = hash_equals($expected, (string) $data['signature']);
        }
        return ['data' => $data, 'signature_valid' => $valid];
    }

    /** Authoritative server-side status check. */
    public function verify(array $payment): VerificationResult
    {
        $url = $this->config['status_url'] . '?' . http_build_query([
            'product_code' => $this->config['product_code'],
            'total_amount' => self::amount((float) $payment['amount']),
            'transaction_uuid' => $payment['attempt_ref'],
        ]);
        try {
            $res = $this->http->request('GET', $url, ['Accept' => 'application/json']);
        } catch (\Throwable $e) {
            return new VerificationResult('error', null, null, 'UNREACHABLE', [], $e->getMessage());
        }
        $body = json_decode($res['body'], true);
        if (!is_array($body) || !isset($body['status'])) {
            return new VerificationResult('error', null, null, 'BAD_RESPONSE', ['http_status' => $res['status']], 'Unexpected response from eSewa.');
        }
        $gwStatus = strtoupper((string) $body['status']);
        $amount = isset($body['total_amount']) ? (float) $body['total_amount'] : null;
        $raw = array_intersect_key($body, array_flip(['product_code', 'transaction_uuid', 'total_amount', 'status', 'ref_id']));

        if (($body['transaction_uuid'] ?? $payment['attempt_ref']) !== $payment['attempt_ref']) {
            return new VerificationResult('error', null, $amount, $gwStatus, $raw, 'Transaction reference mismatch.');
        }
        $status = match ($gwStatus) {
            'COMPLETE' => 'paid',
            'PENDING', 'AMBIGUOUS' => 'pending',
            'CANCELED' => 'cancelled',
            'NOT_FOUND' => 'failed',
            'FULL_REFUND' => 'refunded',
            'PARTIAL_REFUND' => 'partially_refunded',
            default => 'error',
        };
        if ($status === 'paid' && ($amount === null || abs($amount - (float) $payment['amount']) > 0.009)) {
            return new VerificationResult('error', $body['ref_id'] ?? null, $amount, $gwStatus, $raw, 'Paid amount does not match the order total.');
        }
        return new VerificationResult($status, isset($body['ref_id']) ? (string) $body['ref_id'] : null, $amount, $gwStatus, $raw);
    }
}
