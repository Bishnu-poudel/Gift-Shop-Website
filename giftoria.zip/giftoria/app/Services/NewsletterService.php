<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Database;

/** Opt-in newsletter with per-subscriber unsubscribe tokens and a suppression list. */
final class NewsletterService
{
    public static function subscribe(string $email, string $source, ?int $userId = null): void
    {
        $email = mb_strtolower(trim($email));
        Database::query(
            "INSERT INTO newsletter_subscriptions (email, user_id, status, token, source, consent_at)
             VALUES (:e, :u, 'subscribed', :t, :s, UTC_TIMESTAMP())
             ON DUPLICATE KEY UPDATE status = 'subscribed', consent_at = UTC_TIMESTAMP(), unsubscribed_at = NULL, user_id = COALESCE(user_id, VALUES(user_id))",
            ['e' => $email, 'u' => $userId, 't' => random_token(), 's' => mb_substr($source, 0, 40)]
        );
        Database::delete('email_suppressions', ['email' => $email]);
    }

    public static function unsubscribeByToken(string $token): ?string
    {
        $row = Database::fetch('SELECT * FROM newsletter_subscriptions WHERE token = :t', ['t' => $token]);
        if (!$row) {
            return null;
        }
        self::unsubscribe($row['email']);
        return $row['email'];
    }

    public static function unsubscribe(string $email): void
    {
        $email = mb_strtolower(trim($email));
        Database::query("UPDATE newsletter_subscriptions SET status = 'unsubscribed', unsubscribed_at = UTC_TIMESTAMP() WHERE email = :e", ['e' => $email]);
        Database::query('INSERT IGNORE INTO email_suppressions (email, reason) VALUES (:e, :r)', ['e' => $email, 'r' => 'unsubscribed']);
        Database::query('UPDATE customer_profiles cp JOIN users u ON u.id = cp.user_id SET cp.marketing_opt_in = 0 WHERE u.email = :e', ['e' => $email]);
    }

    public static function unsubscribeUrl(string $email): ?string
    {
        $token = Database::fetchColumn("SELECT token FROM newsletter_subscriptions WHERE email = :e", ['e' => mb_strtolower($email)]);
        return $token ? url('/newsletter/unsubscribe/' . $token) : null;
    }
}
