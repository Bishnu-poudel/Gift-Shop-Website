<?php
declare(strict_types=1);

namespace App\Services;

/**
 * The single source of truth for money. Every total shown or charged is computed here on the
 * server from live product prices — never from values posted by the browser.
 */
final class PricingService
{
    private CouponService $coupons;

    public function __construct(?CouponService $coupons = null)
    {
        $this->coupons = $coupons ?? new CouponService();
    }

    public static function unitPrice(array $line): float
    {
        $base = $line['sale_price'] !== null ? (float) $line['sale_price'] : (float) $line['price'];
        return round($base + (float) ($line['price_adjustment'] ?? 0), 2);
    }

    /**
     * @param array $lines CartService::lines() rows
     * @param array $options coupon_code, gift_wrap (bool), district, user_id, email
     */
    public function calculate(array $lines, array $options = []): array
    {
        $priced = [];
        $issues = [];
        $subtotal = 0.0;
        $wrapPossible = false;
        $leadDays = 0;
        $valleyOnly = false;

        foreach ($lines as $l) {
            $unavailable = $l['status'] !== 'active' || ((int) $l['variant_id'] > 0 && !(int) ($l['variant_active'] ?? 0));
            $insufficient = !$unavailable && !(int) $l['allow_backorder'] && (int) $l['quantity'] > (int) $l['stock'];
            $unit = self::unitPrice($l);
            $lineTotal = round($unit * (int) $l['quantity'], 2);
            if ($unavailable) {
                $issues[] = ['item_id' => (int) $l['id'], 'message' => $l['name'] . ' is no longer available.'];
            } elseif ($insufficient) {
                $issues[] = ['item_id' => (int) $l['id'], 'message' => (int) $l['stock'] > 0
                    ? 'Only ' . (int) $l['stock'] . ' of ' . $l['name'] . ' left in stock.'
                    : $l['name'] . ' is out of stock.'];
            }
            if (!$unavailable) {
                $subtotal += $lineTotal;
                $wrapPossible = $wrapPossible || (int) $l['gift_wrap_available'] === 1;
                $leadDays = max($leadDays, (int) $l['lead_time_days']);
                $valleyOnly = $valleyOnly || (int) $l['valley_only'] === 1;
            }
            $priced[] = $l + ['unit_price' => $unit, 'line_total' => $lineTotal, 'unavailable' => $unavailable, 'insufficient' => $insufficient];
        }
        $subtotal = round($subtotal, 2);

        // Coupon (one per order; no stacking)
        $discount = 0.0;
        $freeShipping = false;
        $couponResult = null;
        $code = trim((string) ($options['coupon_code'] ?? ''));
        if ($code !== '' && $subtotal > 0) {
            $coupon = $this->coupons->findByCode($code);
            $couponResult = $this->coupons->evaluate($coupon, array_filter($priced, static fn ($l) => !$l['unavailable']), $subtotal, $options['user_id'] ?? null, $options['email'] ?? null);
            if ($couponResult['ok']) {
                $discount = $couponResult['discount'];
                $freeShipping = $couponResult['free_shipping'];
            }
        }

        $district = $options['district'] ?? null;
        $zone = $district ? ShippingService::zoneForDistrict($district) : null;
        $shipping = $subtotal > 0 && !$freeShipping ? ShippingService::fee($zone, $subtotal - $discount) : 0.0;
        $shippingKnown = $zone !== null;
        if ($district && $valleyOnly && !ShippingService::isValleyDistrict($district)) {
            $issues[] = ['item_id' => 0, 'message' => 'Some items can only be delivered inside Kathmandu Valley.'];
        }

        $giftWrap = !empty($options['gift_wrap']) && $wrapPossible ? (float) setting('gift_wrap_fee', 150) : 0.0;
        // VAT: inclusive prices are split; exclusive prices get VAT added on top.
        $tax = TaxService::breakdown(max(0, $subtotal - $discount) + $shipping + $giftWrap);
        $grand = $tax['total'];

        return [
            'lines' => $priced,
            'issues' => $issues,
            'subtotal' => $subtotal,
            'discount' => round($discount, 2),
            'coupon' => $couponResult,
            'coupon_code' => $couponResult && $couponResult['ok'] ? strtoupper($code) : null,
            'free_shipping' => $freeShipping,
            'shipping' => round($shipping, 2),
            'shipping_known' => $shippingKnown,
            'zone' => $zone,
            'gift_wrap' => $giftWrap,
            'gift_wrap_possible' => $wrapPossible,
            'grand_total' => $grand,
            'tax' => $tax,
            'taxable_amount' => $tax['taxable'],
            'vat_amount' => $tax['vat'],
            'vat_rate' => $tax['rate'],
            'item_count' => array_sum(array_map(static fn ($l) => (int) $l['quantity'], $priced)),
            'lead_days' => $leadDays,
            'valley_only' => $valleyOnly,
            'delivery_estimate' => ShippingService::estimate($leadDays, $zone),
        ];
    }
}
