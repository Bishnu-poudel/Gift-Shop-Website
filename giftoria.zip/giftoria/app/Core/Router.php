<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Pattern router. Patterns use {name} (matches one segment) or {name:regex}.
 * Handlers are [ControllerClass::class, 'method'] or closures taking (Request $r).
 * Middleware names: 'auth', 'guest', 'staff', 'can:permission.slug'.
 */
final class Router
{
    private array $routes = [];
    private array $groupStack = [];

    public function get(string $pattern, callable|array $handler, array $middleware = []): void
    {
        $this->add(['GET', 'HEAD'], $pattern, $handler, $middleware);
    }

    public function post(string $pattern, callable|array $handler, array $middleware = []): void
    {
        $this->add(['POST'], $pattern, $handler, $middleware);
    }

    public function any(string $pattern, callable|array $handler, array $middleware = []): void
    {
        $this->add(['GET', 'HEAD', 'POST'], $pattern, $handler, $middleware);
    }

    public function group(string $prefix, array $middleware, callable $routes): void
    {
        $this->groupStack[] = ['prefix' => $prefix, 'middleware' => $middleware];
        $routes($this);
        array_pop($this->groupStack);
    }

    public function add(array $methods, string $pattern, callable|array $handler, array $middleware = []): void
    {
        $prefix = '';
        $groupMiddleware = [];
        foreach ($this->groupStack as $g) {
            $prefix .= $g['prefix'];
            $groupMiddleware = array_merge($groupMiddleware, $g['middleware']);
        }
        $full = '/' . trim($prefix . '/' . trim($pattern, '/'), '/');
        $this->routes[] = [
            'methods' => $methods,
            'pattern' => $full,
            'regex' => $this->compile($full),
            'handler' => $handler,
            'middleware' => array_merge($groupMiddleware, $middleware),
        ];
    }

    private function compile(string $pattern): string
    {
        $regex = preg_replace_callback('/\{(\w+)(?::([^}]+))?\}/', static function ($m) {
            return '(?P<' . $m[1] . '>' . ($m[2] ?? '[^/]+') . ')';
        }, $pattern);
        return '#^' . $regex . '$#';
    }

    /** @return array{route: array, params: array}|null|string null = 404, 'method' = 405 */
    public function match(string $method, string $path): array|string|null
    {
        $methodMismatch = false;
        foreach ($this->routes as $route) {
            if (!preg_match($route['regex'], $path, $m)) {
                continue;
            }
            if (!in_array($method, $route['methods'], true)) {
                $methodMismatch = true;
                continue;
            }
            $params = array_filter($m, 'is_string', ARRAY_FILTER_USE_KEY);
            return ['route' => $route, 'params' => $params];
        }
        return $methodMismatch ? 'method' : null;
    }

    public function routes(): array
    {
        return $this->routes;
    }
}
