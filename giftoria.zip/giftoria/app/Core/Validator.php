<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Server-side validation.
 * Rules (pipe separated): required, nullable, string, email, numeric, integer, min:n, max:n,
 * between:a,b, in:a,b,c, confirmed, date, url, phone, slug, alpha_dash, array, accepted,
 * unique:table,column[,ignoreId], exists:table,column, regex:/pattern/
 * min/max apply to string length for strings, numeric value for numeric rules, count for arrays.
 */
final class Validator
{
    private array $errors = [];

    public function __construct(private array $data, private array $rules, private array $labels = [])
    {
    }

    public static function make(array $data, array $rules, array $labels = []): self
    {
        return new self($data, $rules, $labels);
    }

    /** @throws ValidationException */
    public static function validate(array $data, array $rules, array $labels = []): array
    {
        $v = new self($data, $rules, $labels);
        if ($v->fails()) {
            throw new ValidationException($v->errors(), $data);
        }
        return $v->validated();
    }

    public function fails(): bool
    {
        $this->errors = [];
        foreach ($this->rules as $field => $ruleSet) {
            $rules = is_array($ruleSet) ? $ruleSet : explode('|', $ruleSet);
            $value = $this->data[$field] ?? null;
            if (is_string($value)) {
                $value = trim($value);
            }
            $empty = $value === null || $value === '' || $value === [];
            if ($empty && !in_array('required', $rules, true) && !in_array('accepted', $rules, true)) {
                continue;
            }
            $isNumeric = (bool) array_intersect($rules, ['numeric', 'integer']);
            foreach ($rules as $rule) {
                [$name, $arg] = array_pad(explode(':', $rule, 2), 2, null);
                $error = $this->check($field, $name, $arg, $value, $empty, $isNumeric);
                if ($error !== null) {
                    $this->errors[$field] = $error;
                    break;
                }
            }
        }
        return $this->errors !== [];
    }

    private function label(string $field): string
    {
        return $this->labels[$field] ?? ucfirst(str_replace(['_', '.'], ' ', $field));
    }

    private function check(string $field, string $name, ?string $arg, mixed $value, bool $empty, bool $isNumeric): ?string
    {
        $label = $this->label($field);
        switch ($name) {
            case 'required':
                return $empty ? "$label is required." : null;
            case 'nullable':
                return null;
            case 'string':
                return ($value !== null && !is_scalar($value)) ? "$label must be text." : null;
            case 'accepted':
                return in_array($value, ['1', 1, 'on', 'yes', true, 'true'], true) ? null : "$label must be accepted.";
            case 'email':
                return filter_var($value, FILTER_VALIDATE_EMAIL) && strlen((string) $value) <= 190 ? null : "$label must be a valid email address.";
            case 'numeric':
                return is_numeric($value) ? null : "$label must be a number.";
            case 'integer':
                return filter_var($value, FILTER_VALIDATE_INT) !== false ? null : "$label must be a whole number.";
            case 'array':
                return is_array($value) ? null : "$label is invalid.";
            case 'min':
                if (is_array($value)) {
                    return count($value) >= (int) $arg ? null : "Select at least $arg $label.";
                }
                if ($isNumeric) {
                    return (float) $value >= (float) $arg ? null : "$label must be at least $arg.";
                }
                return mb_strlen((string) $value) >= (int) $arg ? null : "$label must be at least $arg characters.";
            case 'max':
                if (is_array($value)) {
                    return count($value) <= (int) $arg ? null : "$label may not have more than $arg items.";
                }
                if ($isNumeric) {
                    return (float) $value <= (float) $arg ? null : "$label may not be greater than $arg.";
                }
                return mb_strlen((string) $value) <= (int) $arg ? null : "$label may not exceed $arg characters.";
            case 'between':
                [$a, $b] = explode(',', (string) $arg);
                return ((float) $value >= (float) $a && (float) $value <= (float) $b) ? null : "$label must be between $a and $b.";
            case 'in':
                $allowed = explode(',', (string) $arg);
                if (is_array($value)) {
                    return array_diff(array_map('strval', $value), $allowed) === [] ? null : "$label contains an invalid choice.";
                }
                return in_array((string) $value, $allowed, true) ? null : "$label is invalid.";
            case 'confirmed':
                return ($this->data[$field . '_confirmation'] ?? null) === $value ? null : "$label confirmation does not match.";
            case 'date':
                $d = \DateTime::createFromFormat('Y-m-d', (string) $value);
                return ($d && $d->format('Y-m-d') === $value) ? null : "$label must be a valid date.";
            case 'datetime':
                return strtotime((string) $value) !== false ? null : "$label must be a valid date and time.";
            case 'url':
                return filter_var($value, FILTER_VALIDATE_URL) && preg_match('#^https?://#i', (string) $value) ? null : "$label must be a valid URL.";
            case 'phone':
                // Nepali mobile (98/97/96 + 8 digits) or landline with area code; optional +977
                $digits = preg_replace('/[\s-]/', '', (string) $value);
                return preg_match('/^(\+?977)?(9[678]\d{8}|0\d{7,9})$/', $digits) ? null : "$label must be a valid Nepali phone number.";
            case 'slug':
                return preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', (string) $value) ? null : "$label may contain lowercase letters, numbers and hyphens only.";
            case 'alpha_dash':
                return preg_match('/^[A-Za-z0-9_-]+$/', (string) $value) ? null : "$label may contain letters, numbers, dashes and underscores only.";
            case 'regex':
                return preg_match((string) $arg, (string) $value) ? null : "$label format is invalid.";
            case 'unique':
                $parts = explode(',', (string) $arg);
                $table = Database::ident($parts[0]);
                $col = Database::ident($parts[1] ?? $field);
                $sql = "SELECT COUNT(*) FROM $table WHERE $col = :v";
                $params = ['v' => $value];
                if (!empty($parts[2])) {
                    $sql .= ' AND id <> :id';
                    $params['id'] = (int) $parts[2];
                }
                return (int) Database::fetchColumn($sql, $params) === 0 ? null : "$label is already in use.";
            case 'exists':
                $parts = explode(',', (string) $arg);
                $table = Database::ident($parts[0]);
                $col = Database::ident($parts[1] ?? 'id');
                return (int) Database::fetchColumn("SELECT COUNT(*) FROM $table WHERE $col = :v", ['v' => $value]) > 0 ? null : "Selected $label is invalid.";
        }
        return null;
    }

    public function errors(): array
    {
        return $this->errors;
    }

    /** Returns only the validated keys, with strings trimmed. */
    public function validated(): array
    {
        $out = [];
        foreach (array_keys($this->rules) as $field) {
            $v = $this->data[$field] ?? null;
            $out[$field] = is_string($v) ? trim($v) : $v;
        }
        return $out;
    }
}
