<?php
declare(strict_types=1);

namespace App\Core;

final class Logger
{
    private const SECRET_KEYS = ['password', 'password_hash', 'secret', 'secret_key', 'token', 'authorization', 'signature', 'mpin', 'otp', 'card'];

    public static function log(string $level, string $message, array $context = [], string $channel = 'app'): void
    {
        $line = sprintf(
            "[%s] %s.%s: %s %s\n",
            gmdate('Y-m-d H:i:s'),
            $channel,
            strtoupper($level),
            $message,
            $context ? json_encode(self::redact($context), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : ''
        );
        $dir = BASE_PATH . '/storage/logs';
        @file_put_contents($dir . '/' . $channel . '-' . gmdate('Y-m-d') . '.log', $line, FILE_APPEND | LOCK_EX);
    }

    public static function info(string $m, array $c = [], string $channel = 'app'): void
    {
        self::log('info', $m, $c, $channel);
    }

    public static function warning(string $m, array $c = [], string $channel = 'app'): void
    {
        self::log('warning', $m, $c, $channel);
    }

    public static function error(string $m, array $c = [], string $channel = 'app'): void
    {
        self::log('error', $m, $c, $channel);
    }

    /** Recursively masks values whose keys look secret. */
    public static function redact(array $data): array
    {
        foreach ($data as $k => $v) {
            if (is_array($v)) {
                $data[$k] = self::redact($v);
            } elseif (is_string($k)) {
                foreach (self::SECRET_KEYS as $s) {
                    if (stripos($k, $s) !== false) {
                        $data[$k] = '[redacted]';
                        break;
                    }
                }
            }
        }
        return $data;
    }
}
