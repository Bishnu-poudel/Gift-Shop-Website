<?php
declare(strict_types=1);

namespace App\Core;

use App\Middleware\Middleware;
use Throwable;

/** HTTP kernel: session, CSRF, routing, middleware, error pages. */
final class Kernel
{
    public function __construct(private Router $router)
    {
    }

    public function handle(Request $request): Response
    {
        try {
            if (config('app.force_https') && !$request->isSecure()) {
                return Response::redirect(preg_replace('#^http://#i', 'https://', $request->fullUrl()), 301);
            }
            Session::start($request->isSecure());

            $match = $this->router->match($request->method, $request->path);
            if ($match === null) {
                throw new HttpException(404);
            }
            if ($match === 'method') {
                throw new HttpException(405, 'Method not allowed.');
            }
            $request->params = $match['params'];
            $route = $match['route'];

            if (in_array($request->method, ['POST', 'PUT', 'PATCH', 'DELETE'], true) && !Csrf::verify($request)) {
                throw new HttpException(419);
            }

            foreach ($route['middleware'] as $name) {
                $result = Middleware::run($name, $request);
                if ($result instanceof Response) {
                    return $this->secureHeaders($result);
                }
            }

            $handler = $route['handler'];
            if (is_array($handler)) {
                [$class, $method] = $handler;
                $result = (new $class())->$method($request, ...array_values($request->params));
            } else {
                $result = $handler($request, ...array_values($request->params));
            }
            $response = $result instanceof Response ? $result : Response::html((string) $result);
            return $this->secureHeaders($response);
        } catch (ValidationException $e) {
            if ($request->wantsJson()) {
                return Response::json(['message' => 'Please correct the highlighted fields.', 'errors' => $e->errors], 422);
            }
            Session::flash('errors', $e->errors);
            $old = $e->old;
            foreach (['password', 'password_confirmation', 'current_password', '_token'] as $k) {
                unset($old[$k]);
            }
            Session::flash('old', $old);
            return Response::redirect(back_url('/'));
        } catch (HttpException $e) {
            return $this->secureHeaders($this->errorResponse($request, $e->status, $e->getMessage()));
        } catch (Throwable $e) {
            Logger::error($e->getMessage(), ['file' => $e->getFile(), 'line' => $e->getLine(), 'path' => $request->path]);
            if (config('app.debug')) {
                return Response::html('<pre style="padding:2rem;white-space:pre-wrap">' . e((string) $e) . '</pre>', 500);
            }
            return $this->errorResponse($request, 500, 'Something went wrong on our side. Please try again shortly.');
        }
    }

    private function errorResponse(Request $request, int $status, string $message): Response
    {
        if ($request->wantsJson()) {
            return Response::json(['message' => $message], $status);
        }
        if ($status === 419) {
            Session::flash('error', $message);
            return Response::redirect(back_url('/'));
        }
        $view = in_array($status, [403, 404, 429, 500], true) ? 'errors/' . $status : 'errors/generic';
        try {
            $layout = str_starts_with($request->path, '/' . trim((string) config('app.admin_path', 'admin'), '/')) ? 'layouts/minimal' : 'layouts/app';
            $html = View::render($view, ['title' => $status . ' — ' . $message, 'message' => $message, 'status' => $status], $layout);
        } catch (Throwable $e) {
            Logger::error('Error page failed: ' . $e->getMessage());
            $html = '<h1>' . $status . '</h1><p>' . e($message) . '</p>';
        }
        return Response::html($html, $status);
    }

    private function secureHeaders(Response $response): Response
    {
        $response->headers += [
            'X-Content-Type-Options' => 'nosniff',
            'X-Frame-Options' => 'SAMEORIGIN',
            'Referrer-Policy' => 'strict-origin-when-cross-origin',
            'Permissions-Policy' => 'camera=(), microphone=(), geolocation=()',
        ];
        if (config('app.force_https')) {
            $response->headers += ['Strict-Transport-Security' => 'max-age=31536000; includeSubDomains'];
        }
        return $response;
    }
}
