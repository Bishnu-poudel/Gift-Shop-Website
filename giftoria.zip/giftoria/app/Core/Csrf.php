<?php
declare(strict_types=1);

namespace App\Core;

final class Csrf
{
    public static function token(): string
    {
        $token = Session::get('_csrf');
        if (!$token) {
            $token = bin2hex(random_bytes(32));
            Session::put('_csrf', $token);
        }
        return $token;
    }

    public static function verify(Request $request): bool
    {
        $sent = $request->input('_token') ?? $request->header('X-CSRF-Token');
        $token = Session::get('_csrf');
        return is_string($sent) && is_string($token) && hash_equals($token, $sent);
    }
}
