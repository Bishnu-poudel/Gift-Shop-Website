<?php
declare(strict_types=1);

namespace App\Core;

/**
 * File cache in storage/cache. Group versioning gives cheap invalidation:
 * Cache::remember('catalog', 'key', 300, fn) and Cache::bump('catalog') after product/inventory changes.
 */
final class Cache
{
    private static function dir(): string
    {
        return BASE_PATH . '/storage/cache';
    }

    private static function version(string $group): int
    {
        $file = self::dir() . '/_v_' . preg_replace('/\W/', '', $group);
        return is_file($file) ? (int) file_get_contents($file) : 1;
    }

    public static function bump(string $group): void
    {
        $file = self::dir() . '/_v_' . preg_replace('/\W/', '', $group);
        @file_put_contents($file, (string) (self::version($group) + 1), LOCK_EX);
    }

    public static function remember(string $group, string $key, int $ttl, callable $fn): mixed
    {
        if (!config('app.cache_enabled', true)) {
            return $fn();
        }
        $file = self::dir() . '/' . $group . '_' . sha1($group . self::version($group) . '|' . $key) . '.cache';
        if (is_file($file) && filemtime($file) + $ttl > time()) {
            $data = @unserialize((string) file_get_contents($file), ['allowed_classes' => false]);
            if ($data !== false || filesize($file) === 4) {
                return $data;
            }
        }
        $value = $fn();
        @file_put_contents($file, serialize($value), LOCK_EX);
        return $value;
    }

    public static function clear(): int
    {
        $n = 0;
        foreach (glob(self::dir() . '/*.cache') ?: [] as $f) {
            @unlink($f) && $n++;
        }
        return $n;
    }
}
