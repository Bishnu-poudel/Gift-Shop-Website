<?php
declare(strict_types=1);

namespace App\Core;

final class Paginator
{
    public int $pages;
    public int $offset;

    public function __construct(public int $total, public int $perPage, public int $page)
    {
        $this->pages = max(1, (int) ceil($total / max(1, $perPage)));
        $this->offset = (max(1, min($page, $this->pages)) - 1) * $perPage;
    }

    public static function fromRequest(int $total, int $perPage = 24): self
    {
        $page = max(1, (int) (Request::current()?->query('page', 1) ?? 1));
        return new self($total, $perPage, $page);
    }

    public function currentPage(): int
    {
        return max(1, min($this->page, $this->pages));
    }

    /** URL for page $n preserving the other query parameters. */
    public function url(int $n): string
    {
        $req = Request::current();
        $q = $req ? $req->query() : [];
        $q['page'] = $n;
        return url($req?->path ?? '/') . '?' . http_build_query($q);
    }

    public function links(): string
    {
        if ($this->pages <= 1) {
            return '';
        }
        $cur = $this->currentPage();
        $html = '<nav class="pagination" aria-label="Pagination">';
        if ($cur > 1) {
            $html .= '<a class="page-link" rel="prev" href="' . e($this->url($cur - 1)) . '">&larr; Prev</a>';
        }
        $start = max(1, $cur - 2);
        $end = min($this->pages, $cur + 2);
        for ($i = $start; $i <= $end; $i++) {
            $html .= $i === $cur
                ? '<span class="page-link is-active" aria-current="page">' . $i . '</span>'
                : '<a class="page-link" href="' . e($this->url($i)) . '">' . $i . '</a>';
        }
        if ($cur < $this->pages) {
            $html .= '<a class="page-link" rel="next" href="' . e($this->url($cur + 1)) . '">Next &rarr;</a>';
        }
        return $html . '</nav>';
    }
}
