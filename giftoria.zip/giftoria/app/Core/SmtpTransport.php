<?php
declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/**
 * Dependency-free SMTP client (AUTH LOGIN, STARTTLS or implicit TLS).
 * send() returns only after the server accepts the message with a 250 reply.
 */
final class SmtpTransport
{
    /** @var resource|null */
    private $socket = null;

    public function __construct(
        private string $host,
        private int $port,
        private string $username,
        private string $password,
        private string $encryption, // tls (STARTTLS) | ssl | none
        private int $timeout = 15,
    ) {
    }

    public function send(string $fromEmail, string $fromName, string $to, string $subject, string $html, string $text): void
    {
        $remote = ($this->encryption === 'ssl' ? 'ssl://' : 'tcp://') . $this->host . ':' . $this->port;
        $ctx = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]);
        $this->socket = @stream_socket_client($remote, $errno, $errstr, $this->timeout, STREAM_CLIENT_CONNECT, $ctx);
        if (!$this->socket) {
            throw new RuntimeException("SMTP connect failed: $errstr ($errno)");
        }
        stream_set_timeout($this->socket, $this->timeout);
        try {
            $this->expect([220]);
            $ehloHost = parse_url((string) config('app.url'), PHP_URL_HOST) ?: 'localhost';
            $this->cmd("EHLO $ehloHost", [250]);
            if ($this->encryption === 'tls') {
                $this->cmd('STARTTLS', [220]);
                if (!stream_socket_enable_crypto($this->socket, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT)) {
                    throw new RuntimeException('SMTP STARTTLS negotiation failed');
                }
                $this->cmd("EHLO $ehloHost", [250]);
            }
            if ($this->username !== '') {
                $this->cmd('AUTH LOGIN', [334]);
                $this->cmd(base64_encode($this->username), [334]);
                $this->cmd(base64_encode($this->password), [235]);
            }
            $this->cmd('MAIL FROM:<' . $fromEmail . '>', [250]);
            $this->cmd('RCPT TO:<' . $to . '>', [250, 251]);
            $this->cmd('DATA', [354]);

            $boundary = 'b' . bin2hex(random_bytes(12));
            $headers = [
                'Date: ' . date(DATE_RFC2822),
                'From: ' . $this->encodeHeader($fromName) . ' <' . $fromEmail . '>',
                'To: <' . $to . '>',
                'Subject: ' . $this->encodeHeader($subject),
                'Message-ID: <' . bin2hex(random_bytes(16)) . '@' . $ehloHost . '>',
                'MIME-Version: 1.0',
                'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
            ];
            $body = "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
                . chunk_split(base64_encode($text))
                . "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
                . chunk_split(base64_encode($html))
                . "--$boundary--\r\n";
            $data = implode("\r\n", $headers) . "\r\n\r\n" . $body;
            $data = preg_replace('/^\./m', '..', $data); // dot-stuffing
            fwrite($this->socket, $data . "\r\n.\r\n");
            $this->expect([250]);
            $this->cmd('QUIT', [221]);
        } finally {
            if (is_resource($this->socket)) {
                fclose($this->socket);
            }
        }
    }

    private function encodeHeader(string $value): string
    {
        return preg_match('/[^\x20-\x7E]/', $value) ? '=?UTF-8?B?' . base64_encode($value) . '?=' : $value;
    }

    private function cmd(string $line, array $codes): string
    {
        fwrite($this->socket, $line . "\r\n");
        return $this->expect($codes);
    }

    private function expect(array $codes): string
    {
        $response = '';
        while (($line = fgets($this->socket, 515)) !== false) {
            $response .= $line;
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }
        $code = (int) substr($response, 0, 3);
        if (!in_array($code, $codes, true)) {
            throw new RuntimeException('SMTP unexpected reply: ' . trim($response));
        }
        return $response;
    }
}
