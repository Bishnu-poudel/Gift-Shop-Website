<?php
declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/**
 * Validated image uploads: size limit, real MIME sniffing (finfo), getimagesize() check,
 * randomized filenames and a fixed target directory (no user-controlled paths).
 */
final class Uploader
{
    private const ALLOWED = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
    ];

    /** @return string path relative to public/, e.g. uploads/products/2026/10/ab12.jpg */
    public static function image(array $file, string $folder = 'products', int $maxBytes = 5_242_880): string
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Upload failed. Please choose an image under 5 MB.');
        }
        if (!is_uploaded_file($file['tmp_name']) && PHP_SAPI !== 'cli') {
            throw new RuntimeException('Invalid upload.');
        }
        if ((int) $file['size'] > $maxBytes) {
            throw new RuntimeException('Image is larger than ' . round($maxBytes / 1048576) . ' MB.');
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        if (!isset(self::ALLOWED[$mime])) {
            throw new RuntimeException('Only JPEG, PNG, WebP or GIF images are allowed.');
        }
        $info = @getimagesize($file['tmp_name']);
        if ($info === false || $info[0] < 1 || $info[0] > 8000 || $info[1] > 8000) {
            throw new RuntimeException('The file is not a valid image.');
        }
        $folder = preg_replace('/[^a-z0-9_-]/', '', strtolower($folder)) ?: 'misc';
        $rel = 'uploads/' . $folder . '/' . gmdate('Y/m');
        $dir = BASE_PATH . '/public/' . $rel;
        if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new RuntimeException('Upload directory is not writable.');
        }
        $name = bin2hex(random_bytes(16)) . '.' . self::ALLOWED[$mime];
        $target = $dir . '/' . $name;
        $moved = PHP_SAPI === 'cli' ? copy($file['tmp_name'], $target) : move_uploaded_file($file['tmp_name'], $target);
        if (!$moved) {
            throw new RuntimeException('Could not save the uploaded image.');
        }
        return $rel . '/' . $name;
    }

    /** Deletes a previously uploaded file, refusing anything outside public/uploads. */
    public static function delete(string $relPath): void
    {
        $base = realpath(BASE_PATH . '/public/uploads');
        $full = realpath(BASE_PATH . '/public/' . ltrim($relPath, '/'));
        if ($base && $full && str_starts_with($full, $base . DIRECTORY_SEPARATOR) && is_file($full)) {
            @unlink($full);
        }
    }
}
