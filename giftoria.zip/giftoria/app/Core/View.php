<?php
declare(strict_types=1);

namespace App\Core;

use RuntimeException;

/**
 * Plain-PHP templates in resources/views. Templates must escape output with e().
 * A view renders inside a layout which receives $content plus the same data.
 */
final class View
{
    private static array $shared = [];

    public static function share(string $key, mixed $value): void
    {
        self::$shared[$key] = $value;
    }

    public static function render(string $view, array $data = [], ?string $layout = 'layouts/app'): string
    {
        $data = array_merge(self::$shared, $data);
        $content = self::capture($view, $data);
        if ($layout === null) {
            return $content;
        }
        return self::capture($layout, array_merge($data, ['content' => $content]));
    }

    public static function partial(string $view, array $data = []): string
    {
        return self::capture($view, array_merge(self::$shared, $data));
    }

    private static function capture(string $__view, array $__data): string
    {
        $__file = BASE_PATH . '/resources/views/' . $__view . '.php';
        if (!is_file($__file)) {
            throw new RuntimeException('View not found: ' . $__view);
        }
        extract($__data, EXTR_SKIP);
        ob_start();
        try {
            include $__file;
        } catch (\Throwable $e) {
            ob_end_clean();
            throw $e;
        }
        return (string) ob_get_clean();
    }
}
