<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Permission checks for staff. Permissions come from active roles via role_permissions.
 * The 'super-admin' role implicitly holds every permission.
 */
final class Gate
{
    public const SUPER_ADMIN = 'super-admin';
    private static array $cache = [];

    public static function permissionsFor(int $userId): array
    {
        if (isset(self::$cache[$userId])) {
            return self::$cache[$userId];
        }
        if (self::isSuperAdmin($userId)) {
            $perms = Database::fetchCol('SELECT slug FROM permissions');
        } else {
            $perms = Database::fetchCol(
                'SELECT DISTINCT p.slug FROM user_roles ur
                 JOIN roles r ON r.id = ur.role_id AND r.is_active = 1
                 JOIN role_permissions rp ON rp.role_id = r.id
                 JOIN permissions p ON p.id = rp.permission_id
                 JOIN users u ON u.id = ur.user_id AND u.type = \'staff\' AND u.status = \'active\'
                 WHERE ur.user_id = :u',
                ['u' => $userId]
            );
        }
        return self::$cache[$userId] = array_values($perms);
    }

    public static function isSuperAdmin(int $userId): bool
    {
        return (bool) Database::fetchColumn(
            'SELECT 1 FROM user_roles ur JOIN roles r ON r.id = ur.role_id
             JOIN users u ON u.id = ur.user_id AND u.type = \'staff\' AND u.status = \'active\'
             WHERE ur.user_id = :u AND r.slug = :s AND r.is_active = 1',
            ['u' => $userId, 's' => self::SUPER_ADMIN]
        );
    }

    public static function allows(string $permission, ?int $userId = null): bool
    {
        $userId ??= Auth::staffId();
        if (!$userId) {
            return false;
        }
        return in_array($permission, self::permissionsFor($userId), true);
    }

    public static function any(array $permissions, ?int $userId = null): bool
    {
        foreach ($permissions as $p) {
            if (self::allows($p, $userId)) {
                return true;
            }
        }
        return false;
    }

    /** @throws HttpException 403 */
    public static function authorize(string $permission): void
    {
        if (!self::allows($permission)) {
            AuditLogger::log('access.denied', 'permission', null, null, ['permission' => $permission]);
            throw new HttpException(403);
        }
    }

    /**
     * Delegation rule: an actor may assign a role only if they hold every permission in it,
     * and only a Super Admin may assign the Super Admin role.
     */
    public static function canAssignRole(int $actorId, int $roleId): bool
    {
        $role = Database::fetch('SELECT * FROM roles WHERE id = :id', ['id' => $roleId]);
        if (!$role) {
            return false;
        }
        if (self::isSuperAdmin($actorId)) {
            return true;
        }
        if ($role['slug'] === self::SUPER_ADMIN) {
            return false;
        }
        $rolePerms = Database::fetchCol(
            'SELECT p.slug FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = :r',
            ['r' => $roleId]
        );
        return array_diff($rolePerms, self::permissionsFor($actorId)) === [];
    }

    /** An actor may only grant permissions they themselves hold. */
    public static function canGrantPermissions(int $actorId, array $permissionSlugs): bool
    {
        if (self::isSuperAdmin($actorId)) {
            return true;
        }
        return array_diff($permissionSlugs, self::permissionsFor($actorId)) === [];
    }

    public static function flush(): void
    {
        self::$cache = [];
    }
}
