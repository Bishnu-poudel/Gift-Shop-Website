<?php
declare(strict_types=1);

namespace App\Core;

/** Fixed-window rate limiter stored in the rate_limits table. */
final class RateLimiter
{
    public static function hit(string $key, int $decaySeconds): int
    {
        $key = substr($key, 0, 190);
        $expires = gmdate('Y-m-d H:i:s', time() + $decaySeconds);
        Database::query(
            'INSERT INTO rate_limits (rate_key, hits, expires_at) VALUES (:k, 1, :e)
             ON DUPLICATE KEY UPDATE
               hits = IF(expires_at < UTC_TIMESTAMP(), 1, hits + 1),
               expires_at = IF(expires_at < UTC_TIMESTAMP(), VALUES(expires_at), expires_at)',
            ['k' => $key, 'e' => $expires]
        );
        return self::hits($key);
    }

    public static function hits(string $key): int
    {
        return (int) Database::fetchColumn(
            'SELECT hits FROM rate_limits WHERE rate_key = :k AND expires_at >= UTC_TIMESTAMP()',
            ['k' => substr($key, 0, 190)]
        );
    }

    public static function tooMany(string $key, int $max): bool
    {
        return self::hits($key) >= $max;
    }

    /** Hits and throws 429 when the limit is exceeded. */
    public static function enforce(string $key, int $max, int $decaySeconds): void
    {
        if (self::tooMany($key, $max)) {
            throw new HttpException(429);
        }
        self::hit($key, $decaySeconds);
    }

    public static function clear(string $key): void
    {
        Database::query('DELETE FROM rate_limits WHERE rate_key = :k', ['k' => substr($key, 0, 190)]);
    }
}
