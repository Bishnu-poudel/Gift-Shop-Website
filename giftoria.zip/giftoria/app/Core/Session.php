<?php
declare(strict_types=1);

namespace App\Core;

final class Session
{
    private static array $fallback = [];
    private static bool $cli = false;

    public static function start(bool $secure): void
    {
        if (PHP_SAPI === 'cli') {
            self::$cli = true;
            return;
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        $dir = BASE_PATH . '/storage/sessions';
        if (is_dir($dir) && is_writable($dir)) {
            session_save_path($dir);
        }
        session_name((string) config('app.session_name', 'GIFTORIA_SID'));
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => base_path_prefix() ?: '/',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.gc_maxlifetime', (string) ((int) config('app.session_lifetime', 120) * 60));
        session_start();

        // Idle timeout
        $now = time();
        $last = $_SESSION['_last_activity'] ?? $now;
        if ($now - $last > (int) config('app.session_lifetime', 120) * 60) {
            $_SESSION = [];
            session_regenerate_id(true);
        }
        $_SESSION['_last_activity'] = $now;

        // Age flash data: values set last request become readable now, then vanish.
        $_SESSION['_flash_old'] = $_SESSION['_flash_new'] ?? [];
        $_SESSION['_flash_new'] = [];
    }

    private static function &store(): array
    {
        if (self::$cli || PHP_SAPI === 'cli' || !isset($_SESSION)) {
            return self::$fallback;
        }
        return $_SESSION;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $s = &self::store();
        return $s[$key] ?? $default;
    }

    public static function put(string $key, mixed $value): void
    {
        $s = &self::store();
        $s[$key] = $value;
    }

    public static function forget(string $key): void
    {
        $s = &self::store();
        unset($s[$key]);
    }

    public static function pull(string $key, mixed $default = null): mixed
    {
        $v = self::get($key, $default);
        self::forget($key);
        return $v;
    }

    public static function regenerate(): void
    {
        if (!self::$cli && session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
    }

    public static function flash(string $key, mixed $value): void
    {
        $s = &self::store();
        $s['_flash_new'][$key] = $value;
    }

    public static function getFlash(string $key, mixed $default = null): mixed
    {
        $s = &self::store();
        return $s['_flash_new'][$key] ?? $s['_flash_old'][$key] ?? $default;
    }

    public static function id(): string
    {
        return self::$cli ? 'cli' : session_id();
    }

    /** Stable anonymous key used for feedback / finder sessions (not the session id itself). */
    public static function visitorKey(): string
    {
        $key = self::get('_visitor_key');
        if (!$key) {
            $key = bin2hex(random_bytes(32));
            self::put('_visitor_key', $key);
        }
        return $key;
    }
}
