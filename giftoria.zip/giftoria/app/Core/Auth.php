<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Two independent guards share the users table:
 *  - 'customer' (storefront)  session key auth_customer
 *  - 'staff'    (admin panel) session key auth_staff
 * A user row's `type` decides which guard it can log into; public registration only creates customers.
 * Bumping users.session_version revokes every session for that user.
 */
final class Auth
{
    private static array $cache = [];

    public static function customer(): ?array
    {
        return self::resolve('customer');
    }

    public static function staff(): ?array
    {
        return self::resolve('staff');
    }

    public static function customerId(): ?int
    {
        $u = self::customer();
        return $u ? (int) $u['id'] : null;
    }

    public static function staffId(): ?int
    {
        $u = self::staff();
        return $u ? (int) $u['id'] : null;
    }

    private static function resolve(string $guard): ?array
    {
        if (array_key_exists($guard, self::$cache)) {
            return self::$cache[$guard];
        }
        $s = Session::get('auth_' . $guard);
        $user = null;
        if (is_array($s) && isset($s['id'], $s['v'])) {
            $row = Database::fetch('SELECT * FROM users WHERE id = :id AND type = :type', ['id' => (int) $s['id'], 'type' => $guard]);
            if ($row && $row['status'] === 'active' && (int) $row['session_version'] === (int) $s['v']) {
                unset($row['password_hash']);
                $user = $row;
            } else {
                Session::forget('auth_' . $guard);
            }
        }
        return self::$cache[$guard] = $user;
    }

    public static function login(array $user, string $guard): void
    {
        Session::regenerate();
        Session::put('auth_' . $guard, ['id' => (int) $user['id'], 'v' => (int) $user['session_version']]);
        Database::update('users', ['last_login_at' => Database::now(), 'last_login_ip' => Request::current()?->ip()], ['id' => $user['id']]);
        unset(self::$cache[$guard]);
    }

    public static function logout(string $guard): void
    {
        Session::forget('auth_' . $guard);
        unset(self::$cache[$guard]);
        Session::regenerate();
    }

    /**
     * Verifies credentials with throttling. Returns the user row or null.
     * Always runs password_verify so response time does not reveal whether the email exists.
     */
    public static function attempt(string $email, string $password, string $guard, string $ip): ?array
    {
        $email = mb_strtolower(trim($email));
        $key = 'login:' . $guard . ':' . hash('sha256', $email . '|' . $ip);
        $ipKey = 'login-ip:' . $guard . ':' . $ip;
        if (RateLimiter::tooMany($key, 5) || RateLimiter::tooMany($ipKey, 30)) {
            throw new HttpException(429, 'Too many login attempts. Please wait 15 minutes and try again.');
        }
        $user = Database::fetch('SELECT * FROM users WHERE email = :e AND type = :t', ['e' => $email, 't' => $guard]);
        $hash = $user['password_hash'] ?? '$2y$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinva';
        $ok = password_verify($password, (string) $hash);
        if (!$user || !$ok || !in_array($user['status'], ['active', 'pending'], true)) {
            RateLimiter::hit($key, 900);
            RateLimiter::hit($ipKey, 900);
            return null;
        }
        RateLimiter::clear($key);
        if (password_needs_rehash((string) $user['password_hash'], PASSWORD_DEFAULT)) {
            Database::update('users', ['password_hash' => password_hash($password, PASSWORD_DEFAULT)], ['id' => $user['id']]);
        }
        return $user;
    }

    public static function revokeSessions(int $userId): void
    {
        Database::query('UPDATE users SET session_version = session_version + 1 WHERE id = :id', ['id' => $userId]);
    }

    public static function flushCache(): void
    {
        self::$cache = [];
        Gate::flush();
    }
}
