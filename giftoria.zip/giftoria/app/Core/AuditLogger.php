<?php
declare(strict_types=1);

namespace App\Core;

final class AuditLogger
{
    public static function log(string $action, ?string $entityType = null, ?int $entityId = null, ?array $old = null, ?array $new = null, ?int $userId = null): void
    {
        $req = Request::current();
        try {
            Database::insert('audit_logs', [
                'user_id' => $userId ?? Auth::staffId() ?? Auth::customerId(),
                'action' => substr($action, 0, 80),
                'entity_type' => $entityType,
                'entity_id' => $entityId,
                'old_values' => $old !== null ? json_encode(Logger::redact($old), JSON_UNESCAPED_UNICODE) : null,
                'new_values' => $new !== null ? json_encode(Logger::redact($new), JSON_UNESCAPED_UNICODE) : null,
                'ip' => $req?->ip(),
                'user_agent' => $req?->userAgent(),
            ]);
        } catch (\Throwable $e) {
            Logger::error('Audit log write failed: ' . $e->getMessage());
        }
    }
}
