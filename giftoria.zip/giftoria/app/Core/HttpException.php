<?php
declare(strict_types=1);

namespace App\Core;

use RuntimeException;

final class HttpException extends RuntimeException
{
    public function __construct(public int $status, string $message = '')
    {
        parent::__construct($message ?: match ($status) {
            403 => 'You do not have permission to access this page.',
            404 => 'Page not found.',
            419 => 'Your session expired. Please refresh the page and try again.',
            429 => 'Too many attempts. Please wait a moment and try again.',
            default => 'Something went wrong.',
        }, $status);
    }
}
