<?php
declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOStatement;
use Throwable;

/**
 * Thin PDO wrapper. Native prepared statements are used (emulation off), so:
 *  - never reuse the same named placeholder twice in one query;
 *  - cast LIMIT/OFFSET to (int) and interpolate them.
 */
final class Database
{
    private static ?PDO $pdo = null;
    private static int $transactionLevel = 0;

    public static function pdo(): PDO
    {
        if (self::$pdo === null) {
            $c = config('database');
            $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $c['host'], (int) $c['port'], $c['database']);
            self::$pdo = new PDO($dsn, $c['username'], $c['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_STRINGIFY_FETCHES => false,
            ]);
            self::$pdo->exec("SET time_zone = '+00:00'");
        }
        return self::$pdo;
    }

    public static function setPdo(?PDO $pdo): void
    {
        self::$pdo = $pdo;
        self::$transactionLevel = 0;
    }

    public static function query(string $sql, array $params = []): PDOStatement
    {
        $stmt = self::pdo()->prepare($sql);
        foreach ($params as $key => $value) {
            $param = is_int($key) ? $key + 1 : (str_starts_with((string) $key, ':') ? $key : ':' . $key);
            if (is_bool($value)) {
                $value = (int) $value;
            }
            $type = match (true) {
                is_int($value) => PDO::PARAM_INT,
                $value === null => PDO::PARAM_NULL,
                default => PDO::PARAM_STR,
            };
            $stmt->bindValue($param, $value, $type);
        }
        $stmt->execute();
        return $stmt;
    }

    public static function fetch(string $sql, array $params = []): ?array
    {
        $row = self::query($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    public static function fetchAll(string $sql, array $params = []): array
    {
        return self::query($sql, $params)->fetchAll();
    }

    public static function fetchColumn(string $sql, array $params = []): mixed
    {
        $value = self::query($sql, $params)->fetchColumn();
        return $value === false ? null : $value;
    }

    /** @return array<int|string,mixed> first column values, keyed by order */
    public static function fetchCol(string $sql, array $params = []): array
    {
        return self::query($sql, $params)->fetchAll(PDO::FETCH_COLUMN);
    }

    public static function insert(string $table, array $data): int
    {
        $cols = array_keys($data);
        $sql = sprintf(
            'INSERT INTO %s (%s) VALUES (%s)',
            self::ident($table),
            implode(', ', array_map([self::class, 'ident'], $cols)),
            implode(', ', array_map(static fn ($c) => ':' . $c, $cols))
        );
        self::query($sql, $data);
        return (int) self::pdo()->lastInsertId();
    }

    /** @param array $where column => value equality conditions */
    public static function update(string $table, array $data, array $where): int
    {
        $set = [];
        $params = [];
        foreach ($data as $col => $value) {
            $set[] = self::ident($col) . ' = :s_' . $col;
            $params['s_' . $col] = $value;
        }
        $cond = [];
        foreach ($where as $col => $value) {
            $cond[] = self::ident($col) . ' = :w_' . $col;
            $params['w_' . $col] = $value;
        }
        $sql = sprintf('UPDATE %s SET %s WHERE %s', self::ident($table), implode(', ', $set), implode(' AND ', $cond));
        return self::query($sql, $params)->rowCount();
    }

    public static function delete(string $table, array $where): int
    {
        $cond = [];
        $params = [];
        foreach ($where as $col => $value) {
            $cond[] = self::ident($col) . ' = :w_' . $col;
            $params['w_' . $col] = $value;
        }
        return self::query(sprintf('DELETE FROM %s WHERE %s', self::ident($table), implode(' AND ', $cond)), $params)->rowCount();
    }

    /**
     * Runs $fn inside a transaction. Nested calls join the outer transaction.
     * @template T
     * @param callable():T $fn
     * @return T
     */
    public static function transaction(callable $fn): mixed
    {
        $pdo = self::pdo();
        if (self::$transactionLevel > 0) {
            self::$transactionLevel++;
            try {
                return $fn();
            } finally {
                self::$transactionLevel--;
            }
        }
        $pdo->beginTransaction();
        self::$transactionLevel = 1;
        try {
            $result = $fn();
            $pdo->commit();
            return $result;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        } finally {
            self::$transactionLevel = 0;
        }
    }

    /** Builds "IN (:p0, :p1...)" placeholders and merges values into $params. */
    public static function in(string $prefix, array $values, array &$params): string
    {
        if ($values === []) {
            return '(NULL)';
        }
        $names = [];
        foreach (array_values($values) as $i => $v) {
            $names[] = ':' . $prefix . $i;
            $params[$prefix . $i] = $v;
        }
        return '(' . implode(', ', $names) . ')';
    }

    public static function ident(string $name): string
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) {
            throw new \InvalidArgumentException('Invalid identifier: ' . $name);
        }
        return '`' . $name . '`';
    }

    public static function now(): string
    {
        return gmdate('Y-m-d H:i:s');
    }
}
