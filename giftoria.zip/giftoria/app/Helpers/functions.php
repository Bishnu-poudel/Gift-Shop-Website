<?php
declare(strict_types=1);

use App\Core\Auth;
use App\Core\Config;
use App\Core\Csrf;
use App\Core\Env;
use App\Core\Gate;
use App\Core\Request;
use App\Core\Session;
use App\Core\View;
use App\Services\SettingsService;

function env(string $key, mixed $default = null): mixed
{
    return Env::get($key, $default);
}

function config(string $key, mixed $default = null): mixed
{
    return Config::get($key, $default);
}

/** Admin-editable setting from site_settings, falling back to $default. */
function setting(string $key, mixed $default = null): mixed
{
    return SettingsService::get($key, $default);
}

/** HTML-escape for output. Use for every dynamic value in templates. */
function e(mixed $value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** URL path prefix where the app is mounted, e.g. "/giftoria" (from APP_URL). */
function base_path_prefix(): string
{
    static $prefix = null;
    if ($prefix === null) {
        $prefix = rtrim((string) parse_url((string) config('app.url'), PHP_URL_PATH), '/');
    }
    return $prefix;
}

function url(string $path = '/', array $query = []): string
{
    if (preg_match('#^https?://#i', $path)) {
        return $path;
    }
    $base = rtrim((string) config('app.url'), '/');
    $u = $base . '/' . ltrim($path, '/');
    if ($path === '/' || $path === '') {
        $u = $base . '/';
    }
    if ($query) {
        $u .= (str_contains($u, '?') ? '&' : '?') . http_build_query($query);
    }
    return $u;
}

function asset(string $path): string
{
    $file = BASE_PATH . '/public/' . ltrim($path, '/');
    $v = is_file($file) ? '?v=' . filemtime($file) : '';
    return url($path) . $v;
}

/** Public URL for a stored image path (relative to public/) with a placeholder fallback. */
function image_url(?string $path): string
{
    if (!$path) {
        return url('assets/images/placeholder.svg');
    }
    if (preg_match('#^https?://#i', $path)) {
        return $path;
    }
    return url(ltrim($path, '/'));
}

function admin_url(string $path = ''): string
{
    return url('/' . trim((string) config('app.admin_path', 'admin'), '/') . ($path !== '' ? '/' . ltrim($path, '/') : ''));
}

function csrf_token(): string
{
    return Csrf::token();
}

function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(Csrf::token()) . '">';
}

function method_field(string $method): string
{
    return '<input type="hidden" name="_method" value="' . e(strtoupper($method)) . '">';
}

/** Previously submitted value after a validation failure. */
function old(string $key, mixed $default = ''): mixed
{
    $old = Session::getFlash('old', []);
    return $old[$key] ?? $default;
}

/** Validation error for a field (or all errors when $key is null). */
function errors(?string $key = null): mixed
{
    $errors = Session::getFlash('errors', []);
    return $key === null ? $errors : ($errors[$key] ?? null);
}

function field_error(string $key): string
{
    $err = errors($key);
    return $err ? '<p class="field-error" role="alert">' . e($err) . '</p>' : '';
}

function flash(string $key, mixed $value = null): mixed
{
    if ($value !== null) {
        Session::flash($key, $value);
        return null;
    }
    return Session::getFlash($key);
}

function back_url(string $fallback = '/'): string
{
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    $base = rtrim((string) config('app.url'), '/');
    // Only redirect back to our own origin.
    if ($ref !== '' && str_starts_with($ref, $base)) {
        return $ref;
    }
    return url($fallback);
}

function customer(): ?array
{
    return Auth::customer();
}

function staff(): ?array
{
    return Auth::staff();
}

function can(string $permission): bool
{
    return Gate::allows($permission);
}

/** Formats an amount as NPR, e.g. "NPR 1,250" or "NPR 1,250.50". */
function money(mixed $amount, bool $withCode = true): string
{
    $amount = (float) $amount;
    $decimals = abs($amount - round($amount)) < 0.005 ? 0 : 2;
    $s = number_format($amount, $decimals);
    return $withCode ? (config('app.currency_symbol', 'NPR') . ' ' . $s) : $s;
}

/** Converts a UTC datetime string to the display timezone (Asia/Kathmandu). */
function local_date(?string $utc, string $format = 'M j, Y g:i A'): string
{
    if (!$utc) {
        return '';
    }
    try {
        $d = new DateTimeImmutable($utc, new DateTimeZone('UTC'));
        return $d->setTimezone(new DateTimeZone((string) config('app.timezone', 'Asia/Kathmandu')))->format($format);
    } catch (Throwable) {
        return '';
    }
}

/** Today's date in the store timezone (Y-m-d). */
function local_today(): string
{
    return (new DateTimeImmutable('now', new DateTimeZone((string) config('app.timezone', 'Asia/Kathmandu'))))->format('Y-m-d');
}

/** Converts a local (Kathmandu) datetime-local input to a UTC string for storage. */
function local_to_utc(?string $local): ?string
{
    if (!$local) {
        return null;
    }
    try {
        $d = new DateTimeImmutable($local, new DateTimeZone((string) config('app.timezone', 'Asia/Kathmandu')));
        return $d->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
    } catch (Throwable) {
        return null;
    }
}

function str_slug(string $text): string
{
    $text = mb_strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/u', '-', $text) ?? '';
    return trim($text, '-') ?: 'item';
}

function str_limit(?string $text, int $limit = 120): string
{
    $text = (string) $text;
    return mb_strlen($text) > $limit ? rtrim(mb_substr($text, 0, $limit - 1)) . '…' : $text;
}

function view(string $view, array $data = [], ?string $layout = 'layouts/app'): string
{
    return View::render($view, $data, $layout);
}

function partial(string $view, array $data = []): string
{
    return View::partial($view, $data);
}

function request(): ?Request
{
    return Request::current();
}

/** "is-active" when the current path starts with $prefix. */
function active(string $prefix, bool $exact = false): string
{
    $path = Request::current()?->path ?? '/';
    $ok = $exact ? $path === $prefix : ($prefix === '/' ? $path === '/' : str_starts_with($path, $prefix));
    return $ok ? 'is-active' : '';
}

/** Lucide-style inline SVG icon from resources/views/components/icons. */
function icon(string $name, string $class = 'icon'): string
{
    return App\Helpers\Icons::svg($name, $class);
}

/**
 * Brand mark for headers: the uploaded logo (Admin › Settings › Billing & tax) when enabled,
 * otherwise the round gift mark plus the store name.
 */
function brand_html(bool $withName = true): string
{
    $name = (string) setting('store_name', config('app.name'));
    $logo = (string) setting('store_logo', '');
    if ($logo !== '' && setting('show_logo_in_header', true)) {
        return '<img class="brand-logo" src="' . e(image_url($logo)) . '" alt="' . e($name) . '">';
    }
    return '<span class="brand-mark">' . icon('gift') . '</span>' . ($withName ? e($name) : '');
}

function status_label(string $status): string
{
    return ucwords(str_replace('_', ' ', $status));
}

function json_attr(mixed $data): string
{
    return e(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP));
}

function random_token(int $bytes = 32): string
{
    return bin2hex(random_bytes($bytes));
}

/** Human age label from months, e.g. 18 -> "18 months", 36 -> "3 years". */
function age_label(?int $months): string
{
    if ($months === null) {
        return '';
    }
    if ($months < 24) {
        return $months . ' month' . ($months === 1 ? '' : 's');
    }
    $y = intdiv($months, 12);
    return $y . ' years';
}

function age_range_label(?int $min, ?int $max): string
{
    if ($min === null && $max === null) {
        return 'All ages';
    }
    if ($max === null || $max >= 1200) {
        return age_label($min ?? 0) . '+';
    }
    if (($min ?? 0) === 0) {
        return 'Up to ' . age_label($max);
    }
    return age_label($min) . ' – ' . age_label($max);
}
