<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Cache;
use App\Core\Database;

/** Recipients, occasions, interests, age ranges, budgets, preference tags, categories, makers. */
final class TaxonomyRepository
{
    public const TYPES = ['recipients', 'occasions', 'interests'];

    public function all(string $type, bool $activeOnly = true): array
    {
        if (!in_array($type, self::TYPES, true)) {
            throw new \InvalidArgumentException('Unknown taxonomy ' . $type);
        }
        return Cache::remember('catalog', "tax:$type:" . (int) $activeOnly, 600, static function () use ($type, $activeOnly) {
            $where = $activeOnly ? 'WHERE is_active = 1' : '';
            return Database::fetchAll("SELECT * FROM `$type` $where ORDER BY sort_order, name");
        });
    }

    public function findBySlug(string $type, string $slug): ?array
    {
        foreach ($this->all($type) as $row) {
            if ($row['slug'] === $slug) {
                return $row;
            }
        }
        return null;
    }

    /** slug => row */
    public function keyed(string $type): array
    {
        $out = [];
        foreach ($this->all($type) as $row) {
            $out[$row['slug']] = $row;
        }
        return $out;
    }

    public function ageRanges(): array
    {
        return Cache::remember('catalog', 'age_ranges', 600, static fn () => Database::fetchAll('SELECT * FROM age_ranges ORDER BY sort_order, min_months'));
    }

    public function ageRange(string $slug): ?array
    {
        foreach ($this->ageRanges() as $r) {
            if ($r['slug'] === $slug) {
                return $r;
            }
        }
        return null;
    }

    public function budgets(): array
    {
        return Cache::remember('catalog', 'budgets', 600, static fn () => Database::fetchAll('SELECT * FROM budget_ranges WHERE is_active = 1 ORDER BY sort_order, min_amount'));
    }

    public function preferenceTags(): array
    {
        return Cache::remember('catalog', 'pref_tags', 600, static fn () => Database::fetchAll("SELECT * FROM tags WHERE type = 'preference' ORDER BY name"));
    }

    public function categories(bool $activeOnly = true): array
    {
        return Cache::remember('catalog', 'categories:' . (int) $activeOnly, 600, static function () use ($activeOnly) {
            $where = $activeOnly ? 'WHERE c.is_active = 1' : '';
            return Database::fetchAll(
                "SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id AND p.status = 'active') AS product_count
                 FROM categories c $where ORDER BY c.sort_order, c.name"
            );
        });
    }

    /** Top-level categories with their children under 'children'. */
    public function categoryTree(): array
    {
        $all = $this->categories();
        $tree = [];
        foreach ($all as $c) {
            if ($c['parent_id'] === null) {
                $c['children'] = [];
                $tree[(int) $c['id']] = $c;
            }
        }
        foreach ($all as $c) {
            if ($c['parent_id'] !== null && isset($tree[(int) $c['parent_id']])) {
                $tree[(int) $c['parent_id']]['children'][] = $c;
            }
        }
        return array_values($tree);
    }

    public function category(string $slug): ?array
    {
        return Database::fetch('SELECT * FROM categories WHERE slug = :s AND is_active = 1', ['s' => $slug]);
    }

    public function makers(): array
    {
        return Cache::remember('catalog', 'makers', 600, static fn () => Database::fetchAll('SELECT * FROM makers ORDER BY name'));
    }

    public function synonyms(): array
    {
        return Cache::remember('catalog', 'search_synonyms', 600, static fn () => Database::fetchAll('SELECT phrase, maps_to FROM search_synonyms'));
    }
}
