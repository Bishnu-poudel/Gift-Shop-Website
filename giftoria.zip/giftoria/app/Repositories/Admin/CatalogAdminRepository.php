<?php
declare(strict_types=1);

namespace App\Repositories\Admin;

use App\Core\Database;

/**
 * Admin-only catalog, inventory and purchasing queries (uncached, includes inactive rows).
 * Table names passed to the generic helpers come from controller whitelists only.
 */
final class CatalogAdminRepository
{
    private const SLUG_TABLES = ['products', 'categories', 'recipients', 'occasions', 'interests', 'age_ranges', 'tags', 'makers'];
    /** Column length of each slug column (leaves room for a "-NN" suffix). */
    private const SLUG_LENGTH = ['products' => 210, 'categories' => 140, 'recipients' => 100, 'occasions' => 100, 'interests' => 100, 'age_ranges' => 60, 'tags' => 100, 'makers' => 140];

    /* ------------------------------------------------------------------ helpers */

    /** Returns $base (or base-2, base-3...) so that it is unique in $table.slug, ignoring $exceptId. */
    public function uniqueSlug(string $table, string $base, int $exceptId = 0): string
    {
        if (!in_array($table, self::SLUG_TABLES, true)) {
            throw new \InvalidArgumentException('Slug table not allowed.');
        }
        $base = trim(mb_substr(str_slug($base), 0, self::SLUG_LENGTH[$table] - 5), '-');
        $slug = $base;
        $i = 2;
        while ($this->slugTaken($table, $slug, $exceptId)) {
            $slug = $base . '-' . $i++;
        }
        return $slug;
    }

    public function slugTaken(string $table, string $slug, int $exceptId = 0): bool
    {
        if (!in_array($table, self::SLUG_TABLES, true)) {
            throw new \InvalidArgumentException('Slug table not allowed.');
        }
        $t = Database::ident($table);
        return (int) Database::fetchColumn("SELECT COUNT(*) FROM $t WHERE slug = :s AND id <> :id", ['s' => $slug, 'id' => $exceptId]) > 0;
    }

    /** True when the SKU is used by any product (other than $exceptProduct) or variant (other than $exceptVariant). */
    public function skuTaken(string $sku, int $exceptProduct = 0, int $exceptVariant = 0): bool
    {
        $p = (int) Database::fetchColumn('SELECT COUNT(*) FROM products WHERE sku = :s AND id <> :id', ['s' => $sku, 'id' => $exceptProduct]);
        $v = (int) Database::fetchColumn('SELECT COUNT(*) FROM product_variants WHERE sku = :s AND id <> :id', ['s' => $sku, 'id' => $exceptVariant]);
        return ($p + $v) > 0;
    }

    /* ------------------------------------------------------------------ lookups */

    /** All categories ordered as a tree, each with 'depth' and 'product_count' (any status). */
    public function categoryTree(): array
    {
        $rows = Database::fetchAll(
            'SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS product_count,
                    (SELECT COUNT(*) FROM categories ch WHERE ch.parent_id = c.id) AS child_count
             FROM categories c ORDER BY c.sort_order, c.name'
        );
        $byParent = [];
        $ids = [];
        foreach ($rows as $r) {
            $ids[(int) $r['id']] = true;
        }
        foreach ($rows as $r) {
            $pid = $r['parent_id'] !== null && isset($ids[(int) $r['parent_id']]) ? (int) $r['parent_id'] : 0;
            $byParent[$pid][] = $r;
        }
        $out = [];
        $walk = static function (int $parent, int $depth, array $seen) use (&$walk, &$out, $byParent): void {
            foreach ($byParent[$parent] ?? [] as $r) {
                $id = (int) $r['id'];
                if (isset($seen[$id])) {
                    continue;
                }
                $r['depth'] = $depth;
                $out[] = $r;
                $walk($id, $depth + 1, $seen + [$id => true]);
            }
        };
        $walk(0, 0, []);
        return $out;
    }

    /** Ids of $categoryId and all of its descendants. */
    public function categoryDescendants(int $categoryId): array
    {
        $all = Database::fetchAll('SELECT id, parent_id FROM categories');
        $children = [];
        foreach ($all as $r) {
            if ($r['parent_id'] !== null) {
                $children[(int) $r['parent_id']][] = (int) $r['id'];
            }
        }
        $out = [$categoryId];
        $queue = [$categoryId];
        while ($queue) {
            $id = array_shift($queue);
            foreach ($children[$id] ?? [] as $c) {
                if (!in_array($c, $out, true)) {
                    $out[] = $c;
                    $queue[] = $c;
                }
            }
        }
        return $out;
    }

    public function makers(): array
    {
        return Database::fetchAll('SELECT id, name FROM makers ORDER BY name');
    }

    public function recipients(): array
    {
        return Database::fetchAll('SELECT id, name, is_active FROM recipients ORDER BY sort_order, name');
    }

    public function occasions(): array
    {
        return Database::fetchAll('SELECT id, name, is_active FROM occasions ORDER BY sort_order, name');
    }

    public function interests(): array
    {
        return Database::fetchAll('SELECT id, name, is_active FROM interests ORDER BY sort_order, name');
    }

    public function tags(string $type): array
    {
        return Database::fetchAll('SELECT id, name FROM tags WHERE type = :t ORDER BY name', ['t' => $type]);
    }

    /** @return int[] valid ids from $ids that exist in the whitelisted $table */
    public function existingIds(string $table, array $ids): array
    {
        if (!in_array($table, ['recipients', 'occasions', 'interests', 'tags'], true)) {
            throw new \InvalidArgumentException('Table not allowed.');
        }
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn ($i) => $i > 0)));
        if (!$ids) {
            return [];
        }
        $params = [];
        $in = Database::in('id', $ids, $params);
        return array_map('intval', Database::fetchCol('SELECT id FROM ' . Database::ident($table) . " WHERE id IN $in", $params));
    }

    /* ------------------------------------------------------------------ products */

    public function product(int $id): ?array
    {
        return Database::fetch('SELECT * FROM products WHERE id = :id', ['id' => $id]);
    }

    /** Full product for the edit screen, including inactive variants and assignment ids. */
    public function productForEdit(int $id): ?array
    {
        $p = $this->product($id);
        if (!$p) {
            return null;
        }
        $p['images'] = Database::fetchAll('SELECT * FROM product_images WHERE product_id = :id ORDER BY sort_order, id', ['id' => $id]);
        $p['variants'] = Database::fetchAll(
            'SELECT v.*, COALESCE(i.quantity, 0) AS stock, i.id AS inventory_id FROM product_variants v
             LEFT JOIN inventory i ON i.product_id = v.product_id AND i.variant_id = v.id
             WHERE v.product_id = :id ORDER BY v.sort_order, v.id',
            ['id' => $id]
        );
        $p['attributes'] = Database::fetchAll('SELECT name, value FROM product_attributes WHERE product_id = :id ORDER BY sort_order, id', ['id' => $id]);
        $p['base_inventory'] = Database::fetch('SELECT * FROM inventory WHERE product_id = :id AND variant_id = 0', ['id' => $id]);
        $p['total_stock'] = (int) Database::fetchColumn('SELECT COALESCE(SUM(quantity), 0) FROM inventory WHERE product_id = :id', ['id' => $id]);
        $p['recipient_ids'] = array_map('intval', Database::fetchCol('SELECT recipient_id FROM product_recipients WHERE product_id = :id', ['id' => $id]));
        $p['occasion_ids'] = array_map('intval', Database::fetchCol('SELECT occasion_id FROM product_occasions WHERE product_id = :id', ['id' => $id]));
        $p['interest_ids'] = array_map('intval', Database::fetchCol('SELECT interest_id FROM product_interests WHERE product_id = :id', ['id' => $id]));
        $p['tag_ids'] = array_map('intval', Database::fetchCol('SELECT tag_id FROM product_tags WHERE product_id = :id', ['id' => $id]));
        return $p;
    }

    /** Replaces the rows of a product join table. Call inside a transaction. */
    public function syncJoin(string $table, string $column, int $productId, array $ids): void
    {
        $allowed = [
            'product_recipients' => 'recipient_id',
            'product_occasions' => 'occasion_id',
            'product_interests' => 'interest_id',
            'product_tags' => 'tag_id',
        ];
        if (($allowed[$table] ?? null) !== $column) {
            throw new \InvalidArgumentException('Join table not allowed.');
        }
        Database::delete($table, ['product_id' => $productId]);
        foreach (array_unique($ids) as $id) {
            Database::insert($table, ['product_id' => $productId, $column => (int) $id]);
        }
    }

    /** Ids for the stock-state filter on the product list. */
    public function productIdsByStock(string $state): array
    {
        $sql = match ($state) {
            'out' => 'SELECT p.id FROM products p WHERE COALESCE((SELECT SUM(i.quantity) FROM inventory i WHERE i.product_id = p.id), 0) <= 0',
            'low' => 'SELECT DISTINCT i.product_id FROM inventory i WHERE i.quantity > 0 AND i.quantity <= i.low_stock_threshold',
            'in' => 'SELECT p.id FROM products p WHERE COALESCE((SELECT SUM(i.quantity) FROM inventory i WHERE i.product_id = p.id), 0) > 0',
            default => null,
        };
        if ($sql === null) {
            return [];
        }
        $ids = array_map('intval', Database::fetchCol($sql));
        return $ids ?: [0];
    }

    public function productStatusCounts(): array
    {
        $rows = Database::fetchAll('SELECT status, COUNT(*) AS n FROM products GROUP BY status');
        $out = ['draft' => 0, 'active' => 0, 'inactive' => 0];
        foreach ($rows as $r) {
            $out[$r['status']] = (int) $r['n'];
        }
        return $out;
    }

    /* ------------------------------------------------------------------ inventory */

    /** @return array{items: array, total: int} */
    public function stockLevels(array $f, int $perPage, int $offset): array
    {
        $where = [];
        $params = [];
        if (($f['q'] ?? '') !== '') {
            $params['q1'] = '%' . $f['q'] . '%';
            $params['q2'] = '%' . $f['q'] . '%';
            $params['q3'] = '%' . $f['q'] . '%';
            $where[] = '(p.name LIKE :q1 OR p.sku LIKE :q2 OR v.sku LIKE :q3)';
        }
        if (!empty($f['low'])) {
            $where[] = 'i.quantity <= i.low_stock_threshold';
        }
        if (!empty($f['status'])) {
            $params['st'] = $f['status'];
            $where[] = 'p.status = :st';
        }
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $from = 'FROM inventory i JOIN products p ON p.id = i.product_id LEFT JOIN product_variants v ON v.id = i.variant_id AND i.variant_id <> 0';
        $total = (int) Database::fetchColumn("SELECT COUNT(*) $from $whereSql", $params);
        $items = Database::fetchAll(
            "SELECT i.*, p.name AS product_name, p.sku AS product_sku, p.status AS product_status, p.allow_backorder,
                    v.name AS variant_name, v.sku AS variant_sku, v.is_active AS variant_active
             $from $whereSql
             ORDER BY (i.quantity <= i.low_stock_threshold) DESC, p.name, i.variant_id
             LIMIT " . (int) $perPage . ' OFFSET ' . (int) $offset,
            $params
        );
        return ['items' => $items, 'total' => $total];
    }

    public function inventoryItem(int $id): ?array
    {
        return Database::fetch(
            'SELECT i.*, p.name AS product_name, p.sku AS product_sku, p.allow_backorder, v.name AS variant_name, v.sku AS variant_sku
             FROM inventory i JOIN products p ON p.id = i.product_id
             LEFT JOIN product_variants v ON v.id = i.variant_id AND i.variant_id <> 0
             WHERE i.id = :id',
            ['id' => $id]
        );
    }

    /** @return array{items: array, total: int} */
    public function movements(array $f, int $perPage, int $offset): array
    {
        $where = [];
        $params = [];
        if (!empty($f['product_id'])) {
            $params['pid'] = (int) $f['product_id'];
            $where[] = 'm.product_id = :pid';
        }
        if (isset($f['variant_id']) && $f['variant_id'] !== null) {
            $params['vid'] = (int) $f['variant_id'];
            $where[] = 'm.variant_id = :vid';
        }
        if (!empty($f['type'])) {
            $params['type'] = $f['type'];
            $where[] = 'm.type = :type';
        }
        if (!empty($f['from_utc'])) {
            $params['dfrom'] = $f['from_utc'];
            $where[] = 'm.created_at >= :dfrom';
        }
        if (!empty($f['to_utc'])) {
            $params['dto'] = $f['to_utc'];
            $where[] = 'm.created_at < :dto';
        }
        if (($f['q'] ?? '') !== '') {
            $params['mq1'] = '%' . $f['q'] . '%';
            $params['mq2'] = '%' . $f['q'] . '%';
            $where[] = '(p.name LIKE :mq1 OR p.sku LIKE :mq2)';
        }
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $from = 'FROM inventory_movements m JOIN products p ON p.id = m.product_id';
        $total = (int) Database::fetchColumn("SELECT COUNT(*) $from $whereSql", $params);
        $items = Database::fetchAll(
            "SELECT m.*, p.name AS product_name, p.sku AS product_sku, v.name AS variant_name, u.name AS user_name,
                    o.order_number, po.po_number
             $from
             LEFT JOIN product_variants v ON v.id = m.variant_id AND m.variant_id <> 0
             LEFT JOIN users u ON u.id = m.user_id
             LEFT JOIN orders o ON m.reference_type = 'order' AND o.id = m.reference_id
             LEFT JOIN purchase_orders po ON m.reference_type = 'purchase_order' AND po.id = m.reference_id
             $whereSql
             ORDER BY m.created_at DESC, m.id DESC
             LIMIT " . (int) $perPage . ' OFFSET ' . (int) $offset,
            $params
        );
        return ['items' => $items, 'total' => $total];
    }

    public function productOptions(): array
    {
        return Database::fetchAll('SELECT id, name, sku FROM products ORDER BY name');
    }

    /** Products and variants as purchasable lines: key "productId:variantId". */
    public function purchasableItems(): array
    {
        $rows = Database::fetchAll(
            'SELECT p.id AS product_id, 0 AS variant_id, p.name, p.sku, NULL AS variant_name, p.cost_price
             FROM products p
             UNION ALL
             SELECT v.product_id, v.id, p2.name, v.sku, v.name, p2.cost_price
             FROM product_variants v JOIN products p2 ON p2.id = v.product_id
             ORDER BY name, variant_id'
        );
        $out = [];
        foreach ($rows as $r) {
            $key = (int) $r['product_id'] . ':' . (int) $r['variant_id'];
            $out[$key] = $r + ['label' => $r['name'] . ($r['variant_name'] ? ' — ' . $r['variant_name'] : '') . ' (' . $r['sku'] . ')'];
        }
        return $out;
    }

    /* ------------------------------------------------------------------ suppliers / POs */

    public function suppliers(string $q = ''): array
    {
        $params = [];
        $where = '';
        if ($q !== '') {
            $params['q1'] = '%' . $q . '%';
            $params['q2'] = '%' . $q . '%';
            $where = 'WHERE s.name LIKE :q1 OR s.contact_name LIKE :q2';
        }
        return Database::fetchAll(
            "SELECT s.*, (SELECT COUNT(*) FROM purchase_orders po WHERE po.supplier_id = s.id) AS po_count,
                    (SELECT COUNT(*) FROM purchase_orders po2 WHERE po2.supplier_id = s.id AND po2.status IN ('ordered','partially_received')) AS open_po_count
             FROM suppliers s $where ORDER BY s.is_active DESC, s.name",
            $params
        );
    }

    /** @return array{items: array, total: int} */
    public function purchaseOrders(array $f, int $perPage, int $offset): array
    {
        $where = [];
        $params = [];
        if (!empty($f['status'])) {
            $params['st'] = $f['status'];
            $where[] = 'po.status = :st';
        }
        if (!empty($f['supplier_id'])) {
            $params['sid'] = (int) $f['supplier_id'];
            $where[] = 'po.supplier_id = :sid';
        }
        if (($f['q'] ?? '') !== '') {
            $params['q'] = '%' . $f['q'] . '%';
            $where[] = 'po.po_number LIKE :q';
        }
        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM purchase_orders po $whereSql", $params);
        $items = Database::fetchAll(
            "SELECT po.*, s.name AS supplier_name,
                    (SELECT COALESCE(SUM(quantity_ordered * unit_cost), 0) FROM purchase_order_items a WHERE a.purchase_order_id = po.id) AS total_cost,
                    (SELECT COALESCE(SUM(quantity_ordered), 0) FROM purchase_order_items b WHERE b.purchase_order_id = po.id) AS qty_ordered,
                    (SELECT COALESCE(SUM(quantity_received), 0) FROM purchase_order_items c WHERE c.purchase_order_id = po.id) AS qty_received
             FROM purchase_orders po JOIN suppliers s ON s.id = po.supplier_id
             $whereSql ORDER BY po.created_at DESC, po.id DESC
             LIMIT " . (int) $perPage . ' OFFSET ' . (int) $offset,
            $params
        );
        return ['items' => $items, 'total' => $total];
    }

    public function purchaseOrder(int $id): ?array
    {
        $po = Database::fetch(
            'SELECT po.*, s.name AS supplier_name, s.email AS supplier_email, s.phone AS supplier_phone, u.name AS created_by_name
             FROM purchase_orders po JOIN suppliers s ON s.id = po.supplier_id LEFT JOIN users u ON u.id = po.created_by
             WHERE po.id = :id',
            ['id' => $id]
        );
        if (!$po) {
            return null;
        }
        $po['items'] = Database::fetchAll(
            'SELECT poi.*, p.name AS product_name, p.sku AS product_sku, v.name AS variant_name, v.sku AS variant_sku
             FROM purchase_order_items poi JOIN products p ON p.id = poi.product_id
             LEFT JOIN product_variants v ON v.id = poi.variant_id AND poi.variant_id <> 0
             WHERE poi.purchase_order_id = :id ORDER BY poi.id',
            ['id' => $id]
        );
        return $po;
    }
}
