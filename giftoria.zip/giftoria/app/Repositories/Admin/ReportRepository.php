<?php
declare(strict_types=1);

namespace App\Repositories\Admin;

use App\Core\Database;
use DateTimeImmutable;
use DateTimeZone;

/**
 * Read-only reporting queries for the admin dashboard and reports.
 *
 * Definitions (used consistently and shown in the UI):
 *  - "Paid" orders: payment_status paid or partially_refunded. Revenue = grand_total - refunded_total,
 *    dated by paid_at (falls back to created_at for legacy rows).
 *  - "Counted" orders (product/category popularity): status confirmed → return_requested, i.e. not
 *    pending payment, cancelled, returned or refunded. Dated by created_at.
 * Stored timestamps are UTC; grouping by day uses the store timezone (Asia/Kathmandu).
 */
final class ReportRepository
{
    public const PAID = "('paid','partially_refunded')";
    public const COUNTED = "('confirmed','processing','packed','shipped','out_for_delivery','delivered','return_requested')";
    private const PAID_AT = 'COALESCE(o.paid_at, o.created_at)';

    private int $offset;

    public function __construct()
    {
        $tz = new DateTimeZone((string) config('app.timezone', 'Asia/Kathmandu'));
        $this->offset = (int) round($tz->getOffset(new DateTimeImmutable('now', new DateTimeZone('UTC'))) / 60);
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    /**
     * Resolves a local date range (inclusive) from ?from=&to= into local dates and UTC bounds
     * [from_utc, to_utc). Defaults to the last $defaultDays days. Max span ~2 years.
     * @return array{from: string, to: string, from_utc: string, to_utc: string, days: int}
     */
    public static function range(?string $from, ?string $to, int $defaultDays = 30): array
    {
        $tz = new DateTimeZone((string) config('app.timezone', 'Asia/Kathmandu'));
        $utc = new DateTimeZone('UTC');
        $today = new DateTimeImmutable('today', $tz);
        $f = self::parseDate($from, $tz) ?? $today->modify('-' . max(0, $defaultDays - 1) . ' days');
        $t = self::parseDate($to, $tz) ?? $today;
        if ($f > $t) {
            [$f, $t] = [$t, $f];
        }
        $min = $t->modify('-730 days');
        if ($f < $min) {
            $f = $min;
        }
        return [
            'from' => $f->format('Y-m-d'),
            'to' => $t->format('Y-m-d'),
            'from_utc' => $f->setTimezone($utc)->format('Y-m-d H:i:s'),
            'to_utc' => $t->modify('+1 day')->setTimezone($utc)->format('Y-m-d H:i:s'),
            'days' => (int) $f->diff($t)->days + 1,
        ];
    }

    private static function parseDate(?string $value, DateTimeZone $tz): ?DateTimeImmutable
    {
        if (!$value) {
            return null;
        }
        $d = DateTimeImmutable::createFromFormat('!Y-m-d', $value, $tz);
        return ($d && $d->format('Y-m-d') === $value) ? $d : null;
    }

    /** UTC bounds of "today" in the store timezone. */
    public static function todayBounds(): array
    {
        $r = self::range(local_today(), local_today());
        return [$r['from_utc'], $r['to_utc']];
    }

    private function localDay(string $col): string
    {
        return 'DATE(DATE_ADD(' . $col . ', INTERVAL ' . $this->offset . ' MINUTE))';
    }

    private function localPeriod(string $col, string $group): string
    {
        return $group === 'month'
            ? "DATE_FORMAT(DATE_ADD($col, INTERVAL {$this->offset} MINUTE), '%Y-%m')"
            : $this->localDay($col);
    }

    /** Every period label between two local dates (Y-m-d or Y-m). */
    public static function periods(string $from, string $to, string $group = 'day'): array
    {
        $out = [];
        $d = new DateTimeImmutable($from);
        $end = new DateTimeImmutable($to);
        if ($group === 'month') {
            $d = $d->modify('first day of this month');
            while ($d <= $end) {
                $out[] = $d->format('Y-m');
                $d = $d->modify('+1 month');
            }
            return $out;
        }
        while ($d <= $end) {
            $out[] = $d->format('Y-m-d');
            $d = $d->modify('+1 day');
        }
        return $out;
    }

    /** Category id plus its descendants (up to 4 levels). */
    public function categoryWithChildren(int $categoryId): array
    {
        $ids = [$categoryId];
        $frontier = [$categoryId];
        for ($depth = 0; $depth < 4 && $frontier; $depth++) {
            $params = [];
            $in = Database::in('c', $frontier, $params);
            $frontier = array_map('intval', Database::fetchCol("SELECT id FROM categories WHERE parent_id IN $in", $params));
            $frontier = array_values(array_diff($frontier, $ids));
            $ids = array_merge($ids, $frontier);
        }
        return $ids;
    }

    public function categories(): array
    {
        return Database::fetchAll('SELECT id, name, parent_id FROM categories ORDER BY sort_order, name');
    }

    /**
     * CSV with formula-injection protection: text cells starting with = + - @ (or tab/CR) are
     * prefixed with a single quote. Numeric values are left as numbers.
     */
    public static function csv(array $headers, iterable $rows): string
    {
        $fh = fopen('php://temp', 'r+');
        fwrite($fh, "\xEF\xBB\xBF"); // UTF-8 BOM for Excel
        fputcsv($fh, array_map([self::class, 'csvCell'], $headers));
        foreach ($rows as $row) {
            fputcsv($fh, array_map([self::class, 'csvCell'], array_values($row)));
        }
        rewind($fh);
        $csv = (string) stream_get_contents($fh);
        fclose($fh);
        return $csv;
    }

    public static function csvCell(mixed $v): string
    {
        if ($v === null) {
            return '';
        }
        if (is_bool($v)) {
            return $v ? '1' : '0';
        }
        if (is_int($v) || is_float($v)) {
            return (string) $v;
        }
        $s = (string) $v;
        if ($s !== '' && !is_numeric($s) && in_array($s[0], ['=', '+', '-', '@', "\t", "\r"], true)) {
            $s = "'" . $s;
        }
        return $s;
    }

    // ------------------------------------------------------------------
    // Dashboard KPIs
    // ------------------------------------------------------------------

    /** Net paid sales, paid order count and AOV in a range (optionally one payment method). */
    public function salesSummary(array $r, ?string $method = null): array
    {
        $params = ['f' => $r['from_utc'], 't' => $r['to_utc']];
        $where = '';
        if ($method) {
            $where = ' AND o.payment_method = :m';
            $params['m'] = $method;
        }
        $row = Database::fetch(
            'SELECT COUNT(*) AS orders, COALESCE(SUM(o.grand_total), 0) AS gross, COALESCE(SUM(o.refunded_total), 0) AS refunded,
                    COALESCE(SUM(o.grand_total - o.refunded_total), 0) AS net
             FROM orders o
             WHERE o.payment_status IN ' . self::PAID . ' AND ' . self::PAID_AT . ' >= :f AND ' . self::PAID_AT . ' < :t' . $where,
            $params
        ) ?? [];
        $orders = (int) ($row['orders'] ?? 0);
        $net = (float) ($row['net'] ?? 0);
        return [
            'orders' => $orders,
            'gross' => (float) ($row['gross'] ?? 0),
            'refunded' => (float) ($row['refunded'] ?? 0),
            'net' => $net,
            'aov' => $orders > 0 ? round($net / $orders, 2) : null,
        ];
    }

    public function ordersToday(): array
    {
        [$f, $t] = self::todayBounds();
        $row = Database::fetch(
            "SELECT COUNT(*) AS total, COALESCE(SUM(status NOT IN ('pending_payment','cancelled')), 0) AS placed
             FROM orders WHERE created_at >= :f AND created_at < :t",
            ['f' => $f, 't' => $t]
        ) ?? [];
        return ['total' => (int) ($row['total'] ?? 0), 'placed' => (int) ($row['placed'] ?? 0)];
    }

    public function pendingFulfilment(): array
    {
        $rows = Database::fetchAll(
            "SELECT status, COUNT(*) AS n FROM orders WHERE status IN ('confirmed','processing','packed') GROUP BY status"
        );
        $out = ['confirmed' => 0, 'processing' => 0, 'packed' => 0];
        foreach ($rows as $row) {
            $out[$row['status']] = (int) $row['n'];
        }
        return $out;
    }

    /**
     * Revenue series by period. Without a category: net paid order revenue. With a category:
     * line totals of that category's items in paid orders (discounts/shipping not allocated).
     * @return array<string, array{revenue: float, orders: int}>
     */
    public function revenueSeries(array $r, string $group = 'day', ?int $categoryId = null, ?string $method = null): array
    {
        $period = $this->localPeriod(self::PAID_AT, $group);
        $params = ['f' => $r['from_utc'], 't' => $r['to_utc']];
        $where = '';
        if ($method) {
            $where .= ' AND o.payment_method = :m';
            $params['m'] = $method;
        }
        if ($categoryId) {
            $in = Database::in('cat', $this->categoryWithChildren($categoryId), $params);
            $sql = "SELECT $period AS period, COALESCE(SUM(oi.line_total), 0) AS revenue, COUNT(DISTINCT o.id) AS orders
                    FROM orders o JOIN order_items oi ON oi.order_id = o.id JOIN products p ON p.id = oi.product_id
                    WHERE o.payment_status IN " . self::PAID . ' AND ' . self::PAID_AT . ' >= :f AND ' . self::PAID_AT . " < :t
                      AND p.category_id IN $in $where
                    GROUP BY period";
        } else {
            $sql = "SELECT $period AS period, COALESCE(SUM(o.grand_total - o.refunded_total), 0) AS revenue, COUNT(*) AS orders
                    FROM orders o
                    WHERE o.payment_status IN " . self::PAID . ' AND ' . self::PAID_AT . ' >= :f AND ' . self::PAID_AT . " < :t $where
                    GROUP BY period";
        }
        $series = [];
        foreach (self::periods($r['from'], $r['to'], $group) as $p) {
            $series[$p] = ['revenue' => 0.0, 'orders' => 0];
        }
        foreach (Database::fetchAll($sql, $params) as $row) {
            $key = (string) $row['period'];
            $series[$key] = ['revenue' => (float) $row['revenue'], 'orders' => (int) $row['orders']];
        }
        ksort($series);
        return $series;
    }

    /** Bestselling products by units in counted orders. */
    public function topProducts(array $r, int $limit = 10, ?int $categoryId = null): array
    {
        $params = ['f' => $r['from_utc'], 't' => $r['to_utc']];
        $where = '';
        if ($categoryId) {
            $in = Database::in('cat', $this->categoryWithChildren($categoryId), $params);
            $where = " AND p.category_id IN $in";
        }
        return Database::fetchAll(
            'SELECT oi.product_id, MAX(oi.name) AS name, MAX(p.sku) AS sku, SUM(oi.quantity) AS units,
                    SUM(oi.line_total) AS revenue, COUNT(DISTINCT o.id) AS orders,
                    SUM(oi.unit_cost * oi.quantity) AS cost, SUM(oi.unit_cost IS NULL) AS missing_cost
             FROM order_items oi
             JOIN orders o ON o.id = oi.order_id
             LEFT JOIN products p ON p.id = oi.product_id
             WHERE o.status IN ' . self::COUNTED . ' AND o.created_at >= :f AND o.created_at < :t' . $where . '
             GROUP BY oi.product_id
             ORDER BY units DESC, revenue DESC
             LIMIT ' . (int) $limit,
            $params
        );
    }

    /** Categories ranked by item revenue in counted orders. */
    public function topCategories(array $r, int $limit = 10): array
    {
        return Database::fetchAll(
            "SELECT c.id, COALESCE(c.name, 'Uncategorised') AS name, SUM(oi.quantity) AS units,
                    SUM(oi.line_total) AS revenue, COUNT(DISTINCT o.id) AS orders,
                    SUM(oi.unit_cost * oi.quantity) AS cost, SUM(oi.unit_cost IS NULL) AS missing_cost
             FROM order_items oi
             JOIN orders o ON o.id = oi.order_id
             LEFT JOIN products p ON p.id = oi.product_id
             LEFT JOIN categories c ON c.id = p.category_id
             WHERE o.status IN " . self::COUNTED . ' AND o.created_at >= :f AND o.created_at < :t
             GROUP BY c.id, c.name
             ORDER BY revenue DESC
             LIMIT ' . (int) $limit,
            ['f' => $r['from_utc'], 't' => $r['to_utc']]
        );
    }

    /** @return array<string,int> new customer accounts per local day */
    public function customerGrowth(array $r): array
    {
        $day = $this->localDay('created_at');
        $series = array_fill_keys(self::periods($r['from'], $r['to']), 0);
        $rows = Database::fetchAll(
            "SELECT $day AS d, COUNT(*) AS n FROM users WHERE type = 'customer' AND created_at >= :f AND created_at < :t GROUP BY d",
            ['f' => $r['from_utc'], 't' => $r['to_utc']]
        );
        foreach ($rows as $row) {
            $series[(string) $row['d']] = (int) $row['n'];
        }
        ksort($series);
        return $series;
    }

    public function customerTotals(): array
    {
        $row = Database::fetch(
            "SELECT COUNT(*) AS total, COALESCE(SUM(status = 'active'), 0) AS active FROM users WHERE type = 'customer' AND status <> 'deleted'"
        ) ?? [];
        return ['total' => (int) ($row['total'] ?? 0), 'active' => (int) ($row['active'] ?? 0)];
    }

    /** Coupon redemptions in range (cancelled orders excluded from revenue). */
    public function couponPerformance(array $r, int $limit = 10): array
    {
        return Database::fetchAll(
            "SELECT c.id, c.code, c.type, c.value, c.is_active, COUNT(cr.id) AS uses,
                    COALESCE(SUM(cr.discount), 0) AS discount,
                    COALESCE(SUM(CASE WHEN o.status NOT IN ('cancelled','pending_payment') THEN o.grand_total ELSE 0 END), 0) AS revenue,
                    COALESCE(SUM(o.status NOT IN ('cancelled','pending_payment')), 0) AS placed
             FROM coupon_redemptions cr
             JOIN coupons c ON c.id = cr.coupon_id
             JOIN orders o ON o.id = cr.order_id
             WHERE cr.created_at >= :f AND cr.created_at < :t
             GROUP BY c.id, c.code, c.type, c.value, c.is_active
             ORDER BY uses DESC
             LIMIT " . (int) $limit,
            ['f' => $r['from_utc'], 't' => $r['to_utc']]
        );
    }

    /** Payment attempt outcomes by gateway (from the payments table). */
    public function paymentStats(array $r): array
    {
        return Database::fetchAll(
            "SELECT gateway, COUNT(*) AS attempts,
                    COALESCE(SUM(status IN ('paid','partially_refunded','refunded','refund_pending')), 0) AS succeeded,
                    COALESCE(SUM(status = 'failed'), 0) AS failed,
                    COALESCE(SUM(status IN ('cancelled','expired')), 0) AS abandoned,
                    COALESCE(SUM(status IN ('initiated','pending')), 0) AS open_attempts,
                    COALESCE(SUM(CASE WHEN status IN ('paid','partially_refunded','refunded','refund_pending') THEN amount ELSE 0 END), 0) AS amount
             FROM payments
             WHERE created_at >= :f AND created_at < :t
             GROUP BY gateway
             ORDER BY attempts DESC",
            ['f' => $r['from_utc'], 't' => $r['to_utc']]
        );
    }

    public function refundSummary(array $r): array
    {
        $rows = Database::fetchAll(
            'SELECT status, COUNT(*) AS n, COALESCE(SUM(amount), 0) AS amount FROM refunds
             WHERE created_at >= :f AND created_at < :t GROUP BY status',
            ['f' => $r['from_utc'], 't' => $r['to_utc']]
        );
        $out = [];
        foreach (['requested', 'approved', 'completed', 'rejected'] as $s) {
            $out[$s] = ['n' => 0, 'amount' => 0.0];
        }
        foreach ($rows as $row) {
            $out[$row['status']] = ['n' => (int) $row['n'], 'amount' => (float) $row['amount']];
        }
        $open = Database::fetch("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS amount FROM refunds WHERE status IN ('requested','approved')") ?? [];
        return ['by_status' => $out, 'open_n' => (int) ($open['n'] ?? 0), 'open_amount' => (float) ($open['amount'] ?? 0)];
    }

    /** Measured storefront counters from analytics_daily (local dates). */
    public function conversion(array $r): array
    {
        $rows = Database::fetchAll(
            "SELECT metric, SUM(value) AS v FROM analytics_daily
             WHERE day >= :f AND day <= :t AND metric IN ('visits','add_to_cart','orders','searches')
             GROUP BY metric",
            ['f' => $r['from'], 't' => $r['to']]
        );
        $out = ['visits' => 0, 'add_to_cart' => 0, 'orders' => 0, 'searches' => 0];
        foreach ($rows as $row) {
            $out[$row['metric']] = (int) $row['v'];
        }
        return $out;
    }

    public function recentAudit(int $limit = 10): array
    {
        return Database::fetchAll(
            'SELECT a.id, a.action, a.entity_type, a.entity_id, a.created_at, u.name AS user_name
             FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
             ORDER BY a.id DESC LIMIT ' . (int) $limit
        );
    }

    public function recentOrders(int $limit = 10): array
    {
        return Database::fetchAll(
            'SELECT id, order_number, customer_name, status, payment_status, payment_method, grand_total, created_at
             FROM orders ORDER BY id DESC LIMIT ' . (int) $limit
        );
    }

    // ------------------------------------------------------------------
    // Reports
    // ------------------------------------------------------------------

    /** Paid sales grouped by day or month (by paid date). */
    public function salesReport(array $r, string $group = 'day'): array
    {
        $period = $this->localPeriod(self::PAID_AT, $group);
        $rows = Database::fetchAll(
            "SELECT $period AS period, COUNT(*) AS orders, SUM(o.subtotal) AS subtotal, SUM(o.discount_total) AS discount,
                    SUM(o.shipping_total) AS shipping, SUM(o.gift_wrap_total) AS gift_wrap, SUM(o.grand_total) AS gross,
                    SUM(o.refunded_total) AS refunded, SUM(o.grand_total - o.refunded_total) AS net,
                    SUM(COALESCE(ic.cost, 0)) AS cost, SUM(COALESCE(ic.missing, 0)) AS missing_cost
             FROM orders o
             LEFT JOIN (SELECT order_id, SUM(unit_cost * quantity) AS cost, SUM(unit_cost IS NULL) AS missing
                        FROM order_items GROUP BY order_id) ic ON ic.order_id = o.id
             WHERE o.payment_status IN " . self::PAID . ' AND ' . self::PAID_AT . ' >= :f AND ' . self::PAID_AT . ' < :t
             GROUP BY period ORDER BY period',
            ['f' => $r['from_utc'], 't' => $r['to_utc']]
        );
        foreach ($rows as &$row) {
            $row['item_margin'] = round((float) $row['subtotal'] - (float) $row['discount'] - (float) $row['cost'], 2);
        }
        unset($row);
        return $rows;
    }

    /** Orders by payment method, plus paid revenue. */
    public function paymentMethodsReport(array $r): array
    {
        return Database::fetchAll(
            "SELECT o.payment_method, COUNT(*) AS orders,
                    COALESCE(SUM(o.payment_status IN " . self::PAID . "), 0) AS paid_orders,
                    COALESCE(SUM(o.status = 'cancelled'), 0) AS cancelled,
                    COALESCE(SUM(CASE WHEN o.payment_status IN " . self::PAID . " THEN o.grand_total - o.refunded_total ELSE 0 END), 0) AS net
             FROM orders o
             WHERE o.created_at >= :f AND o.created_at < :t
             GROUP BY o.payment_method ORDER BY orders DESC",
            ['f' => $r['from_utc'], 't' => $r['to_utc']]
        );
    }

    /**
     * Financial ledger: verified payments (money in) and completed refunds (money out).
     * Contains references only — never gateway payloads or secrets.
     */
    public function financeLedger(array $r): array
    {
        $payments = Database::fetchAll(
            "SELECT COALESCE(p.verified_at, p.created_at) AS at, 'payment' AS entry, o.order_number, p.gateway,
                    p.attempt_ref AS reference, p.gateway_txn_id AS gateway_reference, p.amount, p.status
             FROM payments p JOIN orders o ON o.id = p.order_id
             WHERE p.verified_at IS NOT NULL AND p.verified_at >= :f AND p.verified_at < :t
             ORDER BY p.verified_at",
            ['f' => $r['from_utc'], 't' => $r['to_utc']]
        );
        $refunds = Database::fetchAll(
            "SELECT rf.processed_at AS at, 'refund' AS entry, o.order_number, COALESCE(p.gateway, o.payment_method) AS gateway,
                    CONCAT('REFUND-', rf.id) AS reference, rf.gateway_reference, -rf.amount AS amount, rf.status
             FROM refunds rf JOIN orders o ON o.id = rf.order_id LEFT JOIN payments p ON p.id = rf.payment_id
             WHERE rf.status = 'completed' AND rf.processed_at >= :f AND rf.processed_at < :t
             ORDER BY rf.processed_at",
            ['f' => $r['from_utc'], 't' => $r['to_utc']]
        );
        $all = array_merge($payments, $refunds);
        usort($all, static fn ($a, $b) => strcmp((string) $a['at'], (string) $b['at']));
        return $all;
    }
}
