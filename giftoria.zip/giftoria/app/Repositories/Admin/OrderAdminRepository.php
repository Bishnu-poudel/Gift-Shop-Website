<?php
declare(strict_types=1);

namespace App\Repositories\Admin;

use App\Core\Database;
use App\Core\Logger;
use App\Services\OrderStateMachine;
use RuntimeException;

/** Admin order queries: filtered listing, detail sub-records and manual-order line building. */
final class OrderAdminRepository
{
    public const PAYMENT_STATUSES = ['initiated', 'pending', 'paid', 'failed', 'cancelled', 'expired', 'refund_pending', 'partially_refunded', 'refunded'];
    public const PAYMENT_METHODS = ['esewa' => 'eSewa', 'khalti' => 'Khalti', 'cod' => 'Cash on delivery'];

    /** Normalised filters from the query string. */
    public static function filters(array $q): array
    {
        $date = static fn ($v) => is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) ? $v : '';
        $status = (string) ($q['status'] ?? '');
        $pay = (string) ($q['payment_status'] ?? '');
        $method = (string) ($q['payment_method'] ?? '');
        return [
            'q' => mb_substr(trim((string) (is_scalar($q['q'] ?? null) ? $q['q'] : '')), 0, 100),
            'status' => isset(OrderStateMachine::ORDER_LABELS[$status]) ? $status : '',
            'payment_status' => in_array($pay, self::PAYMENT_STATUSES, true) ? $pay : '',
            'payment_method' => isset(self::PAYMENT_METHODS[$method]) ? $method : '',
            'from' => $date($q['from'] ?? null),
            'to' => $date($q['to'] ?? null),
        ];
    }

    /** @return array{0: string, 1: array} WHERE clause and params */
    private function where(array $f): array
    {
        $w = ['1 = 1'];
        $p = [];
        if ($f['q'] !== '') {
            $like = '%' . addcslashes($f['q'], '%_\\') . '%';
            $w[] = '(o.order_number LIKE :q1 OR o.email LIKE :q2 OR o.phone LIKE :q3 OR o.customer_name LIKE :q4)';
            $p += ['q1' => $like, 'q2' => $like, 'q3' => $like, 'q4' => $like];
        }
        foreach (['status', 'payment_status', 'payment_method'] as $col) {
            if ($f[$col] !== '') {
                $w[] = "o.$col = :$col";
                $p[$col] = $f[$col];
            }
        }
        if ($f['from'] !== '') {
            $w[] = 'o.created_at >= :from';
            $p['from'] = local_to_utc($f['from'] . ' 00:00:00');
        }
        if ($f['to'] !== '') {
            $w[] = 'o.created_at < :to';
            $p['to'] = local_to_utc(date('Y-m-d', strtotime($f['to'] . ' +1 day')) . ' 00:00:00');
        }
        return [implode(' AND ', $w), $p];
    }

    public function count(array $f): int
    {
        [$where, $p] = $this->where($f);
        return (int) Database::fetchColumn("SELECT COUNT(*) FROM orders o WHERE $where", $p);
    }

    public function list(array $f, int $limit, int $offset): array
    {
        [$where, $p] = $this->where($f);
        return Database::fetchAll(
            "SELECT o.id, o.order_number, o.customer_name, o.email, o.phone, o.status, o.payment_status, o.payment_method,
                    o.grand_total, o.refunded_total, o.source, o.created_at,
                    (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi WHERE oi.order_id = o.id) AS item_count
             FROM orders o WHERE $where ORDER BY o.id DESC LIMIT " . (int) $limit . ' OFFSET ' . (int) $offset,
            $p
        );
    }

    public function exportRows(array $f, int $max = 20000): array
    {
        [$where, $p] = $this->where($f);
        return Database::fetchAll(
            "SELECT o.order_number, o.created_at, o.customer_name, o.email, o.phone, o.status, o.payment_status, o.payment_method,
                    o.subtotal, o.discount_total, o.shipping_total, o.gift_wrap_total, o.grand_total, o.refunded_total,
                    o.coupon_code, o.source, sa.district, sa.municipality
             FROM orders o LEFT JOIN order_addresses sa ON sa.order_id = o.id AND sa.type = 'shipping'
             WHERE $where ORDER BY o.id DESC LIMIT " . (int) $max,
            $p
        );
    }

    // ------------------------------------------------------------------
    // Detail
    // ------------------------------------------------------------------

    public function find(int $id): ?array
    {
        return Database::fetch(
            'SELECT o.*, cu.name AS created_by_name, dz.name AS zone_name
             FROM orders o LEFT JOIN users cu ON cu.id = o.created_by LEFT JOIN delivery_zones dz ON dz.id = o.delivery_zone_id
             WHERE o.id = :id',
            ['id' => $id]
        );
    }

    public function addresses(int $orderId): array
    {
        $out = ['shipping' => null, 'billing' => null];
        foreach (Database::fetchAll('SELECT * FROM order_addresses WHERE order_id = :o', ['o' => $orderId]) as $a) {
            $out[$a['type']] = $a;
        }
        return $out;
    }

    public function history(int $orderId): array
    {
        return Database::fetchAll(
            'SELECT h.*, u.name AS user_name FROM order_status_history h LEFT JOIN users u ON u.id = h.user_id
             WHERE h.order_id = :o ORDER BY h.id DESC',
            ['o' => $orderId]
        );
    }

    public function notes(int $orderId): array
    {
        return Database::fetchAll(
            'SELECT n.*, u.name AS user_name FROM order_notes n LEFT JOIN users u ON u.id = n.user_id
             WHERE n.order_id = :o ORDER BY n.id DESC',
            ['o' => $orderId]
        );
    }

    public function shipments(int $orderId): array
    {
        return Database::fetchAll('SELECT * FROM shipments WHERE order_id = :o ORDER BY id DESC', ['o' => $orderId]);
    }

    public function refunds(int $orderId): array
    {
        return Database::fetchAll(
            'SELECT r.*, rq.name AS requested_by_name, pr.name AS processed_by_name FROM refunds r
             LEFT JOIN users rq ON rq.id = r.requested_by LEFT JOIN users pr ON pr.id = r.processed_by
             WHERE r.order_id = :o ORDER BY r.id DESC',
            ['o' => $orderId]
        );
    }

    public function returns(int $orderId): array
    {
        return Database::fetchAll('SELECT * FROM return_requests WHERE order_id = :o ORDER BY id DESC', ['o' => $orderId]);
    }

    /** Payment attempts with their (already redacted) events. Never includes secrets. */
    public function payments(int $orderId): array
    {
        $payments = Database::fetchAll(
            'SELECT id, gateway, attempt_ref, gateway_ref, gateway_txn_id, amount, status, gateway_status, verified_at, created_at
             FROM payments WHERE order_id = :o ORDER BY id DESC',
            ['o' => $orderId]
        );
        if (!$payments) {
            return [];
        }
        $params = [];
        $in = Database::in('p', array_column($payments, 'id'), $params);
        $events = Database::fetchAll("SELECT id, payment_id, event_type, payload_json, created_at FROM payment_events WHERE payment_id IN $in ORDER BY id", $params);
        $byPayment = [];
        foreach ($events as $ev) {
            $payload = $ev['payload_json'] ? json_decode((string) $ev['payload_json'], true) : null;
            $ev['payload'] = is_array($payload)
                ? json_encode(Logger::redact($payload), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
                : null;
            unset($ev['payload_json']);
            $byPayment[(int) $ev['payment_id']][] = $ev;
        }
        foreach ($payments as &$p) {
            $p['events'] = $byPayment[(int) $p['id']] ?? [];
        }
        unset($p);
        return $payments;
    }

    /** Amount still refundable: paid total minus completed refunds minus open refund requests. */
    public function refundable(array $order): array
    {
        $paidStatuses = ['paid', 'partially_refunded', 'refund_pending'];
        $paid = in_array($order['payment_status'], $paidStatuses, true) ? (float) $order['grand_total'] : 0.0;
        $open = (float) Database::fetchColumn(
            "SELECT COALESCE(SUM(amount), 0) FROM refunds WHERE order_id = :o AND status IN ('requested','approved')",
            ['o' => (int) $order['id']]
        );
        $refunded = (float) $order['refunded_total'];
        return [
            'paid' => $paid,
            'refunded' => $refunded,
            'open' => $open,
            'available' => max(0.0, round($paid - $refunded - $open, 2)),
        ];
    }

    // ------------------------------------------------------------------
    // Manual orders
    // ------------------------------------------------------------------

    /** Sellable product/variant options for the manual order picker. */
    public function productOptions(int $limit = 600): array
    {
        return Database::fetchAll(
            "SELECT p.id AS product_id, COALESCE(v.id, 0) AS variant_id, p.name, v.name AS variant_name,
                    COALESCE(v.sku, p.sku) AS sku, p.price, p.sale_price, COALESCE(v.price_adjustment, 0) AS price_adjustment,
                    COALESCE(i.quantity, 0) AS stock, p.allow_backorder, p.is_personalizable
             FROM products p
             LEFT JOIN product_variants v ON v.product_id = p.id AND v.is_active = 1
             LEFT JOIN inventory i ON i.product_id = p.id AND i.variant_id = COALESCE(v.id, 0)
             WHERE p.status = 'active'
             ORDER BY p.name, v.sort_order, v.id
             LIMIT " . (int) $limit
        );
    }

    /**
     * Builds CartService::lines()-shaped rows from [product_id, variant_id, quantity, personalization] picks.
     * Validates variant ownership, required variant choice and personalization limits. Identical picks are merged.
     * @throws RuntimeException
     */
    public function buildLines(array $picks): array
    {
        $merged = [];
        foreach ($picks as $pick) {
            $pid = (int) $pick['product_id'];
            $vid = (int) $pick['variant_id'];
            $qty = (int) $pick['quantity'];
            if ($pid <= 0 || $qty <= 0) {
                continue;
            }
            $pers = isset($pick['personalization']) ? trim(strip_tags((string) $pick['personalization'])) : '';
            $key = $pid . ':' . $vid . ':' . md5($pers);
            if (isset($merged[$key])) {
                $merged[$key]['quantity'] += $qty;
            } else {
                $merged[$key] = ['product_id' => $pid, 'variant_id' => $vid, 'quantity' => $qty, 'personalization' => $pers];
            }
        }
        if ($merged === []) {
            throw new RuntimeException('Add at least one product with a quantity.');
        }

        $lines = [];
        $n = 0;
        foreach ($merged as $pick) {
            $row = Database::fetch(
                'SELECT p.id AS product_id, p.name, p.sku, p.price, p.sale_price, p.status, p.category_id, p.allow_backorder,
                        p.cost_price, p.gift_wrap_available, p.is_personalizable, p.personalization_max_chars,
                        p.lead_time_days, p.valley_only
                 FROM products p WHERE p.id = :id',
                ['id' => $pick['product_id']]
            );
            if (!$row) {
                throw new RuntimeException('A selected product no longer exists.');
            }
            $variant = null;
            if ($pick['variant_id'] > 0) {
                $variant = Database::fetch(
                    'SELECT id, name, sku, price_adjustment, is_active FROM product_variants WHERE id = :v AND product_id = :p',
                    ['v' => $pick['variant_id'], 'p' => $pick['product_id']]
                );
                if (!$variant) {
                    throw new RuntimeException('The selected option for ' . $row['name'] . ' is not valid.');
                }
            } elseif ((int) Database::fetchColumn('SELECT COUNT(*) FROM product_variants WHERE product_id = :p AND is_active = 1', ['p' => $pick['product_id']]) > 0) {
                throw new RuntimeException('Please choose an option for ' . $row['name'] . '.');
            }
            if ($pick['quantity'] > 100) {
                throw new RuntimeException('Quantity for ' . $row['name'] . ' is too large.');
            }
            $pers = $pick['personalization'] !== '' && (int) $row['is_personalizable'] ? $pick['personalization'] : null;
            if ($pers !== null && $row['personalization_max_chars'] && mb_strlen($pers) > (int) $row['personalization_max_chars']) {
                throw new RuntimeException('Personalization for ' . $row['name'] . ' is limited to ' . (int) $row['personalization_max_chars'] . ' characters.');
            }
            $stock = (int) Database::fetchColumn(
                'SELECT COALESCE(quantity, 0) FROM inventory WHERE product_id = :p AND variant_id = :v',
                ['p' => $pick['product_id'], 'v' => $pick['variant_id']]
            );
            $lines[] = [
                'id' => ++$n,
                'product_id' => (int) $row['product_id'],
                'variant_id' => $pick['variant_id'],
                'quantity' => $pick['quantity'],
                'personalization' => $pers,
                'status' => $row['status'],
                'price' => $row['price'],
                'sale_price' => $row['sale_price'],
                'price_adjustment' => $variant['price_adjustment'] ?? 0,
                'variant_active' => $variant ? (int) $variant['is_active'] : null,
                'allow_backorder' => (int) $row['allow_backorder'],
                'stock' => $stock,
                'gift_wrap_available' => (int) $row['gift_wrap_available'],
                'lead_time_days' => (int) $row['lead_time_days'],
                'valley_only' => (int) $row['valley_only'],
                'name' => $row['name'],
                'sku' => $row['sku'],
                'variant_sku' => $variant['sku'] ?? null,
                'variant_name' => $variant['name'] ?? null,
                'cost_price' => $row['cost_price'],
                'category_id' => $row['category_id'],
            ];
        }
        return $lines;
    }
}
