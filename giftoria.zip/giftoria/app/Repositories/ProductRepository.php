<?php
declare(strict_types=1);

namespace App\Repositories;

use App\Core\Database;

/**
 * Catalog queries shared by listing pages, search, the Gift Finder and admin.
 *
 * Filter keys accepted by search():
 *   q, category (slug, includes children), recipient, occasion, interests (slug[]), age (age-range slug),
 *   age_min_months/age_max_months, min_price, max_price, rating (min stars), in_stock (bool),
 *   personalizable (bool), gift_wrap (bool), maker (slug), prefs (preference tag slug[]),
 *   featured, bestseller, new (bool), ids (int[]), exclude_ids (int[]), status (admin only; default active)
 */
final class ProductRepository
{
    public const SORTS = [
        'relevance' => 'Relevance',
        'popular' => 'Most popular',
        'newest' => 'Newest',
        'price_asc' => 'Price: low to high',
        'price_desc' => 'Price: high to low',
        'rating' => 'Top rated',
    ];

    /** Columns needed to render a product card. */
    public const CARD_SELECT = "p.id, p.sku, p.name, p.slug, p.short_description, p.price, p.sale_price,
        COALESCE(p.sale_price, p.price) AS effective_price, p.rating_avg, p.rating_count, p.sales_count,
        p.is_personalizable, p.gift_wrap_available, p.allow_backorder, p.is_bestseller, p.is_featured,
        p.age_min_months, p.age_max_months, p.has_small_parts, p.lead_time_days, p.valley_only, p.created_at,
        p.category_id, p.status,
        COALESCE((SELECT SUM(i.quantity) FROM inventory i WHERE i.product_id = p.id), 0) AS stock,
        (SELECT pi.path FROM product_images pi WHERE pi.product_id = p.id ORDER BY pi.sort_order, pi.id LIMIT 1) AS image,
        (SELECT pi2.alt FROM product_images pi2 WHERE pi2.product_id = p.id ORDER BY pi2.sort_order, pi2.id LIMIT 1) AS image_alt";

    /**
     * SQL fragment enforcing age suitability for a child/adult range (months).
     * Babies & toddlers (range starting under 36 months) get strict safety rules:
     *  - product must declare an age range (no unknown-age items),
     *  - its minimum age must not exceed the youngest age in the range,
     *  - items flagged with small parts are excluded.
     */
    public static function ageCondition(int $min, ?int $max, array &$params, string $alias = 'p'): string
    {
        $max ??= 1200;
        $params['age_lo2'] = $min;
        if ($min < 36) {
            $params['age_lo'] = $min;
            return "($alias.age_min_months IS NOT NULL AND $alias.age_min_months <= :age_lo
                     AND ($alias.age_max_months IS NULL OR $alias.age_max_months >= :age_lo2)
                     AND $alias.has_small_parts = 0)";
        }
        $params['age_hi'] = $max;
        return "(($alias.age_min_months IS NULL OR $alias.age_min_months <= :age_hi)
                 AND ($alias.age_max_months IS NULL OR $alias.age_max_months >= :age_lo2))";
    }

    /** @return array{items: array, total: int} */
    public function search(array $f, string $sort = 'popular', int $page = 1, int $perPage = 24, bool $admin = false): array
    {
        $where = [];
        $params = [];
        $joins = '';
        $relevanceSelect = '0';

        if ($admin && !empty($f['status'])) {
            $where[] = 'p.status = :status';
            $params['status'] = $f['status'];
        } elseif (!$admin) {
            $where[] = "p.status = 'active'";
        }

        $q = trim((string) ($f['q'] ?? ''));
        if ($q !== '') {
            $terms = array_filter(preg_split('/\s+/', preg_replace('/[^\p{L}\p{N}\s-]/u', ' ', $q)) ?: [], static fn ($t) => mb_strlen($t) >= 2);
            if ($terms) {
                $boolean = implode(' ', array_map(static fn ($t) => '+' . $t . '*', array_filter($terms, static fn ($t) => mb_strlen($t) >= 3)));
                $likeParts = [];
                foreach (array_values($terms) as $i => $t) {
                    $params['kw' . $i] = '%' . $t . '%';
                    $params['kwt' . $i] = '%' . $t . '%';
                    $params['kws' . $i] = '%' . $t . '%';
                    $likeParts[] = "(p.name LIKE :kw$i OR p.sku LIKE :kws$i OR EXISTS (SELECT 1 FROM product_tags pt JOIN tags t ON t.id = pt.tag_id WHERE pt.product_id = p.id AND t.name LIKE :kwt$i))";
                }
                $cond = '(' . implode(' AND ', $likeParts) . ')';
                if ($boolean !== '') {
                    $params['ft'] = $boolean;
                    $params['ft2'] = $boolean;
                    $cond = "(MATCH(p.name, p.short_description, p.description) AGAINST(:ft IN BOOLEAN MODE) OR $cond)";
                    $relevanceSelect = 'MATCH(p.name, p.short_description, p.description) AGAINST(:ft2 IN BOOLEAN MODE)';
                }
                $where[] = $cond;
            }
        }

        if (!empty($f['category'])) {
            $params['cat'] = $f['category'];
            $params['cat2'] = $f['category'];
            $where[] = 'p.category_id IN (SELECT c.id FROM categories c WHERE c.slug = :cat OR c.parent_id = (SELECT c2.id FROM categories c2 WHERE c2.slug = :cat2))';
        }
        if (!empty($f['recipient'])) {
            $params['rec'] = $f['recipient'];
            $where[] = 'EXISTS (SELECT 1 FROM product_recipients pr JOIN recipients r ON r.id = pr.recipient_id WHERE pr.product_id = p.id AND r.slug = :rec)';
        }
        if (!empty($f['occasion'])) {
            $params['occ'] = $f['occasion'];
            $where[] = 'EXISTS (SELECT 1 FROM product_occasions po JOIN occasions o ON o.id = po.occasion_id WHERE po.product_id = p.id AND o.slug = :occ)';
        }
        if (!empty($f['interests'])) {
            $in = Database::in('int', (array) $f['interests'], $params);
            $where[] = "EXISTS (SELECT 1 FROM product_interests pin JOIN interests it ON it.id = pin.interest_id WHERE pin.product_id = p.id AND it.slug IN $in)";
        }
        if (!empty($f['prefs'])) {
            $in = Database::in('pref', (array) $f['prefs'], $params);
            $where[] = "EXISTS (SELECT 1 FROM product_tags ptp JOIN tags tp ON tp.id = ptp.tag_id WHERE ptp.product_id = p.id AND tp.slug IN $in)";
        }
        if (isset($f['age_min_months']) && $f['age_min_months'] !== null && $f['age_min_months'] !== '') {
            $where[] = self::ageCondition((int) $f['age_min_months'], isset($f['age_max_months']) && $f['age_max_months'] !== '' ? (int) $f['age_max_months'] : null, $params);
        }
        if (isset($f['min_price']) && $f['min_price'] !== '' && is_numeric($f['min_price'])) {
            $params['minp'] = (float) $f['min_price'];
            $where[] = 'COALESCE(p.sale_price, p.price) >= :minp';
        }
        if (isset($f['max_price']) && $f['max_price'] !== '' && is_numeric($f['max_price'])) {
            $params['maxp'] = (float) $f['max_price'];
            $where[] = 'COALESCE(p.sale_price, p.price) <= :maxp';
        }
        if (!empty($f['rating'])) {
            $params['rating'] = (float) $f['rating'];
            $where[] = 'p.rating_count > 0 AND p.rating_avg >= :rating';
        }
        if (!empty($f['in_stock'])) {
            $where[] = '(p.allow_backorder = 1 OR (SELECT COALESCE(SUM(i2.quantity),0) FROM inventory i2 WHERE i2.product_id = p.id) > 0)';
        }
        if (!empty($f['personalizable'])) {
            $where[] = 'p.is_personalizable = 1';
        }
        if (!empty($f['gift_wrap'])) {
            $where[] = 'p.gift_wrap_available = 1';
        }
        if (!empty($f['maker'])) {
            $params['maker'] = $f['maker'];
            $where[] = 'p.maker_id = (SELECT m.id FROM makers m WHERE m.slug = :maker)';
        }
        if (!empty($f['featured'])) {
            $where[] = 'p.is_featured = 1';
        }
        if (!empty($f['bestseller'])) {
            $where[] = '(p.is_bestseller = 1 OR p.sales_count > 0)';
        }
        if (!empty($f['new'])) {
            $where[] = 'p.created_at >= (UTC_TIMESTAMP() - INTERVAL 90 DAY)';
        }
        if (!empty($f['ids'])) {
            $in = Database::in('id', array_map('intval', (array) $f['ids']), $params);
            $where[] = "p.id IN $in";
        }
        if (!empty($f['exclude_ids'])) {
            $in = Database::in('xid', array_map('intval', (array) $f['exclude_ids']), $params);
            $where[] = "p.id NOT IN $in";
        }

        $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $countParams = $params;
        unset($countParams['ft2']);
        $total = (int) Database::fetchColumn("SELECT COUNT(*) FROM products p $joins $whereSql", $countParams);

        if ($relevanceSelect === '0') {
            unset($params['ft2']);
        }
        $order = match ($sort) {
            'newest' => 'p.created_at DESC, p.id DESC',
            'price_asc' => 'effective_price ASC, p.id ASC',
            'price_desc' => 'effective_price DESC, p.id DESC',
            'rating' => 'p.rating_avg DESC, p.rating_count DESC, p.id DESC',
            'relevance' => $relevanceSelect !== '0' ? 'relevance DESC, p.sales_count DESC, p.id DESC' : 'p.is_featured DESC, p.sales_count DESC, p.id DESC',
            'name' => 'p.name ASC',
            default => 'p.is_bestseller DESC, p.sales_count DESC, p.rating_avg DESC, p.id DESC',
        };
        $perPage = max(1, min(100, $perPage));
        $offset = (max(1, $page) - 1) * $perPage;
        $select = self::CARD_SELECT . ", $relevanceSelect AS relevance";
        if ($admin) {
            $select .= ', p.cost_price, p.updated_at, (SELECT c.name FROM categories c WHERE c.id = p.category_id) AS category_name';
        }
        $items = Database::fetchAll("SELECT $select FROM products p $joins $whereSql ORDER BY $order LIMIT $perPage OFFSET $offset", $params);
        return ['items' => $items, 'total' => $total];
    }

    public function findBySlug(string $slug): ?array
    {
        $p = Database::fetch(
            "SELECT p.*, COALESCE(p.sale_price, p.price) AS effective_price, c.name AS category_name, c.slug AS category_slug,
                    m.name AS maker_name, m.slug AS maker_slug, m.location AS maker_location, m.story AS maker_story
             FROM products p
             LEFT JOIN categories c ON c.id = p.category_id
             LEFT JOIN makers m ON m.id = p.maker_id
             WHERE p.slug = :s",
            ['s' => $slug]
        );
        return $p ? $this->hydrate($p) : null;
    }

    public function find(int $id): ?array
    {
        $p = Database::fetch(
            "SELECT p.*, COALESCE(p.sale_price, p.price) AS effective_price, c.name AS category_name, c.slug AS category_slug, m.name AS maker_name
             FROM products p LEFT JOIN categories c ON c.id = p.category_id LEFT JOIN makers m ON m.id = p.maker_id WHERE p.id = :id",
            ['id' => $id]
        );
        return $p ? $this->hydrate($p) : null;
    }

    private function hydrate(array $p): array
    {
        $id = (int) $p['id'];
        $p['images'] = Database::fetchAll('SELECT id, path, alt, sort_order FROM product_images WHERE product_id = :id ORDER BY sort_order, id', ['id' => $id]);
        $p['variants'] = Database::fetchAll(
            'SELECT v.*, COALESCE(i.quantity, 0) AS stock FROM product_variants v
             LEFT JOIN inventory i ON i.product_id = v.product_id AND i.variant_id = v.id
             WHERE v.product_id = :id AND v.is_active = 1 ORDER BY v.sort_order, v.id',
            ['id' => $id]
        );
        $p['attributes'] = Database::fetchAll('SELECT name, value FROM product_attributes WHERE product_id = :id ORDER BY sort_order, id', ['id' => $id]);
        $p['stock'] = (int) Database::fetchColumn('SELECT COALESCE(SUM(quantity),0) FROM inventory WHERE product_id = :id', ['id' => $id]);
        $p['base_stock'] = (int) Database::fetchColumn('SELECT COALESCE(quantity,0) FROM inventory WHERE product_id = :id AND variant_id = 0', ['id' => $id]);
        $p['recipients'] = Database::fetchAll('SELECT r.id, r.name, r.slug FROM product_recipients pr JOIN recipients r ON r.id = pr.recipient_id WHERE pr.product_id = :id ORDER BY r.sort_order', ['id' => $id]);
        $p['occasions'] = Database::fetchAll('SELECT o.id, o.name, o.slug FROM product_occasions po JOIN occasions o ON o.id = po.occasion_id WHERE po.product_id = :id ORDER BY o.sort_order', ['id' => $id]);
        $p['interests'] = Database::fetchAll('SELECT it.id, it.name, it.slug FROM product_interests pi JOIN interests it ON it.id = pi.interest_id WHERE pi.product_id = :id ORDER BY it.sort_order', ['id' => $id]);
        $p['tags'] = Database::fetchAll('SELECT t.id, t.name, t.slug, t.type FROM product_tags pt JOIN tags t ON t.id = pt.tag_id WHERE pt.product_id = :id ORDER BY t.name', ['id' => $id]);
        $p['image'] = $p['images'][0]['path'] ?? null;
        return $p;
    }

    /** Cards for ids, preserving the given order. */
    public function cardsByIds(array $ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
        if (!$ids) {
            return [];
        }
        $params = [];
        $in = Database::in('id', $ids, $params);
        $rows = Database::fetchAll('SELECT ' . self::CARD_SELECT . " FROM products p WHERE p.status = 'active' AND p.id IN $in", $params);
        $byId = [];
        foreach ($rows as $r) {
            $byId[(int) $r['id']] = $r;
        }
        $out = [];
        foreach ($ids as $id) {
            if (isset($byId[$id])) {
                $out[] = $byId[$id];
            }
        }
        return $out;
    }

    public function related(array $product, int $limit = 8): array
    {
        $params = ['pid' => (int) $product['id'], 'pid2' => (int) $product['id'], 'cat' => (int) ($product['category_id'] ?? 0)];
        return Database::fetchAll(
            'SELECT ' . self::CARD_SELECT . ",
                    ((p.category_id = :cat) * 2 + (SELECT COUNT(*) FROM product_interests a JOIN product_interests b ON a.interest_id = b.interest_id
                        WHERE a.product_id = p.id AND b.product_id = :pid2)) AS affinity
             FROM products p
             WHERE p.status = 'active' AND p.id <> :pid
             HAVING affinity > 0
             ORDER BY affinity DESC, p.sales_count DESC, p.id DESC
             LIMIT " . (int) $limit,
            $params
        );
    }

    /** Products most often in the same orders; falls back to related products. */
    public function boughtTogether(array $product, int $limit = 3): array
    {
        $rows = Database::fetchAll(
            'SELECT ' . self::CARD_SELECT . ', COUNT(*) AS together
             FROM order_items a
             JOIN order_items b ON b.order_id = a.order_id AND b.product_id <> a.product_id
             JOIN orders o ON o.id = a.order_id AND o.status NOT IN (\'cancelled\', \'pending_payment\')
             JOIN products p ON p.id = b.product_id AND p.status = \'active\'
             WHERE a.product_id = :pid
             GROUP BY p.id ORDER BY together DESC LIMIT ' . (int) $limit,
            ['pid' => (int) $product['id']]
        );
        return $rows ?: array_slice($this->related($product, $limit), 0, $limit);
    }

    public function flagged(string $flag, int $limit = 8): array
    {
        $f = match ($flag) {
            'bestseller' => ['bestseller' => true],
            'featured' => ['featured' => true],
            'new' => [],
            'personalized' => ['personalizable' => true],
            default => [],
        };
        $sort = $flag === 'new' ? 'newest' : 'popular';
        return $this->search($f + ['in_stock' => true], $sort, 1, $limit)['items'];
    }

    public function incrementViews(int $id): void
    {
        Database::query('UPDATE products SET view_count = view_count + 1 WHERE id = :id', ['id' => $id]);
    }

    /** Words from product names/tags used as a typo-correction vocabulary. */
    public function vocabulary(): array
    {
        $words = [];
        foreach (Database::fetchCol("SELECT name FROM products WHERE status = 'active'") as $name) {
            foreach (preg_split('/[^\p{L}]+/u', mb_strtolower((string) $name)) ?: [] as $w) {
                if (mb_strlen($w) >= 4) {
                    $words[$w] = true;
                }
            }
        }
        foreach (Database::fetchCol('SELECT name FROM tags') as $name) {
            foreach (preg_split('/[^\p{L}]+/u', mb_strtolower((string) $name)) ?: [] as $w) {
                if (mb_strlen($w) >= 4) {
                    $words[$w] = true;
                }
            }
        }
        return array_keys($words);
    }

    public function recordRatingSummary(int $productId): void
    {
        Database::query(
            "UPDATE products p SET
                rating_avg = COALESCE((SELECT AVG(r.rating) FROM reviews r WHERE r.product_id = p.id AND r.status = 'approved'), 0),
                rating_count = (SELECT COUNT(*) FROM reviews r2 WHERE r2.product_id = p.id AND r2.status = 'approved')
             WHERE p.id = :id",
            ['id' => $productId]
        );
    }
}
