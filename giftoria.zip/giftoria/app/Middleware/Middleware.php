<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Core\Auth;
use App\Core\AuditLogger;
use App\Core\Gate;
use App\Core\HttpException;
use App\Core\Request;
use App\Core\Response;
use App\Core\Session;

/**
 * Route middleware resolved by name. Return a Response to short-circuit, null to continue.
 *  auth            customer must be logged in
 *  guest           customer must NOT be logged in
 *  staff           staff must be logged in (admin panel); forces password change when flagged
 *  staff.guest     staff must NOT be logged in
 *  can:perm[|perm] staff must hold at least one of the listed permissions (403 otherwise)
 */
final class Middleware
{
    public static function run(string $name, Request $request): ?Response
    {
        [$key, $arg] = array_pad(explode(':', $name, 2), 2, null);
        return match ($key) {
            'auth' => self::auth($request),
            'guest' => Auth::customer() ? Response::redirect('/account') : null,
            'staff' => self::staff($request),
            'staff.guest' => Auth::staff() ? Response::redirect(admin_url()) : null,
            'can' => self::can((string) $arg),
            default => throw new \LogicException('Unknown middleware: ' . $name),
        };
    }

    private static function auth(Request $request): ?Response
    {
        if (Auth::customer()) {
            return null;
        }
        if ($request->wantsJson()) {
            return Response::json(['message' => 'Please sign in to continue.', 'login' => url('/login')], 401);
        }
        if ($request->method === 'GET') {
            Session::put('intended', $request->fullUrl());
        }
        Session::flash('info', 'Please sign in to continue.');
        return Response::redirect('/login');
    }

    private static function staff(Request $request): ?Response
    {
        $staff = Auth::staff();
        if (!$staff) {
            if ($request->method === 'GET') {
                Session::put('admin_intended', $request->fullUrl());
            }
            return $request->wantsJson()
                ? Response::json(['message' => 'Unauthenticated'], 401)
                : Response::redirect(admin_url('login'));
        }
        $changePath = '/' . trim((string) config('app.admin_path'), '/') . '/password';
        if ((int) $staff['must_change_password'] === 1 && $request->path !== $changePath && $request->path !== $changePath . '/update' && !str_ends_with($request->path, '/logout')) {
            Session::flash('info', 'Please set a new password before continuing.');
            return Response::redirect(admin_url('password'));
        }
        return null;
    }

    private static function can(string $arg): ?Response
    {
        $perms = array_filter(explode('|', $arg));
        if (!Gate::any($perms)) {
            AuditLogger::log('access.denied', 'route', null, null, ['permissions' => $perms, 'path' => Request::current()?->path]);
            throw new HttpException(403);
        }
        return null;
    }
}
