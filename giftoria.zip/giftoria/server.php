<?php
// Router for PHP's built-in server (optional alternative to XAMPP/Apache):
//   php -S 127.0.0.1:8000 -t public server.php    (then set APP_URL=http://127.0.0.1:8000)
$path = urldecode((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH));
if ($path !== '/' && is_file(__DIR__ . '/public' . $path) && !str_ends_with($path, '.php')) {
    return false;
}
require __DIR__ . '/public/index.php';
