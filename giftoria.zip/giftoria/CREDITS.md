# Image credits

All photographs below are **CC0 1.0** or **Public Domain Mark** works found via [Openverse](https://openverse.org).
No attribution is legally required; sources are recorded for provenance. Before launch, replace demo product photos with photos of your actual products.

| Used for | Title | Creator | Source | Licence |
|---|---|---|---|---|
| interest:arts-crafts | Paint Brushes | Khara Woods | [stocksnap](https://stocksnap.io/photo/paint-brushes-AQ051P63XP) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:beauty-wellness | Flatlay Spa | Healthy Living | [stocksnap](https://stocksnap.io/photo/flatlay-spa-2HEUUNACGX) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:books-storytelling | School Books | Krzysztof%20Puszczy%u0144ski | [stocksnap](https://stocksnap.io/photo/school-books-S059QDGBOG) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:building-blocks | Children Toys | Birch Landing Home | [stocksnap](https://stocksnap.io/photo/children-toys-R8U6CVZ24Q) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:cooking | Cooking Kitchen | JESHOOTS.com | [stocksnap](https://stocksnap.io/photo/cooking-kitchen-80C03C2071) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:dolls | Dolls Puppets | Skitter Photo | [stocksnap](https://stocksnap.io/photo/dolls-puppets-BDAA7E17BE) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:educational-toys | Abacus close up | — | [rawpixel](https://www.rawpixel.com/image/6031904/abacus-close-up-free-public-domain-cc0-image) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:experiences | Microphone Music | Freestocks.org | [stocksnap](https://stocksnap.io/photo/microphone-music-8KQC04JDT0) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:fashion | White Sneakers | Ylanite Koppens | [stocksnap](https://stocksnap.io/photo/white-sneakers-EA7TDORJBT) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:games-puzzles | Jigsaw puzzle | — | [rawpixel](https://www.rawpixel.com/image/3337958/free-photo-image-puzzle-cc0-creative-commons) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:gardening | Free garden tools wood | — | [rawpixel](https://www.rawpixel.com/image/5915645/image-public-domain-wood-free) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:gift-hampers | Easter Egg | Travel Photographer | [stocksnap](https://stocksnap.io/photo/easter-egg-YHQKR1QRLM) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:handmade-products | Pottery class, Jaycee Park, USA | — | [rawpixel](https://www.rawpixel.com/image/9658542/pottery-class-jaycee-park-usa) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:home-decor | Home Decor | Kelly Ishmael | [stocksnap](https://stocksnap.io/photo/home-decor-CYUVMP6DER) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:jewelry | Earrings Jewelry | Petar Petkovski | [stocksnap](https://stocksnap.io/photo/earrings-jewelry-VHYI45MIFN) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:music | Guitar Music | Paulina Lohunko | [stocksnap](https://stocksnap.io/photo/guitar-music-8N3NW8ZGRT) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:outdoor-activities | Summer Sun | eberhard grossgasteiger | [stocksnap](https://stocksnap.io/photo/summer-sun-Q7M49RXBQR) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:personalized-keepsakes | Antique silver memorial keepsake box | artinstitutechicago | [rawpixel](https://www.rawpixel.com/image/9009494/vinaigrette) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:princess-toys | Princess crown drawing, headwear vintage | — | [rawpixel](https://www.rawpixel.com/image/6305180/image-vintage-public-domain-illustrations) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:science-stem | heap empty test tubes | — | [rawpixel](https://www.rawpixel.com/image/3305760/free-photo-image-lab-medicine-research) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:sports | Golden trophy football ball flag | — | [rawpixel](https://www.rawpixel.com/image/11176255/image-plant-grass-golden) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:stuffed-animals | Free teddy bear doll suitcase | — | [rawpixel](https://www.rawpixel.com/image/5922395/photo-image-public-domain-cute-free) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:sustainable-gifts | Free frozen vegetable scraps broth | — | [rawpixel](https://www.rawpixel.com/image/5918803/image-public-domain-plant-food) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| interest:technology | Macbook Laptop | Lia Leslie | [stocksnap](https://stocksnap.io/photo/macbook-laptop-DWLWL9USBG) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| maker:himalayan-tea-collective | Tea leaves, herbal drink | — | [rawpixel](https://www.rawpixel.com/image/6031469/photo-image-public-domain-leaf-free) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| maker:kathmandu-felt-studio | Colorful paper background | — | [rawpixel](https://www.rawpixel.com/image/6019901/photo-image-background-paper-texture) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| maker:lokta-leaf-paper | Stroommarmer roze en grijs (1950 | rijksmuseum | [rawpixel](https://www.rawpixel.com/image/13752773/stroommarmer-roze-grijs-1950-1984-anonymous) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| maker:palpa-dhaka-weavers | Loom, weaving machine drawing, vintage | — | [rawpixel](https://www.rawpixel.com/image/6303522/image-vintage-public-domain-illustrations) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| maker:patan-metalcraft | Bowl (Tas) Attached Handles, Decorated | artinstitutechicago | [rawpixel](https://www.rawpixel.com/image/8946037/photo-image-gold-craft-islamic) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| misc:baby | Baby Crib | Freestocks.org | [stocksnap](https://stocksnap.io/photo/baby-crib-17QW4I2CLU) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| misc:campaign-tihar | Flower Decoration | Vintage RS | [stocksnap](https://stocksnap.io/photo/flower-decoration-WPONJJTPTX) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| misc:hero | Christmas Holiday | Negative Space | [stocksnap](https://stocksnap.io/photo/christmas-holiday-N48V8SK5K3) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| misc:personalized | Leaves Rustic | Kelly Ishmael | [stocksnap](https://stocksnap.io/photo/leaves-rustic-T5JCWGDK8B) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| misc:story | Colorful yarns | Peace Corps | [rawpixel](https://www.rawpixel.com/image/3387963/free-photo-image-yarn-peru-weaving) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:anniversary | Champagne Bottle | Kristin Hardwick | [stocksnap](https://stocksnap.io/photo/champagne-bottle-ZLASC4UKIX) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:baby-shower | Paper Pen | Laurel Natale | [stocksnap](https://stocksnap.io/photo/paper-pen-MZO5I0RC7R) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:birth-celebration | Baby Shoes (ca.1937) Edith Towner | nationalgalleryofart | [rawpixel](https://www.rawpixel.com/image/3357915/free-illustration-image-antique-apparel-art) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:birthday | Events Birthday | Freestocks.org | [stocksnap](https://stocksnap.io/photo/events-birthday-7XQHYBOHLC) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:corporate-gifting | Crafts Holiday | Travel Photographer | [stocksnap](https://stocksnap.io/photo/crafts-holiday-T706XGMHBK) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:dashain | Kite Park | AJ Montpetit | [stocksnap](https://stocksnap.io/photo/kite-park-4DUVZGC9AD) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:fathers-day | Cufflinks Tie | Patryk Dziejma | [stocksnap](https://stocksnap.io/photo/cufflinks-tie-FSD2YR09H1) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:festival | Festive Lights | Tricia Gray | [stocksnap](https://stocksnap.io/photo/festive-lights-R2GG6XFPOM) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:first-birthday | Cupcakes Chocolate | Freestocks.org | [stocksnap](https://stocksnap.io/photo/cupcakes-chocolate-4IMSJB7ZF5) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:graduation | Graduation hat and diploma illustration | — | [rawpixel](https://www.rawpixel.com/image/11729190/image-person-collage-cartoon) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:housewarming | Keys Door | WDnet Studio | [stocksnap](https://stocksnap.io/photo/keys-door-Z1TKDI29FZ) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:just-because | Gift Box | George Dolgikh | [stocksnap](https://stocksnap.io/photo/gift-box-GYTXUYX26M) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:mothers-day | Tulip Bouquet | Vintage RS | [stocksnap](https://stocksnap.io/photo/tulip-bouquet-YTDZNVNVLP) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:naming-ceremony | Free play wood block image | — | [rawpixel](https://www.rawpixel.com/image/5903033/photo-image-public-domain-blue-green) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:thank-you | Cute LGBTQ thank you card | — | [rawpixel](https://www.rawpixel.com/image/4021537/photo-image-background-heart-covid19) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:tihar |  | — | [rawpixel](https://www.rawpixel.com/image/5941660/free-public-domain-cc0-photo) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:valentines-day | Valentine Heart | Holiday Scenes | [stocksnap](https://stocksnap.io/photo/valentine-heart-3GIIOPRB4I) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| occasion:wedding | Wedding Rings | Rickopan | [stocksnap](https://stocksnap.io/photo/wedding-rings-KH7YRRTVTS) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1002 | Crown Tiara | Kristin Hardwick | [stocksnap](https://stocksnap.io/photo/crown-tiara-K1FZDLH906) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1003 |  | — | [rawpixel](https://www.rawpixel.com/image/6063628/free-public-domain-cc0-photo) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1013 | silver bracelet, two studs flanking | — | [rawpixel](https://www.rawpixel.com/image/7455654/photo-image-diamond-public-domain-metal) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1014 | Gifts Presents | Lukasz Dec | [stocksnap](https://stocksnap.io/photo/gifts-presents-25UGQ8LTDV) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1024 | Blue jigsaw puzzle pattern | — | [rawpixel](https://www.rawpixel.com/image/5903779/photo-image-background-public-domain-blue) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1027 | Light Bulb | Mikael Kristenson | [stocksnap](https://stocksnap.io/photo/light-bulb-Z9K6Z7XHPD) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1028 | Intricate red woven textile pattern | artinstitutechicago | [rawpixel](https://www.rawpixel.com/image/9052883/border) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1030 | Cup yellow tea small cookie | — | [rawpixel](https://www.rawpixel.com/image/11524499/photo-image-plant-leaf-public-domain) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1031 | Picture Frames | Kristin Hardwick | [stocksnap](https://stocksnap.io/photo/picture-frames-0UGJSGMQJL) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1032 | A set of buttons | — | [rawpixel](https://www.rawpixel.com/image/12568681/set-buttons) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1034 | Free closeup many unshelled chestnuts | — | [rawpixel](https://www.rawpixel.com/image/5919648/photo-image-public-domain-plant-fruit) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1035 | Free Tibetan singing bowl image | — | [rawpixel](https://www.rawpixel.com/image/5912653/image-public-domain-free-travel) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1037 | Pour Over | Kristin Hardwick | [stocksnap](https://stocksnap.io/photo/pour-over-0PZDINJEXE) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1038 | Succulent Plant | Kelly Ishmael | [stocksnap](https://stocksnap.io/photo/succulent-plant-T57PJUYFWM) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1039 | Free basil plant image | — | [rawpixel](https://www.rawpixel.com/image/5901991/photo-image-white-background-public-domain-leaf) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1042 | Close dumpling | — | [rawpixel](https://www.rawpixel.com/image/6039752/close-dumpling-free-public-domain-cc0-photo) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1043 | Hiking Hikers | David Marcu | [stocksnap](https://stocksnap.io/photo/hiking-hikers-820A2B4E00) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1044 | Rolled teal yoga mat standing | — | [rawpixel](https://www.rawpixel.com/image/11524267/rolled-teal-yoga-mat-standing-up) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1050 | White Dog | Lisa Fotios | [stocksnap](https://stocksnap.io/photo/white-dog-HF0VBXDBJG) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1051 | Christmas Tree | Travel Photographer | [stocksnap](https://stocksnap.io/photo/christmas-tree-FWQS1X7CNQ) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1052 | Fountain pen paper | — | [rawpixel](https://www.rawpixel.com/image/3305216/free-photo-image-pen-cc0-creative-commons) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1054 | Photoalbum Album | Michal Jarmoluk | [stocksnap](https://stocksnap.io/photo/photoalbum-album-V1CG4DH22U) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product2:GFT-1056 | Silk Scarfs | — | [rawpixel](https://www.rawpixel.com/image/6076753/silk-scarfs) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1002 | Shiny Gold | Birch Landing Home | [stocksnap](https://stocksnap.io/photo/shiny-gold-TQQWZH7SPP) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1003 |  | — | [rawpixel](https://www.rawpixel.com/image/5940993/free-public-domain-cc0-photo) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1004 | Geometric wood kids toy | — | [rawpixel](https://www.rawpixel.com/image/6016004/photo-image-public-domain-kids-wooden) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1010 | Christmas Gifts | Pawel Kadysz | [stocksnap](https://stocksnap.io/photo/christmas-gifts-3DPEHG8EOI) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1011 | Christmas Gifts | Patryk Dziejma | [stocksnap](https://stocksnap.io/photo/christmas-gifts-A3GOGU0BWF) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1013 |  | — | [rawpixel](https://www.rawpixel.com/image/5958397/free-public-domain-cc0-photo) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1014 |  | — | [rawpixel](https://www.rawpixel.com/image/5961623/free-public-domain-cc0-photo) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1022 | Watercolours palette | — | [rawpixel](https://www.rawpixel.com/image/5925746/photo-image-watercolor-public-domain-art) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1023 | Free colorful board game pieces | — | [rawpixel](https://www.rawpixel.com/image/5921214/photo-image-public-domain-free-game) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1024 | Wooden jigsaw puzzle | Markus Spiske | [rawpixel](https://www.rawpixel.com/image/432900/free-photo-image-puzzle-piece-wooden) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1025 | Writing Drawing | Green Chameleon | [stocksnap](https://stocksnap.io/photo/writing-drawing-8Y0EDX4VP9) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1027 | Dark Night | Toa Heftiba | [stocksnap](https://stocksnap.io/photo/dark-night-WDG2A36JHS) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1028 | Design Woven Shawl Paisley Motifs | — | [rawpixel](https://www.rawpixel.com/image/9064373/design-for-woven-shawl-with-paisley-motifs) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1029 | Hymnal (late 17th-early 18th century) | — | [rawpixel](https://www.rawpixel.com/image/10147094/hymnal-late-17th-early-18th-century-awet) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1030 | Colorful patterned tea tins | — | [rawpixel](https://www.rawpixel.com/image/6031392/photo-image-public-domain-green-pattern) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1031 | Empty wooden frames, white background | — | [rawpixel](https://www.rawpixel.com/image/6041094/photo-image-background-frame-public-domain) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1032 | Silver earrings | — | [rawpixel](https://www.rawpixel.com/image/6038414/silver-earrings-free-public-domain-cc0-photo) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1034 |  | — | [rawpixel](https://www.rawpixel.com/image/5942986/free-public-domain-cc0-photo) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1035 | Overhead view Tibetan singing bowls | — | [rawpixel](https://www.rawpixel.com/image/5918531/image-public-domain-free-meditation) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1036 | Wallets Notepads | Skitter Photo | [stocksnap](https://stocksnap.io/photo/wallets-notepads-109C4CC715) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1037 | Pour Over | Kristin Hardwick | [stocksnap](https://stocksnap.io/photo/pour-over-UE2INO4TXK) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1038 | Potted Plants | Matt Bango | [stocksnap](https://stocksnap.io/photo/potted-plants-NPPTA6CQTM) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1039 | Green leaves urban garden | Markus Spiske | [rawpixel](https://www.rawpixel.com/image/600085/urban-gardening) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1040 | Three bath bombs towel, epsom | — | [rawpixel](https://www.rawpixel.com/image/5928332/photo-image-public-domain-free-candle) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1042 | Free dumpling image | — | [rawpixel](https://www.rawpixel.com/image/5918662/image-public-domain-person-kitchen) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1043 | Hiking Climbing | Markus Spiske | [stocksnap](https://stocksnap.io/photo/hiking-climbing-LP0YZCWGC5) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1044 | Rolled teal yoga mat its | — | [rawpixel](https://www.rawpixel.com/image/11515776/rolled-teal-yoga-mat-its-side) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1046 | Coffee Mug | Alex Holt | [stocksnap](https://stocksnap.io/photo/coffee-mug-M4PI6CXDDP) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1047 | Night Sky | Wil Stewart | [stocksnap](https://stocksnap.io/photo/night-sky-3O51V5Q49Q) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1050 | Dog Pet | Ryan McGuire | [stocksnap](https://stocksnap.io/photo/dog-pet-0FF28AA12D) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1051 | Christmas Tree | Travel Photographer | [stocksnap](https://stocksnap.io/photo/christmas-tree-MY2BHIRSYV) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1052 | Fountain Pen | Vintage RS | [stocksnap](https://stocksnap.io/photo/fountain-pen-CJETOU0HKX) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1054 | Pictures Photos | Paulina Lohunko | [stocksnap](https://stocksnap.io/photo/pictures-photos-AHIVCF3SVD) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1055 | Hot Chocolate rose | — | [rawpixel](https://www.rawpixel.com/image/4021300/hot-chocolate-rose) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1056 | Cashmere scarf end Industrial arts | newyorkpubliclibrary | [rawpixel](https://www.rawpixel.com/image/329588/free-illustration-image-sir-matthew-digby-wyatt-scarf-cashmere) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1059 | Pistachios Nuts | Krzysztof%20Puszczy%u0144ski | [stocksnap](https://stocksnap.io/photo/pistachios-nuts-D3JX2C0MW9) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| product:GFT-1060 | Cozy still life of bamboo toothbrushes with toothpaste on a bamboo mat. | Nora Ferreirós | [wordpress](https://wordpress.org/photos/photo/574641d8aa/) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:anyone-else | Present Gift | Daria Nepriakhina | [stocksnap](https://stocksnap.io/photo/present-gift-206B1A2E4C) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:baby-boy | Blue baby clothes sticker, laundry | — | [rawpixel](https://www.rawpixel.com/image/6431158/vector-sticker-public-domain-blue) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:baby-girl | Free pink baby shoe image | — | [rawpixel](https://www.rawpixel.com/image/5913298/image-background-public-domain-hand) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:boyfriend | Camera Vintage | Pawel Kadysz | [stocksnap](https://stocksnap.io/photo/camera-vintage-HSHTDZ4GS4) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:brother | Clothes Sneakers | Kasia Serbin | [stocksnap](https://stocksnap.io/photo/clothes-sneakers-1U68PK9DJ0) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:child | Wooden toy train | Markus Spiske | [rawpixel](https://www.rawpixel.com/image/432769/free-photo-image-wooden-toys-train-toy) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:colleague | Macbook Laptop | Leeroy | [stocksnap](https://stocksnap.io/photo/macbook-laptop-UDIGU0A2SN) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:couple | Mug Cup | Candace McDaniel | [stocksnap](https://stocksnap.io/photo/mug-cup-MVYHPT6H7C) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:father | Wood Watch | Burst | [stocksnap](https://stocksnap.io/photo/wood-watch-IVZDQN85VY) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:friend | Moon gold chain friendship bracelet | — | [rawpixel](https://www.rawpixel.com/image/11524193/moon-gold-chain-friendship-bracelet) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:girlfriend | Pink Roses | The World is a Stage | [stocksnap](https://stocksnap.io/photo/pink-roses-OWDBF3NXIC) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:grandparent | Office Work | Ch%E2u%20Th%F4ng%20Phan | [stocksnap](https://stocksnap.io/photo/office-work-BCLRC8HNEO) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:husband | Business Technology | Maliha Mannan | [stocksnap](https://stocksnap.io/photo/business-technology-OGLUHZAPGF) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:mother | Tea Smoke | Carli Jean | [stocksnap](https://stocksnap.io/photo/tea-smoke-2E7DE661A5) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:pet-lover | Pug Dog | Matthew Henry | [stocksnap](https://stocksnap.io/photo/pug-dog-JHPVE3XLUE) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:sister | Hokusai's Vintage Japanese jewelry box | rijksmuseum | [rawpixel](https://www.rawpixel.com/image/7697083/image-art-vintage-public-domain) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:teacher | Apple Textbooks | Michal Jarmoluk | [stocksnap](https://stocksnap.io/photo/apple-textbooks-NAOWFGI5EF) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:teenager | Skater Skateboarding | Ryan McGuire | [stocksnap](https://stocksnap.io/photo/skater-skateboarding-E8BEE18655) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
| recipient:wife | Red Roses | Biel Morro | [stocksnap](https://stocksnap.io/photo/red-roses-3OL62OM8V9) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/) |
