<?php /** Vars: $icon, $title, $text, optional $actionUrl, $actionLabel, $extra (raw html) */ ?>
<div class="empty-state">
  <div class="empty-icon"><?= icon($icon ?? 'gift') ?></div>
  <h2 style="font-size:1.6rem"><?= e($title ?? 'Nothing here yet') ?></h2>
  <?php if (!empty($text)): ?><p><?= e($text) ?></p><?php endif; ?>
  <?php if (!empty($actionUrl)): ?><a class="btn btn-primary mt-4" href="<?= e($actionUrl) ?>"><?= e($actionLabel ?? 'Continue shopping') ?></a><?php endif; ?>
  <?= $extra ?? '' ?>
</div>
