<?php /** Vars: $items list of [label, url|null]. Emits visible breadcrumbs; JSON-LD is added by the controller. */ ?>
<nav class="breadcrumbs" aria-label="Breadcrumb">
  <ol>
    <li><a href="<?= e(url('/')) ?>">Home</a></li>
    <?php foreach ($items as $i => [$label, $href]): ?>
      <li><?php if ($href && $i < count($items) - 1): ?><a href="<?= e($href) ?>"><?= e($label) ?></a><?php else: ?><span aria-current="page"><?= e($label) ?></span><?php endif; ?></li>
    <?php endforeach; ?>
  </ol>
</nav>
