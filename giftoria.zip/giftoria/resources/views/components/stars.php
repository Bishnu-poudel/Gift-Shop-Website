<?php
/** @var float $rating @var int $count */
$rating = (float) ($rating ?? 0);
$count = (int) ($count ?? 0);
if ($count < 1) {
    return;
}
$full = (int) round($rating);
?>
<span class="rating" aria-label="Rated <?= e(number_format($rating, 1)) ?> out of 5 from <?= $count ?> review<?= $count === 1 ? '' : 's' ?>">
  <span class="stars" aria-hidden="true"><?php for ($i = 1; $i <= 5; $i++): ?><?= str_replace('<svg class="icon', '<svg class="icon' . ($i <= $full ? ' filled' : ''), icon('star')) ?><?php endfor; ?></span>
  <span><?= e(number_format($rating, 1)) ?> (<?= $count ?>)</span>
</span>
