<?php
// Flash messages (success/error/info/warning) and a summary of validation errors.
$map = ['success' => 'check', 'error' => 'alert', 'info' => 'info', 'warning' => 'alert'];
$messages = [];
foreach (array_keys($map) as $type) {
    $m = flash($type);
    if ($m) {
        $messages[$type] = $m;
    }
}
$errs = errors();
if (!$messages && !$errs) {
    return;
}
?>
<div class="<?= str_contains((string) (request()?->path ?? ''), '/' . config('app.admin_path')) ? '' : 'container' ?>" style="padding-top:16px">
  <?php foreach ($messages as $type => $msg): ?>
    <div class="alert alert-<?= e($type) ?>" role="<?= $type === 'error' ? 'alert' : 'status' ?>"><?= icon($map[$type]) ?><div><?= e($msg) ?></div></div>
  <?php endforeach; ?>
  <?php if ($errs && !isset($messages['error'])): ?>
    <div class="alert alert-error" role="alert"><?= icon('alert') ?><div>Please check the highlighted fields.
      <?php if (count($errs) > 1): ?><ul><?php foreach (array_slice($errs, 0, 6) as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul><?php endif; ?>
    </div></div>
  <?php endif; ?>
</div>
