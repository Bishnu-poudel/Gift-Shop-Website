<?php
/**
 * Product card. Vars: $p (ProductRepository::CARD_SELECT row), optional $saved (bool), $reco (bool: Gift Finder card),
 * $lazy (bool, default true), $criteria (array for feedback context)
 */
$p = $p ?? [];
$saved = $saved ?? false;
$reco = $reco ?? false;
$lazy = $lazy ?? true;
$onSale = $p['sale_price'] !== null && (float) $p['sale_price'] < (float) $p['price'];
$stock = (int) ($p['stock'] ?? 0);
$out = $stock <= 0 && !(int) $p['allow_backorder'];
$isNew = !empty($p['created_at']) && strtotime((string) $p['created_at']) > time() - 86400 * 45;
$url = url('/product/' . $p['slug']);
?>
<article class="product-card<?= $reco ? ' reco-card' : '' ?>" data-product-id="<?= (int) $p['id'] ?>">
  <div class="product-media">
    <div class="product-badges">
      <?php if ($onSale): ?><span class="badge badge-sale">−<?= (int) round((1 - (float) $p['sale_price'] / (float) $p['price']) * 100) ?>%</span><?php endif; ?>
      <?php if ((int) $p['is_bestseller']): ?><span class="badge badge-best">Bestseller</span><?php elseif ($isNew): ?><span class="badge badge-new">New</span><?php endif; ?>
    </div>
    <button type="button" class="wish-btn<?= $saved ? ' is-saved' : '' ?>" data-wishlist="<?= (int) $p['id'] ?>" aria-pressed="<?= $saved ? 'true' : 'false' ?>" aria-label="<?= $saved ? 'Remove from' : 'Save to' ?> wishlist: <?= e($p['name']) ?>"><?= icon('heart', 'icon-sm') ?></button>
    <a href="<?= e($url) ?>" tabindex="-1" aria-hidden="true">
      <img src="<?= e(image_url($p['image'] ?? null)) ?>" alt="<?= e($p['image_alt'] ?? $p['name']) ?>" width="480" height="600" <?= $lazy ? 'loading="lazy" decoding="async"' : 'fetchpriority="high"' ?>>
    </a>
    <?php if (!$out && !$reco): ?>
      <form class="quick-add" method="post" action="<?= e(url('/cart/add')) ?>" data-add-to-cart>
        <?= csrf_field() ?>
        <input type="hidden" name="product_id" value="<?= (int) $p['id'] ?>">
        <input type="hidden" name="quantity" value="1">
        <button class="btn btn-light btn-block btn-sm" type="submit"><?= icon('plus', 'icon-sm') ?> Quick add</button>
      </form>
    <?php endif; ?>
  </div>
  <div class="product-body">
    <h3 class="product-name"><a href="<?= e($url) ?>"><?= e($p['name']) ?></a></h3>
    <div class="price">
      <span class="now<?= $onSale ? ' on-sale' : '' ?>"><?= e(money($p['effective_price'])) ?></span>
      <?php if ($onSale): ?><span class="was"><?= e(money($p['price'])) ?></span><?php endif; ?>
    </div>
    <?= partial('components/stars', ['rating' => $p['rating_avg'], 'count' => $p['rating_count']]) ?>
    <?php if ($out): ?>
      <span class="stock-note stock-out">Out of stock</span>
    <?php elseif ($stock > 0 && $stock <= 3): ?>
      <span class="stock-note">Only <?= $stock ?> left</span>
    <?php endif; ?>
    <?php if ($reco): ?>
      <div class="product-meta-line">
        <?php if ((int) $p['is_personalizable']): ?><span><?= icon('pen') ?> Personalizable</span><?php endif; ?>
        <?php if ((int) $p['gift_wrap_available']): ?><span><?= icon('gift') ?> Gift wrap</span><?php endif; ?>
        <?php if (!empty($p['delivery_estimate'])): ?><span><?= icon('truck') ?> Arrives <?= e($p['delivery_estimate']['label']) ?></span><?php endif; ?>
      </div>
      <?php if (!empty($p['reasons'])): ?>
        <div class="reco-why"><strong>Why it fits</strong><?= e(implode(' · ', array_slice($p['reasons'], 0, 4))) ?></div>
      <?php endif; ?>
      <span class="reco-score" title="Rule-based relevance score from your answers">Match score <?= e(number_format((float) $p['score'], 0)) ?>/100</span>
      <div class="reco-actions">
        <button type="button" class="icon-btn" data-feedback="like" data-product="<?= (int) $p['id'] ?>" aria-label="Good suggestion" title="Good suggestion"><?= icon('thumbs-up', 'icon-sm') ?></button>
        <button type="button" class="icon-btn" data-feedback="dislike" data-product="<?= (int) $p['id'] ?>" aria-label="Not quite" title="Not quite"><?= icon('thumbs-down', 'icon-sm') ?></button>
        <button type="button" class="icon-btn" data-feedback="hide" data-product="<?= (int) $p['id'] ?>" aria-label="Hide this item" title="Hide this item"><?= icon('eye-off', 'icon-sm') ?></button>
        <button type="button" class="icon-btn" data-feedback="more_like_this" data-product="<?= (int) $p['id'] ?>" aria-label="Show me more like this" title="More like this"><?= icon('refresh', 'icon-sm') ?></button>
        <?php if (!$out): ?>
        <form method="post" action="<?= e(url('/cart/add')) ?>" data-add-to-cart style="margin-left:auto">
          <?= csrf_field() ?>
          <input type="hidden" name="product_id" value="<?= (int) $p['id'] ?>">
          <input type="hidden" name="quantity" value="1">
          <button class="btn btn-primary btn-sm" type="submit">Add to bag</button>
        </form>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>
</article>
