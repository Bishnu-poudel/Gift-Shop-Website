<?php
/** Vars: $products (list), optional $saved (int[] wishlist product ids), $cols (3|4), $reco (bool) */
$saved = $saved ?? (new App\Services\WishlistService())->savedProductIds(App\Core\Auth::customerId());
$cols = $cols ?? 4;
?>
<div class="product-grid<?= $cols === 3 ? ' cols-3' : '' ?>">
  <?php foreach ($products as $i => $p): ?>
    <?= partial('components/product-card', ['p' => $p, 'saved' => in_array((int) $p['id'], $saved, true), 'reco' => $reco ?? false, 'lazy' => $i > 3]) ?>
  <?php endforeach; ?>
</div>
