<div class="auth-card">
  <h1 style="font-size:1.8rem">Install Giftoria</h1>
  <p class="sub">Creates the database tables, base data and the first Super Admin. This page disables itself afterwards.</p>
  <form method="post" action="<?= e(url('/install')) ?>" data-loading>
    <?= csrf_field() ?>
    <div class="field"><label for="install_token">Install token (INSTALL_TOKEN in .env)</label><input class="input" type="password" id="install_token" name="install_token" required autocomplete="off"></div>
    <div class="field"><label for="name">Administrator name</label><input class="input" id="name" name="name" required value="<?= e(old('name')) ?>"><?= field_error('name') ?></div>
    <div class="field"><label for="email">Administrator email</label><input class="input" type="email" id="email" name="email" required value="<?= e(old('email')) ?>"><?= field_error('email') ?></div>
    <div class="field"><label for="password">Password (min 12 characters)</label><input class="input" type="password" id="password" name="password" required minlength="12" autocomplete="new-password"><?= field_error('password') ?></div>
    <div class="field"><label for="password_confirmation">Confirm password</label><input class="input" type="password" id="password_confirmation" name="password_confirmation" required autocomplete="new-password"></div>
    <label class="check mb-6"><input type="checkbox" name="demo" value="1"> Load demo catalogue (products, makers, demo customers and orders)</label>
    <button class="btn btn-primary btn-block btn-lg" type="submit">Install</button>
  </form>
</div>
