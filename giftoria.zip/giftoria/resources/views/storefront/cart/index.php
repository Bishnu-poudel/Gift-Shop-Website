<?php $t = $totals; ?>
<div class="container">
  <header class="page-head"><h1>Your bag</h1><?php if ($t['lines']): ?><p><?= (int) $t['item_count'] ?> item<?= $t['item_count'] === 1 ? '' : 's' ?></p><?php endif; ?></header>

  <?php if (!$t['lines']): ?>
    <?= partial('components/empty-state', ['icon' => 'bag', 'title' => 'Your bag is empty', 'text' => 'Need inspiration? The Gift Finder suggests ideas in under a minute.', 'actionUrl' => url('/gift-finder'), 'actionLabel' => 'Find a gift']) ?>
  <?php else: ?>
  <div class="cart-layout">
    <div>
      <?php foreach ($t['issues'] as $issue): ?><div class="alert alert-warning"><?= icon('alert') ?><div><?= e($issue['message']) ?></div></div><?php endforeach; ?>
      <?php foreach ($t['lines'] as $l): ?>
        <div class="cart-line">
          <a href="<?= e(url('/product/' . $l['slug'])) ?>"><img src="<?= e(image_url($l['image'])) ?>" alt="<?= e($l['name']) ?>" width="110" height="138" loading="lazy"></a>
          <div>
            <h3><a href="<?= e(url('/product/' . $l['slug'])) ?>"><?= e($l['name']) ?></a></h3>
            <div class="line-meta">
              <?php if ($l['variant_name']): ?><div>Option: <?= e($l['variant_name']) ?></div><?php endif; ?>
              <?php if ($l['personalization']): ?><div>Personalization: “<?= e($l['personalization']) ?>”</div><?php endif; ?>
              <div><?= e(money($l['unit_price'])) ?> each</div>
              <?php if ($l['insufficient']): ?><div class="stock-note stock-out">Only <?= (int) $l['stock'] ?> available</div><?php elseif ((int) $l['stock'] > 0 && (int) $l['stock'] <= 3): ?><div class="stock-note">Only <?= (int) $l['stock'] ?> left</div><?php endif; ?>
            </div>
            <div class="line-actions">
              <form method="post" action="<?= e(url('/cart/update')) ?>">
                <?= csrf_field() ?><input type="hidden" name="item_id" value="<?= (int) $l['id'] ?>">
                <div class="qty qty-sm">
                  <button type="button" data-qty-step="-1" aria-label="Decrease"><?= icon('minus', 'icon-sm') ?></button>
                  <input type="number" name="quantity" value="<?= (int) $l['quantity'] ?>" min="0" max="20" aria-label="Quantity for <?= e($l['name']) ?>" data-autosubmit>
                  <button type="button" data-qty-step="1" aria-label="Increase"><?= icon('plus', 'icon-sm') ?></button>
                </div>
                <noscript><button class="link-btn" type="submit">Update</button></noscript>
              </form>
              <form method="post" action="<?= e(url('/cart/save-for-later')) ?>"><?= csrf_field() ?><input type="hidden" name="item_id" value="<?= (int) $l['id'] ?>"><input type="hidden" name="saved" value="1"><button class="link-btn" type="submit">Save for later</button></form>
              <form method="post" action="<?= e(url('/cart/remove')) ?>"><?= csrf_field() ?><input type="hidden" name="item_id" value="<?= (int) $l['id'] ?>"><button class="link-btn" type="submit">Remove</button></form>
            </div>
          </div>
          <div class="line-total price"><?= e(money($l['line_total'])) ?></div>
        </div>
      <?php endforeach; ?>

      <form method="post" action="<?= e(url('/cart/gift-options')) ?>" class="panel mt-6">
        <?= csrf_field() ?>
        <h2 style="font-size:1.25rem" class="row"><?= icon('gift') ?> Make it a gift</h2>
        <?php if ($t['gift_wrap_possible']): ?>
          <label class="check mb-4"><input type="checkbox" name="gift_wrap" value="1" <?= !empty($cart['gift_wrap']) ? 'checked' : '' ?>> Wrap in handmade lokta paper with ribbon (+<?= e(money($giftWrapFee)) ?>)</label>
        <?php endif; ?>
        <div class="field"><label for="gift_message">Gift message (printed on a card, prices are never included)</label>
          <textarea class="textarea" id="gift_message" name="gift_message" maxlength="300" data-maxchars="300" data-counter="gm-count" placeholder="Happy first birthday, little one!"><?= e($cart['gift_message'] ?? '') ?></textarea>
          <p class="hint"><span id="gm-count"></span></p></div>
        <button class="btn btn-light" type="submit">Save gift options</button>
      </form>

      <?php if ($savedItems): ?>
        <h2 class="mt-8" style="font-size:1.4rem">Saved for later</h2>
        <?php foreach ($savedItems as $l): ?>
          <div class="cart-line">
            <img src="<?= e(image_url($l['image'])) ?>" alt="" width="110" height="138" loading="lazy">
            <div><h3><?= e($l['name']) ?></h3>
              <form method="post" action="<?= e(url('/cart/save-for-later')) ?>"><?= csrf_field() ?><input type="hidden" name="item_id" value="<?= (int) $l['id'] ?>"><input type="hidden" name="saved" value="0"><button class="link-btn" type="submit">Move to bag</button></form>
            </div>
            <div></div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <aside class="summary-card" aria-label="Order summary">
      <h2>Summary</h2>
      <div class="summary-row"><span>Subtotal</span><span><?= e(money($t['subtotal'])) ?></span></div>
      <?php if ($t['discount'] > 0): ?><div class="summary-row"><span>Discount (<?= e($t['coupon_code']) ?>)</span><span class="discount">−<?= e(money($t['discount'])) ?></span></div><?php endif; ?>
      <?php if ($t['free_shipping']): ?><div class="summary-row"><span>Delivery</span><span class="discount">Free (coupon)</span></div>
      <?php else: ?><div class="summary-row"><span>Delivery</span><span class="muted">Calculated at checkout</span></div><?php endif; ?>
      <?php if ($t['gift_wrap'] > 0): ?><div class="summary-row"><span>Gift wrap</span><span><?= e(money($t['gift_wrap'])) ?></span></div><?php endif; ?>
      <div class="summary-row total"><span>Total</span><span><?= e(money($t['grand_total'])) ?></span></div>

      <form method="post" action="<?= e(url('/cart/coupon')) ?>" class="mt-4">
        <?= csrf_field() ?>
        <?php if ($t['coupon_code']): ?>
          <input type="hidden" name="remove" value="1">
          <div class="row-between small"><span><?= icon('tag', 'icon-sm') ?> <?= e($t['coupon_code']) ?> applied</span><button class="link-btn" type="submit">Remove</button></div>
        <?php else: ?>
          <label class="label" for="coupon">Coupon code</label>
          <div class="input-group"><input class="input" id="coupon" name="code" maxlength="40" autocomplete="off" style="text-transform:uppercase"><button class="btn btn-light" type="submit">Apply</button></div>
        <?php endif; ?>
      </form>

      <a class="btn btn-primary btn-lg btn-block mt-6<?= $t['issues'] ? ' disabled' : '' ?>" href="<?= e(url('/checkout')) ?>" <?= $t['issues'] ? 'aria-disabled="true" onclick="return false"' : '' ?>><?= icon('lock', 'icon-sm') ?> Checkout</a>
      <div class="trust-row"><span class="pay-logo esewa" style="width:40px;height:22px">eSewa</span><span class="pay-logo khalti" style="width:40px;height:22px">Khalti</span><span class="pay-logo cod" style="width:40px;height:22px">COD</span></div>
      <p class="xsmall muted center mt-2">Totals are calculated securely on our server.</p>
    </aside>
  </div>
  <?php if ($suggestions): ?>
    <section class="section-tight"><h2 style="font-size:1.6rem">Pairs well with</h2><?= partial('components/product-grid', ['products' => $suggestions]) ?></section>
  <?php endif; ?>
  <?php endif; ?>
</div>
