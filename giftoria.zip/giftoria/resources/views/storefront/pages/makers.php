<div class="container">
  <?= partial('components/breadcrumbs', ['items' => [['Our makers', null]]]) ?>
  <header class="page-head"><h1>Our makers</h1><p>The studios, cooperatives and families behind our gifts.</p></header>
  <?php if ($makers): ?>
    <div class="grid grid-3 section-tight" style="padding-top:0">
      <?php foreach ($makers as $m): ?>
        <a class="maker-tile" href="<?= e(url('/makers/' . $m['slug'])) ?>">
          <img src="<?= e(image_url($m['image'])) ?>" alt="" loading="lazy" width="800" height="600">
          <div><span class="product-maker"><?= e($m['location']) ?></span><h2 style="font-size:1.3rem;margin:4px 0 8px"><?= e($m['name']) ?></h2><p class="small muted mb-0"><?= e($m['story']) ?></p></div>
        </a>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <?= partial('components/empty-state', ['icon' => 'hand', 'title' => 'Maker stories coming soon']) ?>
  <?php endif; ?>
</div>
