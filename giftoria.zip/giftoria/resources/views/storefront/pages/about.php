<div class="container container-narrow">
  <?= partial('components/breadcrumbs', ['items' => [['Our story', null]]]) ?>
  <header class="page-head"><h1>Our story</h1></header>
  <div class="prose section-tight" style="padding-top:0">
<p>Giftoria began with a simple frustration: finding a gift that felt personal, was made well and arrived on time, without trawling through a dozen shops.</p><p>Today we work directly with independent makers across Nepal, including dhaka weavers in Palpa, lokta paper makers in Bhaktapur, metalworkers in Patan and felt artists in Kathmandu. We pay fairly for their craft and tell their stories alongside the things they make.</p><h2>How we choose gifts</h2><ul><li>Original designs you will not find everywhere.</li><li>Made to last, with honest materials.</li><li>Age guidance and safety information for children's products, taken from the maker.</li><li>Packaged thoughtfully, with plastic-free wrapping wherever we can manage it.</li></ul><h2>Our promise</h2><p>Every order is checked by hand at our studio in Lalitpur before it leaves. If something is not right, we will make it right.</p>
  </div>
</div>
