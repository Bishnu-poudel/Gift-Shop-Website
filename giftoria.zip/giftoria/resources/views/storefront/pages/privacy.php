<div class="container container-narrow">
  <?= partial('components/breadcrumbs', ['items' => [['Privacy policy', null]]]) ?>
  <header class="page-head"><h1>Privacy policy</h1></header>
  <div class="prose section-tight" style="padding-top:0">
<p>We collect only what we need to deliver your orders and run your account. That includes your name, contact details and delivery addresses, your order history, and Gift Center details you choose to save.</p><h2>How we use it</h2><ul><li>To process orders, payments, deliveries and returns.</li><li>To send order emails. Marketing emails are sent only if you opt in, and every one has an unsubscribe link.</li><li>To personalize recommendations, if you allow it. You can turn this off and clear your history at any time.</li></ul><h2>Payments</h2><p>Payments are handled by eSewa and Khalti. We store payment references and status only, never wallet credentials.</p><h2>Your choices</h2><p>You can edit or delete saved recipients and addresses, change notification preferences, and request account deletion from your account settings.</p><p>Contact us with any privacy question.</p>
  </div>
</div>
