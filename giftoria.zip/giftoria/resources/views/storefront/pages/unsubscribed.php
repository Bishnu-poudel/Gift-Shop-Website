<div class="auth-wrap">
  <div class="auth-card" style="text-align:center">
    <div class="status-icon <?= $email ? 'ok' : 'bad' ?>"><?= icon($email ? 'check' : 'alert') ?></div>
    <h1><?= $email ? 'You are unsubscribed' : 'Link not recognised' ?></h1>
    <p class="sub"><?= $email ? 'We will not send marketing emails to this address again. Order and account emails will still arrive.' : 'This unsubscribe link is invalid. You can manage preferences from your account.' ?></p>
    <a class="btn btn-outline" href="<?= e(url('/')) ?>">Back to the shop</a>
  </div>
</div>
