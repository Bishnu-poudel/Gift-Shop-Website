<div class="container container-narrow">
  <?= partial('components/breadcrumbs', ['items' => [['Returns & refunds', null]]]) ?>
  <header class="page-head"><h1>Returns & refunds</h1></header>
  <div class="prose section-tight" style="padding-top:0">
<p>You can request a return within <strong>7 days of delivery</strong> from your account (Orders → Request a return), or by contacting us.</p><h2>What can be returned</h2><ul><li>Unused items in their original packaging.</li><li>Items that arrived damaged or faulty. Please share a photo within 48 hours.</li></ul><h2>What cannot be returned</h2><ul><li>Personalized or made-to-order items, unless they are faulty.</li><li>Perishable items, such as food hampers and live plants.</li></ul><h2>Refunds</h2><p>Approved refunds go back to the original payment method. eSewa and Khalti refunds are processed through the provider and usually appear within 3 to 7 working days. Cash-on-delivery orders are refunded by bank transfer or wallet.</p>
  </div>
</div>
