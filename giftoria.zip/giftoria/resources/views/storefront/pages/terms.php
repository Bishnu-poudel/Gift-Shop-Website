<div class="container container-narrow">
  <?= partial('components/breadcrumbs', ['items' => [['Terms & conditions', null]]]) ?>
  <header class="page-head"><h1>Terms & conditions</h1></header>
  <div class="prose section-tight" style="padding-top:0">
<p>By placing an order you agree to these terms.</p><h2>Prices</h2><p>Prices are shown in Nepalese rupees (NPR). The amount you pay is calculated by our system at checkout and shown before payment.</p><h2>Orders</h2><p>An online-payment order is confirmed only after we have verified the payment with the provider. Unpaid orders are cancelled automatically after the payment window ends, and any reserved stock is released.</p><h2>Product information</h2><p>Handmade items vary slightly from piece to piece. Age guidance and safety information come from the maker. Please always supervise young children.</p><h2>Returns</h2><p>See our returns policy.</p>
  </div>
</div>
