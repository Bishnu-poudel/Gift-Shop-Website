<div class="container container-narrow">
  <?= partial('components/breadcrumbs', ['items' => [['Corporate gifting', null]]]) ?>
  <header class="page-head"><h1>Corporate gifting</h1></header>
  <div class="prose section-tight" style="padding-top:0">
<p>Thank your team, clients or partners with gifts made in Nepal. We handle sourcing, branding-ready packaging, personalized notes and delivery to multiple addresses.</p><h2>What we offer</h2><ul><li>Curated hampers at every budget, from Ilam tea and lokta stationery to brass keepsakes.</li><li>Personalization with names or messages.</li><li>Bulk delivery across Nepal, with a single invoice.</li></ul><p><a class="btn btn-primary" href="<?= e(url('/contact')) ?>">Ask for a proposal</a></p>
  </div>
</div>
