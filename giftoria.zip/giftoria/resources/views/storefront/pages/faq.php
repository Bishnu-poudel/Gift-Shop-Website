<div class="container container-narrow">
  <?= partial('components/breadcrumbs', ['items' => [['Frequently asked questions', null]]]) ?>
  <header class="page-head"><h1>Frequently asked questions</h1></header>
  <div class="prose section-tight" style="padding-top:0">
<h2>How does the Gift Finder choose gifts?</h2><p>It filters our live catalogue by who the gift is for, their age, your budget and delivery needs. It then ranks the results with a transparent score based on how well each gift matches your answers. Your thumbs-up and thumbs-down feedback adjusts future suggestions, and you can switch this off in your account.</p><h2>Is it safe to pay with eSewa or Khalti?</h2><p>Yes. You pay on the provider's own secure page, and we confirm every payment directly with eSewa or Khalti before your order is confirmed. We never see or store your wallet PIN or password.</p><h2>My payment failed. Do I need to order again?</h2><p>No. Open your order and choose <em>Pay now</em> to retry. Your items stay reserved for a limited time.</p><h2>Can I change my delivery address?</h2><p>Contact us before your order ships and we will update it.</p><h2>Are toys safe for babies?</h2><p>We show the maker's recommended age on every toy. The Gift Finder never suggests items with small parts for children under 3.</p>
  </div>
</div>
