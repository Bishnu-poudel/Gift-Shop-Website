<div class="container">
  <?= partial('components/breadcrumbs', ['items' => [['Contact us', null]]]) ?>
  <header class="page-head"><h1>Contact us</h1><p>Questions about an order, a gift idea or corporate gifting? We usually reply within one working day.</p></header>
  <div class="split section-tight" style="padding-top:0;align-items:start">
    <form class="panel" method="post" action="<?= e(url('/contact')) ?>" data-loading>
      <?= csrf_field() ?>
      <div style="position:absolute;left:-9999px" aria-hidden="true"><label for="website">Website</label><input id="website" name="website" tabindex="-1" autocomplete="off"></div>
      <?php if (!$customer): ?>
        <div class="form-row">
          <div class="field"><label for="name">Name</label><input class="input" id="name" name="name" required value="<?= e(old('name')) ?>"><?= field_error('name') ?></div>
          <div class="field"><label for="email">Email</label><input class="input" type="email" id="email" name="email" required value="<?= e(old('email')) ?>"><?= field_error('email') ?></div>
        </div>
      <?php else: ?>
        <p class="small muted">Replying to <?= e($customer['email']) ?></p>
      <?php endif; ?>
      <div class="form-row">
        <div class="field"><label for="category">Topic</label>
          <select class="select" id="category" name="category">
            <?php foreach (['general' => 'General question', 'order' => 'An order', 'delivery' => 'Delivery', 'payment' => 'Payment', 'product' => 'A product', 'return' => 'Return or refund', 'corporate' => 'Corporate gifting'] as $k => $l): ?>
              <option value="<?= e($k) ?>" <?= old('category') === $k ? 'selected' : '' ?>><?= e($l) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="field"><label for="order_number">Order number (optional)</label>
          <?php if ($orders): ?>
            <select class="select" id="order_number" name="order_number"><option value="">—</option><?php foreach ($orders as $o): ?><option value="<?= e($o['order_number']) ?>"><?= e($o['order_number']) ?></option><?php endforeach; ?></select>
          <?php else: ?><input class="input" id="order_number" name="order_number" placeholder="GFT-…" value="<?= e(old('order_number')) ?>"><?php endif; ?>
        </div>
      </div>
      <div class="field"><label for="subject">Subject</label><input class="input" id="subject" name="subject" required maxlength="190" value="<?= e(old('subject')) ?>"><?= field_error('subject') ?></div>
      <div class="field"><label for="message">Message</label><textarea class="textarea" id="message" name="message" required minlength="10" maxlength="4000"><?= e(old('message')) ?></textarea><?= field_error('message') ?></div>
      <button class="btn btn-primary" type="submit">Send message</button>
    </form>
    <div class="stack">
      <div class="panel"><h2 style="font-size:1.2rem">Visit or call</h2>
        <p class="small mb-2"><?= icon('map-pin', 'icon-sm') ?> <?= e(setting('store_address')) ?></p>
        <p class="small mb-2"><?= icon('phone', 'icon-sm') ?> <?= e(setting('store_phone')) ?></p>
        <p class="small mb-0"><?= icon('mail', 'icon-sm') ?> <?= e(setting('store_email')) ?></p>
      </div>
      <div class="panel"><h2 style="font-size:1.2rem">Quick answers</h2>
        <ul class="small mb-0"><li><a href="<?= e(url('/pages/shipping')) ?>">Delivery times &amp; rates</a></li><li><a href="<?= e(url('/pages/returns')) ?>">Returns &amp; refunds</a></li><li><a href="<?= e(url('/pages/faq')) ?>">Payments &amp; FAQ</a></li></ul>
      </div>
    </div>
  </div>
</div>
