<?php
/**
 * Shared listing: catalog pages and search. Filters are plain GET params so URLs are shareable.
 * Vars: $title, $heading?, $intro?, $eyebrow?, $result, $paginator, $fixed (filters locked by the page), $facets, $crumbs, $isSearch?
 */
use App\Repositories\ProductRepository;

$f = $result['filters'];
$applied = $result['applied'];
$isSearch = $isSearch ?? false;
$path = request()?->path ?? '/shop';
$query = request()?->query() ?? [];
unset($query['page']);

// Build "remove this filter" links for active, non-fixed filters.
$labels = [];
$lookup = static function (array $rows, string $slug): string {
    foreach ($rows as $r) {
        if ($r['slug'] === $slug) {
            return $r['name'] ?? $r['label'];
        }
    }
    return $slug;
};
$remove = static function (string $key, ?string $value = null) use ($query, $path): string {
    $q = $query;
    if ($value !== null && is_array($q[$key] ?? null)) {
        $q[$key] = array_values(array_diff($q[$key], [$value]));
        if (!$q[$key]) {
            unset($q[$key]);
        }
    } else {
        unset($q[$key]);
    }
    return url($path, $q);
};
foreach (['category' => 'categories', 'recipient' => 'recipients', 'occasion' => 'occasions', 'age' => 'ages', 'maker' => 'makers'] as $key => $facet) {
    if (!empty($query[$key]) && !isset($fixed[$key]) && is_string($query[$key])) {
        $labels[] = [$lookup($facets[$facet], $query[$key]), $remove($key)];
    }
}
foreach ((array) ($query['interest'] ?? []) as $slug) {
    if (is_string($slug)) {
        $labels[] = [$lookup($facets['interests'], $slug), $remove('interest', $slug)];
    }
}
if (!empty($query['min_price']) || !empty($query['max_price'])) {
    $labels[] = ['Price ' . (!empty($query['min_price']) ? money($query['min_price']) : 'NPR 0') . ' – ' . (!empty($query['max_price']) ? money($query['max_price']) : 'any'), url($path, array_diff_key($query, ['min_price' => 1, 'max_price' => 1]))];
}
foreach (['rating' => 'Rated 4+', 'in_stock' => 'In stock', 'personalized' => 'Personalizable', 'gift_wrap' => 'Gift wrap'] as $key => $label) {
    if (!empty($query[$key]) && !isset($fixed[$key])) {
        $labels[] = [$label, $remove($key)];
    }
}
// What the search understood from free text (transparency).
$understood = [];
if ($isSearch && $result['parsed']) {
    $pp = $result['parsed'];
    if ($pp['recipient']) { $understood[] = 'for ' . $lookup($facets['recipients'], $pp['recipient']); }
    if ($pp['occasion']) { $understood[] = $lookup($facets['occasions'], $pp['occasion']); }
    foreach ($pp['interests'] as $i) { $understood[] = $lookup($facets['interests'], $i); }
    if ($pp['age_min_months'] !== null) { $understood[] = 'ages ' . age_range_label($pp['age_min_months'], $pp['age_max_months']); }
    if ($pp['max_price'] !== null) { $understood[] = 'under ' . money($pp['max_price']); }
    if ($pp['min_price'] !== null) { $understood[] = 'over ' . money($pp['min_price']); }
    if (in_array('personalized', $pp['flags'], true)) { $understood[] = 'personalizable'; }
}
$checked = static fn (string $key, string $value) => in_array($value, (array) ($query[$key] ?? []), true) || (($query[$key] ?? null) === $value);
?>
<div class="container">
  <?= partial('components/breadcrumbs', ['items' => $crumbs]) ?>
  <header class="page-head">
    <?php if (!empty($eyebrow)): ?><span class="eyebrow"><?= e($eyebrow) ?></span><?php endif; ?>
    <h1><?= e($heading ?? $title) ?></h1>
    <?php if (!empty($intro)): ?><p><?= e($intro) ?></p><?php endif; ?>
    <?php if ($understood): ?><p class="small mt-2"><?= icon('sparkles', 'icon-sm') ?> Showing gifts <?= e(implode(' · ', $understood)) ?></p><?php endif; ?>
  </header>

  <div class="listing">
    <aside class="filters" aria-label="Filters">
      <div class="row-between mb-2 filter-toggle-head" style="display:flex">
        <strong>Filter</strong>
        <button class="icon-btn filter-toggle" type="button" data-filters-close aria-label="Close filters"><?= icon('x') ?></button>
      </div>
      <form method="get" action="<?= e(url($path)) ?>" id="filter-form">
        <?php if ($isSearch): ?><input type="hidden" name="q" value="<?= e($f['q']) ?>"><?php endif; ?>
        <?php if (!empty($query['sort'])): ?><input type="hidden" name="sort" value="<?= e($query['sort']) ?>"><?php endif; ?>

        <details class="filter-group" open>
          <summary>Price <?= icon('chevron-down', 'icon-sm') ?></summary>
          <div class="filter-options">
            <?php foreach ($facets['budgets'] as $b): $isOn = (string) ($query['min_price'] ?? '') === (string) (int) $b['min_amount'] && (string) ($query['max_price'] ?? '') === (string) ($b['max_amount'] !== null ? (int) $b['max_amount'] : ''); ?>
              <a class="small<?= $isOn ? ' is-active' : '' ?>" style="<?= $isOn ? 'font-weight:700' : '' ?>" href="<?= e(url($path, array_merge($query, ['min_price' => (int) $b['min_amount'], 'max_price' => $b['max_amount'] !== null ? (int) $b['max_amount'] : '']))) ?>"><?= e($b['label']) ?></a>
            <?php endforeach; ?>
          </div>
          <div class="price-inputs">
            <label class="sr-only" for="min_price">Minimum price</label>
            <input class="input" id="min_price" type="number" name="min_price" min="0" step="50" placeholder="Min" value="<?= e($query['min_price'] ?? '') ?>">
            <label class="sr-only" for="max_price">Maximum price</label>
            <input class="input" id="max_price" type="number" name="max_price" min="0" step="50" placeholder="Max" value="<?= e($query['max_price'] ?? '') ?>">
          </div>
        </details>

        <?php if (!isset($fixed['recipient'])): ?>
        <details class="filter-group" <?= !empty($query['recipient']) ? 'open' : '' ?>>
          <summary>Recipient <?= icon('chevron-down', 'icon-sm') ?></summary>
          <div class="filter-options">
            <?php foreach ($facets['recipients'] as $r): ?>
              <label class="check"><input type="radio" name="recipient" value="<?= e($r['slug']) ?>" <?= $checked('recipient', $r['slug']) ? 'checked' : '' ?> data-autosubmit> <?= e($r['name']) ?></label>
            <?php endforeach; ?>
          </div>
        </details>
        <?php endif; ?>

        <details class="filter-group" <?= !empty($query['age']) ? 'open' : '' ?>>
          <summary>Age <?= icon('chevron-down', 'icon-sm') ?></summary>
          <div class="filter-options">
            <?php foreach ($facets['ages'] as $a): ?>
              <label class="check"><input type="radio" name="age" value="<?= e($a['slug']) ?>" <?= $checked('age', $a['slug']) ? 'checked' : '' ?> data-autosubmit> <?= e($a['label']) ?></label>
            <?php endforeach; ?>
          </div>
        </details>

        <?php if (!isset($fixed['occasion'])): ?>
        <details class="filter-group" <?= !empty($query['occasion']) ? 'open' : '' ?>>
          <summary>Occasion <?= icon('chevron-down', 'icon-sm') ?></summary>
          <div class="filter-options">
            <?php foreach ($facets['occasions'] as $o): ?>
              <label class="check"><input type="radio" name="occasion" value="<?= e($o['slug']) ?>" <?= $checked('occasion', $o['slug']) ? 'checked' : '' ?> data-autosubmit> <?= e($o['name']) ?></label>
            <?php endforeach; ?>
          </div>
        </details>
        <?php endif; ?>

        <?php if (!isset($fixed['interest'])): ?>
        <details class="filter-group" <?= !empty($query['interest']) ? 'open' : '' ?>>
          <summary>Interest <?= icon('chevron-down', 'icon-sm') ?></summary>
          <div class="filter-options">
            <?php foreach ($facets['interests'] as $i): ?>
              <label class="check"><input type="checkbox" name="interest[]" value="<?= e($i['slug']) ?>" <?= $checked('interest', $i['slug']) ? 'checked' : '' ?> data-autosubmit> <?= e($i['name']) ?></label>
            <?php endforeach; ?>
          </div>
        </details>
        <?php endif; ?>

        <?php if (!isset($fixed['category'])): ?>
        <details class="filter-group" <?= !empty($query['category']) ? 'open' : '' ?>>
          <summary>Category <?= icon('chevron-down', 'icon-sm') ?></summary>
          <div class="filter-options">
            <?php foreach ($facets['categories'] as $c): ?>
              <label class="check"><input type="radio" name="category" value="<?= e($c['slug']) ?>" <?= $checked('category', $c['slug']) ? 'checked' : '' ?> data-autosubmit> <?= e($c['name']) ?></label>
            <?php endforeach; ?>
          </div>
        </details>
        <?php endif; ?>

        <details class="filter-group" <?= !empty($query['maker']) ? 'open' : '' ?>>
          <summary>Maker <?= icon('chevron-down', 'icon-sm') ?></summary>
          <div class="filter-options">
            <?php foreach ($facets['makers'] as $m): ?>
              <label class="check"><input type="radio" name="maker" value="<?= e($m['slug']) ?>" <?= $checked('maker', $m['slug']) ? 'checked' : '' ?> data-autosubmit> <?= e($m['name']) ?></label>
            <?php endforeach; ?>
          </div>
        </details>

        <details class="filter-group" open>
          <summary>More options <?= icon('chevron-down', 'icon-sm') ?></summary>
          <div class="filter-options">
            <label class="check"><input type="checkbox" name="in_stock" value="1" <?= !empty($query['in_stock']) ? 'checked' : '' ?> data-autosubmit> In stock only</label>
            <?php if (!isset($fixed['personalized'])): ?><label class="check"><input type="checkbox" name="personalized" value="1" <?= !empty($query['personalized']) ? 'checked' : '' ?> data-autosubmit> Personalizable</label><?php endif; ?>
            <label class="check"><input type="checkbox" name="gift_wrap" value="1" <?= !empty($query['gift_wrap']) ? 'checked' : '' ?> data-autosubmit> Gift wrap available</label>
            <label class="check"><input type="checkbox" name="rating" value="4" <?= !empty($query['rating']) ? 'checked' : '' ?> data-autosubmit> Rated 4★ and up</label>
          </div>
        </details>
        <button class="btn btn-primary btn-block mt-4" type="submit">Apply filters</button>
        <?php if ($labels): ?><a class="btn btn-ghost btn-block mt-2" href="<?= e(url($path, $isSearch ? ['q' => $f['q']] : [])) ?>">Clear all</a><?php endif; ?>
      </form>
    </aside>

    <section aria-live="polite">
      <div class="toolbar">
        <div class="row">
          <button class="btn btn-light btn-sm filter-toggle" type="button" data-filters-open><?= icon('sliders', 'icon-sm') ?> Filters</button>
          <span class="small muted"><?= number_format($result['total']) ?> gift<?= $result['total'] === 1 ? '' : 's' ?></span>
        </div>
        <form method="get" action="<?= e(url($path)) ?>">
          <?php foreach ($query as $k => $v): if ($k === 'sort') { continue; } foreach ((array) $v as $vv): ?>
            <input type="hidden" name="<?= e(is_array($v) ? $k . '[]' : $k) ?>" value="<?= e($vv) ?>">
          <?php endforeach; endforeach; ?>
          <label class="sr-only" for="sort">Sort by</label>
          <select id="sort" class="select" name="sort" data-autosubmit>
            <?php foreach (ProductRepository::SORTS as $k => $label): ?>
              <option value="<?= e($k) ?>" <?= $result['sort'] === $k ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        </form>
      </div>

      <?php if ($labels): ?>
        <div class="active-filters">
          <?php foreach ($labels as [$label, $href]): ?><a class="chip" href="<?= e($href) ?>"><?= e($label) ?> <span class="x" aria-label="Remove">×</span></a><?php endforeach; ?>
        </div>
      <?php endif; ?>
      <?php if ($result['did_you_mean']): ?>
        <div class="notice-bar"><?= icon('info', 'icon-sm') ?> We searched for “<?= e($result['did_you_mean']) ?>”. <a href="<?= e(url('/search', ['q' => $result['did_you_mean']])) ?>" style="text-decoration:underline;margin-left:4px">Search for that instead</a></div>
      <?php endif; ?>
      <?php if ($result['notice']): ?><div class="notice-bar"><?= icon('info', 'icon-sm') ?> <?= e($result['notice']) ?></div><?php endif; ?>

      <?php if ($result['items']): ?>
        <?= partial('components/product-grid', ['products' => $result['items'], 'cols' => 3]) ?>
        <?= $paginator->links() ?>
      <?php else:
        $s = $result['suggestions'];
        ob_start(); ?>
          <?php if (!empty($s['phrases'])): ?>
            <p class="small mt-6 mb-2"><strong>Try one of these:</strong></p>
            <div class="chips" style="justify-content:center">
              <?php foreach ($s['phrases'] as $ph): ?><a class="chip" href="<?= e(url('/search', ['q' => $ph])) ?>"><?= e(ucfirst($ph)) ?></a><?php endforeach; ?>
            </div>
          <?php endif; ?>
          <?php if (!empty($s['categories'])): ?>
            <p class="small mt-6 mb-2"><strong>Or browse a category:</strong></p>
            <div class="chips" style="justify-content:center">
              <?php foreach ($s['categories'] as $c): ?><a class="chip" href="<?= e(url('/category/' . $c['slug'])) ?>"><?= e($c['name']) ?></a><?php endforeach; ?>
            </div>
          <?php endif; ?>
        <?php $extra = (string) ob_get_clean();
        echo partial('components/empty-state', [
            'icon' => 'search',
            'title' => 'No gifts match just yet',
            'text' => $isSearch ? 'Check the spelling, use fewer words, or let the Gift Finder suggest ideas.' : 'Try removing a filter or widening your price range.',
            'actionUrl' => url('/gift-finder'),
            'actionLabel' => 'Open the Gift Finder',
            'extra' => $extra,
        ]); ?>
        <?php if (!empty($s['popular'])): ?>
          <h2 class="mt-8" style="font-size:1.6rem">Popular right now</h2>
          <?= partial('components/product-grid', ['products' => $s['popular'], 'cols' => 4]) ?>
        <?php endif; ?>
      <?php endif; ?>
    </section>
  </div>
</div>
