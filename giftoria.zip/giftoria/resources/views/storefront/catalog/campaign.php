<div class="container section-tight">
  <div class="campaign-banner" style="background:<?= e(preg_match('/^#[0-9a-fA-F]{6}$/', (string) $campaign['theme_color']) ? $campaign['theme_color'] : 'var(--terracotta)') ?>">
    <?php if ($campaign['image']): ?><img src="<?= e(image_url($campaign['image'])) ?>" alt="" fetchpriority="high"><?php endif; ?>
    <div>
      <span class="eyebrow" style="color:#f4ead6"><?= e(ucfirst($campaign['type'])) ?> edit</span>
      <h1 style="color:#fff"><?= e($campaign['headline'] ?: $campaign['name']) ?></h1>
      <?php if ($campaign['subheadline']): ?><p style="color:#f4e9e4"><?= e($campaign['subheadline']) ?></p><?php endif; ?>
      <?php if ($coupon): ?><p class="mt-4"><span class="badge" style="background:#fff;color:var(--ink);font-size:.85rem;padding:8px 14px">Code <strong><?= e($coupon['code']) ?></strong> — <?= e($coupon['description']) ?></span></p><?php endif; ?>
    </div>
  </div>
  <?php if ($campaign['body']): ?>
    <div class="prose mt-8">
      <?php foreach (preg_split('/\n{2,}/', trim((string) $campaign['body'])) as $para): ?><p><?= nl2br(e($para)) ?></p><?php endforeach; ?>
    </div>
  <?php endif; ?>
  <div class="mt-8">
    <?php if ($products): ?>
      <?= partial('components/product-grid', ['products' => $products]) ?>
    <?php else: ?>
      <?= partial('components/empty-state', ['icon' => 'gift', 'title' => 'Gifts coming soon', 'text' => 'This collection is being curated.', 'actionUrl' => url('/shop')]) ?>
    <?php endif; ?>
  </div>
</div>
