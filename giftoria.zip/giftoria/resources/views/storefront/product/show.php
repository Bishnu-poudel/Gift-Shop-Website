<?php
$onSale = $p['sale_price'] !== null && (float) $p['sale_price'] < (float) $p['price'];
$hasVariants = (bool) $p['variants'];
$inStock = $p['stock'] > 0 || (int) $p['allow_backorder'];
$isSaved = in_array((int) $p['id'], $saved, true);
$images = $p['images'] ?: [['path' => null, 'alt' => $p['name']]];
$totalReviews = array_sum($distribution);
?>
<div class="container">
  <?= partial('components/breadcrumbs', ['items' => $crumbs]) ?>
  <div class="pdp">
    <div class="gallery" data-gallery>
      <div class="gallery-thumbs" role="list">
        <?php foreach ($images as $i => $img): ?>
          <button type="button" role="listitem" class="<?= $i === 0 ? 'is-active' : '' ?>" data-src="<?= e(image_url($img['path'])) ?>" data-alt="<?= e($img['alt'] ?: $p['name']) ?>" aria-label="View image <?= $i + 1 ?>">
            <img src="<?= e(image_url($img['path'])) ?>" alt="" width="76" height="76" loading="lazy">
          </button>
        <?php endforeach; ?>
      </div>
      <div class="gallery-main" title="Click to zoom">
        <img src="<?= e(image_url($images[0]['path'])) ?>" alt="<?= e($images[0]['alt'] ?: $p['name']) ?>" width="960" height="1200" fetchpriority="high">
      </div>
    </div>

    <div class="pdp-info">
      <?php if ($p['maker_name']): ?><a class="product-maker" href="<?= e(url('/makers/' . $p['maker_slug'])) ?>">By <?= e($p['maker_name']) ?><?= $p['maker_location'] ? ' · ' . e($p['maker_location']) : '' ?></a><?php endif; ?>
      <h1><?= e($p['name']) ?></h1>
      <?= partial('components/stars', ['rating' => $p['rating_avg'], 'count' => $p['rating_count']]) ?>
      <div class="pdp-price price">
        <span class="now<?= $onSale ? ' on-sale' : '' ?>" data-price-now><?= e(money($p['effective_price'])) ?></span>
        <?php if ($onSale): ?><span class="was"><?= e(money($p['price'])) ?></span><span class="badge badge-sale">Save <?= e(money((float) $p['price'] - (float) $p['sale_price'])) ?></span><?php endif; ?>
      </div>
      <?php if ($p['short_description']): ?><p class="pdp-short"><?= e($p['short_description']) ?></p><?php endif; ?>

      <?php if ($p['age_min_months'] !== null || $p['has_small_parts'] || $p['safety_info']): ?>
        <div class="safety-note" role="note"><?= icon('shield') ?><div>
          <?php if ($p['age_min_months'] !== null): ?><strong>Recommended age: <?= e(age_range_label((int) $p['age_min_months'], $p['age_max_months'] !== null ? (int) $p['age_max_months'] : null)) ?></strong><br><?php endif; ?>
          <?php if ($p['has_small_parts']): ?>Contains small parts — not suitable for children under 3 years.<br><?php endif; ?>
          <?= e($p['safety_info'] ?? '') ?>
        </div></div>
      <?php endif; ?>

      <form method="post" action="<?= e(url('/cart/add')) ?>" data-add-to-cart>
        <?= csrf_field() ?>
        <input type="hidden" name="product_id" value="<?= (int) $p['id'] ?>">
        <?php if ($hasVariants): ?>
          <div class="option-group">
            <label class="label" for="variant">Choose an option</label>
            <select class="select" id="variant" name="variant_id" required data-variant-select>
              <option value="">Select…</option>
              <?php foreach ($p['variants'] as $v):
                  $vPrice = (float) $p['effective_price'] + (float) $v['price_adjustment'];
                  $vOut = (int) $v['stock'] <= 0 && !(int) $p['allow_backorder']; ?>
                <option value="<?= (int) $v['id'] ?>" data-price="<?= e(money($vPrice)) ?>" data-stock-label="<?= $vOut ? 'Out of stock' : ((int) $v['stock'] <= 3 ? 'Only ' . (int) $v['stock'] . ' left' : 'In stock') ?>" <?= $vOut ? 'disabled' : '' ?>>
                  <?= e($v['name']) ?><?= (float) $v['price_adjustment'] != 0 ? ' (' . ((float) $v['price_adjustment'] > 0 ? '+' : '−') . e(money(abs((float) $v['price_adjustment']))) . ')' : '' ?><?= $vOut ? ' — out of stock' : '' ?>
                </option>
              <?php endforeach; ?>
            </select>
            <p class="stock-note mt-2" data-variant-stock></p>
          </div>
        <?php endif; ?>

        <?php if ((int) $p['is_personalizable']): ?>
          <div class="option-group">
            <label class="label" for="personalization"><?= icon('pen', 'icon-sm') ?> <?= e($p['personalization_label'] ?: 'Personalization') ?> <span class="muted">(optional)</span></label>
            <input class="input" id="personalization" name="personalization" maxlength="<?= (int) ($p['personalization_max_chars'] ?: 60) ?>" data-maxchars="<?= (int) ($p['personalization_max_chars'] ?: 60) ?>" data-counter="pers-count" autocomplete="off">
            <p class="hint xsmall muted mt-2"><span id="pers-count"></span> · Please double-check spelling — personalized items cannot be returned.</p>
          </div>
        <?php endif; ?>

        <div class="buy-row">
          <div class="qty" aria-label="Quantity">
            <button type="button" data-qty-step="-1" aria-label="Decrease quantity"><?= icon('minus', 'icon-sm') ?></button>
            <input type="number" name="quantity" value="1" min="1" max="20" aria-label="Quantity">
            <button type="button" data-qty-step="1" aria-label="Increase quantity"><?= icon('plus', 'icon-sm') ?></button>
          </div>
          <?php if ($inStock): ?>
            <button class="btn btn-primary btn-lg" type="submit"><?= icon('bag', 'icon-sm') ?> Add to bag</button>
          <?php else: ?>
            <button class="btn btn-light btn-lg" type="button" disabled>Out of stock</button>
          <?php endif; ?>
          <button type="button" class="icon-btn wish-btn<?= $isSaved ? ' is-saved' : '' ?>" style="position:static;border:1px solid var(--line);width:50px;height:50px" data-wishlist="<?= (int) $p['id'] ?>" aria-pressed="<?= $isSaved ? 'true' : 'false' ?>" aria-label="Save to wishlist"><?= icon('heart') ?></button>
        </div>
      </form>
      <?php if (!$hasVariants && $p['stock'] > 0 && $p['stock'] <= 3): ?><p class="stock-note">Only <?= (int) $p['stock'] ?> left in stock</p><?php endif; ?>

      <div class="perks">
        <div><?= icon('truck') ?><div>
          <?php if ($estimate): ?>
            <strong>Arrives <?= e($estimate['label']) ?></strong> to <?= e($estimate['district']) ?><?= $p['lead_time_days'] > 0 ? ' (includes ' . (int) $p['lead_time_days'] . '-day making time)' : '' ?>.
          <?php else: ?>
            <strong>Delivery:</strong>
            <?php foreach ($zones as $i => $z): ?><?= $i ? ' · ' : '' ?><?= e($z['name']) ?> <?= (int) $z['est_days_min'] + (int) $p['lead_time_days'] ?>–<?= (int) $z['est_days_max'] + (int) $p['lead_time_days'] ?> days<?php endforeach; ?>.
          <?php endif; ?>
          <?php if ($p['valley_only']): ?><br><span class="stock-note">Delivered inside Kathmandu Valley only.</span><?php endif; ?>
        </div></div>
        <?php if ((int) $p['gift_wrap_available']): ?><div><?= icon('gift') ?><div>Gift wrapping and a handwritten note available at checkout (<?= e(money(setting('gift_wrap_fee', 150))) ?>).</div></div><?php endif; ?>
        <div><?= icon('wallet') ?><div>Pay with eSewa, Khalti or cash on delivery (where available).</div></div>
        <div><?= icon('undo') ?><div>Returns within 7 days of delivery<?= (int) $p['is_personalizable'] ? ' (except personalized items)' : '' ?>.</div></div>
      </div>

      <div class="accordion">
        <details open>
          <summary>Description <?= icon('plus', 'icon-sm') ?></summary>
          <div class="acc-body"><?php foreach (preg_split('/\n{2,}/', trim((string) $p['description'])) as $para): ?><p><?= nl2br(e($para)) ?></p><?php endforeach; ?></div>
        </details>
        <details>
          <summary>Details &amp; materials <?= icon('plus', 'icon-sm') ?></summary>
          <div class="acc-body">
            <dl class="spec-list">
              <dt>SKU</dt><dd><?= e($p['sku']) ?></dd>
              <?php if ($p['materials']): ?><dt>Materials</dt><dd><?= e($p['materials']) ?></dd><?php endif; ?>
              <?php if ($p['dimensions']): ?><dt>Dimensions</dt><dd><?= e($p['dimensions']) ?></dd><?php endif; ?>
              <?php if ($p['weight_grams']): ?><dt>Weight</dt><dd><?= (int) $p['weight_grams'] ?> g</dd><?php endif; ?>
              <?php foreach ($p['attributes'] as $a): if ($a['name'] === 'Materials') { continue; } ?><dt><?= e($a['name']) ?></dt><dd><?= e($a['value']) ?></dd><?php endforeach; ?>
            </dl>
          </div>
        </details>
        <details>
          <summary>Who it's for <?= icon('plus', 'icon-sm') ?></summary>
          <div class="acc-body tag-links">
            <?php foreach ($p['recipients'] as $t): ?><a href="<?= e(url('/gifts/for/' . $t['slug'])) ?>"><?= e($t['name']) ?></a><?php endforeach; ?>
            <?php foreach ($p['occasions'] as $t): ?><a href="<?= e(url('/gifts/occasion/' . $t['slug'])) ?>"><?= e($t['name']) ?></a><?php endforeach; ?>
            <?php foreach ($p['interests'] as $t): ?><a href="<?= e(url('/gifts/interest/' . $t['slug'])) ?>"><?= e($t['name']) ?></a><?php endforeach; ?>
          </div>
        </details>
        <?php if ($p['video_url'] && preg_match('#^https://#', (string) $p['video_url'])): ?>
        <details>
          <summary>Video <?= icon('plus', 'icon-sm') ?></summary>
          <div class="acc-body"><a class="link-arrow" href="<?= e($p['video_url']) ?>" target="_blank" rel="noopener">Watch the product video <?= icon('external') ?></a></div>
        </details>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <?php if ($together): ?>
  <section class="section-tight">
    <div class="section-head"><div><h2>Frequently bought together</h2><p>Often added to the same order.</p></div></div>
    <?= partial('components/product-grid', ['products' => $together, 'saved' => $saved, 'cols' => 3]) ?>
  </section>
  <?php endif; ?>

  <?php if ($p['maker_name'] && $p['maker_story']): ?>
  <section class="section-tight">
    <div class="maker-card">
      <div><span class="eyebrow">Meet the maker</span><h2><?= e($p['maker_name']) ?></h2><p class="muted mb-0"><?= e($p['maker_location']) ?></p></div>
      <div><p><?= e($p['maker_story']) ?></p><a class="link-arrow" href="<?= e(url('/makers/' . $p['maker_slug'])) ?>">See all gifts by <?= e($p['maker_name']) ?> <?= icon('arrow-right') ?></a></div>
    </div>
  </section>
  <?php endif; ?>

  <section class="section-tight" id="reviews">
    <div class="section-head"><div><h2>Reviews</h2><p>Only customers can review; verified purchases are marked.</p></div></div>
    <?php if ($totalReviews > 0): ?>
      <div class="rating-summary">
        <div><div class="big"><?= e(number_format((float) $p['rating_avg'], 1)) ?></div><?= partial('components/stars', ['rating' => $p['rating_avg'], 'count' => $p['rating_count']]) ?></div>
        <div class="stack" style="--gap:4px">
          <?php for ($s = 5; $s >= 1; $s--): $pct = $totalReviews ? round($distribution[$s] / $totalReviews * 100) : 0; ?>
            <div class="row small" style="gap:8px;margin:0"><span style="width:28px"><?= $s ?>★</span><span class="bar"><span style="width:<?= (int) $pct ?>%"></span></span><span class="muted"><?= (int) $distribution[$s] ?></span></div>
          <?php endfor; ?>
        </div>
      </div>
      <?php foreach ($reviews as $r): ?>
        <article class="review">
          <div class="review-head">
            <div><?= partial('components/stars', ['rating' => $r['rating'], 'count' => 1]) ?><h4><?= e($r['title'] ?: 'Review') ?></h4></div>
            <div class="small muted"><?= e(explode(' ', $r['name'])[0]) ?> · <?= e(local_date($r['created_at'], 'M j, Y')) ?><?php if ($r['is_verified']): ?> · <span class="verified"><?= icon('check', 'icon-sm') ?> Verified purchase</span><?php endif; ?></div>
          </div>
          <p class="mb-0"><?= nl2br(e($r['body'])) ?></p>
        </article>
      <?php endforeach; ?>
    <?php else: ?>
      <p class="muted">No reviews yet.</p>
    <?php endif; ?>

    <?php if ($canReview): ?>
      <details class="panel mt-6">
        <summary style="cursor:pointer;font-weight:600">Write a review</summary>
        <form method="post" action="<?= e(url('/product/' . $p['slug'] . '/review')) ?>" class="mt-4" data-loading>
          <?= csrf_field() ?>
          <fieldset class="field mb-4">
            <legend class="label" style="font-family:var(--font-body);font-size:var(--fs-sm)">Rating</legend>
            <div class="chips">
              <?php for ($s = 5; $s >= 1; $s--): ?>
                <span><input class="chip-input" type="radio" id="rate<?= $s ?>" name="rating" value="<?= $s ?>" required <?= (string) old('rating') === (string) $s ? 'checked' : '' ?>><label class="chip" for="rate<?= $s ?>"><?= $s ?> ★</label></span>
              <?php endfor; ?>
            </div>
            <?= field_error('rating') ?>
          </fieldset>
          <div class="field"><label for="rv-title">Title</label><input class="input" id="rv-title" name="title" maxlength="150" value="<?= e(old('title')) ?>"></div>
          <div class="field"><label for="rv-body">Your review</label><textarea class="textarea" id="rv-body" name="body" minlength="10" maxlength="2000" required><?= e(old('body')) ?></textarea><?= field_error('body') ?></div>
          <button class="btn btn-primary" type="submit">Submit review</button>
          <p class="xsmall muted mt-2">Reviews are checked by our team before they appear.</p>
        </form>
      </details>
    <?php elseif (!customer()): ?>
      <p class="small"><a class="link-arrow" href="<?= e(url('/login')) ?>">Sign in to write a review <?= icon('arrow-right') ?></a></p>
    <?php elseif ($hasReviewed): ?>
      <p class="small muted">Thanks — you have already reviewed this product.</p>
    <?php endif; ?>
  </section>

  <section class="section-tight" id="questions">
    <div class="section-head"><div><h2>Questions &amp; answers</h2></div></div>
    <?php foreach ($questions as $q): ?>
      <div class="review">
        <p class="mb-2"><strong>Q:</strong> <?= e($q['question']) ?> <span class="xsmall muted">— <?= e($q['name']) ?></span></p>
        <p class="mb-0 muted"><strong>A:</strong> <?= nl2br(e($q['answer'])) ?></p>
      </div>
    <?php endforeach; ?>
    <details class="panel mt-4">
      <summary style="cursor:pointer;font-weight:600">Ask a question</summary>
      <form method="post" action="<?= e(url('/product/' . $p['slug'] . '/question')) ?>" class="mt-4">
        <?= csrf_field() ?>
        <?php if (!customer()): ?><div class="field"><label for="q-name">Your name</label><input class="input" id="q-name" name="name" required maxlength="120"></div><?php endif; ?>
        <div class="field"><label for="q-text">Question</label><textarea class="textarea" id="q-text" name="question" required minlength="8" maxlength="1000"></textarea></div>
        <button class="btn btn-outline" type="submit">Send question</button>
      </form>
    </details>
  </section>

  <?php if ($related): ?>
  <section class="section-tight">
    <div class="section-head"><div><h2>You may also like</h2></div></div>
    <?= partial('components/product-grid', ['products' => $related, 'saved' => $saved]) ?>
  </section>
  <?php endif; ?>
  <?php if ($recent): ?>
  <section class="section-tight">
    <div class="section-head"><div><h2>Recently viewed</h2></div></div>
    <?= partial('components/product-grid', ['products' => $recent, 'saved' => $saved]) ?>
  </section>
  <?php endif; ?>
</div>

<?php if ($inStock && !$hasVariants): ?>
<div class="sticky-buy no-print">
  <div><div class="small"><?= e(str_limit($p['name'], 28)) ?></div><strong><?= e(money($p['effective_price'])) ?></strong></div>
  <form method="post" action="<?= e(url('/cart/add')) ?>" data-add-to-cart style="flex:1;display:flex">
    <?= csrf_field() ?><input type="hidden" name="product_id" value="<?= (int) $p['id'] ?>"><input type="hidden" name="quantity" value="1">
    <button class="btn btn-primary" type="submit" style="flex:1">Add to bag</button>
  </form>
</div>
<?php endif; ?>
