<div class="auth-wrap">
  <div class="auth-card">
    <h1>Welcome back</h1>
    <p class="sub">Sign in to track orders, save wishlists and set gift reminders.</p>
    <form method="post" action="<?= e(url('/login')) ?>" data-loading>
      <?= csrf_field() ?>
      <div class="field"><label for="email">Email</label><input class="input <?= errors('email') ? 'has-error' : '' ?>" type="email" id="email" name="email" required autocomplete="email" value="<?= e(old('email')) ?>"><?= field_error('email') ?></div>
      <div class="field"><label for="password">Password</label><input class="input" type="password" id="password" name="password" required autocomplete="current-password"><?= field_error('password') ?></div>
      <div class="row-between mb-6 small"><span></span><a href="<?= e(url('/forgot-password')) ?>" style="text-decoration:underline">Forgot password?</a></div>
      <button class="btn btn-primary btn-lg btn-block" type="submit">Sign in</button>
    </form>
    <p class="auth-alt">New here? <a href="<?= e(url('/register')) ?>">Create an account</a></p>
    <p class="auth-alt xsmall">You can also check out as a guest — no account needed.</p>
    <p class="auth-alt xsmall">Store staff? <a href="<?= e(admin_url('login')) ?>">Sign in to the admin panel</a> — staff accounts don't work here.</p>
  </div>
</div>
