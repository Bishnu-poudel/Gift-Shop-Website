<div class="auth-wrap">
  <div class="auth-card">
    <h1>Choose a new password</h1>
    <?php if (!$valid): ?>
      <div class="alert alert-error"><?= icon('alert') ?><div>This reset link is invalid or has expired.</div></div>
      <a class="btn btn-primary btn-block" href="<?= e(url('/forgot-password')) ?>">Request a new link</a>
    <?php else: ?>
      <form method="post" action="<?= e(url('/reset-password/' . $token)) ?>" data-loading>
        <?= csrf_field() ?>
        <div class="field"><label for="password">New password</label><input class="input" type="password" id="password" name="password" required minlength="8" autocomplete="new-password"><?= field_error('password') ?></div>
        <div class="field"><label for="password_confirmation">Confirm password</label><input class="input" type="password" id="password_confirmation" name="password_confirmation" required autocomplete="new-password"></div>
        <button class="btn btn-primary btn-lg btn-block" type="submit">Update password</button>
      </form>
    <?php endif; ?>
  </div>
</div>
