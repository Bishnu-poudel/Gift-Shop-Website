<div class="auth-wrap">
  <div class="auth-card">
    <h1>Create your account</h1>
    <p class="sub">Save gift recipients, get occasion reminders and check out faster.</p>
    <form method="post" action="<?= e(url('/register')) ?>" data-loading>
      <?= csrf_field() ?>
      <div style="position:absolute;left:-9999px" aria-hidden="true"><label for="website">Website</label><input id="website" name="website" tabindex="-1" autocomplete="off"></div>
      <div class="field"><label for="name">Full name</label><input class="input <?= errors('name') ? 'has-error' : '' ?>" id="name" name="name" required autocomplete="name" value="<?= e(old('name')) ?>"><?= field_error('name') ?></div>
      <div class="field"><label for="email">Email</label><input class="input <?= errors('email') ? 'has-error' : '' ?>" type="email" id="email" name="email" required autocomplete="email" value="<?= e(old('email')) ?>"><?= field_error('email') ?></div>
      <div class="field"><label for="password">Password</label><input class="input <?= errors('password') ? 'has-error' : '' ?>" type="password" id="password" name="password" required minlength="8" autocomplete="new-password"><p class="hint">At least 8 characters. A short phrase works well.</p><?= field_error('password') ?></div>
      <div class="field"><label for="password_confirmation">Confirm password</label><input class="input" type="password" id="password_confirmation" name="password_confirmation" required autocomplete="new-password"></div>
      <label class="check mb-4"><input type="checkbox" name="marketing" value="1" <?= old('marketing') ? 'checked' : '' ?>> Send me gift ideas and offers (optional — unsubscribe anytime)</label>
      <label class="check mb-6"><input type="checkbox" name="terms" value="1" required <?= old('terms') ? 'checked' : '' ?>> I agree to the <a href="<?= e(url('/pages/terms')) ?>" target="_blank" style="text-decoration:underline">terms</a> and <a href="<?= e(url('/pages/privacy')) ?>" target="_blank" style="text-decoration:underline">privacy policy</a></label>
      <?= field_error('terms') ?>
      <button class="btn btn-primary btn-lg btn-block" type="submit">Create account</button>
    </form>
    <p class="auth-alt">Already have an account? <a href="<?= e(url('/login')) ?>">Sign in</a></p>
  </div>
</div>
