<div class="auth-wrap">
  <div class="auth-card">
    <h1>Forgot your password?</h1>
    <p class="sub">Enter your email and we'll send a secure reset link.</p>
    <form method="post" action="<?= e(url('/forgot-password')) ?>" data-loading>
      <?= csrf_field() ?>
      <div class="field"><label for="email">Email</label><input class="input" type="email" id="email" name="email" required autocomplete="email"><?= field_error('email') ?></div>
      <button class="btn btn-primary btn-lg btn-block" type="submit">Send reset link</button>
    </form>
    <p class="auth-alt"><a href="<?= e(url('/login')) ?>">Back to sign in</a></p>
  </div>
</div>
