<div class="auth-wrap">
  <div class="auth-card" style="text-align:center">
    <div class="status-icon wait"><?= icon('mail') ?></div>
    <h1>Check your inbox</h1>
    <p class="sub">Open the verification link we emailed you to activate your account. It expires in 48 hours.</p>
    <?php if ($canResend): ?>
      <form method="post" action="<?= e(url('/verify-email/resend')) ?>"><?= csrf_field() ?><button class="btn btn-outline" type="submit">Resend the link</button></form>
    <?php endif; ?>
    <p class="auth-alt"><a href="<?= e(url('/login')) ?>">Back to sign in</a></p>
  </div>
</div>
