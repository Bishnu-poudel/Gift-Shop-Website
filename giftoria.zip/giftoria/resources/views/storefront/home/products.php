<?php
if (!$s['products']) {
    return;
}
$c = $s['config'];
$more = match ($c['source'] ?? '') {
    'bestseller' => '/bestsellers',
    'new' => '/new-arrivals',
    'personalized' => '/personalized-gifts',
    'category' => '/category/' . ($c['value'] ?? ''),
    'interest' => '/gifts/interest/' . ($c['value'] ?? ''),
    'recipient' => '/gifts/for/' . ($c['value'] ?? ''),
    'occasion' => '/gifts/occasion/' . ($c['value'] ?? ''),
    default => '/shop',
};
?>
<section class="section<?= $index % 2 === 1 ? ' section-alt' : '' ?>">
  <div class="container">
    <div class="section-head">
      <div><h2><?= e($s['title']) ?></h2><?php if ($s['subtitle']): ?><p><?= e($s['subtitle']) ?></p><?php endif; ?></div>
      <a class="link-arrow" href="<?= e(url($more)) ?>">View all <?= icon('arrow-right') ?></a>
    </div>
    <?= partial('components/product-grid', ['products' => $s['products'], 'saved' => $saved]) ?>
  </div>
</section>
