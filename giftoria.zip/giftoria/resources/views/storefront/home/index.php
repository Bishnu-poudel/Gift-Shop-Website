<?php
/** Homepage: renders admin-managed sections in their configured order. */
foreach ($sections as $i => $section) {
    $file = BASE_PATH . '/resources/views/storefront/home/' . $section['type'] . '.php';
    if (is_file($file)) {
        echo partial('storefront/home/' . $section['type'], ['s' => $section, 'saved' => $saved, 'index' => $i]);
    }
}
if (!$sections) {
    echo partial('components/empty-state', ['icon' => 'layout', 'title' => 'The homepage is being arranged', 'text' => 'Sections can be enabled in Admin > Homepage.', 'actionUrl' => url('/shop'), 'actionLabel' => 'Shop all gifts']);
}
