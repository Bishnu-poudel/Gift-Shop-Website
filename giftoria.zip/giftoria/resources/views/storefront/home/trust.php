<?php $valley = App\Services\ShippingService::zoneForDistrict('Kathmandu'); ?>
<section class="section-tight" style="border-top:1px solid var(--line)">
  <div class="container trust-strip">
    <div class="trust-item"><span class="ti-icon"><?= icon('truck') ?></span><div><strong>Delivery across Nepal</strong><span><?= $valley && $valley['free_shipping_threshold'] !== null ? 'Free in the Valley over ' . e(money($valley['free_shipping_threshold'])) : 'All 77 districts' ?></span></div></div>
    <div class="trust-item"><span class="ti-icon"><?= icon('wallet') ?></span><div><strong>eSewa, Khalti or COD</strong><span>Payments verified with the provider</span></div></div>
    <div class="trust-item"><span class="ti-icon"><?= icon('gift') ?></span><div><strong>Gift wrap &amp; notes</strong><span>Add at checkout for <?= e(money(setting('gift_wrap_fee', 150))) ?></span></div></div>
    <div class="trust-item"><span class="ti-icon"><?= icon('undo') ?></span><div><strong>Easy returns</strong><span>Within 7 days of delivery</span></div></div>
  </div>
</section>
