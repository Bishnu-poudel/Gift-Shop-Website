<section class="section-tight">
  <div class="container">
    <div class="finder-module">
      <div>
        <span class="eyebrow" style="color:var(--gold)">Gift Finder</span>
        <h2><?= e($s['title'] ?? 'Not sure what to get?') ?></h2>
        <p class="mb-0"><?= e($s['subtitle'] ?? '') ?></p>
      </div>
      <form class="finder-form" action="<?= e(url('/gift-finder/results')) ?>" method="get">
        <div>
          <label for="hf-recipient">Shopping for</label>
          <select id="hf-recipient" class="select" name="recipient">
            <option value="">Anyone</option>
            <?php foreach ($s['recipients'] as $r): ?><option value="<?= e($r['slug']) ?>"><?= e($r['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div>
          <label for="hf-occasion">Occasion</label>
          <select id="hf-occasion" class="select" name="occasion">
            <option value="">Any occasion</option>
            <?php foreach ($s['occasions'] as $o): ?><option value="<?= e($o['slug']) ?>"><?= e($o['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div>
          <label for="hf-budget">Budget</label>
          <select id="hf-budget" class="select" name="budget">
            <option value="">Any budget</option>
            <?php foreach ($s['budgets'] as $b): ?><option value="<?= (int) $b['id'] ?>"><?= e($b['label']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <button class="btn btn-accent btn-lg" type="submit"><?= icon('search', 'icon-sm') ?> Find gifts</button>
      </form>
    </div>
    <p class="center small muted mt-4">Want to fine-tune by age, interests and delivery date? <a class="link-arrow" href="<?= e(url('/gift-finder')) ?>">Try the full Gift Finder <?= icon('arrow-right') ?></a></p>
  </div>
</section>
