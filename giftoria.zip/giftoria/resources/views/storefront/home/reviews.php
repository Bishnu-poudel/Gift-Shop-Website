<section class="section">
  <div class="container">
    <div class="section-head"><div><h2><?= e($s['title']) ?></h2><?php if ($s['subtitle']): ?><p><?= e($s['subtitle']) ?></p><?php endif; ?></div></div>
    <?php if (!$s['items']): ?>
      <div class="empty-state" style="padding:40px 24px">
        <div class="empty-icon"><?= icon('star') ?></div>
        <p class="mb-0">Reviews from verified customers will appear here as orders are delivered. We never publish invented reviews.</p>
      </div>
    <?php else: ?>
      <div class="grid grid-3">
        <?php foreach (array_slice($s['items'], 0, 3) as $r): ?>
          <figure class="quote-card" style="margin:0">
            <?= partial('components/stars', ['rating' => $r['rating'], 'count' => 1]) ?>
            <blockquote>“<?= e(str_limit($r['body'], 220)) ?>”</blockquote>
            <cite><?= e(explode(' ', $r['name'])[0]) ?> · on <a href="<?= e(url('/product/' . $r['slug'])) ?>"><?= e($r['product_name']) ?></a></cite>
          </figure>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>
