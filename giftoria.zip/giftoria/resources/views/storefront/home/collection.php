<?php
if (!$s['products']) {
    return;
}
$c = $s['config'];
$reverse = $index % 2 === 0;
?>
<section class="section">
  <div class="container">
    <div class="split" style="align-items:stretch">
      <a class="split-media" href="<?= e(url($c['cta_url'] ?? '/shop')) ?>" style="<?= $reverse ? 'order:2' : '' ?>;aspect-ratio:auto;min-height:420px;position:relative">
        <img src="<?= e(image_url($c['image'] ?? null)) ?>" alt="" loading="lazy" width="1000" height="800" style="position:absolute;inset:0">
      </a>
      <div>
        <span class="eyebrow">Collection</span>
        <h2><?= e($s['title']) ?></h2>
        <?php if ($s['subtitle']): ?><p class="muted"><?= e($s['subtitle']) ?></p><?php endif; ?>
        <div class="product-grid cols-3 mt-6" style="grid-template-columns:repeat(2,minmax(0,1fr))">
          <?php foreach (array_slice($s['products'], 0, 4) as $p): ?>
            <?= partial('components/product-card', ['p' => $p, 'saved' => in_array((int) $p['id'], $saved, true)]) ?>
          <?php endforeach; ?>
        </div>
        <?php if (!empty($c['cta_label'])): ?><a class="btn btn-outline mt-6" href="<?= e(url($c['cta_url'] ?? '/shop')) ?>"><?= e($c['cta_label']) ?></a><?php endif; ?>
      </div>
    </div>
  </div>
</section>
