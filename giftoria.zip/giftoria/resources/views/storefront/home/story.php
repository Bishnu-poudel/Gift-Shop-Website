<section class="section">
  <div class="container">
    <div class="story">
      <div>
        <span class="eyebrow" style="color:var(--gold)">Our story</span>
        <h2><?= e($s['title']) ?></h2>
        <p><?= e($s['subtitle']) ?></p>
        <a class="btn btn-light mt-4" href="<?= e(url('/pages/about')) ?>">Read our story</a>
      </div>
      <div class="story-points">
        <div><?= icon('hand') ?><div><strong>Made by hand</strong><span>Most pieces are crafted by small studios and cooperatives.</span></div></div>
        <div><?= icon('shield') ?><div><strong>Checked before it ships</strong><span>Every order is inspected and packed by our team in Lalitpur.</span></div></div>
        <div><?= icon('leaf') ?><div><strong>Thoughtful packaging</strong><span>Recycled boxes and lokta-paper wrapping, plastic-free where we can.</span></div></div>
      </div>
    </div>
  </div>
</section>
