<?php if (!$s['items']) { return; } ?>
<section class="section section-alt">
  <div class="container">
    <div class="section-head">
      <div><h2><?= e($s['title']) ?></h2><?php if ($s['subtitle']): ?><p><?= e($s['subtitle']) ?></p><?php endif; ?></div>
      <a class="link-arrow" href="<?= e(url('/pages/makers')) ?>">All makers <?= icon('arrow-right') ?></a>
    </div>
    <div class="grid grid-4">
      <?php foreach ($s['items'] as $m): ?>
        <a class="maker-tile" href="<?= e(url('/makers/' . $m['slug'])) ?>">
          <img src="<?= e(image_url($m['image'])) ?>" alt="" loading="lazy" width="800" height="600">
          <div>
            <span class="product-maker"><?= e($m['location']) ?></span>
            <h3 style="font-size:1.2rem;margin:4px 0 8px"><?= e($m['name']) ?></h3>
            <p class="small muted mb-0"><?= e(str_limit($m['story'], 110)) ?></p>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
