<section class="section">
  <div class="container">
    <div class="section-head"><div><h2><?= e($s['title']) ?></h2><?php if ($s['subtitle']): ?><p><?= e($s['subtitle']) ?></p><?php endif; ?></div></div>
    <div class="budget-grid">
      <?php foreach ($s['items'] as $b):
          $q = ['min_price' => (int) $b['min_amount']] + ($b['max_amount'] !== null ? ['max_price' => (int) $b['max_amount']] : []);
          $isUnder = (float) $b['min_amount'] <= 0;
          $isAbove = $b['max_amount'] === null;
      ?>
        <a class="budget-card" href="<?= e(url('/shop', $q + ['sort' => 'price_asc'])) ?>">
          <small><?= $isUnder ? 'Under' : ($isAbove ? 'Above' : 'From') ?></small>
          <strong><?= e($isUnder ? money($b['max_amount']) : money($b['min_amount'])) ?></strong>
          <?php if (!$isUnder && !$isAbove): ?><small>to <?= e(money($b['max_amount'], false)) ?></small><?php endif; ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
