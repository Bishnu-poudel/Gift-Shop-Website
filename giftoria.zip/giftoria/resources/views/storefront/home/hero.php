<?php
$c = $s['config'];
// Title allows <em> for the accent word only; everything else is escaped.
$title = str_replace(['&lt;em&gt;', '&lt;/em&gt;'], ['<em>', '</em>'], e($s['title'] ?? ''));
$productCount = (int) App\Core\Database::fetchColumn("SELECT COUNT(*) FROM products WHERE status = 'active'");
$makerCount = (int) App\Core\Database::fetchColumn('SELECT COUNT(*) FROM makers');
?>
<section class="hero">
  <div class="hero-inner">
    <div>
      <?php if (!empty($c['eyebrow'])): ?><span class="eyebrow"><?= e($c['eyebrow']) ?></span><?php endif; ?>
      <h1><?= $title ?></h1>
      <?php if ($s['subtitle']): ?><p class="lead"><?= e($s['subtitle']) ?></p><?php endif; ?>
      <div class="row">
        <?php if (!empty($c['cta_label'])): ?><a class="btn btn-primary btn-lg" href="<?= e(url($c['cta_url'] ?? '/gift-finder')) ?>"><?= icon('sparkles', 'icon-sm') ?> <?= e($c['cta_label']) ?></a><?php endif; ?>
        <?php if (!empty($c['secondary_label'])): ?><a class="btn btn-outline btn-lg" href="<?= e(url($c['secondary_url'] ?? '/shop')) ?>"><?= e($c['secondary_label']) ?></a><?php endif; ?>
      </div>
      <div class="hero-stats">
        <?php if ($productCount): ?><div><strong><?= $productCount ?></strong>original gifts</div><?php endif; ?>
        <?php if ($makerCount): ?><div><strong><?= $makerCount ?></strong>independent makers</div><?php endif; ?>
        <div><strong>77</strong>districts delivered</div>
      </div>
    </div>
    <div class="hero-media">
      <img src="<?= e(image_url($c['image'] ?? null)) ?>" alt="" width="1000" height="1100" fetchpriority="high">
      <div class="hero-note"><span class="brand-mark"><?= icon('gift') ?></span><span><strong>Gift wrapping &amp; a handwritten note</strong> on every order, on request.</span></div>
    </div>
  </div>
</section>
