<?php
$seg = ['recipients' => 'for', 'occasions' => 'occasion', 'interests' => 'interest'][$s['taxonomy']];
$alt = $index % 2 === 1;
?>
<section class="section<?= $alt ? ' section-alt' : '' ?>">
  <div class="container">
    <div class="section-head">
      <div><h2><?= e($s['title']) ?></h2><?php if ($s['subtitle']): ?><p><?= e($s['subtitle']) ?></p><?php endif; ?></div>
      <a class="link-arrow" href="<?= e(url('/gift-finder')) ?>">Use the Gift Finder <?= icon('arrow-right') ?></a>
    </div>
    <?php if ($s['taxonomy'] === 'occasions'): ?>
      <div class="card-tiles">
        <?php foreach ($s['items'] as $item): ?>
          <a class="card-tile" href="<?= e(url('/gifts/' . $seg . '/' . $item['slug'])) ?>">
            <img src="<?= e(image_url($item['image'])) ?>" alt="" loading="lazy" width="800" height="1000">
            <div class="card-tile-body"><span>Gifts for</span><h3><?= e($item['name']) ?></h3></div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="tile-grid">
        <?php foreach ($s['items'] as $item): ?>
          <a class="tile" href="<?= e(url('/gifts/' . $seg . '/' . $item['slug'])) ?>">
            <span class="tile-img"><img src="<?= e(image_url($item['image'])) ?>" alt="" loading="lazy" width="300" height="300"></span>
            <span class="tile-label"><?= e($item['name']) ?></span>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>
