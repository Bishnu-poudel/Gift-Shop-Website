<?php if (!$s['items']) { return; } ?>
<section class="section-tight">
  <div class="container stack">
    <?php foreach ($s['items'] as $c): ?>
      <div class="campaign-banner" style="background:<?= e(preg_match('/^#[0-9a-fA-F]{6}$/', (string) $c['theme_color']) ? $c['theme_color'] : 'var(--terracotta)') ?>">
        <?php if ($c['image']): ?><img src="<?= e(image_url($c['image'])) ?>" alt="" loading="lazy"><?php endif; ?>
        <div>
          <span class="eyebrow" style="color:#f4ead6"><?= e($s['title'] ?? 'In season') ?></span>
          <h2><?= e($c['headline'] ?: $c['name']) ?></h2>
          <?php if ($c['subheadline']): ?><p style="color:#f4e9e4"><?= e($c['subheadline']) ?></p><?php endif; ?>
          <a class="btn btn-light mt-4" href="<?= e(url($c['cta_url'] ?: '/campaign/' . $c['slug'])) ?>"><?= e($c['cta_label'] ?: 'Explore') ?></a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>
