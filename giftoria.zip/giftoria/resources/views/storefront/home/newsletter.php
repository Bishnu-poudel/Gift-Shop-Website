<section class="section-tight">
  <div class="container">
    <div class="newsletter">
      <div>
        <span class="eyebrow">Newsletter</span>
        <h2 class="mb-2"><?= e($s['title']) ?></h2>
        <p class="muted mb-0"><?= e($s['subtitle']) ?></p>
      </div>
      <form action="<?= e(url('/newsletter')) ?>" method="post">
        <?= csrf_field() ?><input type="hidden" name="source" value="homepage">
        <label for="nl-email" class="sr-only">Email address</label>
        <input id="nl-email" class="input" type="email" name="email" placeholder="you@example.com" required autocomplete="email">
        <button class="btn btn-primary" type="submit">Subscribe</button>
      </form>
    </div>
  </div>
</section>
