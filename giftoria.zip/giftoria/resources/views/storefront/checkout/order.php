<?php
use App\Services\OrderStateMachine;

$paid = $order['payment_status'] === 'paid';
$state = match (true) {
    in_array($order['status'], ['cancelled', 'refunded'], true) => 'bad',
    $order['status'] === 'pending_payment' => 'wait',
    default => 'ok',
};
$headline = match (true) {
    $order['status'] === 'pending_payment' && $order['payment_status'] === 'pending' => 'Waiting for payment confirmation',
    $order['status'] === 'pending_payment' => 'Awaiting payment',
    $order['status'] === 'cancelled' => 'Order cancelled',
    $order['payment_method'] === 'cod' && $order['status'] === 'confirmed' => 'Thank you — your order is confirmed!',
    $paid && $order['status'] === 'confirmed' => 'Payment received — thank you!',
    default => OrderStateMachine::ORDER_LABELS[$order['status']] ?? status_label($order['status']),
};
$tq = ['t' => $order['access_token']];
?>
<div class="container container-narrow section-tight">
  <div class="order-status-card">
    <div class="status-icon <?= $state ?>"><?= icon($state === 'ok' ? 'check' : ($state === 'wait' ? 'clock' : 'x')) ?></div>
    <span class="eyebrow">Order <?= e($order['order_number']) ?></span>
    <h1 style="font-size:2rem"><?= e($headline) ?></h1>
    <p class="muted">We've sent updates to <?= e($order['email']) ?>. Placed <?= e(local_date($order['created_at'])) ?>.</p>
    <div class="row mt-4" style="justify-content:center">
      <span class="badge"><?= e(OrderStateMachine::ORDER_LABELS[$order['status']] ?? $order['status']) ?></span>
      <span class="badge <?= $paid ? 'badge-success' : 'badge-warning' ?>">Payment: <?= e(status_label($order['payment_status'])) ?> · <?= e(strtoupper($order['payment_method'])) ?></span>
    </div>
    <p class="mt-4"><a class="btn btn-light btn-sm" href="<?= e(url('/order/' . $order['order_number'] . '/bill', $tq)) ?>" target="_blank" rel="noopener"><?= icon('file', 'icon-sm') ?> <?= $order['status'] === 'pending_payment' ? 'View bill' : ((int) $order['vat_registered'] ? 'Download tax invoice' : 'Download invoice') ?> <?= e($order['bill_number'] ?? '') ?></a></p>
    <?php if ($canPay): ?>
      <div class="row mt-6" style="justify-content:center">
        <a class="btn btn-primary" href="<?= e(url('/checkout/pay/' . $order['order_number'], $tq)) ?>"><?= icon('wallet', 'icon-sm') ?> Pay now</a>
        <form method="post" action="<?= e(url('/order/' . $order['order_number'] . '/recheck', $tq)) ?>"><?= csrf_field() ?><button class="btn btn-light" type="submit"><?= icon('refresh', 'icon-sm') ?> Check payment status</button></form>
      </div>
    <?php endif; ?>
  </div>

  <div class="grid grid-2 mt-6">
    <div class="panel">
      <h2 style="font-size:1.2rem">Items</h2>
      <div class="summary-items" style="max-height:none">
        <?php foreach ($items as $i): ?>
          <div class="summary-item"><img src="<?= e(image_url($i['image'])) ?>" alt="" width="56" height="64"><div><?= e($i['name']) ?><?= $i['variant_name'] ? ' — ' . e($i['variant_name']) : '' ?><br><span class="qty-pill">Qty <?= (int) $i['quantity'] ?><?= $i['personalization'] ? ' · “' . e($i['personalization']) . '”' : '' ?></span></div><span><?= e(money($i['line_total'])) ?></span></div>
        <?php endforeach; ?>
      </div>
      <div class="summary-row"><span>Subtotal</span><span><?= e(money($order['subtotal'])) ?></span></div>
      <?php if ((float) $order['discount_total'] > 0): ?><div class="summary-row"><span>Discount</span><span class="discount">−<?= e(money($order['discount_total'])) ?></span></div><?php endif; ?>
      <div class="summary-row"><span>Delivery</span><span><?= (float) $order['shipping_total'] > 0 ? e(money($order['shipping_total'])) : 'Free' ?></span></div>
      <?php if ((float) $order['gift_wrap_total'] > 0): ?><div class="summary-row"><span>Gift wrap</span><span><?= e(money($order['gift_wrap_total'])) ?></span></div><?php endif; ?>
      <div class="summary-row total"><span>Total</span><span><?= e(money($order['grand_total'])) ?></span></div>
    </div>
    <div>
      <div class="panel">
        <h2 style="font-size:1.2rem">Delivering to</h2>
        <?php if ($address): ?><p class="small mb-0"><?= e($address['full_name']) ?> · <?= e($address['phone']) ?><br><?= e(trim(($address['street'] ?? '') . ', ' . $address['municipality'] . ($address['ward'] ? '-' . $address['ward'] : ''), ', ')) ?><br><?= e($address['district']) ?>, <?= e($address['province']) ?><?= $address['landmark'] ? '<br>' . e($address['landmark']) : '' ?></p><?php endif; ?>
        <?php if ($order['gift_message']): ?><p class="small mt-4 mb-0"><strong>Gift message:</strong> “<?= e($order['gift_message']) ?>”</p><?php endif; ?>
        <?php if ($shipment): ?><p class="small mt-4 mb-0"><strong>Shipment:</strong> <?= e($shipment['carrier']) ?> <?= e($shipment['tracking_number']) ?><?php if ($shipment['tracking_url'] && preg_match('#^https?://#', (string) $shipment['tracking_url'])): ?> · <a href="<?= e($shipment['tracking_url']) ?>" target="_blank" rel="noopener" style="text-decoration:underline">Track</a><?php endif; ?></p><?php endif; ?>
      </div>
      <div class="panel">
        <h2 style="font-size:1.2rem">Timeline</h2>
        <ul class="timeline">
          <?php foreach ($history as $h): ?><li><div><strong><?= e(OrderStateMachine::ORDER_LABELS[$h['to_status']] ?? $h['to_status']) ?></strong><br><span class="xsmall muted"><?= e(local_date($h['created_at'])) ?></span></div></li><?php endforeach; ?>
        </ul>
      </div>
      <?php if ($isGuest && !$accountExists): ?>
        <form class="panel" method="post" action="<?= e(url('/order/' . $order['order_number'] . '/create-account', $tq)) ?>">
          <?= csrf_field() ?>
          <h2 style="font-size:1.2rem">Save your details for next time</h2>
          <p class="small muted">Create an account with <?= e($order['email']) ?> to track orders and save addresses.</p>
          <div class="field"><label for="ca-pw">Password</label><input class="input" type="password" id="ca-pw" name="password" minlength="8" required autocomplete="new-password"><?= field_error('password') ?></div>
          <div class="field"><label for="ca-pw2">Confirm password</label><input class="input" type="password" id="ca-pw2" name="password_confirmation" minlength="8" required autocomplete="new-password"></div>
          <button class="btn btn-outline" type="submit">Create account</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
  <p class="center mt-6"><a class="btn btn-ghost" href="<?= e(url('/shop')) ?>">Continue shopping</a></p>
</div>
