<?php $failed = $lastPayment && in_array($lastPayment['status'], ['failed', 'cancelled', 'expired'], true); ?>
<div class="container container-narrow section-tight">
  <div class="order-status-card">
    <div class="status-icon wait"><?= icon('wallet') ?></div>
    <span class="eyebrow">Order <?= e($order['order_number']) ?></span>
    <h1 style="font-size:2rem"><?= $failed ? 'Let\'s try that payment again' : 'Complete your payment' ?></h1>
    <p class="muted">Amount due: <strong style="color:var(--ink)"><?= e(money($order['grand_total'])) ?></strong>. Your items are reserved until <?= e(local_date($order['expires_at'], 'g:i A')) ?> (Nepal time). Retrying never creates a duplicate order.</p>
    <?php
      $vatOn = (int) $order['vat_registered'] === 1 && (float) $order['vat_rate'] > 0;
      $vatRate = rtrim(rtrim(number_format((float) $order['vat_rate'], 2), '0'), '.');
      $billUrl = url('/order/' . $order['order_number'] . '/bill', ['t' => $order['access_token']]);
    ?>
    <div class="panel mt-6" style="text-align:left;margin-bottom:0">
      <div class="row-between mb-4">
        <div><span class="eyebrow mb-0">Step 1 · Review your bill</span><h2 style="font-size:1.25rem;margin:4px 0 0">Bill <?= e($order['bill_number']) ?></h2></div>
        <a class="btn btn-outline btn-sm" href="<?= e($billUrl) ?>" target="_blank" rel="noopener"><?= icon('file', 'icon-sm') ?> View / download bill</a>
      </div>
      <?php foreach ($items as $it): ?>
        <div class="summary-row"><span><?= e($it['name']) ?><?= $it['variant_name'] ? ' — ' . e($it['variant_name']) : '' ?> × <?= (int) $it['quantity'] ?></span><span><?= e(money($it['line_total'])) ?></span></div>
      <?php endforeach; ?>
      <?php if ((float) $order['discount_total'] > 0): ?><div class="summary-row"><span>Discount<?= $order['coupon_code'] ? ' (' . e($order['coupon_code']) . ')' : '' ?></span><span class="discount">−<?= e(money($order['discount_total'])) ?></span></div><?php endif; ?>
      <div class="summary-row"><span>Delivery</span><span><?= (float) $order['shipping_total'] > 0 ? e(money($order['shipping_total'])) : 'Free' ?></span></div>
      <?php if ((float) $order['gift_wrap_total'] > 0): ?><div class="summary-row"><span>Gift wrap</span><span><?= e(money($order['gift_wrap_total'])) ?></span></div><?php endif; ?>
      <?php if ($vatOn): ?>
        <div class="summary-row"><span>Taxable amount</span><span><?= e(money($order['taxable_amount'])) ?></span></div>
        <div class="summary-row"><span>VAT <?= e($vatRate) ?>%<?= (int) $order['prices_include_vat'] ? ' (included)' : '' ?></span><span><?= e(money($order['vat_amount'])) ?></span></div>
      <?php endif; ?>
      <div class="summary-row total"><span>Amount payable</span><span><?= e(money($order['grand_total'])) ?></span></div>
      <p class="xsmall muted mb-0 mt-2">This is a proforma bill. It becomes your <?= $vatOn ? 'tax invoice' : 'invoice' ?> automatically once the payment is verified.</p>
    </div>
    <h2 class="mt-6" style="font-size:1.25rem;text-align:left"><span class="eyebrow mb-0" style="display:block">Step 2</span>Choose how to pay</h2>
    <?php if ($failed): ?><div class="alert alert-warning" style="text-align:left"><?= icon('alert') ?><div>Your last attempt was <?= e($lastPayment['status']) ?>. If money left your wallet, it will be reconciled automatically — you can also use “Check payment status” on the order page.</div></div><?php endif; ?>
    <form method="post" action="<?= e(url('/checkout/pay/' . $order['order_number'], ['t' => $order['access_token']])) ?>" class="pay-options mt-4" style="text-align:left" data-loading>
      <?= csrf_field() ?>
      <?php foreach (array_keys($methods) as $m): ?>
        <div class="pay-option">
          <input type="radio" name="gateway" id="g-<?= e($m) ?>" value="<?= e($m) ?>" <?= $order['payment_method'] === $m ? 'checked' : '' ?>>
          <label for="g-<?= e($m) ?>"><span class="pay-logo <?= e($m) ?>"><?= $m === 'esewa' ? 'eSewa' : 'Khalti' ?></span><span><strong>Pay with <?= $m === 'esewa' ? 'eSewa' : 'Khalti' ?></strong><br><span class="xsmall muted">You'll be redirected to the secure <?= $m === 'esewa' ? 'eSewa' : 'Khalti' ?> page.</span></span></label>
        </div>
      <?php endforeach; ?>
      <button class="btn btn-primary btn-lg btn-block mt-4" type="submit"><?= icon('lock', 'icon-sm') ?> Pay <?= e(money($order['grand_total'])) ?></button>
    </form>
    <?php if ($testMode): ?><p class="xsmall muted mt-4"><?= $simulator ? 'Local simulator enabled — no real money moves.' : 'Payment gateways are in sandbox/test mode.' ?></p><?php endif; ?>
    <a class="link-btn mt-4" style="display:inline-block" href="<?= e(url('/order/' . $order['order_number'], ['t' => $order['access_token']])) ?>">View order details</a>
  </div>
</div>
