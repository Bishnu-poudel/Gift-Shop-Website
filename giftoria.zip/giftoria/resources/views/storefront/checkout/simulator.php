<div class="order-status-card" style="max-width:520px;text-align:left">
  <span class="badge badge-warning">Local payment simulator · not a real payment</span>
  <h1 style="font-size:1.6rem" class="mt-4"><?= e(ucfirst($gateway)) ?> sandbox simulation</h1>
  <p class="muted small">This page imitates the gateway's hosted page so the full verification flow can be tested offline. It is only available when <code>PAYMENT_SIMULATOR=true</code> and never in production.</p>
  <dl class="spec-list mb-6"><dt>Reference</dt><dd><?= e($payment['attempt_ref']) ?></dd><dt>Amount</dt><dd><?= e(money($payment['amount'])) ?></dd></dl>
  <form method="post" class="stack">
    <?= csrf_field() ?>
    <button class="btn btn-primary btn-block" name="outcome" value="success">Simulate successful payment</button>
    <button class="btn btn-light btn-block" name="outcome" value="pending">Simulate pending payment</button>
    <button class="btn btn-light btn-block" name="outcome" value="cancel">Simulate cancel / failure</button>
    <label class="check small"><input type="checkbox" name="tamper" value="1"> Report a wrong amount (verification must reject it)</label>
  </form>
</div>
