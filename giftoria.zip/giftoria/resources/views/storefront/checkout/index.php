<?php
$t = $totals;
$d = $default ?? [];
$v = static fn (string $key, string $fallback = '') => old($key, $fallback);
$selectedMethod = (string) old('payment_method', array_key_first($methods) ?? 'esewa');
?>
<div class="container">
  <header class="page-head"><h1>Checkout</h1><p>Secure checkout · <?= $customer ? 'Signed in as ' . e($customer['email']) : 'Checking out as a guest — <a href="' . e(url('/login')) . '" style="text-decoration:underline">sign in</a> to use saved addresses' ?></p></header>

  <form method="post" action="<?= e(url('/checkout')) ?>" class="checkout-layout" id="checkout-form" data-loading data-quote-url="<?= e(url('/checkout/quote')) ?>" novalidate>
    <?= csrf_field() ?>
    <input type="hidden" name="checkout_token" value="<?= e($checkoutToken) ?>">
    <div>
      <section class="checkout-section">
        <h2><span class="step-num">1</span> Your details</h2>
        <div class="form-row">
          <div class="field"><label for="customer_name">Full name</label><input class="input <?= errors('customer_name') ? 'has-error' : '' ?>" id="customer_name" name="customer_name" required autocomplete="name" value="<?= e($v('customer_name', $customer['name'] ?? '')) ?>"><?= field_error('customer_name') ?></div>
          <div class="field"><label for="phone">Mobile number</label><input class="input <?= errors('phone') ? 'has-error' : '' ?>" id="phone" name="phone" required inputmode="tel" autocomplete="tel" placeholder="98XXXXXXXX" value="<?= e($v('phone', $customer['phone'] ?? '')) ?>"><?= field_error('phone') ?></div>
        </div>
        <div class="field"><label for="email">Email (for your receipt and order updates)</label><input class="input <?= errors('email') ? 'has-error' : '' ?>" id="email" type="email" name="email" required autocomplete="email" value="<?= e($v('email', $customer['email'] ?? '')) ?>"><?= field_error('email') ?></div>
        <details <?= (old('buyer_pan') || errors('buyer_pan')) ? 'open' : '' ?>>
          <summary class="small" style="cursor:pointer;font-weight:600">Need a business bill with your PAN/VAT number?</summary>
          <div class="form-row mt-4">
            <div class="field"><label for="buyer_company">Company / organisation name</label><input class="input" id="buyer_company" name="buyer_company" maxlength="150" autocomplete="organization" value="<?= e($v('buyer_company')) ?>"><?= field_error('buyer_company') ?></div>
            <div class="field"><label for="buyer_pan">Buyer PAN / VAT no.</label><input class="input <?= errors('buyer_pan') ? 'has-error' : '' ?>" id="buyer_pan" name="buyer_pan" inputmode="numeric" pattern="\d{9}" maxlength="9" placeholder="9 digits" value="<?= e($v('buyer_pan')) ?>"><?= field_error('buyer_pan') ?></div>
          </div>
          <p class="hint mb-0">Printed on your bill. Leave empty for a personal purchase.</p>
        </details>
      </section>

      <section class="checkout-section">
        <h2><span class="step-num">2</span> Delivery address</h2>
        <?php if ($addresses): ?>
          <div class="saved-addresses">
            <?php foreach ($addresses as $a): ?>
              <label class="address-card <?= $a['is_default'] ? 'is-default' : '' ?>" style="cursor:pointer">
                <input type="radio" name="_saved_address" value="<?= (int) $a['id'] ?>" data-address='<?= json_attr(array_intersect_key($a, array_flip(['full_name', 'phone', 'province', 'district', 'municipality', 'ward', 'street', 'landmark']))) ?>' <?= $a['is_default'] ? 'checked' : '' ?>>
                <strong><?= e($a['label'] ?: 'Address') ?></strong> · <?= e($a['full_name']) ?>, <?= e($a['municipality']) ?><?= $a['ward'] ? '-' . e($a['ward']) : '' ?>, <?= e($a['district']) ?>
              </label>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <div class="form-row">
          <div class="field"><label for="full_name">Recipient name</label><input class="input <?= errors('full_name') ? 'has-error' : '' ?>" id="full_name" name="full_name" required value="<?= e($v('full_name', $d['full_name'] ?? ($customer['name'] ?? ''))) ?>"><?= field_error('full_name') ?></div>
          <div class="field"><label for="ship_phone">Recipient phone</label><input class="input <?= errors('ship_phone') ? 'has-error' : '' ?>" id="ship_phone" name="ship_phone" required inputmode="tel" value="<?= e($v('ship_phone', $d['phone'] ?? '')) ?>"><?= field_error('ship_phone') ?></div>
        </div>
        <div class="form-row">
          <div class="field"><label for="province">Province</label>
            <select class="select <?= errors('province') ? 'has-error' : '' ?>" id="province" name="province" required data-province-select data-district-target="district" data-districts='<?= json_attr($provinces) ?>'>
              <option value="">Select province</option>
              <?php foreach (array_keys($provinces) as $prov): ?><option value="<?= e($prov) ?>" <?= $v('province', $d['province'] ?? '') === $prov ? 'selected' : '' ?>><?= e($prov) ?></option><?php endforeach; ?>
            </select><?= field_error('province') ?></div>
          <div class="field"><label for="district">District</label>
            <select class="select <?= errors('district') ? 'has-error' : '' ?>" id="district" name="district" required data-selected="<?= e($v('district', $d['district'] ?? '')) ?>" data-quote>
              <option value="">Select district</option>
              <?php $selProv = $v('province', $d['province'] ?? ''); foreach ($provinces[$selProv] ?? [] as $dist): ?><option value="<?= e($dist) ?>" <?= $v('district', $d['district'] ?? '') === $dist ? 'selected' : '' ?>><?= e($dist) ?></option><?php endforeach; ?>
            </select><?= field_error('district') ?></div>
        </div>
        <div class="form-row">
          <div class="field"><label for="municipality">Municipality / city</label><input class="input <?= errors('municipality') ? 'has-error' : '' ?>" id="municipality" name="municipality" required placeholder="e.g. Lalitpur Metropolitan City" value="<?= e($v('municipality', $d['municipality'] ?? '')) ?>"><?= field_error('municipality') ?></div>
          <div class="field"><label for="ward">Ward no.</label><input class="input" id="ward" name="ward" inputmode="numeric" maxlength="2" value="<?= e($v('ward', (string) ($d['ward'] ?? ''))) ?>"><?= field_error('ward') ?></div>
        </div>
        <div class="field"><label for="street">Street / tole</label><input class="input" id="street" name="street" value="<?= e($v('street', $d['street'] ?? '')) ?>"></div>
        <div class="field"><label for="landmark">Landmark or delivery instructions</label><input class="input" id="landmark" name="landmark" placeholder="Near the temple gate, call on arrival" value="<?= e($v('landmark', $d['landmark'] ?? '')) ?>"></div>
        <?php if ($customer): ?><label class="check mb-4"><input type="checkbox" name="save_address" value="1"> Save this address to my account</label><?php endif; ?>
        <div class="field" style="max-width:280px"><label for="requested_delivery_date">Preferred delivery date (optional)</label><input class="input" type="date" id="requested_delivery_date" name="requested_delivery_date" min="<?= e(local_today()) ?>" value="<?= e($v('requested_delivery_date')) ?>"><?= field_error('requested_delivery_date') ?></div>
        <label class="check"><input type="checkbox" name="billing_different" value="1" data-toggle-billing <?= old('billing_different') ? 'checked' : '' ?>> Billing address is different</label>
        <div data-billing <?= old('billing_different') ? '' : 'hidden' ?> class="mt-4">
          <div class="form-row">
            <div class="field"><label for="b_full_name">Billing name</label><input class="input" id="b_full_name" name="b_full_name" value="<?= e($v('b_full_name')) ?>"><?= field_error('b_full_name') ?></div>
            <div class="field"><label for="b_phone">Billing phone</label><input class="input" id="b_phone" name="b_phone" value="<?= e($v('b_phone')) ?>"><?= field_error('b_phone') ?></div>
          </div>
          <div class="form-row">
            <div class="field"><label for="b_province">Province</label>
              <select class="select" id="b_province" name="b_province" data-province-select data-district-target="b_district" data-districts='<?= json_attr($provinces) ?>'>
                <option value="">Select province</option>
                <?php foreach (array_keys($provinces) as $prov): ?><option value="<?= e($prov) ?>" <?= $v('b_province') === $prov ? 'selected' : '' ?>><?= e($prov) ?></option><?php endforeach; ?>
              </select></div>
            <div class="field"><label for="b_district">District</label><select class="select" id="b_district" name="b_district" data-selected="<?= e($v('b_district')) ?>"><option value="">Select district</option></select><?= field_error('b_district') ?></div>
          </div>
          <div class="form-row">
            <div class="field"><label for="b_municipality">Municipality</label><input class="input" id="b_municipality" name="b_municipality" value="<?= e($v('b_municipality')) ?>"></div>
            <div class="field"><label for="b_ward">Ward</label><input class="input" id="b_ward" name="b_ward" value="<?= e($v('b_ward')) ?>"></div>
          </div>
          <div class="field"><label for="b_street">Street</label><input class="input" id="b_street" name="b_street" value="<?= e($v('b_street')) ?>"></div>
        </div>
      </section>

      <section class="checkout-section">
        <h2><span class="step-num">3</span> Gift options</h2>
        <?php if ($t['gift_wrap_possible']): ?><label class="check mb-4"><input type="checkbox" name="gift_wrap" value="1" data-quote <?= (old('gift_wrap') || !empty($cart['gift_wrap'])) ? 'checked' : '' ?>> Gift wrap with a handwritten card (+<?= e(money($giftWrapFee)) ?>)</label><?php endif; ?>
        <div class="field"><label for="gift_message">Gift message</label><textarea class="textarea" id="gift_message" name="gift_message" maxlength="300"><?= e($v('gift_message', $cart['gift_message'] ?? '')) ?></textarea><p class="hint">Gift orders never include prices on the packing slip.</p></div>
        <div class="field mb-0"><label for="customer_note">Note for our team (optional)</label><input class="input" id="customer_note" name="customer_note" maxlength="500" value="<?= e($v('customer_note')) ?>"></div>
      </section>

      <section class="checkout-section">
        <h2><span class="step-num">4</span> Payment</h2>
        <div class="pay-options" role="radiogroup" aria-label="Payment method">
          <?php foreach ($allMethods as $key => $label): $available = isset($methods[$key]); ?>
            <div class="pay-option" data-method="<?= e($key) ?>" <?= $available ? '' : 'hidden' ?>>
              <input type="radio" name="payment_method" id="pm-<?= e($key) ?>" value="<?= e($key) ?>" <?= $selectedMethod === $key && $available ? 'checked' : '' ?>>
              <label for="pm-<?= e($key) ?>">
                <span class="pay-logo <?= e($key) ?>"><?= e($key === 'cod' ? 'COD' : $label) ?></span>
                <span><strong><?= e($label) ?></strong><br><span class="xsmall muted"><?= e(match ($key) { 'esewa' => 'Pay securely with your eSewa wallet. You will be redirected to eSewa.', 'khalti' => 'Pay with Khalti wallet, mobile banking or cards. You will be redirected to Khalti.', default => 'Pay in cash when your gift arrives (where available).' }) ?></span></span>
              </label>
            </div>
          <?php endforeach; ?>
        </div>
        <p class="xsmall muted mt-4" data-cod-note>Cash on delivery is available in selected delivery zones for orders up to <?= e(money(setting('cod_max_order', 25000))) ?>.</p>
        <?= field_error('payment_method') ?>
        <label class="check mt-4"><input type="checkbox" name="terms" value="1" required <?= old('terms') ? 'checked' : '' ?>> I agree to the <a href="<?= e(url('/pages/terms')) ?>" target="_blank" style="text-decoration:underline">terms</a> and <a href="<?= e(url('/pages/returns')) ?>" target="_blank" style="text-decoration:underline">returns policy</a>.</label>
        <?= field_error('terms') ?>
      </section>
    </div>

    <aside class="summary-card" aria-label="Order summary">
      <h2>Order summary</h2>
      <div class="summary-items">
        <?php foreach ($t['lines'] as $l): ?>
          <div class="summary-item"><img src="<?= e(image_url($l['image'])) ?>" alt="" width="56" height="64"><div><?= e($l['name']) ?><?php if ($l['variant_name']): ?><br><span class="qty-pill"><?= e($l['variant_name']) ?></span><?php endif; ?><br><span class="qty-pill">Qty <?= (int) $l['quantity'] ?></span></div><span><?= e(money($l['line_total'])) ?></span></div>
        <?php endforeach; ?>
      </div>
      <?php foreach ($t['issues'] as $issue): ?><div class="alert alert-warning small"><?= e($issue['message']) ?></div><?php endforeach; ?>
      <div data-quote-issues></div>
      <div class="summary-row"><span>Subtotal</span><span data-q="subtotal"><?= e(money($t['subtotal'])) ?></span></div>
      <div class="summary-row" data-row="discount" <?= $t['discount'] > 0 ? '' : 'hidden' ?>><span>Discount <?= $t['coupon_code'] ? '(' . e($t['coupon_code']) . ')' : '' ?></span><span class="discount" data-q="discount">−<?= e(money($t['discount'])) ?></span></div>
      <div class="summary-row"><span>Delivery <span class="xsmall muted" data-q="zone"><?= e($t['zone']['name'] ?? '') ?></span></span><span data-q="shipping"><?= $t['shipping_known'] ? ($t['shipping'] > 0 ? e(money($t['shipping'])) : 'Free') : 'Select district' ?></span></div>
      <div class="summary-row" data-row="gift_wrap" <?= $t['gift_wrap'] > 0 ? '' : 'hidden' ?>><span>Gift wrap</span><span data-q="gift_wrap"><?= e(money($t['gift_wrap'])) ?></span></div>
      <?php $vatOn = $t['tax']['registered'] && $t['tax']['rate'] > 0; $vatRate = rtrim(rtrim(number_format((float) $t['tax']['rate'], 2), '0'), '.'); ?>
      <?php if ($vatOn && !$t['tax']['inclusive']): ?><div class="summary-row"><span>VAT <?= e($vatRate) ?>%</span><span data-q="vat"><?= e(money($t['vat_amount'])) ?></span></div><?php endif; ?>
      <div class="summary-row total"><span>Total</span><span data-q="total"><?= e(money($t['grand_total'])) ?></span></div>
      <?php if ($vatOn && $t['tax']['inclusive']): ?><div class="summary-row xsmall muted" style="padding-top:0"><span>Includes VAT <?= e($vatRate) ?>%</span><span data-q="vat"><?= e(money($t['vat_amount'])) ?></span></div><?php endif; ?>
      <p class="small muted mt-2" data-q="estimate"><?= $t['delivery_estimate'] ? 'Estimated delivery: ' . e($t['delivery_estimate']['label']) : '' ?></p>
      <button class="btn btn-primary btn-lg btn-block mt-4" type="submit"><?= icon('lock', 'icon-sm') ?> Place order</button>
      <p class="xsmall muted center mt-2">Next you'll see your bill to review and download before paying. Totals are always recalculated on our server.</p>
      <a class="link-btn mt-4" style="display:block;text-align:center" href="<?= e(url('/cart')) ?>">Edit bag</a>
    </aside>
  </form>
</div>
<script src="<?= e(asset('assets/js/checkout.js')) ?>" defer></script>
