<div class="order-status-card" style="max-width:460px">
  <div class="status-icon wait"><?= icon('lock') ?></div>
  <h1 style="font-size:1.6rem">Taking you to eSewa…</h1>
  <p class="muted">Please don't close this window. You'll come back here automatically after paying.</p>
  <form method="post" action="<?= e($action) ?>" id="gateway-form">
    <?php foreach ($fields as $name => $value): ?><input type="hidden" name="<?= e($name) ?>" value="<?= e($value) ?>"><?php endforeach; ?>
    <?php if (str_starts_with($action, rtrim((string) config('app.url'), '/'))): ?><?= csrf_field() ?><?php endif; ?>
    <button class="btn btn-primary mt-4" type="submit">Continue to eSewa</button>
  </form>
</div>
<script>setTimeout(function () { document.getElementById('gateway-form').submit(); }, 400);</script>
