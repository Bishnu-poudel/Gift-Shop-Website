<?php
use App\Controllers\GiftFinderController;

$pre = $prefill;
$isChecked = static fn (string $key, string $val) => in_array($val, (array) ($pre[$key] ?? []), true) || (($pre[$key] ?? null) === $val);
$districtList = [];
foreach ($districts as $prov => $ds) {
    foreach ($ds as $d) {
        $districtList[] = $d;
    }
}
sort($districtList);
?>
<div class="container">
  <div class="finder">
    <div class="center mb-8">
      <span class="eyebrow">Gift Finder</span>
      <p class="muted small mb-0">Seven quick questions · skip any you are unsure about · ideas come from our real catalogue</p>
    </div>
    <div class="finder-progress" aria-hidden="true"><?php for ($i = 0; $i < 7; $i++): ?><span class="<?= $i === 0 ? 'is-done' : '' ?>"></span><?php endfor; ?></div>

    <form action="<?= e(url('/gift-finder/results')) ?>" method="get" id="finder-form" novalidate>
      <!-- Step 1 -->
      <section class="finder-step is-active" data-step="1" aria-labelledby="st1">
        <h2 id="st1">Who are you shopping for?</h2>
        <p class="step-sub">We will tailor ideas to them.</p>
        <div class="option-grid">
          <?php foreach ($recipients as $r): ?>
            <div class="option-card">
              <input type="radio" name="recipient" id="rc-<?= e($r['slug']) ?>" value="<?= e($r['slug']) ?>" data-audience="<?= e($r['audience']) ?>" <?= $isChecked('recipient', $r['slug']) ? 'checked' : '' ?>>
              <label for="rc-<?= e($r['slug']) ?>"><?= icon(GiftFinderController::RECIPIENT_ICONS[$r['slug']] ?? 'gift') ?><?= e($r['name']) ?></label>
            </div>
          <?php endforeach; ?>
        </div>
      </section>

      <!-- Step 2 -->
      <section class="finder-step" data-step="2" aria-labelledby="st2">
        <h2 id="st2">What's the occasion?</h2>
        <p class="step-sub">Pick one, or skip if it's just because.</p>
        <div class="option-grid">
          <?php foreach ($occasions as $o): ?>
            <div class="option-card">
              <input type="radio" name="occasion" id="oc-<?= e($o['slug']) ?>" value="<?= e($o['slug']) ?>" <?= $isChecked('occasion', $o['slug']) ? 'checked' : '' ?>>
              <label for="oc-<?= e($o['slug']) ?>"><?= icon(GiftFinderController::OCCASION_ICONS[$o['slug']] ?? 'gift') ?><?= e($o['name']) ?></label>
            </div>
          <?php endforeach; ?>
        </div>
      </section>

      <!-- Step 3 -->
      <section class="finder-step" data-step="3" aria-labelledby="st3">
        <h2 id="st3">What are they into?</h2>
        <p class="step-sub">Choose as many as you like.</p>
        <div class="chips">
          <?php foreach ($interests as $it): ?>
            <span><input class="chip-input" type="checkbox" name="interests[]" id="in-<?= e($it['slug']) ?>" value="<?= e($it['slug']) ?>" <?= $isChecked('interests', $it['slug']) ? 'checked' : '' ?>><label class="chip" for="in-<?= e($it['slug']) ?>"><?= e($it['name']) ?></label></span>
          <?php endforeach; ?>
        </div>
        <div class="field mt-6" style="max-width:420px">
          <label for="custom_interest">Something else they love?</label>
          <input class="input" id="custom_interest" name="custom_interest" maxlength="80" placeholder="e.g. momo, trekking, origami" value="<?= e($pre['custom_interest'] ?? '') ?>">
          <p class="hint">We match this against our catalogue (spelling mistakes are fine).</p>
        </div>
        <label class="check mt-2"><input type="checkbox" name="strict_interests" value="1" <?= !empty($pre['strict_interests']) ? 'checked' : '' ?>> Only show gifts that match these interests</label>
      </section>

      <!-- Step 4 -->
      <section class="finder-step" data-step="4" aria-labelledby="st4">
        <h2 id="st4">How old are they?</h2>
        <p class="step-sub" data-age-hint>For little ones we only suggest items whose maker-stated age range fits — and never toys with small parts for under-3s.</p>
        <div class="option-grid">
          <?php foreach ($ages as $a): ?>
            <div class="option-card" data-age-audience="<?= e($a['audience']) ?>">
              <input type="radio" name="age" id="ag-<?= e($a['slug']) ?>" value="<?= e($a['slug']) ?>" <?= $isChecked('age', $a['slug']) ? 'checked' : '' ?>>
              <label for="ag-<?= e($a['slug']) ?>"><?= e($a['label']) ?></label>
            </div>
          <?php endforeach; ?>
        </div>
      </section>

      <!-- Step 5 -->
      <section class="finder-step" data-step="5" aria-labelledby="st5">
        <h2 id="st5">What's your budget?</h2>
        <p class="step-sub">Prices in Nepalese rupees.</p>
        <div class="option-grid">
          <?php foreach ($budgets as $b): ?>
            <div class="option-card">
              <input type="radio" name="budget" id="bd-<?= (int) $b['id'] ?>" value="<?= (int) $b['id'] ?>" <?= (string) ($pre['budget'] ?? '') === (string) $b['id'] ? 'checked' : '' ?>>
              <label for="bd-<?= (int) $b['id'] ?>"><?= e($b['label']) ?></label>
            </div>
          <?php endforeach; ?>
          <div class="option-card">
            <input type="radio" name="budget" id="bd-custom" value="" data-custom-budget>
            <label for="bd-custom">Custom range</label>
          </div>
        </div>
        <div class="form-row mt-6" style="max-width:420px" data-custom-range hidden>
          <div class="field"><label for="min_price">Min (NPR)</label><input class="input" type="number" id="min_price" name="min_price" min="0" step="100" value="<?= e($pre['min_price'] ?? '') ?>"></div>
          <div class="field"><label for="max_price">Max (NPR)</label><input class="input" type="number" id="max_price" name="max_price" min="0" step="100" value="<?= e($pre['max_price'] ?? '') ?>"></div>
        </div>
      </section>

      <!-- Step 6 -->
      <section class="finder-step" data-step="6" aria-labelledby="st6">
        <h2 id="st6">Anything else?</h2>
        <p class="step-sub">Optional preferences.</p>
        <div class="chips">
          <?php foreach ($prefs as $t): ?>
            <span><input class="chip-input" type="checkbox" name="prefs[]" id="pf-<?= e($t['slug']) ?>" value="<?= e($t['slug']) ?>" <?= $isChecked('prefs', $t['slug']) ? 'checked' : '' ?>><label class="chip" for="pf-<?= e($t['slug']) ?>"><?= e($t['name']) ?></label></span>
          <?php endforeach; ?>
          <span><input class="chip-input" type="checkbox" name="gift_wrap" id="pf-wrap" value="1" <?= !empty($pre['gift_wrap']) ? 'checked' : '' ?>><label class="chip" for="pf-wrap">Gift wrapping required</label></span>
        </div>
        <div class="form-row mt-6" style="max-width:560px">
          <div class="field">
            <label for="district">Delivery district</label>
            <select class="select" id="district" name="district">
              <option value="">Anywhere in Nepal</option>
              <?php foreach ($districtList as $d): ?><option value="<?= e($d) ?>" <?= ($pre['district'] ?? '') === $d ? 'selected' : '' ?>><?= e($d) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label for="delivery_date">Needed by</label>
            <input class="input" type="date" id="delivery_date" name="delivery_date" min="<?= e(local_today()) ?>" value="<?= e($pre['delivery_date'] ?? '') ?>">
            <p class="hint">We hide items that cannot arrive in time.</p>
          </div>
        </div>
      </section>

      <!-- Step 7 -->
      <section class="finder-step" data-step="7" aria-labelledby="st7">
        <h2 id="st7">Ready when you are</h2>
        <p class="step-sub">Here's what we'll look for:</p>
        <div class="finder-summary" data-summary></div>
        <button class="btn btn-accent btn-lg" type="submit"><?= icon('sparkles', 'icon-sm') ?> Show my gift ideas</button>
      </section>

      <div class="finder-nav">
        <button class="btn btn-ghost" type="button" data-prev hidden><?= icon('chevron-left', 'icon-sm') ?> Back</button>
        <span class="small muted" data-step-label>Step 1 of 7</span>
        <div class="row">
          <button class="btn btn-light" type="button" data-skip>Skip</button>
          <button class="btn btn-primary" type="button" data-next>Next <?= icon('chevron-right', 'icon-sm') ?></button>
        </div>
      </div>
      <noscript><p class="center mt-6"><button class="btn btn-accent" type="submit">Show my gift ideas</button></p><style>.finder-step{display:block!important;margin-bottom:48px}.finder-nav{display:none}</style></noscript>
    </form>
  </div>
</div>
<script src="<?= e(asset('assets/js/finder.js')) ?>" defer></script>
