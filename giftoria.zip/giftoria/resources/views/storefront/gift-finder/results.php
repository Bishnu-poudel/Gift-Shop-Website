<?php
$c = $criteria;
$chips = [];
if ($c['recipient']) { $chips[] = 'For ' . ($labels['recipients'][$c['recipient']]['name'] ?? $c['recipient']); }
if ($c['occasion']) { $chips[] = $labels['occasions'][$c['occasion']]['name'] ?? $c['occasion']; }
foreach ($c['interests'] as $i) { $chips[] = $labels['interests'][$i]['name'] ?? $i; }
if ($c['custom_interest'] !== '') { $chips[] = '“' . $c['custom_interest'] . '”'; }
if ($ageRange) { $chips[] = 'Age ' . $ageRange['label']; } elseif ($c['age_min_months'] !== null) { $chips[] = 'Age ' . age_range_label($c['age_min_months'], $c['age_max_months']); }
if ($c['min_price'] !== null || $c['max_price'] !== null) { $chips[] = ($c['min_price'] ? money($c['min_price']) : 'NPR 0') . ' – ' . ($c['max_price'] !== null ? money($c['max_price']) : 'any'); }
foreach ($c['prefs'] as $p) { $chips[] = $prefs[$p] ?? $p; }
if ($c['gift_wrap']) { $chips[] = 'Gift wrap'; }
if ($c['district']) { $chips[] = 'Deliver to ' . $c['district']; }
if ($c['delivery_date']) { $chips[] = 'Needed by ' . date('M j', strtotime($c['delivery_date'])); }
$editQuery = request()?->query() ?? [];
unset($editQuery['page'], $editQuery['sort'], $editQuery['similar_to']);
// Criteria exposed to JS for feedback context (no personal data).
$jsCriteria = array_intersect_key($c, array_flip(['recipient', 'occasion', 'interests', 'age', 'budget', 'min_price', 'max_price', 'prefs']));
?>
<div class="container">
  <div class="results-head">
    <div>
      <span class="eyebrow"><?= $c['similar_to'] ? 'More like this' : 'Your gift ideas' ?></span>
      <h1 style="font-size:clamp(2rem,4vw,3rem)"><?= $result['total'] ? number_format($result['total']) . ' gift' . ($result['total'] === 1 ? '' : 's') . ' picked for you' : 'No exact matches yet' ?></h1>
      <div class="finder-summary mb-0">
        <?php foreach ($chips as $chip): ?><span class="chip is-active"><?= e($chip) ?></span><?php endforeach; ?>
        <?php if (!$chips): ?><span class="chip">Showing our most-loved gifts</span><?php endif; ?>
      </div>
    </div>
    <div class="row">
      <a class="btn btn-light" href="<?= e(url('/gift-finder', $editQuery)) ?>"><?= icon('edit', 'icon-sm') ?> Refine answers</a>
      <form method="get" action="<?= e(url('/gift-finder/results')) ?>">
        <?php foreach (request()?->query() ?? [] as $k => $v): if (in_array($k, ['sort', 'page'], true)) { continue; } foreach ((array) $v as $vv): ?>
          <input type="hidden" name="<?= e(is_array($v) ? $k . '[]' : $k) ?>" value="<?= e($vv) ?>">
        <?php endforeach; endforeach; ?>
        <label class="sr-only" for="fsort">Sort</label>
        <select class="select" id="fsort" name="sort" data-autosubmit style="min-height:46px;width:auto">
          <?php foreach (['relevance' => 'Best match', 'popular' => 'Most popular', 'rating' => 'Top rated', 'newest' => 'Newest', 'price_asc' => 'Price: low to high', 'price_desc' => 'Price: high to low'] as $k => $l): ?>
            <option value="<?= e($k) ?>" <?= $sort === $k ? 'selected' : '' ?>><?= e($l) ?></option>
          <?php endforeach; ?>
        </select>
      </form>
    </div>
  </div>

  <?php if ($c['corrections']): ?><div class="notice-bar"><?= icon('info', 'icon-sm') ?> We read “<?= e(implode(', ', array_keys($c['corrections']))) ?>” as “<?= e(implode(', ', array_values($c['corrections']))) ?>”.</div><?php endif; ?>
  <?php foreach ($result['relaxed'] as $note): ?><div class="notice-bar"><?= icon('info', 'icon-sm') ?> <?= e($note) ?></div><?php endforeach; ?>
  <?php if ($c['age_min_months'] !== null && $c['age_min_months'] < 36): ?>
    <div class="alert alert-info"><?= icon('shield') ?><div>For babies and toddlers we only show items whose maker-stated age range starts at or below this age, and exclude anything with small parts.</div></div>
  <?php endif; ?>

  <?php if ($result['items']): ?>
    <script>window.GIFT_FINDER_CRITERIA = <?= json_encode($jsCriteria, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) ?>;</script>
    <?= partial('components/product-grid', ['products' => $result['items'], 'saved' => $saved, 'reco' => true]) ?>
    <?= $paginator->links() ?>
    <p class="center xsmall muted mt-8">How we rank: a transparent, rule-based score from your answers (recipient, interests, occasion, age fit, budget, preferences) plus popularity from real orders. Your 👍/👎 feedback adjusts future suggestions; you can turn this off in your account.</p>
  <?php else:
      $s = $result['suggestions'];
      ob_start(); ?>
      <?php if (!empty($s['phrases'])): ?>
        <p class="small mt-6 mb-2"><strong>Did you mean:</strong></p>
        <div class="chips" style="justify-content:center"><?php foreach ($s['phrases'] as $ph): ?><a class="chip" href="<?= e(url('/search', ['q' => $ph])) ?>"><?= e(ucfirst($ph)) ?></a><?php endforeach; ?></div>
      <?php endif; ?>
      <?php if (!empty($s['interests'])): ?>
        <p class="small mt-6 mb-2"><strong>Interests with gifts for this person:</strong></p>
        <div class="chips" style="justify-content:center">
          <?php foreach ($s['interests'] as $it): $q = $editQuery; $q['interests'] = [$it['slug']]; unset($q['custom_interest'], $q['strict_interests']); ?>
            <a class="chip" href="<?= e(url('/gift-finder/results', $q)) ?>"><?= e($it['name']) ?> (<?= (int) $it['n'] ?>)</a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <?php $extra = (string) ob_get_clean();
      echo partial('components/empty-state', [
          'icon' => 'sparkles',
          'title' => 'We could not find a perfect match',
          'text' => 'Try a wider budget, fewer interests or a different delivery date. Age-safety rules are never relaxed.',
          'actionUrl' => url('/gift-finder', $editQuery),
          'actionLabel' => 'Adjust my answers',
          'extra' => $extra,
      ]); ?>
      <?php if (!empty($s['popular'])): ?>
        <h2 class="mt-8" style="font-size:1.6rem">Popular gifts right now</h2>
        <?= partial('components/product-grid', ['products' => $s['popular'], 'saved' => $saved]) ?>
      <?php endif; ?>
  <?php endif; ?>
</div>
<div style="height:48px"></div>
