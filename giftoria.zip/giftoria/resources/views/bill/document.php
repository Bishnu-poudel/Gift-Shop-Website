<?php
/**
 * Printable bill (A4). Vars: $order, $items, $shipping, $billing, $seller, $docTitle, $words, $fiscalYear,
 * $audience (customer|guest|admin), $backUrl, $payUrl
 */
use App\Services\OrderStateMachine;

$o = $order;
$inclusive = (int) $o['prices_include_vat'] === 1;
$vatReg = (int) $o['vat_registered'] === 1 && (float) $o['vat_rate'] > 0;
$rate = rtrim(rtrim(number_format((float) $o['vat_rate'], 2), '0'), '.');
$isProforma = $o['status'] === 'pending_payment';
$isCancelled = $o['status'] === 'cancelled';
$buyerAddr = $billing ?: $shipping;
$amt = static fn ($v) => number_format((float) $v, 2);
$fmtAddr = static function (?array $a): string {
    if (!$a) {
        return '';
    }
    $line = trim(($a['street'] ? $a['street'] . ', ' : '') . $a['municipality'] . ($a['ward'] ? '-' . $a['ward'] : ''));
    return $line . ', ' . $a['district'] . ', ' . $a['province'] . ' Province';
};
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e($docTitle . ' ' . $o['bill_number']) ?></title>
<style>
  :root { --ink:#1f1b16; --muted:#6b6258; --line:#ddd2c2; --accent:#b4532a; --paper:#fff; --bg:#f3ece1; }
  * { box-sizing: border-box; }
  body { margin:0; background:var(--bg); color:var(--ink); font: 13px/1.5 "Inter", "Segoe UI", Arial, sans-serif; }
  .toolbar { max-width: 820px; margin: 20px auto 0; display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap; padding: 0 16px; }
  .toolbar a, .toolbar button { font: 600 13px/1 inherit; padding: 11px 18px; border-radius: 999px; border:1px solid var(--ink); background:#fff; color:var(--ink); text-decoration:none; cursor:pointer; }
  .toolbar .primary { background:var(--ink); color:#fff; }
  .toolbar .accent { background:var(--accent); border-color:var(--accent); color:#fff; }
  .sheet { position:relative; max-width: 820px; margin: 16px auto 40px; background:var(--paper); padding: 40px 44px; border-radius: 6px; box-shadow: 0 10px 30px -18px rgba(0,0,0,.35); overflow:hidden; }
  .head { display:flex; justify-content:space-between; gap:24px; align-items:flex-start; border-bottom:2px solid var(--ink); padding-bottom:18px; }
  .brand { display:flex; gap:14px; align-items:flex-start; }
  .brand img { max-height:64px; max-width:160px; object-fit:contain; }
  .brand .mark { width:48px; height:48px; border-radius:50%; background:var(--accent); color:#fff; display:grid; place-items:center; font: 600 22px Georgia, serif; flex:none; }
  .seller h1 { font: 600 20px/1.2 Georgia, "Times New Roman", serif; margin:0 0 4px; }
  .seller p { margin:0; color:var(--muted); font-size:12px; }
  .ids { margin-top:6px !important; color:var(--ink) !important; font-weight:600; }
  .doc { text-align:right; }
  .doc h2 { margin:0; font: 700 18px/1.2 "Inter", Arial, sans-serif; letter-spacing:.08em; text-transform:uppercase; color: var(--accent); }
  .doc .sub { color:var(--muted); font-size:11px; margin-top:2px; }
  .meta { display:grid; grid-template-columns: 1fr 1fr; gap: 18px 32px; margin: 20px 0; }
  .meta h3 { margin:0 0 6px; font: 700 10px/1 "Inter", Arial, sans-serif; letter-spacing:.14em; text-transform:uppercase; color:var(--muted); }
  .meta table td { padding: 1px 0; vertical-align:top; }
  .meta table td:first-child { color:var(--muted); padding-right:12px; white-space:nowrap; }
  table.items { width:100%; border-collapse:collapse; margin-top:8px; }
  table.items th { text-align:left; font-size:10.5px; letter-spacing:.08em; text-transform:uppercase; color:var(--muted); border-bottom:1px solid var(--ink); padding:8px 6px; }
  table.items td { border-bottom:1px solid var(--line); padding:9px 6px; vertical-align:top; }
  .num { text-align:right; white-space:nowrap; font-variant-numeric: tabular-nums; }
  .desc small { color:var(--muted); display:block; }
  .totals { display:flex; justify-content:space-between; gap:24px; margin-top:16px; }
  .words { flex:1; font-size:12px; }
  .words strong { display:block; font-size:10px; letter-spacing:.12em; text-transform:uppercase; color:var(--muted); margin-bottom:4px; }
  table.sum { width: 320px; border-collapse:collapse; }
  table.sum td { padding: 5px 6px; }
  table.sum tr.total td { border-top:2px solid var(--ink); font-weight:700; font-size:15px; padding-top:9px; }
  table.sum tr.sub td { color:var(--muted); font-size:12px; }
  .note { margin-top: 22px; padding: 12px 14px; border-radius: 6px; font-size:12px; }
  .note.warn { background:#f8ecd2; color:#6b4c15; }
  .note.info { background:#f3ece1; color:var(--muted); }
  .foot { display:flex; justify-content:space-between; align-items:flex-end; gap:24px; margin-top: 36px; font-size:11.5px; color:var(--muted); }
  .sign { text-align:center; min-width: 200px; }
  .sign span { display:block; border-top:1px solid var(--ink); padding-top:6px; margin-top: 40px; color:var(--ink); }
  .stamp { position:absolute; top: 46%; left: 50%; transform: translate(-50%,-50%) rotate(-18deg); font: 800 72px/1 Arial, sans-serif; letter-spacing:.1em; color: rgba(162,50,42,.12); border: 8px solid rgba(162,50,42,.12); padding: 6px 22px; pointer-events:none; white-space:nowrap; }
  .stamp.paid { color: rgba(63,107,71,.13); border-color: rgba(63,107,71,.13); }
  @media (max-width: 640px) { .sheet { padding: 22px 18px; } .head, .totals, .foot { flex-direction:column; } .doc { text-align:left; } .meta { grid-template-columns: 1fr; } table.sum { width:100%; } .stamp { font-size: 44px; } }
  @media print {
    body { background:#fff; }
    .toolbar { display:none; }
    .sheet { box-shadow:none; margin:0; max-width:none; padding: 0; border-radius:0; }
    @page { size: A4; margin: 14mm; }
  }
</style>
</head>
<body>
<div class="toolbar">
  <?php if ($backUrl): ?><a href="<?= e($backUrl) ?>">&larr; Back</a><?php endif; ?>
  <?php if ($payUrl && $isProforma): ?><a class="accent" href="<?= e($payUrl) ?>">Proceed to payment</a><?php endif; ?>
  <button class="primary" type="button" onclick="window.print()">Print / Save as PDF</button>
</div>

<main class="sheet">
  <?php if ($isCancelled): ?><div class="stamp">CANCELLED</div><?php elseif ($o['payment_status'] === 'paid'): ?><div class="stamp paid">PAID</div><?php endif; ?>

  <header class="head">
    <div class="brand">
      <?php if (!empty($seller['logo'])): ?>
        <img src="<?= e(image_url($seller['logo'])) ?>" alt="<?= e($seller['name']) ?> logo">
      <?php else: ?>
        <span class="mark" aria-hidden="true"><?= e(mb_strtoupper(mb_substr((string) $seller['name'], 0, 1))) ?></span>
      <?php endif; ?>
      <div class="seller">
        <h1><?= e($seller['legal_name'] ?: $seller['name']) ?></h1>
        <?php if (($seller['legal_name'] ?? '') && $seller['legal_name'] !== $seller['name']): ?><p>Trading as <?= e($seller['name']) ?></p><?php endif; ?>
        <?php if ($seller['address']): ?><p><?= e($seller['address']) ?></p><?php endif; ?>
        <p><?= e(implode(' · ', array_filter([$seller['phone'] ?? '', $seller['email'] ?? '']))) ?></p>
        <p class="ids">
          <?php if (!empty($seller['vat_registered']) && $seller['vat_number']): ?>VAT No: <?= e($seller['vat_number']) ?><?php endif; ?>
          <?php if (!empty($seller['vat_registered']) && $seller['vat_number'] && $seller['pan']): ?> &nbsp;·&nbsp; <?php endif; ?>
          <?php if ($seller['pan']): ?>PAN: <?= e($seller['pan']) ?><?php endif; ?>
          <?php if (!$seller['pan'] && empty($seller['vat_number'])): ?><span style="color:#a2322a">PAN/VAT number not set (Admin › Settings › Billing &amp; tax)</span><?php endif; ?>
        </p>
      </div>
    </div>
    <div class="doc">
      <h2><?= e($docTitle) ?></h2>
      <?php if ($isProforma): ?><div class="sub">Payment pending · not a tax invoice</div><?php endif; ?>
    </div>
  </header>

  <section class="meta">
    <div>
      <h3>Bill details</h3>
      <table>
        <tr><td>Bill no.</td><td><strong><?= e($o['bill_number']) ?></strong></td></tr>
        <tr><td>Bill date</td><td><?= e(local_date($o['bill_issued_at'] ?: $o['created_at'], 'd M Y, g:i A')) ?> (NPT)</td></tr>
        <tr><td>Fiscal year</td><td><?= e($fiscalYear) ?></td></tr>
        <tr><td>Order no.</td><td><?= e($o['order_number']) ?></td></tr>
        <tr><td>Payment</td><td><?= e(strtoupper($o['payment_method'] === 'cod' ? 'Cash on delivery' : $o['payment_method'])) ?> · <?= e(status_label($o['payment_status'])) ?><?= $o['paid_at'] ? ' (' . e(local_date($o['paid_at'], 'd M Y')) . ')' : '' ?></td></tr>
        <?php if ($audience === 'admin'): ?><tr><td>Status</td><td><?= e(OrderStateMachine::ORDER_LABELS[$o['status']] ?? $o['status']) ?></td></tr><?php endif; ?>
      </table>
    </div>
    <div>
      <h3>Billed to</h3>
      <table>
        <tr><td>Name</td><td><strong><?= e($o['buyer_company'] ?: ($buyerAddr['full_name'] ?? $o['customer_name'])) ?></strong></td></tr>
        <?php if ($o['buyer_company']): ?><tr><td>Attn.</td><td><?= e($o['customer_name']) ?></td></tr><?php endif; ?>
        <?php if ($o['buyer_pan']): ?><tr><td>Buyer PAN/VAT</td><td><strong><?= e($o['buyer_pan']) ?></strong></td></tr><?php endif; ?>
        <tr><td>Address</td><td><?= e($fmtAddr($buyerAddr)) ?></td></tr>
        <tr><td>Phone</td><td><?= e($buyerAddr['phone'] ?? $o['phone']) ?></td></tr>
        <tr><td>Email</td><td><?= e($o['email']) ?></td></tr>
        <?php if ($billing && $shipping && $fmtAddr($billing) !== $fmtAddr($shipping)): ?><tr><td>Ship to</td><td><?= e($shipping['full_name']) ?>, <?= e($fmtAddr($shipping)) ?></td></tr><?php endif; ?>
      </table>
    </div>
  </section>

  <table class="items">
    <thead><tr><th style="width:36px">S.N.</th><th>Particulars</th><th class="num">Qty</th><th class="num">Rate (NPR)</th><th class="num">Amount (NPR)</th></tr></thead>
    <tbody>
      <?php foreach ($items as $i => $it): ?>
        <tr>
          <td><?= $i + 1 ?></td>
          <td class="desc"><?= e($it['name']) ?>
            <small><?= e(trim('SKU ' . $it['sku'] . ($it['variant_name'] ? ' · ' . $it['variant_name'] : ''))) ?></small>
            <?php if ($it['personalization']): ?><small>Personalization: “<?= e($it['personalization']) ?>”</small><?php endif; ?>
          </td>
          <td class="num"><?= (int) $it['quantity'] ?></td>
          <td class="num"><?= $amt($it['unit_price']) ?></td>
          <td class="num"><?= $amt($it['line_total']) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if ((float) $o['shipping_total'] > 0): ?><tr><td><?= count($items) + 1 ?></td><td class="desc">Delivery charge</td><td class="num">1</td><td class="num"><?= $amt($o['shipping_total']) ?></td><td class="num"><?= $amt($o['shipping_total']) ?></td></tr><?php endif; ?>
      <?php if ((float) $o['gift_wrap_total'] > 0): ?><tr><td><?= count($items) + ((float) $o['shipping_total'] > 0 ? 2 : 1) ?></td><td class="desc">Gift wrapping<?= $o['gift_message'] ? '<small>Includes a printed gift card</small>' : '' ?></td><td class="num">1</td><td class="num"><?= $amt($o['gift_wrap_total']) ?></td><td class="num"><?= $amt($o['gift_wrap_total']) ?></td></tr><?php endif; ?>
    </tbody>
  </table>

  <div class="totals">
    <div class="words">
      <strong>Amount in words</strong>
      <?= e($words) ?>
      <?php if ($vatReg && $inclusive): ?><p style="margin:10px 0 0;color:#6b6258">Rates are inclusive of VAT @ <?= e($rate) ?>%.</p><?php endif; ?>
    </div>
    <table class="sum">
      <tr><td>Sub total</td><td class="num"><?= $amt((float) $o['subtotal'] + (float) $o['shipping_total'] + (float) $o['gift_wrap_total']) ?></td></tr>
      <?php if ((float) $o['discount_total'] > 0): ?><tr><td>Discount<?= $o['coupon_code'] ? ' (' . e($o['coupon_code']) . ')' : '' ?></td><td class="num">−<?= $amt($o['discount_total']) ?></td></tr><?php endif; ?>
      <?php if ($vatReg && !$inclusive): ?>
        <tr><td>Taxable amount</td><td class="num"><?= $amt($o['taxable_amount']) ?></td></tr>
        <tr><td>VAT @ <?= e($rate) ?>%</td><td class="num"><?= $amt($o['vat_amount']) ?></td></tr>
      <?php endif; ?>
      <tr class="total"><td>Grand total</td><td class="num">NPR <?= $amt($o['grand_total']) ?></td></tr>
      <?php if ($vatReg && $inclusive): ?>
        <tr class="sub"><td>Taxable amount</td><td class="num"><?= $amt($o['taxable_amount']) ?></td></tr>
        <tr class="sub"><td>VAT @ <?= e($rate) ?>% (included)</td><td class="num"><?= $amt($o['vat_amount']) ?></td></tr>
      <?php endif; ?>
      <?php if (!$vatReg): ?><tr class="sub"><td colspan="2">Seller is not VAT-registered; no VAT charged.</td></tr><?php endif; ?>
      <?php if ((float) $o['refunded_total'] > 0): ?><tr class="sub"><td>Refunded</td><td class="num">−<?= $amt($o['refunded_total']) ?></td></tr><?php endif; ?>
    </table>
  </div>

  <?php if ($isProforma): ?>
    <div class="note warn"><strong>Payment pending.</strong> This proforma invoice confirms the amount payable for order <?= e($o['order_number']) ?>. It becomes your tax invoice automatically once payment is verified<?= $o['expires_at'] ? ' (please pay before ' . e(local_date($o['expires_at'], 'g:i A, d M')) . ' NPT)' : '' ?>.</div>
  <?php elseif ($isCancelled): ?>
    <div class="note warn">This bill has been cancelled together with the order. It is retained for record-keeping and is not payable.</div>
  <?php endif; ?>
  <?php if ($o['gift_message'] && $audience !== 'guest'): ?><div class="note info"><strong>Gift message:</strong> “<?= e($o['gift_message']) ?>” (printed on the card; prices are never included in the gift parcel)</div><?php endif; ?>

  <footer class="foot">
    <div><?= e($seller['footer'] ?? '') ?><br>This is a computer-generated bill. Prices in Nepalese Rupees (NPR).</div>
    <div class="sign"><span>Authorised signature</span></div>
  </footer>
</main>
</body>
</html>
