<?php /** Email wrapper. Vars: $subject, $body (trusted, rendered template HTML), $unsubscribeUrl */ $store = (string) setting('store_name', config('app.name')); ?><!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= e($subject) ?></title></head>
<body style="margin:0;padding:0;background:#f3ece1;font-family:Inter,Segoe UI,Helvetica,Arial,sans-serif;color:#1f1b16">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f3ece1;padding:32px 12px">
  <tr><td align="center">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:580px;background:#fffdf9;border-radius:18px;overflow:hidden;border:1px solid #e4d9c8">
      <tr><td style="padding:28px 32px;border-bottom:1px solid #efe6d8">
        <?php $logo = (string) setting('store_logo', ''); if ($logo !== '' && setting('show_logo_in_header', true)): ?><img src="<?= e(image_url($logo)) ?>" alt="<?= e($store) ?>" style="max-height:48px;max-width:200px"><?php else: ?><span style="display:inline-block;width:26px;height:26px;border-radius:50%;background:#b4532a;vertical-align:middle"></span>
        <span style="font-family:Georgia,serif;font-size:22px;vertical-align:middle;margin-left:8px"><?= e($store) ?></span><?php endif; ?>
      </td></tr>
      <tr><td style="padding:32px;font-size:15px;line-height:1.6"><?= $body ?></td></tr>
      <tr><td style="padding:20px 32px;background:#faf6ef;font-size:12px;color:#7a6f63;line-height:1.5">
        <?= e($store) ?> · <?= e((string) setting('store_address')) ?><br>
        Questions? Reply to this email or visit <a href="<?= e(url('/contact')) ?>" style="color:#b4532a">our help page</a>.
        <?php if (!empty($unsubscribeUrl)): ?><br><a href="<?= e($unsubscribeUrl) ?>" style="color:#7a6f63">Unsubscribe</a><?php endif; ?>
      </td></tr>
    </table>
  </td></tr>
</table>
</body>
</html>
