<div class="container error-page">
  <div class="code">404</div>
  <h1 style="font-size:2rem">This page wandered off</h1>
  <p class="muted"><?= e($message ?? 'We could not find the page you were looking for.') ?></p>
  <form action="<?= e(url('/search')) ?>" method="get" class="input-group" style="max-width:440px;margin:24px auto">
    <label for="err-q" class="sr-only">Search</label>
    <input id="err-q" class="input" type="search" name="q" placeholder="Search for a gift">
    <button class="btn btn-primary" type="submit">Search</button>
  </form>
  <div class="row" style="justify-content:center">
    <a class="btn btn-outline" href="<?= e(url('/')) ?>">Back home</a>
    <a class="btn btn-accent" href="<?= e(url('/gift-finder')) ?>"><?= icon('sparkles', 'icon-sm') ?> Try the Gift Finder</a>
  </div>
</div>
