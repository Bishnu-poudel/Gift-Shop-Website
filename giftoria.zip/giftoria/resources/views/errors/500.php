<div class="container error-page">
  <div class="code">500</div>
  <h1 style="font-size:2rem">Something went wrong</h1>
  <p class="muted"><?= e($message ?? 'Please try again in a moment.') ?></p>
  <a class="btn btn-primary mt-4" href="<?= e(url('/')) ?>">Back home</a>
</div>
