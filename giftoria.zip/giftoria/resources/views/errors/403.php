<div class="<?= isset($status) && str_contains((string) (request()?->path ?? ''), '/' . config('app.admin_path')) ? 'auth-card' : 'container error-page' ?>" style="text-align:center">
  <div class="code" style="font-family:var(--font-display);font-size:4rem;color:var(--terracotta)">403</div>
  <h1 style="font-size:1.8rem">Access denied</h1>
  <p class="muted"><?= e($message ?? 'You do not have permission to access this page.') ?></p>
  <a class="btn btn-primary mt-4" href="<?= e(str_contains((string) (request()?->path ?? ''), '/' . config('app.admin_path')) ? admin_url() : url('/')) ?>">Go back</a>
</div>
