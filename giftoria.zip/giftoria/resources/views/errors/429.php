<div class="container error-page">
  <div class="code">429</div>
  <h1 style="font-size:2rem">Slow down a little</h1>
  <p class="muted"><?= e($message ?? 'Too many attempts. Please wait and try again.') ?></p>
  <a class="btn btn-primary mt-4" href="javascript:history.back()">Go back</a>
</div>
