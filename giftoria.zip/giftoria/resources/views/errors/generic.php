<div class="container error-page">
  <div class="code"><?= (int) ($status ?? 400) ?></div>
  <h1 style="font-size:2rem"><?= e($message ?? 'Something went wrong') ?></h1>
  <a class="btn btn-primary mt-4" href="<?= e(url('/')) ?>">Back home</a>
</div>
