<?php
/**
 * Storefront layout.
 * Optional vars: $title, $metaDescription, $canonical, $ogImage, $ogType, $jsonLd (array|list), $bodyClass, $noindex
 */
use App\Services\CartService;
use App\Services\NavigationService;

$storeName = (string) setting('store_name', config('app.name'));
$pageTitle = isset($title) && $title ? $title . ' · ' . $storeName : $storeName . ' — ' . config('app.tagline');
$metaDescription = $metaDescription ?? 'Original, thoughtful gifts for every person and occasion — curated in Nepal, delivered with care. Pay with eSewa, Khalti or cash on delivery.';
$canonical = $canonical ?? url(request()?->path ?? '/');
$nav = NavigationService::storefront();
$cartCount = 0;
try { $cartCount = (new CartService())->count(); } catch (\Throwable) {}
$customer = customer();
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?></title>
<meta name="description" content="<?= e(str_limit($metaDescription, 160)) ?>">
<link rel="canonical" href="<?= e($canonical) ?>">
<?php if (!empty($noindex)): ?><meta name="robots" content="noindex, nofollow"><?php endif; ?>
<meta property="og:site_name" content="<?= e($storeName) ?>">
<meta property="og:title" content="<?= e($title ?? $storeName) ?>">
<meta property="og:description" content="<?= e(str_limit($metaDescription, 200)) ?>">
<meta property="og:type" content="<?= e($ogType ?? 'website') ?>">
<meta property="og:url" content="<?= e($canonical) ?>">
<?php if (!empty($ogImage)): ?><meta property="og:image" content="<?= e($ogImage) ?>"><?php endif; ?>
<meta name="twitter:card" content="summary_large_image">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<meta name="theme-color" content="#faf6ef">
<link rel="icon" href="<?= e(asset('assets/images/favicon.svg')) ?>" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=Inter:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="<?= e(asset('assets/css/app.css')) ?>">
<?php foreach ((array) ($jsonLd ?? []) as $ld): ?>
<script type="application/ld+json"><?= json_encode($ld, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?></script>
<?php endforeach; ?>
</head>
<body class="<?= e($bodyClass ?? '') ?>" data-base="<?= e(url('/')) ?>">
<a class="skip-link" href="#main">Skip to content</a>

<?php if (setting('announcement_enabled', true) && setting('announcement_text')): ?>
<div class="announcement" role="region" aria-label="Announcement"><?= e(setting('announcement_text')) ?></div>
<?php endif; ?>

<header class="site-header">
  <div class="container header-inner">
    <button class="icon-btn menu-toggle" type="button" data-drawer-open aria-label="Open menu" aria-controls="mobile-drawer"><?= icon('menu') ?></button>
    <a class="brand" href="<?= e(url('/')) ?>" aria-label="<?= e($storeName) ?> home">
      <?= brand_html() ?>
    </a>
    <form class="header-search" action="<?= e(url('/search')) ?>" method="get" role="search" data-live-search>
      <?= icon('search') ?>
      <label for="site-search" class="sr-only">Search gifts</label>
      <input id="site-search" class="input" type="search" name="q" value="<?= e(request()?->query('q', '') ?? '') ?>" placeholder="Try “gifts for baby girl under 2000”" autocomplete="off" aria-autocomplete="list" aria-controls="suggest-panel">
      <div class="suggest-panel" id="suggest-panel" role="listbox"></div>
    </form>
    <div class="header-actions">
      <a class="icon-btn" href="<?= e(url($customer ? '/account' : '/login')) ?>" aria-label="<?= $customer ? 'My account' : 'Sign in' ?>"><?= icon('user') ?></a>
      <a class="icon-btn" href="<?= e(url('/account/wishlist')) ?>" aria-label="Wishlist"><?= icon('heart') ?></a>
      <a class="icon-btn" href="<?= e(url('/cart')) ?>" aria-label="Shopping bag, <?= (int) $cartCount ?> items">
        <?= icon('bag') ?><span class="count-badge" data-cart-count data-count="<?= (int) $cartCount ?>"><?= (int) $cartCount ?></span>
      </a>
    </div>
  </div>
  <nav class="main-nav" aria-label="Main">
    <div class="container">
      <ul>
        <li class="nav-item"><a class="nav-link <?= active('/shop') ?>" href="<?= e(url('/shop')) ?>">Shop All Gifts</a></li>
        <li class="nav-item" data-mega>
          <button class="nav-link" type="button" aria-expanded="false">By Recipient <?= icon('chevron-down') ?></button>
          <div class="mega"><div class="mega-inner">
            <?php foreach ($nav['recipients'] as $group => $items): ?>
              <div><h4><?= e($group) ?></h4><ul>
                <?php foreach ($items as $r): ?><li><a href="<?= e(url('/gifts/for/' . $r['slug'])) ?>"><?= e($r['name']) ?></a></li><?php endforeach; ?>
              </ul></div>
            <?php endforeach; ?>
            <a class="mega-feature" href="<?= e(url('/gift-finder')) ?>">
              <span class="eyebrow">Not sure?</span><h3>Let the Gift Finder choose</h3><p>Answer a few questions and get ideas matched to age, interests and budget.</p>
              <span class="link-arrow">Start now <?= icon('arrow-right') ?></span>
            </a>
          </div></div>
        </li>
        <li class="nav-item" data-mega>
          <button class="nav-link" type="button" aria-expanded="false">By Occasion <?= icon('chevron-down') ?></button>
          <div class="mega"><div class="mega-inner">
            <?php foreach (array_chunk($nav['occasions'], (int) max(1, ceil(count($nav['occasions']) / 3))) as $i => $chunk): ?>
              <div><h4><?= ['Celebrations', 'Milestones', 'Seasons & more'][$i] ?? 'More' ?></h4><ul>
                <?php foreach ($chunk as $o): ?><li><a href="<?= e(url('/gifts/occasion/' . $o['slug'])) ?>"><?= e($o['name']) ?></a></li><?php endforeach; ?>
              </ul></div>
            <?php endforeach; ?>
            <a class="mega-feature" href="<?= e(url('/gifts/occasion/tihar')) ?>">
              <span class="eyebrow">In season</span><h3>Festival gifting</h3><p>Dashain and Tihar hampers, diyos, sweets boxes and family keepsakes.</p>
              <span class="link-arrow">Explore <?= icon('arrow-right') ?></span>
            </a>
          </div></div>
        </li>
        <li class="nav-item" data-mega>
          <button class="nav-link" type="button" aria-expanded="false">By Interest <?= icon('chevron-down') ?></button>
          <div class="mega"><div class="mega-inner">
            <?php foreach (array_chunk($nav['interests'], (int) max(1, ceil(count($nav['interests']) / 3))) as $chunk): ?>
              <div><ul>
                <?php foreach ($chunk as $it): ?><li><a href="<?= e(url('/gifts/interest/' . $it['slug'])) ?>"><?= e($it['name']) ?></a></li><?php endforeach; ?>
              </ul></div>
            <?php endforeach; ?>
            <a class="mega-feature" href="<?= e(url('/gifts/interest/handmade-products')) ?>">
              <span class="eyebrow">Made by hand</span><h3>Nepali makers</h3><p>Lokta paper, dhaka weaves, felt and ceramics from independent studios.</p>
              <span class="link-arrow">Meet the makers <?= icon('arrow-right') ?></span>
            </a>
          </div></div>
        </li>
        <li class="nav-item" data-mega>
          <button class="nav-link" type="button" aria-expanded="false">By Category <?= icon('chevron-down') ?></button>
          <div class="mega"><div class="mega-inner">
            <?php foreach (array_slice($nav['categories'], 0, 3) as $cat): ?>
              <div><h4><a href="<?= e(url('/category/' . $cat['slug'])) ?>"><?= e($cat['name']) ?></a></h4><ul>
                <?php foreach ($cat['children'] as $child): ?><li><a href="<?= e(url('/category/' . $child['slug'])) ?>"><?= e($child['name']) ?></a></li><?php endforeach; ?>
              </ul></div>
            <?php endforeach; ?>
            <div><h4>More</h4><ul>
              <?php foreach (array_slice($nav['categories'], 3) as $cat): ?><li><a href="<?= e(url('/category/' . $cat['slug'])) ?>"><?= e($cat['name']) ?></a></li><?php endforeach; ?>
            </ul></div>
          </div></div>
        </li>
        <li class="nav-item"><a class="nav-link <?= active('/personalized-gifts') ?>" href="<?= e(url('/personalized-gifts')) ?>">Personalized</a></li>
        <li class="nav-item"><a class="nav-link is-accent <?= active('/gift-finder') ?>" href="<?= e(url('/gift-finder')) ?>"><?= icon('sparkles', 'icon-sm') ?> Gift Finder</a></li>
        <li class="nav-item"><a class="nav-link <?= active('/bestsellers') ?>" href="<?= e(url('/bestsellers')) ?>">Bestsellers</a></li>
        <li class="nav-item"><a class="nav-link <?= active('/new-arrivals') ?>" href="<?= e(url('/new-arrivals')) ?>">New Arrivals</a></li>
      </ul>
    </div>
  </nav>
</header>

<div class="drawer-backdrop" data-drawer-close></div>
<aside class="drawer" id="mobile-drawer" aria-label="Mobile menu">
  <div class="drawer-head">
    <a class="brand" href="<?= e(url('/')) ?>"><?= brand_html() ?></a>
    <button class="icon-btn" type="button" data-drawer-close aria-label="Close menu"><?= icon('x') ?></button>
  </div>
  <ul class="drawer-nav">
    <li><a href="<?= e(url('/gift-finder')) ?>"><span><?= icon('sparkles', 'icon-sm') ?> Gift Finder</span></a></li>
    <li><a href="<?= e(url('/shop')) ?>">Shop All Gifts</a></li>
    <li><details><summary>By Recipient <?= icon('chevron-down') ?></summary><ul>
      <?php foreach ($nav['recipients'] as $items): foreach ($items as $r): ?><li><a href="<?= e(url('/gifts/for/' . $r['slug'])) ?>"><?= e($r['name']) ?></a></li><?php endforeach; endforeach; ?>
    </ul></details></li>
    <li><details><summary>By Occasion <?= icon('chevron-down') ?></summary><ul>
      <?php foreach ($nav['occasions'] as $o): ?><li><a href="<?= e(url('/gifts/occasion/' . $o['slug'])) ?>"><?= e($o['name']) ?></a></li><?php endforeach; ?>
    </ul></details></li>
    <li><details><summary>By Interest <?= icon('chevron-down') ?></summary><ul>
      <?php foreach ($nav['interests'] as $it): ?><li><a href="<?= e(url('/gifts/interest/' . $it['slug'])) ?>"><?= e($it['name']) ?></a></li><?php endforeach; ?>
    </ul></details></li>
    <li><details><summary>By Category <?= icon('chevron-down') ?></summary><ul>
      <?php foreach ($nav['categories'] as $cat): ?><li><a href="<?= e(url('/category/' . $cat['slug'])) ?>"><?= e($cat['name']) ?></a></li><?php endforeach; ?>
    </ul></details></li>
    <li><a href="<?= e(url('/personalized-gifts')) ?>">Personalized Gifts</a></li>
    <li><a href="<?= e(url('/bestsellers')) ?>">Bestsellers</a></li>
    <li><a href="<?= e(url('/new-arrivals')) ?>">New Arrivals</a></li>
  </ul>
  <div class="drawer-foot">
    <?php if ($customer): ?>
      <a class="btn btn-outline btn-block" href="<?= e(url('/account')) ?>">My account</a>
    <?php else: ?>
      <a class="btn btn-primary btn-block" href="<?= e(url('/login')) ?>">Sign in</a>
      <a class="btn btn-light btn-block" href="<?= e(url('/register')) ?>">Create account</a>
    <?php endif; ?>
  </div>
</aside>

<main id="main" tabindex="-1">
  <?= partial('components/flash') ?>
  <?= $content ?>
</main>

<footer class="site-footer">
  <div class="container">
    <div class="footer-top">
      <div>
        <a class="brand" href="<?= e(url('/')) ?>"><?= brand_html() ?></a>
        <p class="small mt-4" style="max-width:34ch">Original gifts chosen with care, from independent makers in Nepal and around the world.</p>
        <form class="footer-news" action="<?= e(url('/newsletter')) ?>" method="post">
          <?= csrf_field() ?><input type="hidden" name="source" value="footer">
          <label class="sr-only" for="footer-email">Email address</label>
          <input id="footer-email" class="input" type="email" name="email" placeholder="Your email" required>
          <button class="btn btn-accent" type="submit">Subscribe</button>
        </form>
        <p class="xsmall mt-2" style="opacity:.7">Occasional emails about new gifts. Unsubscribe anytime.</p>
        <div class="socials">
          <?php if (setting('social_facebook')): ?><a href="<?= e(setting('social_facebook')) ?>" rel="noopener" target="_blank" aria-label="Facebook"><?= icon('facebook', 'icon-sm') ?></a><?php endif; ?>
          <?php if (setting('social_instagram')): ?><a href="<?= e(setting('social_instagram')) ?>" rel="noopener" target="_blank" aria-label="Instagram"><?= icon('instagram', 'icon-sm') ?></a><?php endif; ?>
        </div>
      </div>
      <div><h4>Shop</h4><ul>
        <li><a href="<?= e(url('/shop')) ?>">All gifts</a></li>
        <li><a href="<?= e(url('/gift-finder')) ?>">Gift Finder</a></li>
        <li><a href="<?= e(url('/bestsellers')) ?>">Bestsellers</a></li>
        <li><a href="<?= e(url('/new-arrivals')) ?>">New arrivals</a></li>
        <li><a href="<?= e(url('/personalized-gifts')) ?>">Personalized gifts</a></li>
      </ul></div>
      <div><h4>Help</h4><ul>
        <li><a href="<?= e(url('/contact')) ?>">Contact us</a></li>
        <li><a href="<?= e(url('/pages/shipping')) ?>">Delivery information</a></li>
        <li><a href="<?= e(url('/pages/returns')) ?>">Returns &amp; refunds</a></li>
        <li><a href="<?= e(url('/pages/faq')) ?>">FAQ</a></li>
        <li><a href="<?= e(url('/account/orders')) ?>">Track an order</a></li>
      </ul></div>
      <div><h4>Company</h4><ul>
        <li><a href="<?= e(url('/pages/about')) ?>">Our story</a></li>
        <li><a href="<?= e(url('/pages/makers')) ?>">Our makers</a></li>
        <li><a href="<?= e(url('/pages/corporate-gifting')) ?>">Corporate gifting</a></li>
      </ul></div>
      <div><h4>Visit</h4><ul>
        <li><?= e(setting('store_address')) ?></li>
        <li><a href="tel:<?= e(preg_replace('/[^\d+]/', '', (string) setting('store_phone'))) ?>"><?= e(setting('store_phone')) ?></a></li>
        <li><a href="mailto:<?= e(setting('store_email')) ?>"><?= e(setting('store_email')) ?></a></li>
        <li class="xsmall" style="opacity:.75">Sun–Fri, 10am–6pm NPT</li>
      </ul></div>
    </div>
    <div class="footer-bottom">
      <span>© <?= gmdate('Y') ?> <?= e($storeName) ?>. Prices in NPR, inclusive of applicable taxes.</span>
      <span class="row" style="gap:12px">
        <a href="<?= e(url('/pages/privacy')) ?>">Privacy</a>
        <a href="<?= e(url('/pages/terms')) ?>">Terms</a>
        <span class="pay-badges"><span class="pay-logo esewa" style="width:42px;height:24px">eSewa</span><span class="pay-logo khalti" style="width:42px;height:24px">Khalti</span><span class="pay-logo cod" style="width:42px;height:24px">COD</span></span>
      </span>
    </div>
  </div>
</footer>

<div class="toast-region" aria-live="polite" aria-atomic="true" data-toasts></div>
<script src="<?= e(asset('assets/js/app.js')) ?>" defer></script>
<?php if (!empty($scripts)): foreach ((array) $scripts as $s): ?><script src="<?= e(asset($s)) ?>" defer></script><?php endforeach; endif; ?>
</body>
</html>
