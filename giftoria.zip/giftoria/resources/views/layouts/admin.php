<?php
/**
 * Admin layout. Vars: $title, $content, optional $scripts (list of asset paths), $useCharts (bool).
 * The sidebar only lists modules the staff member has permission for (server-side checks still apply).
 */
use App\Services\NavigationService;

$staffUser = staff();
$menu = NavigationService::adminMenu();
$adminBase = '/' . trim((string) config('app.admin_path', 'admin'), '/');
$current = request()?->path ?? '';
$storeName = (string) setting('store_name', config('app.name'));
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e(($title ?? 'Admin') . ' · ' . $storeName . ' Admin') ?></title>
<link rel="icon" href="<?= e(asset('assets/images/favicon.svg')) ?>" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500&family=Inter:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="<?= e(asset('assets/css/app.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('assets/css/admin.css')) ?>">
</head>
<body class="admin" data-base="<?= e(url('/')) ?>">
<div class="admin-shell">
  <div class="drawer-backdrop" data-drawer-close></div>
  <aside class="admin-sidebar" aria-label="Admin navigation">
    <a class="admin-brand" href="<?= e(admin_url()) ?>"><?= brand_html() ?><small>Admin</small></a>
    <nav class="admin-nav">
      <?php foreach ($menu as $section => $items): ?>
        <div class="nav-section"><?= e($section) ?></div>
        <?php foreach ($items as $item):
            $href = $adminBase . ($item['path'] !== '' ? '/' . $item['path'] : '');
            $first = explode('/', $item['path'])[0];
            $isActive = $item['path'] === '' ? $current === $adminBase : str_starts_with($current, $adminBase . '/' . $first);
        ?>
          <a href="<?= e(url($href)) ?>" class="<?= $isActive ? 'is-active' : '' ?>"><?= icon($item['icon']) ?><?= e($item['label']) ?></a>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </nav>
    <div class="admin-sidebar-foot">
      <a href="<?= e(url('/')) ?>" target="_blank" rel="noopener" class="row" style="gap:6px"><?= icon('external', 'icon-sm') ?> View storefront</a>
    </div>
  </aside>
  <div class="admin-main">
    <header class="admin-topbar">
      <button class="icon-btn admin-menu-toggle" type="button" data-drawer-open aria-label="Open navigation"><?= icon('menu') ?></button>
      <span class="crumb"><?= e($title ?? '') ?></span>
      <?php if ($staffUser): ?>
      <div class="user-chip">
        <span class="avatar"><?= e(mb_strtoupper(mb_substr($staffUser['name'], 0, 1))) ?></span>
        <span><?= e($staffUser['name']) ?></span>
        <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('password')) ?>">Password</a>
        <form method="post" action="<?= e(admin_url('logout')) ?>" class="inline-form"><?= csrf_field() ?><button class="btn btn-light btn-sm" type="submit"><?= icon('log-out', 'icon-sm') ?> Sign out</button></form>
      </div>
      <?php endif; ?>
    </header>
    <main class="admin-content" id="main">
      <?= partial('components/flash') ?>
      <?= $content ?>
    </main>
  </div>
</div>
<div class="toast-region" aria-live="polite" data-toasts></div>
<?php if (!empty($useCharts)): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js" defer></script>
<?php endif; ?>
<script src="<?= e(asset('assets/js/app.js')) ?>" defer></script>
<script src="<?= e(asset('assets/js/admin.js')) ?>" defer></script>
<?php foreach ((array) ($scripts ?? []) as $s): ?><script src="<?= e(asset($s)) ?>" defer></script><?php endforeach; ?>
</body>
</html>
