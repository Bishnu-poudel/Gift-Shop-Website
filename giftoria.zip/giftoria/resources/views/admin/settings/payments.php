<?php /** Vars: $gateways, $simulator, $appEnv, $tab */ ?>
<?= partial('admin/settings/_tabs', ['tab' => $tab]) ?>

<div class="alert alert-info"><?= icon('lock') ?><div>Payment credentials are read from environment variables (<code>.env</code>) and are never stored in the database or shown here. This panel is read-only.</div></div>

<?php if ($simulator): ?>
  <div class="alert alert-warning"><?= icon('alert') ?><div><strong>Payment simulator is ON.</strong> Gateway verification uses a fake HTTP client (local development only; it is always off when APP_ENV=production).</div></div>
<?php endif; ?>

<div class="card card-flush">
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead><tr><th>Method</th><th>Status</th><th>Environment</th><th>Credentials</th><th>Notes</th></tr></thead>
    <tbody>
    <?php foreach ($gateways as $g): ?>
      <tr>
        <td><strong><?= e($g['name']) ?></strong></td>
        <td><span class="status status-<?= $g['enabled'] ? 'active' : 'inactive' ?>"><?= $g['enabled'] ? 'Enabled' : 'Disabled' ?></span></td>
        <td>
          <?php if ($g['environment'] === null): ?>
            <span class="muted">—</span>
          <?php else: ?>
            <span class="status status-<?= $g['environment'] === 'production' ? 'live' : 'draft' ?>"><?= $g['environment'] === 'production' ? 'Production' : 'Test / sandbox' ?></span>
          <?php endif; ?>
        </td>
        <td>
          <?php if (!$g['checks']): ?>
            <span class="muted">Not required</span>
          <?php else: ?>
            <?php foreach ($g['checks'] as $label => $ok): ?>
              <div class="small"><?= e($label) ?>: <span class="status status-<?= $ok ? 'completed' : 'failed' ?>"><?= $ok ? 'Configured' : 'Missing' ?></span></div>
            <?php endforeach; ?>
          <?php endif; ?>
        </td>
        <td class="small muted"><?= e($g['note'] ?? '') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>
<p class="muted small">Application environment: <code><?= e($appEnv) ?></code>. To change gateways, edit <code>ESEWA_*</code>, <code>KHALTI_*</code> and <code>COD_ENABLED</code> in the server's <code>.env</code> file.</p>
