<?php
/** Vars: $zone (null = create), $selected, $provinces, $taken (district => other zone name), $tab */
$editing = $zone !== null;
$action = $editing ? admin_url('settings/zones/' . (int) $zone['id']) : admin_url('settings/zones');
$hasOld = old('name', null) !== null;
$oldDistricts = old('districts', null);
$sel = is_array($oldDistricts) ? array_map('strval', $oldDistricts) : $selected;
$val = static fn (string $k, $default = '') => old($k, $zone[$k] ?? $default);
$flag = static function (string $k, bool $default) use ($hasOld, $zone): bool {
    if ($hasOld) {
        return (bool) old($k, false);
    }
    return $zone !== null ? (int) $zone[$k] === 1 : $default;
};
?>
<?= partial('admin/settings/_tabs', ['tab' => $tab]) ?>

<form method="post" action="<?= e($action) ?>" data-loading novalidate>
  <?= csrf_field() ?>
  <div class="admin-grid admin-grid-3-1">
    <div class="card">
      <div class="card-head">
        <h2><?= $editing ? 'Edit zone: ' . e($zone['name']) : 'New delivery zone' ?></h2>
        <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('settings/zones')) ?>">Back to zones</a>
      </div>
      <div class="field">
        <label for="name">Zone name</label>
        <input class="input<?= errors('name') ? ' has-error' : '' ?>" id="name" name="name" value="<?= e($val('name')) ?>" required maxlength="80" placeholder="e.g. Kathmandu Valley">
        <?= field_error('name') ?>
      </div>

      <div class="field">
        <label>Districts</label>
        <?= field_error('districts') ?>
        <p class="hint mb-4">Districts already used by another zone are disabled (a district can belong to one zone only).</p>
        <?php foreach ($provinces as $province => $districts): ?>
          <fieldset class="perm-group">
            <h4><?= e($province) ?> Province</h4>
            <div class="checkbox-grid">
              <?php foreach ($districts as $d):
                  $usedBy = $taken[$d] ?? null;
                  $isSel = in_array($d, $sel, true);
              ?>
                <label class="check" style="<?= $usedBy && !$isSel ? 'opacity:.5' : '' ?>" <?= $usedBy ? 'title="Used by ' . e($usedBy) . '"' : '' ?>>
                  <input type="checkbox" name="districts[]" value="<?= e($d) ?>" <?= $isSel ? 'checked' : '' ?> <?= $usedBy && !$isSel ? 'disabled' : '' ?>>
                  <span><?= e($d) ?><?php if ($usedBy && !$isSel): ?><br><span class="muted" style="font-size:.7rem"><?= e($usedBy) ?></span><?php endif; ?></span>
                </label>
              <?php endforeach; ?>
            </div>
          </fieldset>
        <?php endforeach; ?>
      </div>
    </div>

    <div>
      <div class="card">
        <div class="card-head"><h2>Rates &amp; delivery</h2></div>
        <div class="field">
          <label for="rate">Shipping rate (NPR)</label>
          <input class="input<?= errors('rate') ? ' has-error' : '' ?>" type="number" step="0.01" min="0" id="rate" name="rate" value="<?= e($val('rate', '0')) ?>" required>
          <?= field_error('rate') ?>
        </div>
        <div class="field">
          <label for="free_shipping_threshold">Free shipping above (NPR)</label>
          <input class="input<?= errors('free_shipping_threshold') ? ' has-error' : '' ?>" type="number" step="0.01" min="0" id="free_shipping_threshold" name="free_shipping_threshold" value="<?= e($val('free_shipping_threshold')) ?>" placeholder="No free shipping">
          <p class="hint">Leave empty for no free-shipping threshold.</p>
          <?= field_error('free_shipping_threshold') ?>
        </div>
        <div class="form-grid">
          <div class="field">
            <label for="est_days_min">Min days</label>
            <input class="input<?= errors('est_days_min') ? ' has-error' : '' ?>" type="number" min="0" max="60" id="est_days_min" name="est_days_min" value="<?= e($val('est_days_min', '1')) ?>" required>
            <?= field_error('est_days_min') ?>
          </div>
          <div class="field">
            <label for="est_days_max">Max days</label>
            <input class="input<?= errors('est_days_max') ? ' has-error' : '' ?>" type="number" min="0" max="60" id="est_days_max" name="est_days_max" value="<?= e($val('est_days_max', '3')) ?>" required>
            <?= field_error('est_days_max') ?>
          </div>
        </div>
        <p class="hint">Business days; Saturdays are skipped in estimates.</p>
        <div class="field">
          <label for="sort_order">Sort order</label>
          <input class="input<?= errors('sort_order') ? ' has-error' : '' ?>" type="number" id="sort_order" name="sort_order" value="<?= e($val('sort_order', '0')) ?>">
          <?= field_error('sort_order') ?>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h2>Options</h2></div>
        <div class="stack">
          <label class="check"><input type="checkbox" name="is_active" value="1" <?= $flag('is_active', true) ? 'checked' : '' ?>> <span>Active</span></label>
          <label class="check"><input type="checkbox" name="cod_available" value="1" <?= $flag('cod_available', true) ? 'checked' : '' ?>> <span>Cash on delivery available</span></label>
          <label class="check"><input type="checkbox" name="is_valley" value="1" <?= $flag('is_valley', false) ? 'checked' : '' ?>> <span>Kathmandu Valley zone (enables valley-only products)</span></label>
          <label class="check"><input type="checkbox" name="is_default" value="1" <?= $flag('is_default', false) ? 'checked' : '' ?>> <span>Default zone for unlisted districts (only one zone can be default)</span></label>
          <?= field_error('is_default') ?>
        </div>
      </div>
    </div>
  </div>

  <div class="form-actions">
    <a class="btn btn-light" href="<?= e(admin_url('settings/zones')) ?>">Cancel</a>
    <button class="btn btn-primary" type="submit"><?= $editing ? 'Save zone' : 'Create zone' ?></button>
  </div>
</form>
