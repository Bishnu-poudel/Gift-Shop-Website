<?php /** Vars: $zones, $unassigned, $hasDefault, $tab */ ?>
<?= partial('admin/settings/_tabs', ['tab' => $tab]) ?>

<div class="row-between mb-4">
  <p class="muted small mb-0">A customer's district is matched to its zone; districts not listed in any zone use the default zone.</p>
  <a class="btn btn-primary btn-sm" href="<?= e(admin_url('settings/zones/create')) ?>"><?= icon('plus', 'icon-sm') ?> New zone</a>
</div>

<?php if (!$hasDefault): ?>
  <div class="alert alert-warning"><?= icon('alert') ?><div>No active default zone. Customers in unlisted districts will not get a shipping quote or delivery estimate.</div></div>
<?php endif; ?>

<div class="card card-flush">
  <?php if (!$zones): ?>
    <div style="padding:var(--s-8)"><?= partial('components/empty-state', ['icon' => 'truck', 'title' => 'No delivery zones yet', 'text' => 'Create a zone to set shipping rates and delivery estimates.']) ?></div>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead><tr><th>Zone</th><th>Districts</th><th class="num">Rate</th><th class="num">Free above</th><th>Estimate</th><th>COD</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($zones as $z):
        $list = array_values(array_filter(array_map('trim', explode(',', (string) $z['districts']))));
    ?>
      <tr>
        <td>
          <strong><?= e($z['name']) ?></strong>
          <?php if ((int) $z['is_default'] === 1): ?> <span class="badge badge-info">Default</span><?php endif; ?>
          <?php if ((int) $z['is_valley'] === 1): ?> <span class="badge">Valley</span><?php endif; ?>
          <div class="muted small">Sort <?= (int) $z['sort_order'] ?></div>
        </td>
        <td class="small"><?= $list ? e(str_limit(implode(', ', $list), 90)) . ' <span class="muted">(' . count($list) . ')</span>' : '<span class="muted">All other districts</span>' ?></td>
        <td class="num"><?= e(money($z['rate'])) ?></td>
        <td class="num"><?= $z['free_shipping_threshold'] !== null ? e(money($z['free_shipping_threshold'])) : '<span class="muted">—</span>' ?></td>
        <td><?= (int) $z['est_days_min'] === (int) $z['est_days_max'] ? (int) $z['est_days_min'] : (int) $z['est_days_min'] . '–' . (int) $z['est_days_max'] ?> business days</td>
        <td><?= (int) $z['cod_available'] === 1 ? 'Yes' : 'No' ?></td>
        <td><span class="status status-<?= (int) $z['is_active'] === 1 ? 'active' : 'inactive' ?>"><?= (int) $z['is_active'] === 1 ? 'Active' : 'Inactive' ?></span></td>
        <td class="num">
          <div class="row" style="justify-content:flex-end;gap:6px">
            <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('settings/zones/' . (int) $z['id'] . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
            <?php if ((int) $z['is_default'] !== 1): ?>
              <form method="post" action="<?= e(admin_url('settings/zones/' . (int) $z['id'] . '/delete')) ?>" class="inline-form" data-confirm="Delete the zone &quot;<?= e($z['name']) ?>&quot;? Its districts will fall back to the default zone.">
                <?= csrf_field() ?>
                <button class="btn btn-ghost btn-sm" type="submit" aria-label="Delete zone"><?= icon('trash', 'icon-sm') ?></button>
              </form>
            <?php endif; ?>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>

<?php if ($unassigned): ?>
<div class="card">
  <div class="card-head"><h3>Districts using the default zone (<?= count($unassigned) ?>)</h3></div>
  <p class="small muted mb-0"><?= e(implode(', ', $unassigned)) ?></p>
</div>
<?php endif; ?>
