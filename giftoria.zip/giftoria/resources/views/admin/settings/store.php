<?php
/** Vars: $values, $tab */
$v = static fn (string $k) => old($k, is_bool($values[$k] ?? null) ? '' : (string) ($values[$k] ?? ''));
$hasOld = old('store_name', null) !== null;
$announceOn = $hasOld ? (bool) old('announcement_enabled', false) : (bool) ($values['announcement_enabled'] ?? false);
?>
<?= partial('admin/settings/_tabs', ['tab' => $tab]) ?>

<form method="post" action="<?= e(admin_url('settings/store')) ?>" data-loading novalidate>
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h2>Store details</h2></div>
    <div class="form-grid">
      <div class="field">
        <label for="store_name">Store name</label>
        <input class="input<?= errors('store_name') ? ' has-error' : '' ?>" id="store_name" name="store_name" value="<?= e($v('store_name')) ?>" required maxlength="120">
        <?= field_error('store_name') ?>
      </div>
      <div class="field">
        <label for="store_email">Store email</label>
        <input class="input<?= errors('store_email') ? ' has-error' : '' ?>" type="email" id="store_email" name="store_email" value="<?= e($v('store_email')) ?>" required maxlength="190">
        <p class="hint">Shown to customers and used as the contact address in emails.</p>
        <?= field_error('store_email') ?>
      </div>
      <div class="field">
        <label for="store_phone">Store phone</label>
        <input class="input<?= errors('store_phone') ? ' has-error' : '' ?>" type="tel" id="store_phone" name="store_phone" value="<?= e($v('store_phone')) ?>" maxlength="40">
        <?= field_error('store_phone') ?>
      </div>
      <div class="field">
        <label for="store_address">Store address</label>
        <input class="input<?= errors('store_address') ? ' has-error' : '' ?>" id="store_address" name="store_address" value="<?= e($v('store_address')) ?>" maxlength="255">
        <?= field_error('store_address') ?>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h2>Announcement bar</h2></div>
    <div class="field">
      <label class="check"><input type="checkbox" name="announcement_enabled" value="1" <?= $announceOn ? 'checked' : '' ?>> <span>Show the announcement bar on the storefront</span></label>
    </div>
    <div class="field">
      <label for="announcement_text">Announcement text</label>
      <input class="input<?= errors('announcement_text') ? ' has-error' : '' ?>" id="announcement_text" name="announcement_text" value="<?= e($v('announcement_text')) ?>" maxlength="255">
      <p class="hint">Plain text only, up to 255 characters.</p>
      <?= field_error('announcement_text') ?>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h2>Social links</h2></div>
    <div class="form-grid">
      <div class="field">
        <label for="social_facebook">Facebook URL</label>
        <input class="input<?= errors('social_facebook') ? ' has-error' : '' ?>" type="url" id="social_facebook" name="social_facebook" value="<?= e($v('social_facebook')) ?>" maxlength="255" placeholder="https://facebook.com/yourpage">
        <?= field_error('social_facebook') ?>
      </div>
      <div class="field">
        <label for="social_instagram">Instagram URL</label>
        <input class="input<?= errors('social_instagram') ? ' has-error' : '' ?>" type="url" id="social_instagram" name="social_instagram" value="<?= e($v('social_instagram')) ?>" maxlength="255" placeholder="https://instagram.com/yourhandle">
        <?= field_error('social_instagram') ?>
      </div>
    </div>
    <p class="hint">Must start with https://. Leave empty to hide the icon.</p>
  </div>

  <div class="form-actions">
    <button class="btn btn-primary" type="submit">Save store settings</button>
  </div>
</form>
