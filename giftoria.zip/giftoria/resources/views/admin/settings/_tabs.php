<?php
/** Vars: $tab (store|checkout|zones|payments) */
$tabs = [
    'store' => ['Store', 'settings'],
    'checkout' => ['Checkout', 'settings/checkout'],
    'billing' => ['Billing & tax', 'settings/billing'],
    'zones' => ['Delivery zones', 'settings/zones'],
    'payments' => ['Payments', 'settings/payments'],
];
?>
<div class="admin-page-head">
  <div>
    <h1>Settings</h1>
    <p>Changes apply storefront-wide immediately and are recorded in the audit log.</p>
  </div>
</div>
<nav class="tabs" aria-label="Settings sections">
  <?php foreach ($tabs as $key => [$label, $path]): ?>
    <a href="<?= e(admin_url($path)) ?>" class="<?= ($tab ?? '') === $key ? 'is-active' : '' ?>" <?= ($tab ?? '') === $key ? 'aria-current="page"' : '' ?>><?= e($label) ?></a>
  <?php endforeach; ?>
</nav>
