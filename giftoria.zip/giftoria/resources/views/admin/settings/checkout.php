<?php
/** Vars: $values, $tab */
$v = static fn (string $k) => old($k, is_bool($values[$k] ?? null) ? '' : (string) ($values[$k] ?? ''));
$hasOld = old('gift_wrap_fee', null) !== null;
$autoApprove = $hasOld ? (bool) old('review_auto_approve_verified', false) : (bool) ($values['review_auto_approve_verified'] ?? false);
?>
<?= partial('admin/settings/_tabs', ['tab' => $tab]) ?>

<form method="post" action="<?= e(admin_url('settings/checkout')) ?>" data-loading novalidate>
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h2>Checkout</h2></div>
    <div class="form-grid">
      <div class="field">
        <label for="gift_wrap_fee">Gift wrap fee (NPR)</label>
        <input class="input<?= errors('gift_wrap_fee') ? ' has-error' : '' ?>" type="number" step="0.01" min="0" id="gift_wrap_fee" name="gift_wrap_fee" value="<?= e($v('gift_wrap_fee')) ?>" required>
        <p class="hint">Charged once per order when the customer selects gift wrapping.</p>
        <?= field_error('gift_wrap_fee') ?>
      </div>
      <div class="field">
        <label for="cod_max_order">Cash on delivery maximum order (NPR)</label>
        <input class="input<?= errors('cod_max_order') ? ' has-error' : '' ?>" type="number" step="0.01" min="0" id="cod_max_order" name="cod_max_order" value="<?= e($v('cod_max_order')) ?>" required>
        <p class="hint">Orders above this total must be paid online.</p>
        <?= field_error('cod_max_order') ?>
      </div>
      <div class="field">
        <label for="low_stock_alert_email">Low-stock alert email</label>
        <input class="input<?= errors('low_stock_alert_email') ? ' has-error' : '' ?>" type="email" id="low_stock_alert_email" name="low_stock_alert_email" value="<?= e($v('low_stock_alert_email')) ?>" maxlength="190" placeholder="inventory@example.com">
        <p class="hint">Leave empty to disable low-stock emails.</p>
        <?= field_error('low_stock_alert_email') ?>
      </div>
      <div class="field">
        <label>Reviews</label>
        <label class="check"><input type="checkbox" name="review_auto_approve_verified" value="1" <?= $autoApprove ? 'checked' : '' ?>> <span>Auto-approve reviews from verified buyers</span></label>
        <p class="hint">Other reviews always wait for moderation.</p>
      </div>
    </div>
  </div>
  <div class="form-actions">
    <button class="btn btn-primary" type="submit">Save checkout settings</button>
  </div>
</form>
