<?php
/** Vars: $values, $tab, $fiscalYear, $billsThisYear, $nextNumber */
$hasOld = old('bill_prefix', null) !== null;
$v = static fn (string $k) => old($k, is_bool($values[$k] ?? null) ? '' : (string) ($values[$k] ?? ''));
$chk = static fn (string $k) => $hasOld ? (bool) old($k, false) : (bool) ($values[$k] ?? false);
$inclusive = $hasOld ? old('prices_include_vat', '1') === '1' : (bool) $values['prices_include_vat'];
$logo = (string) ($values['store_logo'] ?? '');
?>
<?= partial('admin/settings/_tabs', ['tab' => $tab]) ?>

<form method="post" action="<?= e(admin_url('settings/billing')) ?>" enctype="multipart/form-data" data-loading novalidate>
  <?= csrf_field() ?>
  <div class="admin-grid admin-grid-3-1">
    <div>
      <div class="card">
        <div class="card-head"><h2>Business identity on bills</h2></div>
        <div class="form-grid">
          <div class="field span-2">
            <label for="business_legal_name">Registered business name</label>
            <input class="input<?= errors('business_legal_name') ? ' has-error' : '' ?>" id="business_legal_name" name="business_legal_name" maxlength="150" value="<?= e($v('business_legal_name')) ?>" placeholder="e.g. Giftoria Pvt. Ltd.">
            <p class="hint">As registered with the Office of the Company Registrar / IRD. Leave empty to use the store name (<?= e(setting('store_name')) ?>). Address, phone and email come from the Store tab.</p>
            <?= field_error('business_legal_name') ?>
          </div>
          <div class="field">
            <label for="store_pan">PAN number</label>
            <input class="input<?= errors('store_pan') ? ' has-error' : '' ?>" id="store_pan" name="store_pan" inputmode="numeric" maxlength="9" pattern="\d{9}" value="<?= e($v('store_pan')) ?>" placeholder="9 digits">
            <?= field_error('store_pan') ?>
          </div>
          <div class="field">
            <label for="store_vat_number">VAT registration number</label>
            <input class="input<?= errors('store_vat_number') ? ' has-error' : '' ?>" id="store_vat_number" name="store_vat_number" inputmode="numeric" maxlength="9" pattern="\d{9}" value="<?= e($v('store_vat_number')) ?>" placeholder="9 digits (usually same as PAN)">
            <?= field_error('store_vat_number') ?>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h2>VAT</h2></div>
        <div class="form-grid">
          <div class="field span-2">
            <label class="check"><input type="checkbox" name="vat_registered" value="1" <?= $chk('vat_registered') ? 'checked' : '' ?>> <span><strong>VAT registered</strong>: issue <em>Tax invoices</em> showing taxable amount and VAT</span></label>
            <p class="hint">Untick if you are PAN-registered only; bills are then issued as plain invoices with no VAT line.</p>
          </div>
          <div class="field">
            <label for="vat_rate">VAT rate (%)</label>
            <input class="input<?= errors('vat_rate') ? ' has-error' : '' ?>" type="number" step="0.01" min="0" max="100" id="vat_rate" name="vat_rate" value="<?= e($v('vat_rate')) ?>" required>
            <p class="hint">Nepal's standard rate is 13%.</p>
            <?= field_error('vat_rate') ?>
          </div>
          <div class="field">
            <label>Product prices are entered…</label>
            <label class="check"><input type="radio" name="prices_include_vat" value="1" <?= $inclusive ? 'checked' : '' ?>> <span>Including VAT (customers pay the listed price)</span></label>
            <label class="check mt-2"><input type="radio" name="prices_include_vat" value="0" <?= !$inclusive ? 'checked' : '' ?>> <span>Excluding VAT (VAT is added at checkout)</span></label>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h2>Bill numbering &amp; footer</h2></div>
        <div class="form-grid">
          <div class="field">
            <label for="bill_prefix">Bill number prefix</label>
            <input class="input<?= errors('bill_prefix') ? ' has-error' : '' ?>" id="bill_prefix" name="bill_prefix" maxlength="10" value="<?= e($v('bill_prefix')) ?>" required style="text-transform:uppercase">
            <p class="hint">Next bill: <strong><?= e($nextNumber) ?></strong> · <?= (int) $billsThisYear ?> issued in FY <?= e($fiscalYear) ?>. Numbers are sequential per fiscal year and never reused.</p>
            <?= field_error('bill_prefix') ?>
          </div>
          <div class="field span-2">
            <label for="bill_footer">Footer note on bills</label>
            <textarea class="textarea" id="bill_footer" name="bill_footer" maxlength="500" rows="3"><?= e($v('bill_footer')) ?></textarea>
            <?= field_error('bill_footer') ?>
          </div>
        </div>
      </div>
    </div>

    <div>
      <div class="card">
        <div class="card-head"><h2>Logo</h2></div>
        <div style="border:1px dashed var(--line-strong);border-radius:var(--r-md);padding:16px;display:grid;place-items:center;min-height:120px;background:var(--ivory)">
          <?php if ($logo): ?>
            <img src="<?= e(image_url($logo)) ?>" alt="Current logo" style="max-height:90px;max-width:100%;object-fit:contain">
          <?php else: ?>
            <span class="muted small">No logo uploaded: the round brand mark is used.</span>
          <?php endif; ?>
        </div>
        <div class="field mt-4">
          <label for="store_logo"><?= $logo ? 'Replace logo' : 'Upload logo' ?></label>
          <input class="input<?= errors('store_logo') ? ' has-error' : '' ?>" type="file" id="store_logo" name="store_logo" accept="image/png,image/jpeg,image/webp">
          <p class="hint">PNG, JPG or WebP, up to 2 MB. A wide logo on a transparent background works best (about 400 × 120 px).</p>
          <?= field_error('store_logo') ?>
        </div>
        <label class="check"><input type="checkbox" name="show_logo_in_header" value="1" <?= $chk('show_logo_in_header') ? 'checked' : '' ?>> <span>Show logo in the website header and emails</span></label>
        <p class="hint">The logo always appears on bills.</p>
      </div>
      <div class="card">
        <div class="card-head"><h2>Preview</h2></div>
        <p class="small muted">Open any order's bill to see how it looks, e.g. from <a href="<?= e(admin_url('orders')) ?>">Orders</a> → order → Invoice.</p>
        <p class="small muted mb-0">Changes apply to new bills. Bills already issued keep the seller details they were issued with, as required for tax records.</p>
      </div>
    </div>
  </div>
  <div class="form-actions">
    <button class="btn btn-primary" type="submit">Save billing &amp; tax settings</button>
  </div>
</form>
<?php if ($logo): ?>
<form method="post" action="<?= e(admin_url('settings/billing/remove-logo')) ?>" data-confirm="Remove the logo?" style="margin-top:-8px">
  <?= csrf_field() ?><button class="btn btn-ghost btn-sm" type="submit"><?= icon('trash', 'icon-sm') ?> Remove logo</button>
</form>
<?php endif; ?>
