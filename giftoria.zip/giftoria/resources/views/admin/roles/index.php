<div class="admin-page-head">
  <div>
    <h1>Roles &amp; permissions</h1>
    <p>You can only grant permissions you hold. Only a Super Admin can edit the Super Admin role.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-primary" href="<?= e(admin_url('roles/create')) ?>"><?= icon('plus', 'icon-sm') ?> New role</a>
  </div>
</div>

<div class="card card-flush">
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead>
      <tr><th>Role</th><th class="num">Permissions</th><th class="num">Members</th><th>Status</th><th></th></tr>
    </thead>
    <tbody>
    <?php foreach ($roles as $r): ?>
      <?php $isSuper = $r['slug'] === \App\Core\Gate::SUPER_ADMIN; ?>
      <tr>
        <td>
          <strong><?= e($r['name']) ?></strong>
          <?php if ((int) $r['is_system'] === 1): ?> <span class="badge">System</span><?php endif; ?>
          <div class="muted small"><code><?= e($r['slug']) ?></code><?= $r['description'] ? ' · ' . e($r['description']) : '' ?></div>
        </td>
        <td class="num"><?= $isSuper ? 'All' : (int) $r['perm_count'] . ' / ' . (int) $totalPermissions ?></td>
        <td class="num">
          <?php if (can('staff.manage')): ?>
            <a href="<?= e(admin_url('staff') . '?role=' . (int) $r['id']) ?>"><?= (int) $r['member_count'] ?></a>
          <?php else: ?>
            <?= (int) $r['member_count'] ?>
          <?php endif; ?>
        </td>
        <td><span class="status status-<?= (int) $r['is_active'] === 1 ? 'active' : 'inactive' ?>"><?= (int) $r['is_active'] === 1 ? 'Active' : 'Inactive' ?></span></td>
        <td class="num">
          <?php if ($r['editable']): ?>
            <div class="row" style="justify-content:flex-end;gap:6px">
              <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('roles/' . (int) $r['id'] . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
              <?php if (!$isSuper): ?>
                <form method="post" action="<?= e(admin_url('roles/' . (int) $r['id'] . '/toggle')) ?>" class="inline-form" data-confirm="<?= (int) $r['is_active'] === 1 ? 'Deactivate this role? Members lose its permissions immediately.' : 'Activate this role?' ?>">
                  <?= csrf_field() ?>
                  <button class="btn btn-light btn-sm" type="submit"><?= (int) $r['is_active'] === 1 ? 'Deactivate' : 'Activate' ?></button>
                </form>
              <?php endif; ?>
              <?php if ((int) $r['is_system'] !== 1 && !$isSuper): ?>
                <form method="post" action="<?= e(admin_url('roles/' . (int) $r['id'] . '/delete')) ?>" class="inline-form" data-confirm="Delete the role &quot;<?= e($r['name']) ?>&quot;? This cannot be undone.">
                  <?= csrf_field() ?>
                  <button class="btn btn-ghost btn-sm" type="submit" aria-label="Delete role"><?= icon('trash', 'icon-sm') ?></button>
                </form>
              <?php endif; ?>
            </div>
          <?php else: ?>
            <span class="muted small" title="This role includes permissions you do not hold"><?= icon('lock', 'icon-sm') ?> Locked</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>
