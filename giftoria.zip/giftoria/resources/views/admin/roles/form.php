<?php
/** Vars: $role (null = create), $matrix, $granted, $actorPerms, $isSuperRole */
$editing = $role !== null;
$slugLocked = $editing && ((int) $role['is_system'] === 1 || $isSuperRole);
$oldPerms = old('permissions', null);
$checked = is_array($oldPerms) ? array_map('strval', $oldPerms) : $granted;
$active = $editing ? (int) old('is_active', $role['is_active']) === 1 : (old('name', '') === '' ? true : (bool) old('is_active', false));
$action = $editing ? admin_url('roles/' . (int) $role['id']) : admin_url('roles');
?>
<div class="admin-page-head">
  <div>
    <h1><?= $editing ? 'Edit role' : 'New role' ?></h1>
    <p><?= $editing ? e($role['name']) : 'Group permissions into a role, then assign it to staff.' ?></p>
  </div>
  <div class="admin-actions"><a class="btn btn-light" href="<?= e(admin_url('roles')) ?>">Back to roles</a></div>
</div>

<form method="post" action="<?= e($action) ?>" data-loading novalidate>
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h2>Details</h2></div>
    <div class="form-grid">
      <div class="field">
        <label for="name">Name</label>
        <input class="input<?= errors('name') ? ' has-error' : '' ?>" id="name" name="name" value="<?= e(old('name', $role['name'] ?? '')) ?>" required maxlength="80">
        <?= field_error('name') ?>
      </div>
      <div class="field">
        <label for="slug">Slug</label>
        <?php if ($slugLocked): ?>
          <input class="input" id="slug" value="<?= e($role['slug']) ?>" readonly>
          <p class="hint">System role slugs are fixed.</p>
        <?php else: ?>
          <input class="input<?= errors('slug') ? ' has-error' : '' ?>" id="slug" name="slug" value="<?= e(old('slug', $role['slug'] ?? '')) ?>" required maxlength="80" pattern="[a-z0-9]+(-[a-z0-9]+)*" data-slug-from="#name">
          <?= field_error('slug') ?>
        <?php endif; ?>
      </div>
      <div class="field span-2">
        <label for="description">Description</label>
        <input class="input<?= errors('description') ? ' has-error' : '' ?>" id="description" name="description" value="<?= e(old('description', $role['description'] ?? '')) ?>" maxlength="255">
        <?= field_error('description') ?>
      </div>
      <div class="field span-2">
        <?php if ($isSuperRole): ?>
          <input type="hidden" name="is_active" value="1">
          <p class="muted small"><?= icon('lock', 'icon-sm') ?> The Super Admin role is always active.</p>
        <?php else: ?>
          <label class="check"><input type="checkbox" name="is_active" value="1" <?= $active ? 'checked' : '' ?>> <span>Active (inactive roles grant no permissions)</span></label>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-head">
      <h2>Permissions</h2>
      <?php if (!$isSuperRole): ?><span class="muted small">Greyed-out permissions are ones you do not hold and cannot grant.</span><?php endif; ?>
    </div>
    <?php if ($isSuperRole): ?>
      <div class="alert alert-info"><?= icon('shield') ?><div><strong>All permissions.</strong> The Super Admin role implicitly holds every permission, including ones added in the future. This cannot be changed.</div></div>
    <?php else: ?>
      <?= field_error('permissions') ?>
      <?php foreach ($matrix as $group => $perms): ?>
        <fieldset class="perm-group">
          <h4><?= e($group) ?></h4>
          <div class="checkbox-grid">
            <?php foreach ($perms as $slug => $label):
                $holds = in_array($slug, $actorPerms, true);
                $isChecked = in_array($slug, $checked, true);
            ?>
              <label class="check" title="<?= e($slug) ?>" style="<?= $holds ? '' : 'opacity:.55' ?>">
                <input type="checkbox" name="permissions[]" value="<?= e($slug) ?>" <?= $isChecked ? 'checked' : '' ?> <?= $holds ? '' : 'disabled' ?>>
                <span><?= e($label) ?><br><code class="muted" style="font-size:.7rem"><?= e($slug) ?></code></span>
              </label>
            <?php endforeach; ?>
          </div>
        </fieldset>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <div class="form-actions">
    <a class="btn btn-light" href="<?= e(admin_url('roles')) ?>">Cancel</a>
    <button class="btn btn-primary" type="submit"><?= $editing ? 'Save role' : 'Create role' ?></button>
  </div>
</form>
