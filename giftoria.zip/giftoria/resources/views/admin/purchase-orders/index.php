<?php /** Vars: $orders, $total, $paginator, $suppliers, $statuses, $filters */ ?>
<div class="admin-page-head">
  <div>
    <h1>Suppliers &amp; purchasing</h1>
    <p>Purchase orders move from draft to ordered, then stock is received line by line.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-accent" href="<?= e(admin_url('suppliers/purchase-orders/create')) ?>"><?= icon('plus', 'icon-sm') ?> New purchase order</a>
  </div>
</div>

<?= partial('admin/suppliers/_tabs', ['active' => 'orders']) ?>

<form class="filter-bar" method="get" action="<?= e(admin_url('suppliers/purchase-orders')) ?>">
  <div class="field">
    <label for="po-q">PO number</label>
    <input class="input" id="po-q" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="PO-">
  </div>
  <div class="field">
    <label for="po-status">Status</label>
    <select class="select" id="po-status" name="status">
      <option value="">All statuses</option>
      <?php foreach ($statuses as $s): ?>
        <option value="<?= e($s) ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= e(status_label($s)) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field">
    <label for="po-supplier">Supplier</label>
    <select class="select" id="po-supplier" name="supplier">
      <option value="">All suppliers</option>
      <?php foreach ($suppliers as $s): ?>
        <option value="<?= (int) $s['id'] ?>" <?= (int) $filters['supplier_id'] === (int) $s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <button class="btn btn-primary btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
  <?php if ($filters['q'] !== '' || $filters['status'] !== '' || $filters['supplier_id']): ?><a class="btn btn-ghost btn-sm" href="<?= e(admin_url('suppliers/purchase-orders')) ?>">Clear</a><?php endif; ?>
</form>

<?php if (!$orders): ?>
  <?= partial('components/empty-state', ['icon' => 'clipboard', 'title' => 'No purchase orders', 'text' => 'Create a purchase order to restock from a supplier. Received quantities are added to inventory automatically.', 'actionUrl' => admin_url('suppliers/purchase-orders/create'), 'actionLabel' => 'New purchase order']) ?>
<?php else: ?>
<div class="card card-flush">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th scope="col">PO number</th>
          <th scope="col">Supplier</th>
          <th scope="col">Status</th>
          <th scope="col" class="num">Received</th>
          <th scope="col" class="num">Total cost</th>
          <th scope="col">Expected</th>
          <th scope="col">Created</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($orders as $o):
          $statusClass = $o['status'] === 'ordered' ? 'confirmed' : ($o['status'] === 'partially_received' ? 'processing' : $o['status']);
          $overdue = $o['expected_at'] && in_array($o['status'], ['ordered', 'partially_received'], true) && $o['expected_at'] < local_today();
      ?>
        <tr>
          <td><a class="row-link" href="<?= e(admin_url('suppliers/purchase-orders/' . (int) $o['id'])) ?>"><?= e($o['po_number']) ?></a></td>
          <td><?= e($o['supplier_name']) ?></td>
          <td><span class="status status-<?= e($statusClass) ?>"><?= e(status_label($o['status'])) ?></span></td>
          <td class="num"><?= (int) $o['qty_received'] ?> / <?= (int) $o['qty_ordered'] ?></td>
          <td class="num"><?= e(money($o['total_cost'])) ?></td>
          <td><?= $o['expected_at'] ? e(date('M j, Y', strtotime($o['expected_at']))) : '<span class="muted">—</span>' ?><?= $overdue ? ' <span class="badge badge-danger">Overdue</span>' : '' ?></td>
          <td class="muted small"><?= e(local_date($o['created_at'], 'M j, Y')) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<p class="muted small"><?= e(number_format($total)) ?> purchase order(s)</p>
<?= $paginator->links() ?>
<?php endif; ?>
