<?php
/** Vars: $po (with items), $receipts (inventory movements) */
$poId = (int) $po['id'];
$status = $po['status'];
$statusClass = $status === 'ordered' ? 'confirmed' : ($status === 'partially_received' ? 'processing' : $status);
$canReceive = in_array($status, ['ordered', 'partially_received'], true);
$totalOrdered = 0;
$totalReceived = 0;
$totalCost = 0.0;
foreach ($po['items'] as $it) {
    $totalOrdered += (int) $it['quantity_ordered'];
    $totalReceived += (int) $it['quantity_received'];
    $totalCost += (int) $it['quantity_ordered'] * (float) $it['unit_cost'];
}
$oldReceive = (array) old('receive', []);
$steps = ['draft' => 'Draft', 'ordered' => 'Ordered', 'partially_received' => 'Partially received', 'received' => 'Received'];
?>
<div class="admin-page-head">
  <div>
    <p class="small"><a href="<?= e(admin_url('suppliers/purchase-orders')) ?>"><?= icon('chevron-left', 'icon-sm') ?> Purchase orders</a></p>
    <h1><?= e($po['po_number']) ?></h1>
    <p><span class="status status-<?= e($statusClass) ?>"><?= e(status_label($status)) ?></span> · <?= e($po['supplier_name']) ?> · created <?= e(local_date($po['created_at'])) ?><?= $po['created_by_name'] ? ' by ' . e($po['created_by_name']) : '' ?></p>
  </div>
  <div class="admin-actions">
    <?php if ($status === 'draft'): ?>
      <a class="btn btn-light" href="<?= e(admin_url('suppliers/purchase-orders/' . $poId . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
      <form method="post" action="<?= e(admin_url('suppliers/purchase-orders/' . $poId . '/status')) ?>" class="inline-form" data-confirm="Mark this purchase order as sent to the supplier? Lines can no longer be edited.">
        <?= csrf_field() ?><input type="hidden" name="status" value="ordered">
        <button class="btn btn-accent" type="submit"><?= icon('truck', 'icon-sm') ?> Mark as ordered</button>
      </form>
    <?php endif; ?>
    <?php if ($status === 'draft' || ($status === 'ordered' && $totalReceived === 0)): ?>
      <form method="post" action="<?= e(admin_url('suppliers/purchase-orders/' . $poId . '/status')) ?>" class="inline-form" data-confirm="Cancel this purchase order?">
        <?= csrf_field() ?><input type="hidden" name="status" value="cancelled">
        <button class="btn btn-ghost" type="submit">Cancel PO</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php if ($status !== 'cancelled'): ?>
<nav class="tabs" aria-label="Progress" style="pointer-events:none">
  <?php $reached = true; foreach ($steps as $key => $label):
      $isCurrent = $key === $status;
  ?>
    <span class="<?= $isCurrent ? 'is-active' : '' ?>" style="padding:var(--s-3) var(--s-4);font-size:var(--fs-sm);border-bottom:2px solid <?= $isCurrent ? 'var(--terracotta)' : 'transparent' ?>;color:<?= $reached ? 'var(--ink)' : 'var(--muted)' ?>"><?= $reached && !$isCurrent ? icon('check', 'icon-sm') . ' ' : '' ?><?= e($label) ?></span>
  <?php if ($isCurrent) { $reached = false; } endforeach; ?>
</nav>
<?php endif; ?>

<div class="kpis">
  <div class="kpi"><p class="label">Units ordered</p><div class="value"><?= e(number_format($totalOrdered)) ?></div><div class="sub"><?= count($po['items']) ?> line(s)</div></div>
  <div class="kpi"><p class="label">Units received</p><div class="value"><?= e(number_format($totalReceived)) ?></div><div class="sub"><?= e(number_format(max(0, $totalOrdered - $totalReceived))) ?> outstanding</div></div>
  <div class="kpi"><p class="label">Order value</p><div class="value" style="font-size:1.5rem"><?= e(money($totalCost)) ?></div><div class="sub">At unit cost</div></div>
  <div class="kpi"><p class="label">Expected</p><div class="value" style="font-size:1.5rem"><?= $po['expected_at'] ? e(date('M j, Y', strtotime($po['expected_at']))) : '—' ?></div><div class="sub"><?= $canReceive && $po['expected_at'] && $po['expected_at'] < local_today() ? 'Overdue' : '&nbsp;' ?></div></div>
</div>

<div class="admin-grid admin-grid-3-1">
  <section class="card card-flush">
    <div class="card-head"><h2><?= $canReceive ? 'Receive stock' : 'Lines' ?></h2><?php if ($canReceive): ?><span class="muted small">Enter what actually arrived. You cannot receive more than ordered.</span><?php endif; ?></div>
    <?php if ($canReceive): ?><form method="post" action="<?= e(admin_url('suppliers/purchase-orders/' . $poId . '/receive')) ?>" data-loading data-confirm="Add the entered quantities to stock?"><?= csrf_field() ?><?php endif; ?>
    <?php if (errors('receive')): ?><div style="padding:0 var(--s-6)"><?= field_error('receive') ?></div><?php endif; ?>
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th scope="col">Product</th>
            <th scope="col">SKU</th>
            <th scope="col" class="num">Unit cost</th>
            <th scope="col" class="num">Ordered</th>
            <th scope="col" class="num">Received</th>
            <?php if ($canReceive): ?><th scope="col" class="num">Receive now</th><?php endif; ?>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($po['items'] as $it):
            $lid = (int) $it['id'];
            $remaining = (int) $it['quantity_ordered'] - (int) $it['quantity_received'];
        ?>
          <tr>
            <td><strong><?= e($it['product_name']) ?></strong><?php if ((int) $it['variant_id'] !== 0): ?><div class="muted small"><?= e($it['variant_name'] ?? 'Variant #' . (int) $it['variant_id']) ?></div><?php endif; ?></td>
            <td class="muted small"><?= e($it['variant_sku'] ?: $it['product_sku']) ?></td>
            <td class="num"><?= e(money($it['unit_cost'])) ?></td>
            <td class="num"><?= (int) $it['quantity_ordered'] ?></td>
            <td class="num"><?= (int) $it['quantity_received'] ?><?= $remaining <= 0 ? ' ' . icon('check', 'icon-sm') : '' ?></td>
            <?php if ($canReceive): ?>
            <td class="num">
              <?php if ($remaining > 0): ?>
                <label class="sr-only" for="rcv-<?= $lid ?>">Receive quantity for <?= e($it['product_name']) ?></label>
                <input class="input" id="rcv-<?= $lid ?>" name="receive[<?= $lid ?>]" type="number" min="0" max="<?= $remaining ?>" step="1" value="<?= e(is_scalar($oldReceive[$lid] ?? null) ? $oldReceive[$lid] : '') ?>" placeholder="0–<?= $remaining ?>" style="width:110px">
              <?php else: ?>
                <span class="muted small">Complete</span>
              <?php endif; ?>
            </td>
            <?php endif; ?>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php if ($canReceive): ?>
      <div style="padding:var(--s-4) var(--s-6) var(--s-6)">
        <div class="field">
          <label for="rcv-note">Receiving note</label>
          <input class="input" id="rcv-note" name="note" maxlength="200" placeholder="e.g. Delivery challan #1234">
        </div>
        <div class="form-actions"><button class="btn btn-accent" type="submit"><?= icon('package', 'icon-sm') ?> Receive into stock</button></div>
      </div>
      </form>
    <?php endif; ?>
  </section>

  <div>
    <section class="card">
      <div class="card-head"><h2>Supplier</h2></div>
      <ul class="list-plain">
        <li><span>Name</span><strong><?= e($po['supplier_name']) ?></strong></li>
        <?php if ($po['supplier_email']): ?><li><span>Email</span><a href="mailto:<?= e($po['supplier_email']) ?>"><?= e($po['supplier_email']) ?></a></li><?php endif; ?>
        <?php if ($po['supplier_phone']): ?><li><span>Phone</span><span><?= e($po['supplier_phone']) ?></span></li><?php endif; ?>
      </ul>
      <a class="btn btn-ghost btn-sm mt-2" href="<?= e(admin_url('suppliers/' . (int) $po['supplier_id'] . '/edit')) ?>">View supplier</a>
    </section>
    <?php if ($po['notes']): ?>
    <section class="card">
      <div class="card-head"><h2>Notes</h2></div>
      <p class="small" style="white-space:pre-line;margin:0"><?= e($po['notes']) ?></p>
    </section>
    <?php endif; ?>
    <section class="card">
      <div class="card-head"><h2>Receipts</h2></div>
      <?php if (!$receipts): ?>
        <p class="muted small mb-0">Nothing received yet.</p>
      <?php else: ?>
        <ul class="timeline-admin">
          <?php foreach ($receipts as $r): ?>
            <li>
              <strong>+<?= (int) $r['change_qty'] ?></strong> <?= e($r['product_name']) ?><?= (int) $r['variant_id'] !== 0 ? ' — ' . e($r['variant_name'] ?? '') : '' ?>
              <div class="when"><?= e(local_date($r['created_at'])) ?> · <?= e($r['user_name'] ?? 'System') ?></div>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </section>
  </div>
</div>
