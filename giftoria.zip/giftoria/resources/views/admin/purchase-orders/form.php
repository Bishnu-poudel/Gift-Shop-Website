<?php
/** Vars: $po (null on create), $suppliers, $items (key "pid:vid" => row with label, cost_price), $presetSupplier */
$isEdit = $po !== null;
$hasOld = (bool) errors() && old('supplier_id', null) !== null;
if ($hasOld) {
    $lines = array_values(array_filter((array) old('lines', []), 'is_array'));
    $supplierVal = (string) old('supplier_id', '');
    $expected = (string) old('expected_at', '');
    $notes = (string) old('notes', '');
} elseif ($isEdit) {
    $lines = array_map(static fn ($i) => [
        'item' => (int) $i['product_id'] . ':' . (int) $i['variant_id'],
        'qty' => (string) (int) $i['quantity_ordered'],
        'cost' => (string) $i['unit_cost'],
    ], $po['items']);
    $supplierVal = (string) $po['supplier_id'];
    $expected = (string) ($po['expected_at'] ?? '');
    $notes = (string) ($po['notes'] ?? '');
} else {
    $lines = [];
    $supplierVal = $presetSupplier ? (string) $presetSupplier : '';
    $expected = '';
    $notes = '';
}
$lines = array_values(array_filter($lines, static fn ($l) => ($l['item'] ?? '') !== '' || ($l['qty'] ?? '') !== ''));
$blank = max(3, 8 - count($lines));
for ($i = 0; $i < $blank; $i++) {
    $lines[] = ['item' => '', 'qty' => '', 'cost' => ''];
}
$action = $isEdit ? admin_url('suppliers/purchase-orders/' . (int) $po['id']) : admin_url('suppliers/purchase-orders');
?>
<div class="admin-page-head">
  <div>
    <p class="small"><a href="<?= e(admin_url('suppliers/purchase-orders')) ?>"><?= icon('chevron-left', 'icon-sm') ?> Purchase orders</a></p>
    <h1><?= e($isEdit ? 'Edit ' . $po['po_number'] : 'New purchase order') ?></h1>
    <p>Saved as a draft. A PO number (PO-YYMMDD-XXXX) is assigned automatically.</p>
  </div>
</div>

<form method="post" action="<?= e($action) ?>" data-loading novalidate>
  <?= csrf_field() ?>
  <div class="admin-grid admin-grid-3-1">
    <section class="card card-flush">
      <div class="card-head"><h2>Lines</h2><span class="muted small">Leave unused rows empty. Unit cost defaults to the product cost price.</span></div>
      <?php if (errors('lines')): ?><div style="padding:0 var(--s-6)"><?= field_error('lines') ?></div><?php endif; ?>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th scope="col">Product / variant</th><th scope="col" class="num">Quantity</th><th scope="col" class="num">Unit cost (NPR)</th></tr></thead>
          <tbody>
          <?php foreach ($lines as $i => $l): $itemVal = is_scalar($l['item'] ?? null) ? (string) $l['item'] : ''; ?>
            <tr>
              <td>
                <label class="sr-only" for="line-item-<?= $i ?>">Line <?= $i + 1 ?> product</label>
                <select class="select" id="line-item-<?= $i ?>" name="lines[<?= $i ?>][item]" style="min-width:260px">
                  <option value="">— Select product —</option>
                  <?php foreach ($items as $key => $it): ?>
                    <option value="<?= e($key) ?>" <?= $itemVal === (string) $key ? 'selected' : '' ?>><?= e($it['label']) ?><?= $it['cost_price'] !== null ? ' · cost ' . e(money($it['cost_price'])) : '' ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td class="num"><label class="sr-only" for="line-qty-<?= $i ?>">Quantity</label><input class="input" id="line-qty-<?= $i ?>" name="lines[<?= $i ?>][qty]" type="number" min="1" step="1" value="<?= e(is_scalar($l['qty'] ?? null) ? $l['qty'] : '') ?>" style="width:100px"></td>
              <td class="num"><label class="sr-only" for="line-cost-<?= $i ?>">Unit cost</label><input class="input" id="line-cost-<?= $i ?>" name="lines[<?= $i ?>][cost]" type="number" min="0" step="0.01" value="<?= e(is_scalar($l['cost'] ?? null) ? $l['cost'] : '') ?>" style="width:130px"></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <p class="muted small" style="padding:var(--s-3) var(--s-6) var(--s-5)">Need more rows? Save the draft and edit it again — new empty rows are added each time.</p>
    </section>

    <div>
      <section class="card">
        <div class="card-head"><h2>Order details</h2></div>
        <div class="field">
          <label for="po-supplier">Supplier *</label>
          <select class="select <?= errors('supplier_id') ? 'has-error' : '' ?>" id="po-supplier" name="supplier_id" required>
            <option value="">— Choose supplier —</option>
            <?php foreach ($suppliers as $s): ?>
              <option value="<?= (int) $s['id'] ?>" <?= $supplierVal === (string) $s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?><?= (int) $s['is_active'] ? '' : ' (inactive)' ?></option>
            <?php endforeach; ?>
          </select>
          <?= field_error('supplier_id') ?>
        </div>
        <div class="field">
          <label for="po-expected">Expected delivery</label>
          <input class="input <?= errors('expected_at') ? 'has-error' : '' ?>" id="po-expected" name="expected_at" type="date" value="<?= e($expected) ?>">
          <?= field_error('expected_at') ?>
        </div>
        <div class="field">
          <label for="po-notes">Notes</label>
          <textarea class="textarea <?= errors('notes') ? 'has-error' : '' ?>" id="po-notes" name="notes" rows="3"><?= e($notes) ?></textarea>
          <?= field_error('notes') ?>
        </div>
        <div class="form-actions">
          <a class="btn btn-ghost" href="<?= e($isEdit ? admin_url('suppliers/purchase-orders/' . (int) $po['id']) : admin_url('suppliers/purchase-orders')) ?>">Cancel</a>
          <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save draft' : 'Create draft' ?></button>
        </div>
      </section>
    </div>
  </div>
</form>
