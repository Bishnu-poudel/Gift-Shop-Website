<div class="auth-card">
  <h1>Reset password</h1>
  <p class="sub">Enter your work email and we will send you a reset link.</p>
  <form method="post" action="<?= e(admin_url('forgot-password')) ?>" data-loading novalidate>
    <?= csrf_field() ?>
    <div class="field">
      <label for="email">Work email</label>
      <input class="input<?= errors('email') ? ' has-error' : '' ?>" type="email" id="email" name="email" value="<?= e(old('email')) ?>" autocomplete="username" required autofocus maxlength="190">
      <?= field_error('email') ?>
    </div>
    <button class="btn btn-primary btn-block btn-lg" type="submit"><?= icon('mail', 'icon-sm') ?> Send reset link</button>
  </form>
  <p class="auth-alt"><a href="<?= e(admin_url('login')) ?>">Back to sign in</a></p>
</div>
