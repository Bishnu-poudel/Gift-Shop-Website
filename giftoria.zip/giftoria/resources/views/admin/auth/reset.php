<div class="auth-card">
  <h1>Choose a new password</h1>
  <?php if (empty($valid)): ?>
    <p class="sub">This reset link is invalid or has expired.</p>
    <a class="btn btn-primary btn-block" href="<?= e(admin_url('forgot-password')) ?>">Request a new link</a>
  <?php else: ?>
    <p class="sub">Use at least 8 characters. Signing in elsewhere will be ended.</p>
    <form method="post" action="<?= e(admin_url('reset-password/' . $token)) ?>" data-loading novalidate>
      <?= csrf_field() ?>
      <div class="field">
        <label for="password">New password</label>
        <input class="input<?= errors('password') ? ' has-error' : '' ?>" type="password" id="password" name="password" autocomplete="new-password" required minlength="8" maxlength="128" autofocus>
        <?= field_error('password') ?>
      </div>
      <div class="field">
        <label for="password_confirmation">Confirm new password</label>
        <input class="input" type="password" id="password_confirmation" name="password_confirmation" autocomplete="new-password" required minlength="8" maxlength="128">
      </div>
      <button class="btn btn-primary btn-block btn-lg" type="submit">Update password</button>
    </form>
  <?php endif; ?>
  <p class="auth-alt"><a href="<?= e(admin_url('login')) ?>">Back to sign in</a></p>
</div>
