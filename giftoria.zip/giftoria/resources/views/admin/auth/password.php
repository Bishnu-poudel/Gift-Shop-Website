<div class="admin-page-head">
  <div>
    <h1>Change password</h1>
    <p>Changing your password signs out all your other sessions.</p>
  </div>
</div>

<?php if (!empty($mustChange)): ?>
  <div class="alert alert-warning" role="status"><?= icon('alert') ?><div>An administrator requires you to set a new password before continuing.</div></div>
<?php endif; ?>

<div class="card" style="max-width:560px">
  <form method="post" action="<?= e(admin_url('password/update')) ?>" data-loading novalidate>
    <?= csrf_field() ?>
    <?php if (!empty($needsCurrent)): ?>
    <div class="field">
      <label for="current_password">Current password</label>
      <input class="input<?= errors('current_password') ? ' has-error' : '' ?>" type="password" id="current_password" name="current_password" autocomplete="current-password" required maxlength="128">
      <?= field_error('current_password') ?>
    </div>
    <?php endif; ?>
    <div class="field">
      <label for="password">New password</label>
      <input class="input<?= errors('password') ? ' has-error' : '' ?>" type="password" id="password" name="password" autocomplete="new-password" required minlength="8" maxlength="128">
      <p class="hint">At least 8 characters.</p>
      <?= field_error('password') ?>
    </div>
    <div class="field">
      <label for="password_confirmation">Confirm new password</label>
      <input class="input" type="password" id="password_confirmation" name="password_confirmation" autocomplete="new-password" required minlength="8" maxlength="128">
    </div>
    <div class="form-actions">
      <?php if (empty($mustChange)): ?><a class="btn btn-light" href="<?= e(admin_url()) ?>">Cancel</a><?php endif; ?>
      <button class="btn btn-primary" type="submit">Update password</button>
    </div>
  </form>
</div>
