<?php $storeName = (string) setting('store_name', config('app.name')); ?>
<div class="auth-card">
  <h1>Welcome to <?= e($storeName) ?></h1>
  <?php if (empty($valid)): ?>
    <p class="sub">This invitation link is invalid, has expired or was already used. Ask your administrator to resend the invitation.</p>
    <a class="btn btn-primary btn-block" href="<?= e(admin_url('login')) ?>">Go to sign in</a>
  <?php else: ?>
    <p class="sub">Hi <?= e($inviteName) ?>, set a password to activate your staff account.</p>
    <form method="post" action="<?= e(admin_url('invite/' . $token)) ?>" data-loading novalidate>
      <?= csrf_field() ?>
      <div class="field">
        <label for="invite_email">Work email</label>
        <input class="input" type="email" id="invite_email" value="<?= e($inviteEmail) ?>" autocomplete="username" readonly>
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input class="input<?= errors('password') ? ' has-error' : '' ?>" type="password" id="password" name="password" autocomplete="new-password" required minlength="8" maxlength="128" autofocus>
        <p class="hint">At least 8 characters. A passphrase is easier to remember and harder to guess.</p>
        <?= field_error('password') ?>
      </div>
      <div class="field">
        <label for="password_confirmation">Confirm password</label>
        <input class="input" type="password" id="password_confirmation" name="password_confirmation" autocomplete="new-password" required minlength="8" maxlength="128">
      </div>
      <button class="btn btn-primary btn-block btn-lg" type="submit">Activate account</button>
    </form>
  <?php endif; ?>
</div>
