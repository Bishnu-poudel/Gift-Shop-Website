<?php $storeName = (string) setting('store_name', config('app.name')); ?>
<div class="auth-card">
  <p class="text-center" style="text-align:center;margin:0 0 var(--s-4)">
    <span class="brand-mark" style="display:inline-grid;place-items:center;width:52px;height:52px;border-radius:50%;background:var(--terracotta-tint);color:var(--terracotta)"><?= icon('gift') ?></span>
  </p>
  <h1><?= e($storeName) ?> Admin</h1>
  <p class="sub">Sign in with your staff account.</p>

  <form method="post" action="<?= e(admin_url('login')) ?>" data-loading novalidate>
    <?= csrf_field() ?>
    <div class="field">
      <label for="email">Work email</label>
      <input class="input<?= errors('email') ? ' has-error' : '' ?>" type="email" id="email" name="email" value="<?= e(old('email')) ?>" autocomplete="username" required autofocus maxlength="190">
      <?= field_error('email') ?>
    </div>
    <div class="field">
      <div class="row-between">
        <label for="password">Password</label>
        <a class="small" href="<?= e(admin_url('forgot-password')) ?>">Forgot password?</a>
      </div>
      <input class="input<?= errors('password') ? ' has-error' : '' ?>" type="password" id="password" name="password" autocomplete="current-password" required maxlength="128">
      <?= field_error('password') ?>
    </div>
    <button class="btn btn-primary btn-block btn-lg" type="submit"><?= icon('lock', 'icon-sm') ?> Sign in</button>
  </form>

  <p class="auth-alt"><?= icon('shield', 'icon-sm') ?> Staff accounts are created by invitation only.</p>
</div>
