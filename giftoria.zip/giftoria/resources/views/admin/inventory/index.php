<?php
/** Vars: $items, $total, $paginator, $filters, $summary */
?>
<div class="admin-page-head">
  <div>
    <h1>Inventory</h1>
    <p>Stock per product and variant. Every change is recorded as a movement with the staff member responsible.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light" href="<?= e(admin_url('inventory/movements')) ?>"><?= icon('clock', 'icon-sm') ?> Movement history</a>
    <?php if (can('suppliers.manage')): ?><a class="btn btn-light" href="<?= e(admin_url('suppliers/purchase-orders')) ?>"><?= icon('truck', 'icon-sm') ?> Purchase orders</a><?php endif; ?>
  </div>
</div>

<div class="kpis">
  <div class="kpi"><p class="label">Units on hand</p><div class="value"><?= e(number_format((int) ($summary['units'] ?? 0))) ?></div><div class="sub"><?= e(number_format((int) ($summary['items'] ?? 0))) ?> stock items</div></div>
  <div class="kpi"><p class="label">Low stock</p><div class="value"><?= e(number_format((int) ($summary['low'] ?? 0))) ?></div><div class="sub">At or below threshold</div></div>
  <div class="kpi"><p class="label">Out of stock</p><div class="value"><?= e(number_format((int) ($summary['out_of_stock'] ?? 0))) ?></div><div class="sub">Zero or less</div></div>
  <div class="kpi"><p class="label">Damaged (lifetime)</p><div class="value"><?= e(number_format((int) ($summary['damaged'] ?? 0))) ?></div><div class="sub">Units written off</div></div>
</div>

<form class="filter-bar" method="get" action="<?= e(admin_url('inventory')) ?>" role="search">
  <div class="field">
    <label for="i-q">Search</label>
    <input class="input" id="i-q" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Product, SKU or variant SKU">
  </div>
  <div class="field">
    <label for="i-status">Product status</label>
    <select class="select" id="i-status" name="status">
      <option value="">Any status</option>
      <?php foreach (['active' => 'Active', 'draft' => 'Draft', 'inactive' => 'Inactive'] as $k => $l): ?>
        <option value="<?= e($k) ?>" <?= $filters['status'] === $k ? 'selected' : '' ?>><?= e($l) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <label class="check" style="align-self:center;margin-bottom:8px"><input type="checkbox" name="low" value="1" <?= $filters['low'] ? 'checked' : '' ?>> Low stock only</label>
  <button class="btn btn-primary btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
  <?php if ($filters['q'] !== '' || $filters['low'] || $filters['status'] !== ''): ?><a class="btn btn-ghost btn-sm" href="<?= e(admin_url('inventory')) ?>">Clear</a><?php endif; ?>
</form>

<?php if (!$items): ?>
  <?= partial('components/empty-state', ['icon' => 'boxes', 'title' => 'No stock items found', 'text' => $filters['low'] ? 'Nothing is running low. Nice work.' : 'Stock rows are created automatically when products and variants are added.']) ?>
<?php else: ?>
<div class="card card-flush">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th scope="col">Product</th>
          <th scope="col">Variant</th>
          <th scope="col">SKU</th>
          <th scope="col" class="num">On hand</th>
          <th scope="col" class="num">Damaged</th>
          <th scope="col" class="num">Threshold</th>
          <th scope="col">Location</th>
          <th scope="col">Updated</th>
          <th scope="col"><span class="sr-only">Actions</span></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($items as $it):
          $qty = (int) $it['quantity'];
          $low = $qty <= (int) $it['low_stock_threshold'];
      ?>
        <tr<?= $low ? ' style="background:var(--warning-tint)"' : '' ?>>
          <td>
            <?php if (can('products.manage')): ?>
              <a class="row-link" href="<?= e(admin_url('products/' . (int) $it['product_id'] . '/edit')) ?>"><?= e($it['product_name']) ?></a>
            <?php else: ?>
              <strong><?= e($it['product_name']) ?></strong>
            <?php endif; ?>
            <?php if ($it['product_status'] !== 'active'): ?> <span class="status status-<?= e($it['product_status']) ?>"><?= e(status_label($it['product_status'])) ?></span><?php endif; ?>
          </td>
          <td><?= (int) $it['variant_id'] === 0 ? '<span class="muted">Base product</span>' : e($it['variant_name'] ?? 'Variant #' . (int) $it['variant_id']) ?><?= (int) $it['variant_id'] !== 0 && isset($it['variant_active']) && !(int) $it['variant_active'] ? ' <span class="muted small">(inactive)</span>' : '' ?></td>
          <td class="muted small"><?= e($it['variant_sku'] ?: $it['product_sku']) ?></td>
          <td class="num">
            <?php if ($qty <= 0): ?>
              <span class="badge badge-danger"><?= e((string) $qty) ?></span>
            <?php elseif ($low): ?>
              <span class="badge badge-warning"><?= e((string) $qty) ?> · Low</span>
            <?php else: ?>
              <strong><?= e(number_format($qty)) ?></strong>
            <?php endif; ?>
          </td>
          <td class="num"><?= (int) $it['damaged_quantity'] ?></td>
          <td class="num"><?= (int) $it['low_stock_threshold'] ?></td>
          <td><?= e($it['location'] ?: '—') ?></td>
          <td class="muted small"><?= e(local_date($it['updated_at'], 'M j, g:i A')) ?></td>
          <td><a class="btn btn-light btn-sm" href="<?= e(admin_url('inventory/' . (int) $it['id'])) ?>"><?= icon('sliders', 'icon-sm') ?> Adjust</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<p class="muted small"><?= e(number_format($total)) ?> stock item(s). Low-stock rows are highlighted.</p>
<?= $paginator->links() ?>
<?php endif; ?>
