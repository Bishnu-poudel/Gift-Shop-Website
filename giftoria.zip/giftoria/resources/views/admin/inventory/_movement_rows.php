<?php
/** Movement table rows. Vars: $movements, $showProduct (bool) */
$typeClass = [
    'sale' => 'status-processing', 'release' => 'status-refunded', 'adjustment' => 'status-pending', 'receive' => 'status-received',
    'return' => 'status-active', 'damage' => 'status-cancelled', 'initial' => 'status-confirmed',
];
foreach ($movements as $m):
    $change = (int) $m['change_qty'];
?>
<tr>
  <td class="muted small" style="white-space:nowrap"><?= e(local_date($m['created_at'], 'M j, Y g:i A')) ?></td>
  <?php if ($showProduct): ?>
  <td>
    <a class="row-link" href="<?= e(admin_url('inventory/movements?product=' . (int) $m['product_id'])) ?>"><?= e($m['product_name']) ?></a>
    <div class="muted small"><?= (int) $m['variant_id'] === 0 ? 'Base' : e($m['variant_name'] ?? 'Variant #' . (int) $m['variant_id']) ?> · <?= e($m['product_sku']) ?></div>
  </td>
  <?php endif; ?>
  <td><span class="status <?= e($typeClass[$m['type']] ?? '') ?>"><?= e(status_label($m['type'])) ?></span></td>
  <td class="num" style="color:<?= $change < 0 ? 'var(--danger)' : 'var(--success)' ?>;font-weight:600"><?= $change > 0 ? '+' : '' ?><?= e((string) $change) ?></td>
  <td class="num"><?= e((string) (int) $m['balance_after']) ?></td>
  <td>
    <?php if ($m['reference_type'] === 'order' && $m['reference_id']): ?>
      <?php if (can('orders.view')): ?>
        <a href="<?= e(admin_url('orders/' . (int) $m['reference_id'])) ?>">Order <?= e($m['order_number'] ?? '#' . (int) $m['reference_id']) ?></a>
      <?php else: ?>
        Order <?= e($m['order_number'] ?? '#' . (int) $m['reference_id']) ?>
      <?php endif; ?>
    <?php elseif ($m['reference_type'] === 'purchase_order' && $m['reference_id']): ?>
      <?php if (can('suppliers.manage')): ?>
        <a href="<?= e(admin_url('suppliers/purchase-orders/' . (int) $m['reference_id'])) ?>"><?= e($m['po_number'] ?? 'PO #' . (int) $m['reference_id']) ?></a>
      <?php else: ?>
        <?= e($m['po_number'] ?? 'PO #' . (int) $m['reference_id']) ?>
      <?php endif; ?>
    <?php elseif ($m['reference_type']): ?>
      <span class="muted"><?= e(ucfirst(str_replace('_', ' ', (string) $m['reference_type']))) ?></span>
    <?php else: ?>
      <span class="muted">—</span>
    <?php endif; ?>
  </td>
  <td><?= $m['user_name'] ? e($m['user_name']) : '<span class="muted">System / customer</span>' ?></td>
  <td class="small"><?= e($m['note'] ?? '') ?></td>
</tr>
<?php endforeach; ?>
