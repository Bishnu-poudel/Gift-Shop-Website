<?php
/** Vars: $item, $reasons, $history, $historyTotal */
$iid = (int) $item['id'];
$qty = (int) $item['quantity'];
$low = $qty <= (int) $item['low_stock_threshold'];
$hasOld = (bool) errors() && (old('mode', null) !== null || old('low_stock_threshold', null) !== null);
$mode = $hasOld ? (string) old('mode', 'delta') : 'delta';
?>
<div class="admin-page-head">
  <div>
    <p class="small"><a href="<?= e(admin_url('inventory')) ?>"><?= icon('chevron-left', 'icon-sm') ?> Inventory</a></p>
    <h1><?= e($item['product_name']) ?></h1>
    <p><?= (int) $item['variant_id'] === 0 ? 'Base product' : 'Variant: ' . e($item['variant_name'] ?? '#' . (int) $item['variant_id']) ?> · SKU <?= e($item['variant_sku'] ?: $item['product_sku']) ?><?= (int) $item['allow_backorder'] ? ' · backorders allowed' : '' ?></p>
  </div>
  <div class="admin-actions">
    <?php if (can('products.manage')): ?><a class="btn btn-light" href="<?= e(admin_url('products/' . (int) $item['product_id'] . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit product</a><?php endif; ?>
  </div>
</div>

<div class="kpis">
  <div class="kpi"><p class="label">On hand</p><div class="value" style="color:<?= $qty <= 0 ? 'var(--danger)' : ($low ? 'var(--warning)' : 'inherit') ?>"><?= e(number_format($qty)) ?></div><div class="sub"><?= $qty <= 0 ? 'Out of stock' : ($low ? 'Low stock' : 'Healthy') ?></div></div>
  <div class="kpi"><p class="label">Low-stock threshold</p><div class="value"><?= (int) $item['low_stock_threshold'] ?></div></div>
  <div class="kpi"><p class="label">Damaged (lifetime)</p><div class="value"><?= (int) $item['damaged_quantity'] ?></div></div>
  <div class="kpi"><p class="label">Location</p><div class="value" style="font-size:1.3rem"><?= e($item['location'] ?: '—') ?></div></div>
</div>

<div class="admin-grid admin-grid-2">
  <section class="card">
    <div class="card-head"><h2>Change by amount</h2></div>
    <form method="post" action="<?= e(admin_url('inventory/' . $iid . '/adjust')) ?>" data-loading>
      <?= csrf_field() ?>
      <input type="hidden" name="mode" value="delta">
      <div class="form-grid">
        <div class="field">
          <label for="a-reason">Reason *</label>
          <select class="select <?= errors('reason') ? 'has-error' : '' ?>" id="a-reason" name="reason" required>
            <?php foreach ($reasons as $k => $l): ?>
              <option value="<?= e($k) ?>" <?= $hasOld && $mode === 'delta' && old('reason') === $k ? 'selected' : '' ?>><?= e($l) ?></option>
            <?php endforeach; ?>
          </select>
          <?= field_error('reason') ?>
        </div>
        <div class="field">
          <label for="a-delta">Quantity *</label>
          <input class="input <?= errors('delta') ? 'has-error' : '' ?>" id="a-delta" name="delta" type="number" step="1" required value="<?= e($hasOld && $mode === 'delta' ? old('delta') : '') ?>">
          <p class="hint">Receive/return add, damage removes. For a correction, use a negative number to remove.</p>
          <?= field_error('delta') ?>
        </div>
        <div class="field span-2">
          <label for="a-note">Note</label>
          <input class="input <?= errors('note') ? 'has-error' : '' ?>" id="a-note" name="note" maxlength="255" value="<?= e($hasOld && $mode === 'delta' ? old('note') : '') ?>" placeholder="Required for corrections and damage">
          <?= field_error('note') ?>
        </div>
      </div>
      <div class="form-actions"><button class="btn btn-primary" type="submit">Apply change</button></div>
    </form>
  </section>

  <section class="card">
    <div class="card-head"><h2>Set counted quantity</h2></div>
    <p class="muted small">After a physical stock count, enter the real number. The difference is recorded as an adjustment.</p>
    <form method="post" action="<?= e(admin_url('inventory/' . $iid . '/adjust')) ?>" data-loading data-confirm="Set the stock to this exact quantity?">
      <?= csrf_field() ?>
      <input type="hidden" name="mode" value="set">
      <div class="form-grid">
        <div class="field">
          <label for="s-qty">Counted quantity *</label>
          <input class="input <?= errors('quantity') ? 'has-error' : '' ?>" id="s-qty" name="quantity" type="number" min="0" step="1" required value="<?= e($hasOld && $mode === 'set' ? old('quantity') : (string) max(0, $qty)) ?>">
          <?= field_error('quantity') ?>
        </div>
        <div class="field">
          <label for="s-note">Note</label>
          <input class="input" id="s-note" name="note" maxlength="200" placeholder="e.g. Monthly count">
        </div>
      </div>
      <div class="form-actions"><button class="btn btn-light" type="submit">Save count</button></div>
    </form>

    <h3 class="label mt-6">Threshold &amp; location</h3>
    <form method="post" action="<?= e(admin_url('inventory/' . $iid . '/settings')) ?>">
      <?= csrf_field() ?>
      <div class="form-grid">
        <div class="field">
          <label for="t-thr">Low-stock threshold</label>
          <input class="input <?= errors('low_stock_threshold') ? 'has-error' : '' ?>" id="t-thr" name="low_stock_threshold" type="number" min="0" value="<?= e($hasOld && old('low_stock_threshold', null) !== null ? old('low_stock_threshold') : (string) (int) $item['low_stock_threshold']) ?>">
          <?= field_error('low_stock_threshold') ?>
        </div>
        <div class="field">
          <label for="t-loc">Storage location</label>
          <input class="input <?= errors('location') ? 'has-error' : '' ?>" id="t-loc" name="location" maxlength="80" value="<?= e($hasOld && old('low_stock_threshold', null) !== null ? old('location') : (string) $item['location']) ?>" placeholder="e.g. Shelf B3">
          <?= field_error('location') ?>
        </div>
      </div>
      <div class="form-actions"><button class="btn btn-light" type="submit">Save settings</button></div>
    </form>
  </section>
</div>

<section class="card card-flush">
  <div class="card-head">
    <h2>Recent movements</h2>
    <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('inventory/movements?product=' . (int) $item['product_id'])) ?>">All <?= (int) $historyTotal ?> for this product <?= icon('arrow-right', 'icon-sm') ?></a>
  </div>
  <?php if (!$history): ?>
    <p class="muted" style="padding:0 var(--s-6) var(--s-6)">No movements recorded yet.</p>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th scope="col">When</th><th scope="col">Type</th><th scope="col" class="num">Change</th><th scope="col" class="num">Balance</th><th scope="col">Reference</th><th scope="col">By</th><th scope="col">Note</th></tr></thead>
      <tbody><?= partial('admin/inventory/_movement_rows', ['movements' => $history, 'showProduct' => false]) ?></tbody>
    </table>
  </div>
  <?php endif; ?>
</section>
