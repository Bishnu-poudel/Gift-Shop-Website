<?php
/** Vars: $movements, $total, $paginator, $products, $types, $filters */
$filtered = $filters['product'] || $filters['type'] !== '' || $filters['q'] !== '' || $filters['from'] !== '' || $filters['to'] !== '';
?>
<div class="admin-page-head">
  <div>
    <p class="small"><a href="<?= e(admin_url('inventory')) ?>"><?= icon('chevron-left', 'icon-sm') ?> Inventory</a></p>
    <h1>Stock movements</h1>
    <p>Every unit in or out, with the order, purchase order or staff member responsible.</p>
  </div>
</div>

<form class="filter-bar" method="get" action="<?= e(admin_url('inventory/movements')) ?>">
  <div class="field">
    <label for="m-product">Product</label>
    <select class="select" id="m-product" name="product" style="max-width:260px">
      <option value="">All products</option>
      <?php foreach ($products as $p): ?>
        <option value="<?= (int) $p['id'] ?>" <?= (int) $filters['product'] === (int) $p['id'] ? 'selected' : '' ?>><?= e($p['name'] . ' (' . $p['sku'] . ')') ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field">
    <label for="m-q">or search</label>
    <input class="input" id="m-q" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Name or SKU">
  </div>
  <div class="field">
    <label for="m-type">Type</label>
    <select class="select" id="m-type" name="type">
      <option value="">All types</option>
      <?php foreach ($types as $t): ?>
        <option value="<?= e($t) ?>" <?= $filters['type'] === $t ? 'selected' : '' ?>><?= e(status_label($t)) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field">
    <label for="m-from">From</label>
    <input class="input" id="m-from" type="date" name="from" value="<?= e($filters['from']) ?>">
  </div>
  <div class="field">
    <label for="m-to">To</label>
    <input class="input" id="m-to" type="date" name="to" value="<?= e($filters['to']) ?>">
  </div>
  <button class="btn btn-primary btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
  <?php if ($filtered): ?><a class="btn btn-ghost btn-sm" href="<?= e(admin_url('inventory/movements')) ?>">Clear</a><?php endif; ?>
</form>

<?php if (!$movements): ?>
  <?= partial('components/empty-state', ['icon' => 'clock', 'title' => 'No movements found', 'text' => $filtered ? 'Try widening the date range or clearing filters.' : 'Stock movements will appear here as orders are placed and stock is adjusted.']) ?>
<?php else: ?>
<div class="card card-flush">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr><th scope="col">When</th><th scope="col">Product</th><th scope="col">Type</th><th scope="col" class="num">Change</th><th scope="col" class="num">Balance</th><th scope="col">Reference</th><th scope="col">By</th><th scope="col">Note</th></tr>
      </thead>
      <tbody><?= partial('admin/inventory/_movement_rows', ['movements' => $movements, 'showProduct' => true]) ?></tbody>
    </table>
  </div>
</div>
<p class="muted small"><?= e(number_format($total)) ?> movement(s). Times shown in Nepal time.</p>
<?= $paginator->links() ?>
<?php endif; ?>
