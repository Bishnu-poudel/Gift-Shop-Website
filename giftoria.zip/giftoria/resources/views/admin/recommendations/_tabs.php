<?php /** Vars: $tab */ ?>
<div class="admin-page-head">
  <div>
    <h1>Gift Finder rules</h1>
    <p>Transparent, rule-based ranking. Hard filters (age safety, stock, budget, delivery area) run first; the weights below decide the order of what remains.</p>
  </div>
  <div class="admin-actions">
    <?php if (can('categories.manage')): ?>
      <a class="btn btn-light" href="<?= e(admin_url('taxonomies/synonyms')) ?>"><?= icon('tag', 'icon-sm') ?> Search synonyms</a>
    <?php endif; ?>
    <a class="btn btn-light" href="<?= e(url('/gift-finder')) ?>" target="_blank" rel="noopener"><?= icon('external', 'icon-sm') ?> Open Gift Finder</a>
  </div>
</div>
<nav class="tabs" aria-label="Gift Finder sections">
  <a href="<?= e(admin_url('recommendations')) ?>" class="<?= $tab === 'rules' ? 'is-active' : '' ?>">Rules &amp; test console</a>
  <a href="<?= e(admin_url('recommendations/insights')) ?>" class="<?= $tab === 'insights' ? 'is-active' : '' ?>">Feedback &amp; searches</a>
</nav>
