<?php
/**
 * @var array $weights @var bool $requireInterest @var bool $feedbackEnabled @var ?array $console
 * @var array $recipients @var array $occasions @var array $interests @var array $ageRanges @var array $budgets @var string $tab
 */
use App\Controllers\Admin\RecommendationsController;

$labels = RecommendationsController::WEIGHT_LABELS;
$hasOld = (bool) errors();
$oldWeights = $hasOld ? (array) old('weights', []) : [];
$in = $console['input'] ?? ['recipient' => '', 'occasion' => '', 'interests' => [], 'custom_interest' => '', 'age' => '', 'budget' => 0, 'min_price' => '', 'max_price' => '', 'strict_interests' => 0];
$fmt = static fn ($n) => rtrim(rtrim(number_format((float) $n, 2), '0'), '.');
?>
<?= partial('admin/recommendations/_tabs', ['tab' => $tab]) ?>

<div class="admin-grid admin-grid-2">
  <form class="card" method="post" action="<?= e(admin_url('recommendations/weights')) ?>">
    <?= csrf_field() ?>
    <div class="card-head"><h2>Scoring weights</h2><span class="muted small">0–50 each</span></div>
    <p class="muted small">Each component earns up to its weight. Components the shopper didn’t ask about are left out, and the result is scaled to 0–100.</p>
    <?= field_error('weights') ?>
    <?php foreach ($labels as $key => $label): $w = (int) ($oldWeights[$key] ?? $weights[$key]); ?>
      <div class="weight-row">
        <label for="w-<?= e($key) ?>"><?= e($label) ?></label>
        <input type="range" id="w-<?= e($key) ?>" name="weights[<?= e($key) ?>]" min="0" max="50" step="1" value="<?= $w ?>" data-range-output="wo-<?= e($key) ?>">
        <output id="wo-<?= e($key) ?>" for="w-<?= e($key) ?>" class="num" style="font-variant-numeric:tabular-nums;font-weight:600"><?= $w ?></output>
      </div>
    <?php endforeach; ?>
    <div style="margin-top:16px" class="stack">
      <label class="check"><input type="checkbox" name="reco_require_interest_match" value="1" <?= ($hasOld ? old('reco_require_interest_match') : $requireInterest) ? 'checked' : '' ?>>
        <span><strong>Require an interest match</strong><br><span class="muted small">When interests are chosen, only products tagged with at least one of them are shown (relaxed automatically if nothing matches).</span></span></label>
      <label class="check"><input type="checkbox" name="reco_feedback_enabled" value="1" <?= ($hasOld ? old('reco_feedback_enabled') : $feedbackEnabled) ? 'checked' : '' ?>>
        <span><strong>Use shopper feedback</strong><br><span class="muted small">Likes, dislikes and “more like this” adjust that shopper’s own rankings (hidden items are always excluded for them).</span></span></label>
    </div>
    <div class="form-actions">
      <button class="btn btn-primary" type="submit">Save rules</button>
    </div>
  </form>

  <form class="card" method="get" action="<?= e(admin_url('recommendations')) ?>">
    <input type="hidden" name="run" value="1">
    <div class="card-head"><h2>Test console</h2><span class="muted small">Runs the live engine</span></div>
    <div class="form-grid">
      <div class="field">
        <label for="t-recipient">Recipient</label>
        <select class="select" id="t-recipient" name="recipient">
          <option value="">Any</option>
          <?php foreach ($recipients as $r): ?><option value="<?= e($r['slug']) ?>" <?= $in['recipient'] === $r['slug'] ? 'selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="t-occasion">Occasion</label>
        <select class="select" id="t-occasion" name="occasion">
          <option value="">Any</option>
          <?php foreach ($occasions as $o): ?><option value="<?= e($o['slug']) ?>" <?= $in['occasion'] === $o['slug'] ? 'selected' : '' ?>><?= e($o['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="t-age">Age range</label>
        <select class="select" id="t-age" name="age">
          <option value="">From recipient / any</option>
          <?php foreach ($ageRanges as $a): ?><option value="<?= e($a['slug']) ?>" <?= $in['age'] === $a['slug'] ? 'selected' : '' ?>><?= e($a['label']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="t-budget">Budget</label>
        <select class="select" id="t-budget" name="budget">
          <option value="">Any / custom</option>
          <?php foreach ($budgets as $b): ?><option value="<?= (int) $b['id'] ?>" <?= (int) $in['budget'] === (int) $b['id'] ? 'selected' : '' ?>><?= e($b['label']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label for="t-min">Min price (NPR)</label>
        <input class="input" id="t-min" name="min_price" type="number" min="0" step="1" value="<?= e($in['min_price']) ?>">
      </div>
      <div class="field">
        <label for="t-max">Max price (NPR)</label>
        <input class="input" id="t-max" name="max_price" type="number" min="0" step="1" value="<?= e($in['max_price']) ?>">
      </div>
      <div class="field span-2">
        <label for="t-interests">Interests</label>
        <select class="select" id="t-interests" name="interests[]" multiple size="5" style="height:auto;background-image:none">
          <?php foreach ($interests as $i): ?><option value="<?= e($i['slug']) ?>" <?= in_array($i['slug'], (array) $in['interests'], true) ? 'selected' : '' ?>><?= e($i['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="field span-2">
        <label for="t-custom">Free-text interest</label>
        <input class="input" id="t-custom" name="custom_interest" value="<?= e($in['custom_interest']) ?>" maxlength="80" placeholder="e.g. loves trekking and tea">
      </div>
      <div class="field span-2">
        <label class="check"><input type="checkbox" name="strict_interests" value="1" <?= !empty($in['strict_interests']) ? 'checked' : '' ?>> <span>Strict interest match for this test</span></label>
      </div>
    </div>
    <div class="form-actions">
      <a class="btn btn-ghost" href="<?= e(admin_url('recommendations')) ?>">Reset</a>
      <button class="btn btn-accent" type="submit"><?= icon('sparkles', 'icon-sm') ?> Run test</button>
    </div>
  </form>
</div>

<?php if (!empty($consoleError)): ?>
  <div class="alert alert-error" role="alert"><?= icon('alert') ?><div><?= e($consoleError) ?></div></div>
<?php endif; ?>
<?php if ($console): $res = $console['result']; $crit = $res['criteria']; ?>
<div class="card card-flush">
  <div class="card-head">
    <h2>Top <?= count($res['items']) ?> of <?= number_format((int) $res['total']) ?> matching product(s)</h2>
    <span class="muted small">Neutral ranking (no shopper feedback). Weights in use: <?= e(implode(' · ', array_map(static fn ($k) => $labels[$k] . ' ' . $weights[$k], array_keys($labels)))) ?></span>
  </div>
  <div style="padding:0 24px">
    <?php foreach ($res['relaxed'] as $msg): ?><div class="alert alert-warning"><?= icon('alert') ?><div><?= e($msg) ?></div></div><?php endforeach; ?>
    <p class="small muted">
      Interpreted criteria:
      recipient <strong><?= e($crit['recipient'] ?: 'any') ?></strong>,
      occasion <strong><?= e($crit['occasion'] ?: 'any') ?></strong>,
      interests <strong><?= e($crit['interests'] ? implode(', ', $crit['interests']) : 'none') ?></strong><?= $crit['keywords'] ? ', keywords <strong>' . e(implode(', ', $crit['keywords'])) . '</strong>' : '' ?>,
      age <strong><?= $crit['age_min_months'] !== null ? e(age_range_label($crit['age_min_months'], $crit['age_max_months'])) : 'any' ?></strong>,
      price <strong><?= $crit['min_price'] !== null || $crit['max_price'] !== null ? e(money($crit['min_price'] ?? 0) . ' – ' . ($crit['max_price'] !== null ? money($crit['max_price']) : 'no max')) : 'any' ?></strong>,
      strict interests <strong><?= $crit['strict_interests'] ? 'yes' : 'no' ?></strong>.
      <?php if (!empty($crit['corrections'])): ?><br>Typo corrections: <?= e(implode(', ', array_map(static fn ($k, $v) => $k . ' → ' . (is_scalar($v) ? $v : ''), array_keys($crit['corrections']), $crit['corrections']))) ?><?php endif; ?>
    </p>
  </div>
  <?php if (!$res['items']): ?>
    <div style="padding:0 24px 24px">
      <?= partial('components/empty-state', ['icon' => 'search', 'title' => 'No products match', 'text' => 'Hard filters removed every product. Try a wider budget or age range, or check product tagging.']) ?>
      <?php if (!empty($res['suggestions']['interests'])): ?>
        <p class="small">Interests that do have products here: <?= e(implode(', ', array_map(static fn ($i) => $i['name'] . ' (' . (int) $i['n'] . ')', $res['suggestions']['interests']))) ?></p>
      <?php endif; ?>
    </div>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead>
      <tr>
        <th>#</th><th>Product</th><th class="num">Score</th>
        <?php foreach ($labels as $k => $l): ?><th class="num" title="<?= e($l) ?>"><?= e(ucfirst($k)) ?><br><span class="muted" style="font-weight:400">/<?= (int) $weights[$k] ?></span></th><?php endforeach; ?>
        <th class="num">Adj.</th>
        <th>Why it ranks</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($res['items'] as $i => $p): $b = $p['score_breakdown']; $adj = (float) ($b['feedback'] ?? 0) + (float) ($b['similar'] ?? 0); ?>
      <tr>
        <td class="num"><?= $i + 1 ?></td>
        <td style="min-width:200px">
          <a class="row-link" href="<?= e(url('/product/' . $p['slug'])) ?>" target="_blank" rel="noopener"><?= e($p['name']) ?></a>
          <div class="muted small"><?= e($p['sku']) ?> · <?= e(money($p['effective_price'])) ?> · stock <?= (int) $p['stock'] ?></div>
        </td>
        <td class="num"><strong><?= e($fmt($p['score'])) ?></strong></td>
        <?php foreach (array_keys($labels) as $k): ?>
          <td class="num"><?= array_key_exists($k, $b) ? e($fmt($b[$k])) : '<span class="muted" title="Not requested — excluded from the score">—</span>' ?></td>
        <?php endforeach; ?>
        <td class="num"><?= $adj != 0 ? e(($adj > 0 ? '+' : '') . $fmt($adj)) : '<span class="muted">0</span>' ?></td>
        <td class="small" style="min-width:220px"><?= $p['reasons'] ? e(implode(' · ', $p['reasons'])) : '<span class="muted">No specific match reasons</span>' ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <p class="muted small" style="padding:12px 24px">Score = earned points ÷ points possible for the requested components × 100, then feedback/similarity adjustments, clamped to 0–100. “—” means the component wasn’t requested and is not counted.</p>
  <?php endif; ?>
</div>
<?php endif; ?>
