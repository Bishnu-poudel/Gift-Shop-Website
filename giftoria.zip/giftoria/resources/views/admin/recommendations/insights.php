<?php
/**
 * @var array $feedback @var array $hidden @var array $sessionStats @var array $sessions @var bool $zeroOnly
 * @var array $names @var bool $feedbackEnabled @var string $tab
 */
$actionLabels = ['like' => 'Liked', 'dislike' => 'Disliked', 'hide' => 'Hidden', 'more_like_this' => 'More like this', 'wishlist' => 'Wishlisted'];
$totalSessions = (int) ($sessionStats['total'] ?? 0);
$zero = (int) ($sessionStats['zero'] ?? 0);
$describe = static function (array $c) use ($names): string {
    $parts = [];
    if (!empty($c['recipient'])) {
        $parts[] = 'for ' . ($names['recipient'][$c['recipient']] ?? $c['recipient']);
    }
    if (!empty($c['occasion'])) {
        $parts[] = ($names['occasion'][$c['occasion']] ?? $c['occasion']);
    }
    if (!empty($c['interests'])) {
        $parts[] = 'likes ' . implode(', ', array_map(static fn ($s) => $names['interest'][$s] ?? $s, (array) $c['interests']));
    }
    if (!empty($c['custom_interest'])) {
        $parts[] = '“' . $c['custom_interest'] . '”';
    }
    if (!empty($c['age'])) {
        $parts[] = 'age ' . $c['age'];
    }
    $min = $c['min_price'] ?? null;
    $max = $c['max_price'] ?? null;
    if ($min !== null || $max !== null) {
        $parts[] = money($min ?? 0) . '–' . ($max !== null ? money($max) : 'any');
    }
    if (!empty($c['prefs'])) {
        $parts[] = implode(', ', (array) $c['prefs']);
    }
    if (!empty($c['district'])) {
        $parts[] = 'to ' . $c['district'];
    }
    return $parts ? implode(' · ', $parts) : 'No criteria';
};
?>
<?= partial('admin/recommendations/_tabs', ['tab' => $tab]) ?>

<?php if (!$feedbackEnabled): ?>
  <div class="alert alert-warning"><?= icon('alert') ?><div>Shopper feedback is currently <strong>not used</strong> for ranking. It is still recorded, and hidden items stay hidden for the shopper who hid them.</div></div>
<?php endif; ?>

<div class="kpis">
  <div class="kpi"><p class="label">Finder searches (30 days)</p><div class="value"><?= number_format($totalSessions) ?></div></div>
  <div class="kpi"><p class="label">Zero-result searches</p><div class="value"><?= number_format($zero) ?></div><div class="sub"><?= $totalSessions ? e(round($zero / $totalSessions * 100, 1) . '% of searches') : '—' ?></div></div>
  <div class="kpi"><p class="label">Avg. results per search</p><div class="value"><?= $totalSessions ? e(number_format((float) $sessionStats['avg_results'], 1)) : '—' ?></div></div>
  <div class="kpi"><p class="label">Feedback signals</p><div class="value"><?= number_format(array_sum(array_map(static fn ($f) => (int) $f['total'], $feedback))) ?></div><div class="sub">All time</div></div>
</div>

<div class="admin-grid admin-grid-2">
  <div class="card card-flush">
    <div class="card-head"><h2>Feedback by action</h2></div>
    <?php if (!$feedback): ?>
      <p class="muted small" style="padding:0 24px 24px">No feedback recorded yet.</p>
    <?php else: ?>
    <table class="data-table">
      <thead><tr><th>Action</th><th class="num">Last 30 days</th><th class="num">All time</th></tr></thead>
      <tbody>
      <?php foreach ($feedback as $f): ?>
        <tr><td><?= e($actionLabels[$f['action']] ?? $f['action']) ?></td><td class="num"><?= number_format((int) $f['last_30']) ?></td><td class="num"><?= number_format((int) $f['total']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

  <div class="card card-flush">
    <div class="card-head"><h2>Most hidden products</h2><span class="muted small">Check tagging or age ranges</span></div>
    <?php if (!$hidden): ?>
      <p class="muted small" style="padding:0 24px 24px">No products have been hidden by shoppers.</p>
    <?php else: ?>
    <table class="data-table">
      <thead><tr><th>Product</th><th class="num">Hidden</th><th class="num">Disliked</th><th class="num">Positive</th></tr></thead>
      <tbody>
      <?php foreach ($hidden as $h): ?>
        <tr>
          <td>
            <?php if (can('products.manage')): ?><a class="row-link" href="<?= e(admin_url('products/' . (int) $h['id'] . '/edit')) ?>"><?= e($h['name']) ?></a><?php else: ?><strong><?= e($h['name']) ?></strong><?php endif; ?>
            <div class="muted small"><?= e($h['sku']) ?><?= $h['status'] !== 'active' ? ' · ' . e($h['status']) : '' ?></div>
          </td>
          <td class="num"><strong><?= number_format((int) $h['hides']) ?></strong></td>
          <td class="num"><?= number_format((int) $h['dislikes']) ?></td>
          <td class="num"><?= number_format((int) $h['positives']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>

<div class="card card-flush">
  <div class="card-head">
    <h2>Recent Gift Finder searches</h2>
    <div class="row" style="gap:8px">
      <a class="btn btn-sm <?= $zeroOnly ? 'btn-light' : 'btn-primary' ?>" href="<?= e(admin_url('recommendations/insights')) ?>">All</a>
      <a class="btn btn-sm <?= $zeroOnly ? 'btn-primary' : 'btn-light' ?>" href="<?= e(admin_url('recommendations/insights?zero=1')) ?>">Zero results only</a>
    </div>
  </div>
  <?php if (!$sessions): ?>
    <p class="muted small" style="padding:0 24px 24px">No searches recorded<?= $zeroOnly ? ' with zero results' : '' ?>.</p>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead><tr><th>When (NPT)</th><th>Criteria</th><th>Shopper</th><th class="num">Results</th></tr></thead>
    <tbody>
    <?php foreach ($sessions as $s): $isZero = (int) $s['result_count'] === 0; ?>
      <tr style="<?= $isZero ? 'background:var(--danger-tint)' : '' ?>">
        <td class="small" style="white-space:nowrap"><?= e(local_date($s['created_at'])) ?></td>
        <td class="small"><?= e($describe($s['criteria'])) ?></td>
        <td class="small"><?= $s['user_id'] ? 'Signed in' : '<span class="muted">Guest</span>' ?></td>
        <td class="num"><?= $isZero ? '<span class="status status-failed">0 results</span>' : number_format((int) $s['result_count']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <p class="muted small" style="padding:12px 24px">Zero-result searches often point to missing taxonomy tags or synonyms. Add phrases under <?php if (can('categories.manage')): ?><a href="<?= e(admin_url('taxonomies/synonyms')) ?>">search synonyms</a><?php else: ?>search synonyms (Catalog)<?php endif; ?>.</p>
  <?php endif; ?>
</div>
