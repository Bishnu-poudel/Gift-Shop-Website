<?php
/** Vars: $tab, $range, $group, $rows, $extra, $canFinance */
use App\Controllers\Admin\ReportsController;
use App\Repositories\Admin\OrderAdminRepository;

$base = ['from' => $range['from'], 'to' => $range['to']];
$tabUrl = static fn (string $t) => admin_url('reports') . '?' . http_build_query($base + ['tab' => $t] + ($t === 'sales' ? ['group' => $group] : []));
$exportUrl = admin_url('reports/export/' . $tab) . '?' . http_build_query($base + ($tab === 'sales' ? ['group' => $group] : []));
$sum = static fn (string $k) => array_sum(array_map(static fn ($r) => (float) $r[$k], $rows));
$margin = static fn (array $r) => (int) $r['missing_cost'] > 0 ? null : (float) $r['revenue'] - (float) $r['cost'];
$rangeLabel = date('M j, Y', strtotime($range['from'])) . ' – ' . date('M j, Y', strtotime($range['to']));
?>
<div class="admin-page-head">
  <div>
    <h1>Reports</h1>
    <p><?= e($rangeLabel) ?> · Nepal time. Paid figures use the payment date; product and category figures use confirmed orders by order date.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light btn-sm" href="<?= e($exportUrl) ?>"><?= icon('download', 'icon-sm') ?> Export this report (CSV)</a>
    <?php if ($canFinance): ?>
      <a class="btn btn-primary btn-sm" href="<?= e(admin_url('reports/export-finance') . '?' . http_build_query($base)) ?>"><?= icon('download', 'icon-sm') ?> Finance ledger (CSV)</a>
    <?php endif; ?>
  </div>
</div>

<nav class="tabs" aria-label="Report type">
  <?php foreach (ReportsController::TABS as $k => $label): ?>
    <a href="<?= e($tabUrl($k)) ?>" class="<?= $tab === $k ? 'is-active' : '' ?>"><?= e($label) ?></a>
  <?php endforeach; ?>
</nav>

<form class="filter-bar" method="get" action="<?= e(admin_url('reports')) ?>">
  <input type="hidden" name="tab" value="<?= e($tab) ?>">
  <div class="field"><label for="r-from">From</label><input class="input" type="date" id="r-from" name="from" value="<?= e($range['from']) ?>"></div>
  <div class="field"><label for="r-to">To</label><input class="input" type="date" id="r-to" name="to" value="<?= e($range['to']) ?>"></div>
  <?php if ($tab === 'sales'): ?>
    <div class="field"><label for="r-group">Group by</label>
      <select class="select" id="r-group" name="group">
        <option value="day" <?= $group === 'day' ? 'selected' : '' ?>>Day</option>
        <option value="month" <?= $group === 'month' ? 'selected' : '' ?>>Month</option>
      </select>
    </div>
  <?php endif; ?>
  <button class="btn btn-primary btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Apply</button>
</form>

<?php if ($tab === 'sales'):
    $series = $extra['series'];
    $chart = [
        'type' => $group === 'month' ? 'bar' : 'line',
        'labels' => array_map(static fn ($p) => $group === 'month' ? date('M Y', strtotime($p . '-01')) : date('M j', strtotime($p)), array_keys($series)),
        'datasets' => [['label' => 'Net paid revenue (NPR)', 'data' => array_map(static fn ($s) => round($s['revenue'], 2), array_values($series))]],
    ];
?>
  <div class="kpis">
    <div class="kpi"><p class="label">Paid orders</p><div class="value"><?= number_format((int) $sum('orders')) ?></div></div>
    <div class="kpi"><p class="label">Gross</p><div class="value"><?= e(money($sum('gross'))) ?></div><div class="sub">Discounts <?= e(money($sum('discount'))) ?></div></div>
    <div class="kpi"><p class="label">Refunded</p><div class="value"><?= e(money($sum('refunded'))) ?></div></div>
    <div class="kpi"><p class="label">Net</p><div class="value"><?= e(money($sum('net'))) ?></div><div class="sub"><?= $sum('orders') > 0 ? 'AOV ' . e(money($sum('net') / $sum('orders'))) : 'No paid orders' ?></div></div>
  </div>
  <div class="card">
    <div class="card-head"><h2>Net paid revenue by <?= e($group) ?></h2></div>
    <div class="chart-box"><canvas data-chart='<?= json_attr($chart) ?>' role="img" aria-label="Revenue chart"></canvas></div>
  </div>
  <div class="card card-flush">
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th><?= $group === 'month' ? 'Month' : 'Day' ?></th><th class="num">Orders</th><th class="num">Subtotal</th><th class="num">Discounts</th><th class="num">Shipping</th><th class="num">Gift wrap</th><th class="num">Gross</th><th class="num">Refunded</th><th class="num">Net</th><th class="num">Item cost</th><th class="num">Item margin</th></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="11" class="muted">No paid orders in this range.</td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= e($group === 'month' ? date('M Y', strtotime($r['period'] . '-01')) : date('D, M j, Y', strtotime($r['period']))) ?></td>
            <td class="num"><?= (int) $r['orders'] ?></td>
            <td class="num"><?= e(money($r['subtotal'])) ?></td>
            <td class="num"><?= e(money($r['discount'])) ?></td>
            <td class="num"><?= e(money($r['shipping'])) ?></td>
            <td class="num"><?= e(money($r['gift_wrap'])) ?></td>
            <td class="num"><?= e(money($r['gross'])) ?></td>
            <td class="num"><?= e(money($r['refunded'])) ?></td>
            <td class="num"><strong><?= e(money($r['net'])) ?></strong></td>
            <td class="num"><?= e(money($r['cost'])) ?></td>
            <td class="num"><?= (int) $r['missing_cost'] > 0 ? '<span class="muted" title="' . (int) $r['missing_cost'] . ' item lines have no cost price">' . e(money($r['item_margin'])) . '*</span>' : e(money($r['item_margin'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <p class="muted small">Item margin = subtotal − discounts − recorded item cost. * Some items lack a cost price, so the margin is overstated.</p>

<?php elseif ($tab === 'products' || $tab === 'categories'): ?>
  <div class="card card-flush">
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>#</th><th><?= $tab === 'products' ? 'Product' : 'Category' ?></th><th class="num">Units</th><th class="num">Orders</th><th class="num">Revenue</th><th class="num">Item cost</th><th class="num">Margin</th><th class="num">Margin %</th></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="8" class="muted">No confirmed orders in this range.</td></tr><?php endif; ?>
        <?php foreach ($rows as $i => $r): $m = $margin($r); ?>
          <tr>
            <td class="muted"><?= $i + 1 ?></td>
            <td><?= e($r['name'] ?? '—') ?><?php if ($tab === 'products' && !empty($r['sku'])): ?><div class="muted small"><?= e($r['sku']) ?></div><?php endif; ?></td>
            <td class="num"><?= (int) $r['units'] ?></td>
            <td class="num"><?= (int) $r['orders'] ?></td>
            <td class="num"><?= e(money($r['revenue'])) ?></td>
            <td class="num"><?= $r['cost'] !== null ? e(money($r['cost'])) : '—' ?></td>
            <td class="num"><?= $m !== null ? e(money($m)) : '<span class="muted">n/a</span>' ?></td>
            <td class="num"><?= $m !== null && (float) $r['revenue'] > 0 ? e(number_format($m / (float) $r['revenue'] * 100, 1)) . '%' : '—' ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <p class="muted small">Revenue is item line totals before order-level discounts. Margin shows “n/a” when any sold item lacks a cost price.</p>

<?php elseif ($tab === 'coupons'): ?>
  <div class="card card-flush">
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Code</th><th>Type</th><th class="num">Redemptions</th><th class="num">Placed orders</th><th class="num">Discount given</th><th class="num">Order revenue</th><th class="num">Avg discount</th></tr></thead>
        <tbody>
        <?php if (!$rows): ?><tr><td colspan="7" class="muted">No coupon redemptions in this range.</td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><strong><?= e($r['code']) ?></strong> <?php if (!(int) $r['is_active']): ?><span class="status status-inactive">Inactive</span><?php endif; ?></td>
            <td><?= e($r['type'] === 'percent' ? rtrim(rtrim((string) $r['value'], '0'), '.') . '%' : ($r['type'] === 'fixed' ? money($r['value']) : 'Free shipping')) ?></td>
            <td class="num"><?= (int) $r['uses'] ?></td>
            <td class="num"><?= (int) $r['placed'] ?></td>
            <td class="num"><?= e(money($r['discount'])) ?></td>
            <td class="num"><?= e(money($r['revenue'])) ?></td>
            <td class="num"><?= (int) $r['uses'] > 0 ? e(money((float) $r['discount'] / (int) $r['uses'])) : '—' ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

<?php else: ?>
  <div class="card card-flush">
    <div class="card-head"><h2>Orders by payment method</h2><span class="muted small">Orders created in range</span></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Method</th><th class="num">Orders</th><th class="num">Paid</th><th class="num">Cancelled</th><th class="num">Net paid revenue</th><th class="num">Share of orders</th></tr></thead>
        <tbody>
        <?php $allOrders = (int) $sum('orders'); ?>
        <?php if (!$rows): ?><tr><td colspan="6" class="muted">No orders in this range.</td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= e(OrderAdminRepository::PAYMENT_METHODS[$r['payment_method']] ?? $r['payment_method']) ?></td>
            <td class="num"><?= (int) $r['orders'] ?></td>
            <td class="num"><?= (int) $r['paid_orders'] ?></td>
            <td class="num"><?= (int) $r['cancelled'] ?></td>
            <td class="num"><?= e(money($r['net'])) ?></td>
            <td class="num"><?= $allOrders > 0 ? e(number_format((int) $r['orders'] / $allOrders * 100, 1)) . '%' : '—' ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card card-flush">
    <div class="card-head"><h2>Gateway attempts</h2><span class="muted small">Attempts started in range</span></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Gateway</th><th class="num">Attempts</th><th class="num">Succeeded</th><th class="num">Failed</th><th class="num">Cancelled / expired</th><th class="num">Still open</th><th class="num">Captured</th></tr></thead>
        <tbody>
        <?php if (!$extra['attempts']): ?><tr><td colspan="7" class="muted">No payment attempts in this range.</td></tr><?php endif; ?>
        <?php foreach ($extra['attempts'] as $g): ?>
          <tr>
            <td><?= e(strtoupper($g['gateway'])) ?></td>
            <td class="num"><?= (int) $g['attempts'] ?></td>
            <td class="num"><?= (int) $g['succeeded'] ?></td>
            <td class="num"><?= (int) $g['failed'] ?></td>
            <td class="num"><?= (int) $g['abandoned'] ?></td>
            <td class="num"><?= (int) $g['open_attempts'] ?></td>
            <td class="num"><?= e(money($g['amount'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endif; ?>
