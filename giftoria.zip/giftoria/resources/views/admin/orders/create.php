<?php
/** Vars: $products, $provinces, $methods, $token, $canSeeCost */
$oldItems = old('items', []);
$oldItems = is_array($oldItems) ? array_values($oldItems) : [];
$rows = max(6, count($oldItems));
$oldProvince = (string) old('province', '');
$oldDistrict = (string) old('district', '');
$oldMethod = (string) old('payment_method', array_key_first($methods) ?? '');
?>
<div class="admin-page-head">
  <div>
    <p class="small"><a href="<?= e(admin_url('orders')) ?>">&larr; Orders</a></p>
    <h1>Create manual order</h1>
    <p>For phone, social or walk-in orders. Prices, stock, coupons and delivery fees are recalculated on the server exactly as at web checkout.</p>
  </div>
</div>

<?php if (!$methods): ?>
  <div class="alert alert-warning"><?= icon('alert') ?><div>No payment methods are enabled. Enable eSewa, Khalti or cash on delivery in the environment configuration first.</div></div>
<?php endif; ?>

<form method="post" action="<?= e(admin_url('orders/create')) ?>" data-loading>
  <?= csrf_field() ?>
  <input type="hidden" name="checkout_token" value="<?= e($token) ?>">

  <div class="admin-grid admin-grid-3-1">
    <div>
      <div class="card">
        <div class="card-head"><h2>Products</h2><span class="muted small">Leave unused rows empty</span></div>
        <?php if (!$products): ?><p class="muted">There are no active products to sell.</p><?php endif; ?>
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr><th style="min-width:280px">Product / option</th><th style="width:110px">Qty</th><th style="min-width:180px">Personalization</th></tr></thead>
            <tbody>
            <?php for ($i = 0; $i < $rows; $i++):
                $sel = (string) ($oldItems[$i]['product'] ?? '');
                $qty = (string) ($oldItems[$i]['quantity'] ?? '1');
                $pers = (string) ($oldItems[$i]['personalization'] ?? '');
            ?>
              <tr>
                <td>
                  <label class="sr-only" for="item-<?= $i ?>">Product <?= $i + 1 ?></label>
                  <select class="select" id="item-<?= $i ?>" name="items[<?= $i ?>][product]">
                    <option value="">— Select product —</option>
                    <?php foreach ($products as $p):
                        $val = (int) $p['product_id'] . ':' . (int) $p['variant_id'];
                        $unit = ($p['sale_price'] !== null ? (float) $p['sale_price'] : (float) $p['price']) + (float) $p['price_adjustment'];
                        $stockLabel = (int) $p['stock'] > 0 ? (int) $p['stock'] . ' in stock' : ((int) $p['allow_backorder'] ? 'backorder' : 'out of stock');
                    ?>
                      <option value="<?= e($val) ?>" <?= $sel === $val ? 'selected' : '' ?> <?= (int) $p['stock'] <= 0 && !(int) $p['allow_backorder'] ? 'disabled' : '' ?>>
                        <?= e($p['name'] . ($p['variant_name'] ? ' — ' . $p['variant_name'] : '') . ' · ' . money($unit) . ' · ' . $stockLabel . ' · ' . $p['sku']) ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </td>
                <td><input class="input" type="number" min="1" max="100" name="items[<?= $i ?>][quantity]" value="<?= e($qty) ?>" aria-label="Quantity <?= $i + 1 ?>"></td>
                <td><input class="input" type="text" maxlength="255" name="items[<?= $i ?>][personalization]" value="<?= e($pers) ?>" aria-label="Personalization <?= $i + 1 ?>" placeholder="If personalizable"></td>
              </tr>
            <?php endfor; ?>
            </tbody>
          </table>
        </div>
        <p class="muted small mt-2">Personalization is only kept for personalizable products. Out-of-stock items without backorder are disabled.</p>
      </div>

      <div class="card">
        <div class="card-head"><h2>Delivery address</h2></div>
        <div class="form-grid">
          <div class="field"><label for="m-full">Recipient name</label><input class="input" id="m-full" name="full_name" maxlength="120" value="<?= e(old('full_name')) ?>" placeholder="Defaults to customer name"><?= field_error('full_name') ?></div>
          <div class="field"><label for="m-aphone">Recipient phone</label><input class="input" id="m-aphone" name="address_phone" maxlength="20" value="<?= e(old('address_phone')) ?>" placeholder="Defaults to customer phone"><?= field_error('address_phone') ?></div>
          <div class="field"><label for="m-prov">Province</label>
            <select class="select" id="m-prov" name="province" required data-province-select data-district-target="m-dist" data-districts='<?= json_attr($provinces) ?>'>
              <option value="">Select province</option>
              <?php foreach (array_keys($provinces) as $prov): ?><option value="<?= e($prov) ?>" <?= $oldProvince === $prov ? 'selected' : '' ?>><?= e($prov) ?></option><?php endforeach; ?>
            </select><?= field_error('province') ?>
          </div>
          <div class="field"><label for="m-dist">District</label>
            <select class="select" id="m-dist" name="district" required data-selected="<?= e($oldDistrict) ?>">
              <option value="">Select district</option>
              <?php if ($oldProvince !== '' && isset($provinces[$oldProvince])): foreach ($provinces[$oldProvince] as $d): ?>
                <option value="<?= e($d) ?>" <?= $oldDistrict === $d ? 'selected' : '' ?>><?= e($d) ?></option>
              <?php endforeach; endif; ?>
            </select><?= field_error('district') ?>
          </div>
          <div class="field"><label for="m-mun">Municipality</label><input class="input" id="m-mun" name="municipality" maxlength="100" required value="<?= e(old('municipality')) ?>"><?= field_error('municipality') ?></div>
          <div class="field"><label for="m-ward">Ward</label><input class="input" id="m-ward" name="ward" maxlength="10" value="<?= e(old('ward')) ?>"><?= field_error('ward') ?></div>
          <div class="field"><label for="m-street">Street / tole</label><input class="input" id="m-street" name="street" maxlength="190" value="<?= e(old('street')) ?>"><?= field_error('street') ?></div>
          <div class="field"><label for="m-land">Landmark</label><input class="input" id="m-land" name="landmark" maxlength="190" value="<?= e(old('landmark')) ?>"><?= field_error('landmark') ?></div>
        </div>
      </div>
    </div>

    <div>
      <div class="card">
        <div class="card-head"><h2>Customer</h2></div>
        <div class="field"><label for="m-name">Name</label><input class="input" id="m-name" name="customer_name" maxlength="120" required value="<?= e(old('customer_name')) ?>"><?= field_error('customer_name') ?></div>
        <div class="field"><label for="m-email">Email</label><input class="input" type="email" id="m-email" name="email" maxlength="190" required value="<?= e(old('email')) ?>"><?= field_error('email') ?>
          <p class="hint">If a customer account uses this email, the order is linked to it.</p></div>
        <div class="field"><label for="m-phone">Phone</label><input class="input" type="tel" id="m-phone" name="phone" maxlength="20" required value="<?= e(old('phone')) ?>"><?= field_error('phone') ?></div>
      </div>

      <div class="card">
        <div class="card-head"><h2>Payment &amp; extras</h2></div>
        <div class="field"><label for="m-pm">Payment method</label>
          <select class="select" id="m-pm" name="payment_method" required>
            <?php foreach ($methods as $k => $label): ?><option value="<?= e($k) ?>" <?= $oldMethod === $k ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?>
          </select><?= field_error('payment_method') ?>
          <p class="hint">Cash on delivery confirms the order immediately. eSewa/Khalti create a payment link for the customer.</p>
        </div>
        <div class="field"><label for="m-coupon">Coupon code</label><input class="input" id="m-coupon" name="coupon_code" maxlength="40" value="<?= e(old('coupon_code')) ?>"><?= field_error('coupon_code') ?></div>
        <label class="check mb-4"><input type="checkbox" name="gift_wrap" value="1" <?= old('gift_wrap') ? 'checked' : '' ?>> Gift wrap (fee applied if any item supports it)</label>
        <div class="field"><label for="m-gm">Gift message</label><textarea class="textarea" id="m-gm" name="gift_message" maxlength="500" rows="2"><?= e(old('gift_message')) ?></textarea><?= field_error('gift_message') ?></div>
        <div class="field"><label for="m-date">Requested delivery date</label><input class="input" type="date" id="m-date" name="requested_delivery_date" min="<?= e(local_today()) ?>" value="<?= e(old('requested_delivery_date')) ?>"><?= field_error('requested_delivery_date') ?></div>
        <div class="field"><label for="m-note">Customer note</label><textarea class="textarea" id="m-note" name="customer_note" maxlength="500" rows="2"><?= e(old('customer_note')) ?></textarea><?= field_error('customer_note') ?></div>
        <button class="btn btn-primary btn-block" type="submit" <?= $methods ? '' : 'disabled' ?>>Create order</button>
      </div>
    </div>
  </div>
</form>
