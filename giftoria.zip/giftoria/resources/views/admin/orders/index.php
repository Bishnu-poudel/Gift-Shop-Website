<?php
/** Vars: $filters, $orders, $total, $paginator */
use App\Repositories\Admin\OrderAdminRepository;
use App\Services\OrderStateMachine;

$exportQuery = http_build_query(array_filter($filters, static fn ($v) => $v !== ''));
?>
<div class="admin-page-head">
  <div>
    <h1>Orders</h1>
    <p><?= number_format($total) ?> order<?= $total === 1 ? '' : 's' ?> match the current filters.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light btn-sm" href="<?= e(admin_url('orders/export') . ($exportQuery !== '' ? '?' . $exportQuery : '')) ?>"><?= icon('download', 'icon-sm') ?> Export CSV</a>
    <?php if (can('orders.create')): ?><a class="btn btn-primary btn-sm" href="<?= e(admin_url('orders/create')) ?>"><?= icon('plus', 'icon-sm') ?> Manual order</a><?php endif; ?>
  </div>
</div>

<form class="filter-bar" method="get" action="<?= e(admin_url('orders')) ?>">
  <div class="field"><label for="o-q">Search</label><input class="input" type="search" id="o-q" name="q" value="<?= e($filters['q']) ?>" placeholder="Order no., email, phone, name"></div>
  <div class="field"><label for="o-status">Status</label>
    <select class="select" id="o-status" name="status">
      <option value="">Any status</option>
      <?php foreach (OrderStateMachine::ORDER_LABELS as $k => $label): ?><option value="<?= e($k) ?>" <?= $filters['status'] === $k ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="field"><label for="o-ps">Payment status</label>
    <select class="select" id="o-ps" name="payment_status">
      <option value="">Any</option>
      <?php foreach (OrderAdminRepository::PAYMENT_STATUSES as $s): ?><option value="<?= e($s) ?>" <?= $filters['payment_status'] === $s ? 'selected' : '' ?>><?= e(status_label($s)) ?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="field"><label for="o-pm">Method</label>
    <select class="select" id="o-pm" name="payment_method">
      <option value="">Any</option>
      <?php foreach (OrderAdminRepository::PAYMENT_METHODS as $k => $label): ?><option value="<?= e($k) ?>" <?= $filters['payment_method'] === $k ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="field"><label for="o-from">From</label><input class="input" type="date" id="o-from" name="from" value="<?= e($filters['from']) ?>"></div>
  <div class="field"><label for="o-to">To</label><input class="input" type="date" id="o-to" name="to" value="<?= e($filters['to']) ?>"></div>
  <button class="btn btn-primary btn-sm" type="submit"><?= icon('search', 'icon-sm') ?> Filter</button>
  <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('orders')) ?>">Reset</a>
</form>

<div class="card card-flush">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr><th>Order</th><th>Customer</th><th>Status</th><th>Payment</th><th class="num">Items</th><th class="num">Total</th><th>Placed</th></tr>
      </thead>
      <tbody>
      <?php if (!$orders): ?>
        <tr><td colspan="7" class="muted" style="padding:32px;text-align:center">No orders found.</td></tr>
      <?php endif; ?>
      <?php foreach ($orders as $o): ?>
        <tr>
          <td>
            <a class="row-link" href="<?= e(admin_url('orders/' . (int) $o['id'])) ?>"><?= e($o['order_number']) ?></a>
            <?php if ($o['source'] === 'manual'): ?><div class="muted small">Manual</div><?php endif; ?>
          </td>
          <td><?= e($o['customer_name']) ?><div class="muted small"><?= e($o['email']) ?> · <?= e($o['phone']) ?></div></td>
          <td><span class="status status-<?= e($o['status']) ?>"><?= e(OrderStateMachine::ORDER_LABELS[$o['status']] ?? status_label($o['status'])) ?></span></td>
          <td><span class="status status-<?= e($o['payment_status']) ?>"><?= e(status_label($o['payment_status'])) ?></span><div class="muted small"><?= e(OrderAdminRepository::PAYMENT_METHODS[$o['payment_method']] ?? $o['payment_method']) ?></div></td>
          <td class="num"><?= (int) $o['item_count'] ?></td>
          <td class="num"><?= e(money($o['grand_total'])) ?><?php if ((float) $o['refunded_total'] > 0): ?><div class="muted small">−<?= e(money($o['refunded_total'])) ?> refunded</div><?php endif; ?></td>
          <td><?= e(local_date($o['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?= $paginator->links() ?>
