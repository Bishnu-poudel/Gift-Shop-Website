<?php
/**
 * Vars: $order, $items, $addresses, $history, $notes, $shipments, $refunds, $returns, $payments (null = no permission),
 * $refundable, $nextStates, $canSeeCost, $canShip, $payUrl, $customer
 */
use App\Repositories\Admin\OrderAdminRepository;
use App\Services\OrderStateMachine;

$oid = (int) $order['id'];
$labels = OrderStateMachine::ORDER_LABELS;
$latestShipment = $shipments[0] ?? null;
$itemCost = 0.0;
$costKnown = true;
foreach ($items as $i) {
    if ($i['unit_cost'] === null) {
        $costKnown = false;
    } else {
        $itemCost += (float) $i['unit_cost'] * (int) $i['quantity'];
    }
}
$addressBlock = static function (?array $a): string {
    if (!$a) {
        return '<p class="muted">Not provided.</p>';
    }
    $lines = [
        $a['full_name'],
        $a['phone'],
        trim(($a['street'] ?? '') . ($a['ward'] ? ', Ward ' . $a['ward'] : ''), ', '),
        $a['municipality'] . ', ' . $a['district'],
        $a['province'] . ' Province',
        $a['landmark'] ? 'Landmark: ' . $a['landmark'] : '',
    ];
    return '<address style="font-style:normal;line-height:1.6">' . implode('<br>', array_map('e', array_filter($lines, static fn ($l) => trim((string) $l) !== ''))) . '</address>';
};
?>
<div class="admin-page-head">
  <div>
    <p class="small"><a href="<?= e(admin_url('orders')) ?>">&larr; Orders</a></p>
    <h1><?= e($order['order_number']) ?></h1>
    <p>
      Placed <?= e(local_date($order['created_at'])) ?>
      <?= $order['source'] === 'manual' ? ' · Manual order' . ($order['created_by_name'] ? ' by ' . e($order['created_by_name']) : '') : '' ?>
    </p>
    <div class="row mt-2" style="gap:8px">
      <span class="status status-<?= e($order['status']) ?>"><?= e($labels[$order['status']] ?? status_label($order['status'])) ?></span>
      <span class="status status-<?= e($order['payment_status']) ?>">Payment: <?= e(status_label($order['payment_status'])) ?></span>
      <span class="muted small"><?= e(OrderAdminRepository::PAYMENT_METHODS[$order['payment_method']] ?? $order['payment_method']) ?></span>
    </div>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light btn-sm" href="<?= e(admin_url('orders/' . $oid . '/invoice')) ?>" target="_blank" rel="noopener"><?= icon('printer', 'icon-sm') ?> Invoice</a>
    <?php if ((can('payments.view') || can('orders.edit_status')) && in_array($order['payment_method'], ['esewa', 'khalti'], true)): ?>
      <form method="post" action="<?= e(admin_url('orders/' . $oid . '/recheck')) ?>" class="inline-form" data-loading>
        <?= csrf_field() ?>
        <button class="btn btn-light btn-sm" type="submit"><?= icon('refresh', 'icon-sm') ?> Re-check payment</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<?php if ($payUrl): ?>
  <div class="alert alert-info"><?= icon('wallet') ?><div>
    <strong>Customer payment link</strong> — share this with the customer so they can pay with <?= e(OrderAdminRepository::PAYMENT_METHODS[$order['payment_method']] ?? $order['payment_method']) ?><?= $order['expires_at'] ? ' before ' . e(local_date($order['expires_at'])) : '' ?>:
    <div class="input-group mt-2"><input class="input" type="text" readonly value="<?= e($payUrl) ?>" onclick="this.select()" aria-label="Payment link"></div>
  </div></div>
<?php endif; ?>

<div class="admin-grid admin-grid-3-1">
  <div>
    <div class="card card-flush">
      <div class="card-head"><h2>Items</h2><span class="muted small"><?= array_sum(array_map(static fn ($i) => (int) $i['quantity'], $items)) ?> units</span></div>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Product</th><th class="num">Unit price</th><th class="num">Qty</th><th class="num">Total</th><?php if ($canSeeCost): ?><th class="num">Unit cost</th><?php endif; ?></tr></thead>
          <tbody>
          <?php foreach ($items as $i): ?>
            <tr>
              <td>
                <strong><?= e($i['name']) ?></strong><?= $i['variant_name'] ? ' — ' . e($i['variant_name']) : '' ?>
                <div class="muted small">SKU <?= e($i['sku']) ?></div>
                <?php if ($i['personalization']): ?><div class="small">Personalization: “<?= e($i['personalization']) ?>”</div><?php endif; ?>
              </td>
              <td class="num"><?= e(money($i['unit_price'])) ?></td>
              <td class="num"><?= (int) $i['quantity'] ?></td>
              <td class="num"><?= e(money($i['line_total'])) ?></td>
              <?php if ($canSeeCost): ?><td class="num"><?= $i['unit_cost'] !== null ? e(money($i['unit_cost'])) : '<span class="muted">—</span>' ?></td><?php endif; ?>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div style="padding:16px 24px">
        <ul class="list-plain">
          <li><span>Subtotal</span><span><?= e(money($order['subtotal'])) ?></span></li>
          <?php if ((float) $order['discount_total'] > 0): ?><li><span>Discount<?= $order['coupon_code'] ? ' (' . e($order['coupon_code']) . ')' : '' ?></span><span>−<?= e(money($order['discount_total'])) ?></span></li><?php endif; ?>
          <li><span>Shipping<?= $order['zone_name'] ? ' · ' . e($order['zone_name']) : '' ?></span><span><?= e(money($order['shipping_total'])) ?></span></li>
          <?php if ((float) $order['gift_wrap_total'] > 0): ?><li><span>Gift wrap</span><span><?= e(money($order['gift_wrap_total'])) ?></span></li><?php endif; ?>
          <li><strong>Grand total</strong><strong><?= e(money($order['grand_total'])) ?></strong></li>
          <?php if ((float) $order['refunded_total'] > 0): ?><li><span>Refunded</span><span>−<?= e(money($order['refunded_total'])) ?></span></li><?php endif; ?>
          <?php if ($canSeeCost): ?>
            <li><span class="muted">Item margin (subtotal − discount − cost)</span><span class="muted"><?= $costKnown ? e(money((float) $order['subtotal'] - (float) $order['discount_total'] - $itemCost)) : 'n/a (missing cost prices)' ?></span></li>
          <?php endif; ?>
        </ul>
      </div>
    </div>

    <?php if ($order['gift_message'] || $order['customer_note'] || $order['requested_delivery_date'] || (int) $order['gift_wrap']): ?>
    <div class="card">
      <div class="card-head"><h2>Gift &amp; delivery details</h2></div>
      <ul class="list-plain">
        <?php if ((int) $order['gift_wrap']): ?><li><span>Gift wrap</span><span>Yes</span></li><?php endif; ?>
        <?php if ($order['requested_delivery_date']): ?><li><span>Requested delivery</span><span><?= e(date('D, M j, Y', strtotime($order['requested_delivery_date']))) ?></span></li><?php endif; ?>
        <?php if ($order['gift_message']): ?><li><span>Gift message</span><span style="text-align:right">“<?= e($order['gift_message']) ?>”</span></li><?php endif; ?>
        <?php if ($order['customer_note']): ?><li><span>Customer note</span><span style="text-align:right"><?= e($order['customer_note']) ?></span></li><?php endif; ?>
      </ul>
    </div>
    <?php endif; ?>

    <div class="card" id="shipment">
      <div class="card-head"><h2>Shipments</h2></div>
      <?php if (!$shipments): ?><p class="muted">No shipment recorded yet.</p><?php endif; ?>
      <?php if ($shipments): ?>
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr><th>Carrier</th><th>Tracking</th><th>Shipped</th><th>Recorded</th></tr></thead>
            <tbody>
            <?php foreach ($shipments as $s): ?>
              <tr>
                <td><?= e($s['carrier'] ?: '—') ?></td>
                <td>
                  <?= e($s['tracking_number'] ?: '—') ?>
                  <?php if ($s['tracking_url'] && preg_match('#^https?://#i', $s['tracking_url'])): ?>
                    <div><a class="small" href="<?= e($s['tracking_url']) ?>" target="_blank" rel="noopener noreferrer">Track <?= icon('external', 'icon-sm') ?></a></div>
                  <?php endif; ?>
                </td>
                <td><?= e($s['shipped_at'] ? local_date($s['shipped_at']) : '—') ?></td>
                <td><?= e(local_date($s['created_at'])) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>

      <?php if ($canShip): ?>
        <form method="post" action="<?= e(admin_url('orders/' . $oid . '/shipment')) ?>" class="mt-4" data-loading>
          <?= csrf_field() ?>
          <?php if ($latestShipment): ?><input type="hidden" name="shipment_id" value="<?= (int) $latestShipment['id'] ?>"><?php endif; ?>
          <div class="form-grid">
            <div class="field"><label for="s-carrier">Carrier</label><input class="input" id="s-carrier" name="carrier" maxlength="80" value="<?= e(old('carrier', $latestShipment['carrier'] ?? '')) ?>" placeholder="e.g. Pathao, Upaya, own rider"><?= field_error('carrier') ?></div>
            <div class="field"><label for="s-num">Tracking number</label><input class="input" id="s-num" name="tracking_number" maxlength="100" value="<?= e(old('tracking_number', $latestShipment['tracking_number'] ?? '')) ?>"><?= field_error('tracking_number') ?></div>
            <div class="field span-2"><label for="s-url">Tracking URL</label><input class="input" type="url" id="s-url" name="tracking_url" maxlength="255" value="<?= e(old('tracking_url', $latestShipment['tracking_url'] ?? '')) ?>" placeholder="https://"><?= field_error('tracking_url') ?></div>
            <?php if (OrderStateMachine::canOrder($order['status'], 'shipped')): ?>
              <label class="check span-2"><input type="checkbox" name="mark_shipped" value="1" checked> Mark the order as shipped and email the customer</label>
            <?php endif; ?>
          </div>
          <div class="form-actions"><button class="btn btn-primary btn-sm" type="submit"><?= $latestShipment ? 'Update shipment' : 'Save shipment' ?></button></div>
        </form>
      <?php endif; ?>
    </div>

    <?php if ($payments !== null): ?>
    <div class="card">
      <div class="card-head"><h2>Payment attempts</h2><a class="small" href="<?= e(admin_url('payments') . '?' . http_build_query(['q' => $order['order_number']])) ?>">In payments list</a></div>
      <?php if (!$payments): ?><p class="muted">No payment attempts recorded.</p><?php endif; ?>
      <?php foreach ($payments as $p): ?>
        <div class="perm-group">
          <div class="row-between">
            <div>
              <strong><?= e(strtoupper($p['gateway'])) ?></strong> · <?= e($p['attempt_ref']) ?>
              <div class="muted small">
                Started <?= e(local_date($p['created_at'])) ?>
                <?= $p['verified_at'] ? ' · Verified ' . e(local_date($p['verified_at'])) : '' ?>
                <?= $p['gateway_txn_id'] ? ' · Txn ' . e($p['gateway_txn_id']) : '' ?>
                <?= $p['gateway_status'] ? ' · Gateway: ' . e($p['gateway_status']) : '' ?>
              </div>
            </div>
            <div class="row" style="gap:8px"><strong><?= e(money($p['amount'])) ?></strong><span class="status status-<?= e($p['status']) ?>"><?= e(status_label($p['status'])) ?></span></div>
          </div>
          <?php if ($p['events']): ?>
            <details class="mt-2">
              <summary class="small">Events (<?= count($p['events']) ?>)</summary>
              <ul class="timeline-admin mt-2">
                <?php foreach ($p['events'] as $ev): ?>
                  <li>
                    <strong><?= e($ev['event_type']) ?></strong> <span class="when"><?= e(local_date($ev['created_at'])) ?></span>
                    <?php if ($ev['payload']): ?><div class="code-block mt-2"><?= e($ev['payload']) ?></div><?php endif; ?>
                  </li>
                <?php endforeach; ?>
              </ul>
            </details>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="card">
      <div class="card-head"><h2>Refunds &amp; returns</h2><?php if (can('refunds.manage') || can('payments.view')): ?><a class="small" href="<?= e(admin_url('refunds')) ?>">All refunds</a><?php endif; ?></div>
      <?php if (!$refunds && !$returns): ?><p class="muted">No refunds or return requests.</p><?php endif; ?>
      <?php if ($refunds): ?>
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr><th>Refund</th><th>Reason</th><th class="num">Amount</th><th>Status</th><th>Reference</th></tr></thead>
            <tbody>
            <?php foreach ($refunds as $r): ?>
              <tr>
                <td>#<?= (int) $r['id'] ?><div class="muted small"><?= e(local_date($r['created_at'])) ?></div></td>
                <td><?= e($r['reason'] ?: '—') ?></td>
                <td class="num"><?= e(money($r['amount'])) ?></td>
                <td><span class="status status-<?= e($r['status']) ?>"><?= e(status_label($r['status'])) ?></span></td>
                <td><?= e($r['gateway_reference'] ?: '—') ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
      <?php if ($returns): ?>
        <h3 class="small mt-4">Return requests</h3>
        <ul class="list-plain">
          <?php foreach ($returns as $rr): ?>
            <li><span><?= e($rr['reason']) ?><span class="muted small"> · <?= e(local_date($rr['created_at'])) ?></span></span><span class="status status-<?= e($rr['status']) ?>"><?= e(status_label($rr['status'])) ?></span></li>
          <?php endforeach; ?>
        </ul>
        <?php if (can('support.manage') || can('refunds.manage')): ?><p class="small mt-2"><a href="<?= e(admin_url('returns')) ?>">Manage returns</a></p><?php endif; ?>
      <?php endif; ?>

      <?php if (can('refunds.manage') && $refundable['available'] > 0): ?>
        <form method="post" action="<?= e(admin_url('refunds')) ?>" class="mt-4" data-confirm="Create a refund request for this order?">
          <?= csrf_field() ?>
          <input type="hidden" name="order_id" value="<?= $oid ?>">
          <div class="form-grid">
            <div class="field"><label for="r-amount">Refund amount (max <?= e(money($refundable['available'])) ?>)</label><input class="input" type="number" id="r-amount" name="amount" step="0.01" min="0.01" max="<?= e(number_format($refundable['available'], 2, '.', '')) ?>" value="<?= e(number_format($refundable['available'], 2, '.', '')) ?>" required></div>
            <div class="field"><label for="r-reason">Reason</label><input class="input" id="r-reason" name="reason" maxlength="500" required></div>
          </div>
          <p class="muted small">Paid <?= e(money($refundable['paid'])) ?> · refunded <?= e(money($refundable['refunded'])) ?> · open requests <?= e(money($refundable['open'])) ?></p>
          <div class="form-actions"><button class="btn btn-light btn-sm" type="submit"><?= icon('undo', 'icon-sm') ?> Request refund</button></div>
        </form>
      <?php endif; ?>
    </div>

    <div class="card">
      <div class="card-head"><h2>Status history</h2></div>
      <?php if (!$history): ?><p class="muted">No history.</p><?php endif; ?>
      <ul class="timeline-admin">
        <?php foreach ($history as $h): ?>
          <li>
            <strong><?= $h['field'] === 'payment_status' ? 'Payment: ' : '' ?><?= e($h['from_status'] ? status_label($h['from_status']) . ' → ' : '') ?><?= e(status_label($h['to_status'])) ?></strong>
            <?php if ($h['note']): ?><div><?= e($h['note']) ?></div><?php endif; ?>
            <div class="when"><?= e(local_date($h['created_at'])) ?> · <?= e($h['user_name'] ?? 'System') ?></div>
          </li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>

  <div>
    <div class="card">
      <div class="card-head"><h2>Update status</h2></div>
      <?php if (!$nextStates): ?>
        <p class="muted small">No further status changes are available to you from “<?= e($labels[$order['status']] ?? $order['status']) ?>”.</p>
      <?php else: ?>
        <form method="post" action="<?= e(admin_url('orders/' . $oid . '/status')) ?>" data-confirm="Change the order status?">
          <?= csrf_field() ?>
          <div class="field"><label for="st-to">New status</label>
            <select class="select" id="st-to" name="status" required>
              <?php foreach ($nextStates as $s): ?><option value="<?= e($s) ?>"><?= e($labels[$s] ?? status_label($s)) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="field"><label for="st-note">Note (optional)</label><input class="input" id="st-note" name="note" maxlength="500"></div>
          <button class="btn btn-primary btn-block btn-sm" type="submit">Update status</button>
          <p class="muted small mt-2">Cancelling releases reserved stock; cancelling a paid order creates a refund request.</p>
        </form>
      <?php endif; ?>
    </div>

    <div class="card">
      <div class="card-head"><h2>Customer</h2><?php if ($customer && can('customers.view')): ?><a class="small" href="<?= e(admin_url('customers/' . (int) $customer['id'])) ?>">Profile</a><?php endif; ?></div>
      <p class="mb-0"><strong><?= e($order['customer_name']) ?></strong><?= $customer ? '' : ' <span class="muted small">(guest)</span>' ?></p>
      <p class="mb-0 small"><a href="mailto:<?= e($order['email']) ?>"><?= e($order['email']) ?></a></p>
      <p class="small"><a href="tel:<?= e($order['phone']) ?>"><?= e($order['phone']) ?></a></p>
    </div>

    <div class="card">
      <div class="card-head"><h2>Shipping address</h2></div>
      <?= $addressBlock($addresses['shipping']) ?>
      <?php if ($addresses['billing']): ?>
        <div class="card-head mt-4"><h2>Billing address</h2></div>
        <?= $addressBlock($addresses['billing']) ?>
      <?php endif; ?>
    </div>

    <div class="card" id="notes">
      <div class="card-head"><h2>Internal notes</h2><span class="muted small">Staff only</span></div>
      <?php if (can('orders.edit_status') || can('support.manage')): ?>
        <form method="post" action="<?= e(admin_url('orders/' . $oid . '/notes')) ?>">
          <?= csrf_field() ?>
          <div class="field"><label for="n-note" class="sr-only">Note</label><textarea class="textarea" id="n-note" name="note" maxlength="2000" rows="3" placeholder="Add a note for the team" required></textarea><?= field_error('note') ?></div>
          <button class="btn btn-light btn-sm" type="submit">Add note</button>
        </form>
      <?php endif; ?>
      <?php if (!$notes): ?><p class="muted small mt-4">No notes yet.</p><?php endif; ?>
      <ul class="timeline-admin mt-4">
        <?php foreach ($notes as $n): ?>
          <li><div style="white-space:pre-wrap"><?= e($n['note']) ?></div><div class="when"><?= e($n['user_name'] ?? 'Staff') ?> · <?= e(local_date($n['created_at'])) ?></div></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</div>
