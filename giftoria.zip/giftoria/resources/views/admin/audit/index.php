<?php /** Vars: $rows, $paginator, $total, $filters, $staffUsers, $entityTypes, $actionPrefixes */ ?>
<div class="admin-page-head">
  <div>
    <h1>Audit log</h1>
    <p>A read-only record of staff actions, sign-ins and access denials. <?= number_format((int) $total) ?> matching entries.</p>
  </div>
</div>

<form class="filter-bar" method="get" action="<?= e(admin_url('audit')) ?>">
  <div class="field">
    <label for="f-user">User</label>
    <select class="select" id="f-user" name="user">
      <option value="">Anyone</option>
      <?php foreach ($staffUsers as $u): ?>
        <option value="<?= (int) $u['id'] ?>" <?= (int) $filters['user'] === (int) $u['id'] ? 'selected' : '' ?>><?= e($u['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field">
    <label for="f-action">Action starts with</label>
    <input class="input" id="f-action" name="action" value="<?= e($filters['action']) ?>" list="action-prefixes" placeholder="e.g. staff. or order." maxlength="80">
    <datalist id="action-prefixes">
      <?php foreach ($actionPrefixes as $ap): ?><option value="<?= e($ap) ?>."></option><?php endforeach; ?>
    </datalist>
  </div>
  <div class="field">
    <label for="f-entity">Entity type</label>
    <select class="select" id="f-entity" name="entity">
      <option value="">All</option>
      <?php foreach ($entityTypes as $et): ?>
        <option value="<?= e($et) ?>" <?= $filters['entity'] === $et ? 'selected' : '' ?>><?= e($et) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field">
    <label for="f-from">From</label>
    <input class="input" type="date" id="f-from" name="from" value="<?= e($filters['from']) ?>">
  </div>
  <div class="field">
    <label for="f-to">To</label>
    <input class="input" type="date" id="f-to" name="to" value="<?= e($filters['to']) ?>">
  </div>
  <button class="btn btn-light" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
  <?php if ($filters['user'] || $filters['action'] !== '' || $filters['entity'] !== '' || $filters['from'] !== '' || $filters['to'] !== ''): ?>
    <a class="btn btn-ghost" href="<?= e(admin_url('audit')) ?>">Reset</a>
  <?php endif; ?>
</form>

<div class="card card-flush">
  <?php if (!$rows): ?>
    <p class="muted" style="padding:var(--s-6)">No audit entries match these filters.</p>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead><tr><th>When</th><th>User</th><th>Action</th><th>Entity</th><th>IP</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td class="small" style="white-space:nowrap"><?= e(local_date($r['created_at'])) ?></td>
        <td>
          <?php if ($r['user_id'] === null): ?>
            <span class="muted">System / guest</span>
          <?php else: ?>
            <?= e($r['user_name'] ?? ('User #' . $r['user_id'])) ?>
            <?php if (($r['user_type'] ?? '') === 'customer'): ?> <span class="badge">Customer</span><?php endif; ?>
          <?php endif; ?>
        </td>
        <td><code class="<?= str_starts_with($r['action'], 'access.denied') ? 'status status-failed' : '' ?>"><?= e($r['action']) ?></code></td>
        <td class="small"><?= $r['entity_type'] ? e($r['entity_type']) . ($r['entity_id'] ? ' #' . (int) $r['entity_id'] : '') : '<span class="muted">—</span>' ?></td>
        <td class="small"><?= e($r['ip'] ?? '') ?></td>
        <td class="num"><a class="btn btn-ghost btn-sm" href="<?= e(admin_url('audit/' . (int) $r['id'])) ?>">Details</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>
<?= $paginator->links() ?>
