<?php /** Vars: $log, $oldJson, $newJson */ ?>
<div class="admin-page-head">
  <div>
    <h1><code><?= e($log['action']) ?></code></h1>
    <p>Audit entry #<?= (int) $log['id'] ?> · <?= e(local_date($log['created_at'])) ?></p>
  </div>
  <div class="admin-actions"><a class="btn btn-light" href="<?= e(admin_url('audit')) ?>">Back to audit log</a></div>
</div>

<div class="admin-grid admin-grid-3-1">
  <div>
    <div class="card">
      <div class="card-head"><h2>Previous values</h2></div>
      <?php if ($oldJson === null): ?>
        <p class="muted small">None recorded.</p>
      <?php else: ?>
        <pre class="code-block"><?= e($oldJson) ?></pre>
      <?php endif; ?>
    </div>
    <div class="card">
      <div class="card-head"><h2>New values</h2></div>
      <?php if ($newJson === null): ?>
        <p class="muted small">None recorded.</p>
      <?php else: ?>
        <pre class="code-block"><?= e($newJson) ?></pre>
      <?php endif; ?>
    </div>
  </div>
  <div class="card">
    <div class="card-head"><h2>Context</h2></div>
    <ul class="list-plain">
      <li><span class="muted">User</span><span>
        <?php if ($log['user_id'] === null): ?>System / guest<?php else: ?>
          <?php if (($log['user_type'] ?? '') === 'staff' && can('staff.manage')): ?>
            <a href="<?= e(admin_url('staff/' . (int) $log['user_id'])) ?>"><?= e($log['user_name'] ?? ('User #' . $log['user_id'])) ?></a>
          <?php else: ?>
            <?= e($log['user_name'] ?? ('User #' . $log['user_id'])) ?>
          <?php endif; ?>
        <?php endif; ?>
      </span></li>
      <?php if (!empty($log['user_email'])): ?><li><span class="muted">Email</span><span><?= e($log['user_email']) ?></span></li><?php endif; ?>
      <li><span class="muted">Entity</span><span><?= $log['entity_type'] ? e($log['entity_type']) . ($log['entity_id'] ? ' #' . (int) $log['entity_id'] : '') : '—' ?></span></li>
      <li><span class="muted">IP address</span><span><?= e($log['ip'] ?? '—') ?></span></li>
      <li><span class="muted">Time (UTC)</span><span><?= e($log['created_at']) ?></span></li>
    </ul>
    <?php if (!empty($log['user_agent'])): ?>
      <label class="label mt-4">User agent</label>
      <div class="code-block"><?= e($log['user_agent']) ?></div>
    <?php endif; ?>
    <p class="muted small mt-4">Audit entries are read-only and cannot be edited or deleted from the admin panel.</p>
  </div>
</div>
