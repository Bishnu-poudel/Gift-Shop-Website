<?php
/** @var array $sections */
use App\Controllers\Admin\HomepageController;

$labels = HomepageController::TYPE_LABELS;
$summary = static function (array $s): string {
    $c = $s['config'];
    switch ($s['type']) {
        case 'products':
        case 'collection':
            $src = HomepageController::PRODUCT_SOURCES[$c['source'] ?? 'bestseller'] ?? ($c['source'] ?? '');
            $extra = !empty($c['value']) ? ': ' . $c['value'] : (($c['source'] ?? '') === 'manual' ? ': ' . count((array) ($c['product_ids'] ?? [])) . ' products' : '');
            return $src . $extra . ' · up to ' . (int) ($c['limit'] ?? 8);
        case 'taxonomy_grid':
            return ucfirst((string) ($c['taxonomy'] ?? 'recipients')) . (!empty($c['slugs']) ? ' · ' . count((array) $c['slugs']) . ' selected' : ' · all') . ' · up to ' . (int) ($c['limit'] ?? 12);
        case 'hero':
            return trim(($c['cta_label'] ?? '') . (!empty($c['cta_url']) ? ' → ' . $c['cta_url'] : '')) ?: 'Hero';
        case 'campaigns':
            return 'Live seasonal & banner campaigns';
        case 'budget_grid':
            return 'Uses budget ranges';
        default:
            return 'Text & data driven';
    }
};
?>
<div class="admin-page-head">
  <div>
    <h1>Homepage</h1>
    <p>Drag sections to reorder them (or use the arrow buttons), then save the order. Hidden sections stay configured but are not shown.</p>
  </div>
  <div class="admin-actions">
    <?php if (can('banners.manage') || can('campaigns.manage')): ?>
      <a class="btn btn-light" href="<?= e(admin_url('campaigns')) ?>"><?= icon('megaphone', 'icon-sm') ?> Manage banners</a>
    <?php endif; ?>
    <a class="btn btn-light" href="<?= e(url('/')) ?>" target="_blank" rel="noopener"><?= icon('external', 'icon-sm') ?> View homepage</a>
  </div>
</div>

<?php if (!$sections): ?>
  <div class="card"><?= partial('components/empty-state', ['icon' => 'layout', 'title' => 'No homepage sections', 'text' => 'Run the database seeder to create the default homepage sections.']) ?></div>
<?php else: ?>
<form method="post" action="<?= e(admin_url('homepage/reorder')) ?>" class="card">
  <?= csrf_field() ?>
  <input type="hidden" name="order" id="section_order" value="<?= e(implode(',', array_map(static fn ($s) => (int) $s['id'], $sections))) ?>">
  <ul class="sortable-list" data-sortable data-input="section_order" aria-label="Homepage sections">
    <?php foreach ($sections as $s): $enabled = (int) $s['is_enabled'] === 1; ?>
      <li data-id="<?= (int) $s['id'] ?>" style="<?= $enabled ? '' : 'opacity:.65' ?>">
        <span class="grip" aria-hidden="true"><?= icon('grip') ?></span>
        <div style="flex:1;min-width:0">
          <strong><?= e($s['title'] ?: ($labels[$s['type']] ?? $s['type'])) ?></strong>
          <span class="badge" style="margin-left:6px"><?= e($labels[$s['type']] ?? $s['type']) ?></span>
          <div class="muted small" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($summary($s)) ?></div>
        </div>
        <span class="status status-<?= $enabled ? 'active' : 'inactive' ?>"><?= $enabled ? 'Visible' : 'Hidden' ?></span>
        <button class="btn btn-ghost btn-sm" type="button" data-move="up" aria-label="Move <?= e($s['title'] ?: $s['section_key']) ?> up"><?= icon('arrow-up', 'icon-sm') ?></button>
        <button class="btn btn-ghost btn-sm" type="button" data-move="down" aria-label="Move <?= e($s['title'] ?: $s['section_key']) ?> down"><?= icon('arrow-down', 'icon-sm') ?></button>
        <button class="btn btn-light btn-sm" type="submit" form="toggle-<?= (int) $s['id'] ?>"><?= $enabled ? icon('eye-off', 'icon-sm') . ' Hide' : icon('eye', 'icon-sm') . ' Show' ?></button>
        <a class="btn btn-light btn-sm" href="<?= e(admin_url('homepage/' . (int) $s['id'] . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
      </li>
    <?php endforeach; ?>
  </ul>
  <div class="form-actions">
    <button class="btn btn-primary" type="submit"><?= icon('check', 'icon-sm') ?> Save order</button>
  </div>
</form>
<?php foreach ($sections as $s): ?>
  <form id="toggle-<?= (int) $s['id'] ?>" method="post" action="<?= e(admin_url('homepage/' . (int) $s['id'] . '/toggle')) ?>" hidden><?= csrf_field() ?></form>
<?php endforeach; ?>
<?php endif; ?>
