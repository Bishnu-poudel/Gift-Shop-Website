<?php
/** @var array $section @var array $products @var array $slugOptions */
use App\Controllers\Admin\HomepageController;

$type = (string) $section['type'];
$cfg = $section['config'];
$hasOld = (bool) errors();
$val = static function (string $key, mixed $default = '') use ($section, $hasOld) {
    return $hasOld ? old($key, $default) : ($section[$key] ?? $default);
};
$c = static function (string $key, mixed $default = '') use ($cfg, $hasOld) {
    if ($hasOld) {
        return old($key, $default);
    }
    $v = $cfg[$key] ?? $default;
    return is_array($v) ? implode(', ', $v) : $v;
};
$enabled = $hasOld ? (bool) old('is_enabled', false) : (int) $section['is_enabled'] === 1;
$source = (string) $c('source', 'bestseller');
$selProducts = array_map('intval', $hasOld ? (array) old('product_ids', []) : (array) ($cfg['product_ids'] ?? []));
$hasImage = in_array($type, ['hero', 'collection'], true);
$label = HomepageController::TYPE_LABELS[$type] ?? $type;
?>
<div class="admin-page-head">
  <div>
    <h1>Edit section: <?= e($section['title'] ?: $label) ?></h1>
    <p><?= e($label) ?> · key <code><?= e($section['section_key']) ?></code></p>
  </div>
  <div class="admin-actions"><a class="btn btn-light" href="<?= e(admin_url('homepage')) ?>">Back to homepage</a></div>
</div>

<form class="card" method="post" action="<?= e(admin_url('homepage/' . (int) $section['id'])) ?>" <?= $hasImage ? 'enctype="multipart/form-data"' : '' ?> data-loading>
  <?= csrf_field() ?>
  <div class="form-grid">
    <div class="field">
      <label for="title">Title</label>
      <input class="input" id="title" name="title" value="<?= e($val('title')) ?>" maxlength="190">
      <?= field_error('title') ?>
    </div>
    <div class="field">
      <label for="subtitle">Subtitle</label>
      <input class="input" id="subtitle" name="subtitle" value="<?= e($val('subtitle')) ?>" maxlength="500">
      <?= field_error('subtitle') ?>
    </div>

    <?php if ($type === 'hero'): ?>
      <div class="field span-2">
        <label for="eyebrow">Eyebrow text</label>
        <input class="input" id="eyebrow" name="eyebrow" value="<?= e($c('eyebrow')) ?>" maxlength="80" placeholder="Handmade in Nepal">
        <?= field_error('eyebrow') ?>
      </div>
      <div class="field">
        <label for="cta_label">Main button label</label>
        <input class="input" id="cta_label" name="cta_label" value="<?= e($c('cta_label')) ?>" maxlength="60">
        <?= field_error('cta_label') ?>
      </div>
      <div class="field">
        <label for="cta_url">Main button link</label>
        <input class="input <?= errors('cta_url') ? 'has-error' : '' ?>" id="cta_url" name="cta_url" value="<?= e($c('cta_url')) ?>" maxlength="255" placeholder="/gift-finder">
        <?= field_error('cta_url') ?>
      </div>
      <div class="field">
        <label for="secondary_label">Secondary button label</label>
        <input class="input" id="secondary_label" name="secondary_label" value="<?= e($c('secondary_label')) ?>" maxlength="60">
        <?= field_error('secondary_label') ?>
      </div>
      <div class="field">
        <label for="secondary_url">Secondary button link</label>
        <input class="input <?= errors('secondary_url') ? 'has-error' : '' ?>" id="secondary_url" name="secondary_url" value="<?= e($c('secondary_url')) ?>" maxlength="255" placeholder="/shop">
        <?= field_error('secondary_url') ?>
      </div>
    <?php endif; ?>

    <?php if (in_array($type, ['products', 'collection'], true)): ?>
      <div class="field">
        <label for="source">Product source</label>
        <select class="select <?= errors('source') ? 'has-error' : '' ?>" id="source" name="source" data-source-select>
          <?php foreach (HomepageController::PRODUCT_SOURCES as $k => $lbl): ?>
            <option value="<?= e($k) ?>" <?= $source === $k ? 'selected' : '' ?>><?= e($lbl) ?></option>
          <?php endforeach; ?>
        </select>
        <?= field_error('source') ?>
      </div>
      <div class="field">
        <label for="limit">Number of products</label>
        <input class="input <?= errors('limit') ? 'has-error' : '' ?>" id="limit" name="limit" type="number" min="1" max="24" value="<?= e($c('limit', '8')) ?>">
        <?= field_error('limit') ?>
      </div>
      <div class="field span-2" data-source-for="category interest recipient occasion">
        <label for="value">Slug</label>
        <input class="input <?= errors('value') ? 'has-error' : '' ?>" id="value" name="value" value="<?= e($c('value')) ?>" list="slug-options" maxlength="140" autocomplete="off">
        <datalist id="slug-options"></datalist>
        <p class="hint">Start typing — suggestions match the chosen source.</p>
        <?= field_error('value') ?>
      </div>
      <div class="field span-2" data-source-for="manual">
        <label for="product_ids">Hand-picked products <span class="muted">(up to 24)</span></label>
        <select class="select <?= errors('product_ids') ? 'has-error' : '' ?>" id="product_ids" name="product_ids[]" multiple size="10" style="height:auto;background-image:none">
          <?php foreach ($products as $p): ?>
            <option value="<?= (int) $p['id'] ?>" <?= in_array((int) $p['id'], $selProducts, true) ? 'selected' : '' ?>><?= e($p['name']) ?> (<?= e($p['sku']) ?>)</option>
          <?php endforeach; ?>
        </select>
        <p class="hint">Hold Ctrl (Cmd on Mac) to select several. Only active products are shown on the storefront.</p>
        <?= field_error('product_ids') ?>
      </div>
      <?php if ($type === 'collection'): ?>
        <div class="field">
          <label for="cta_label">Button label</label>
          <input class="input" id="cta_label" name="cta_label" value="<?= e($c('cta_label')) ?>" maxlength="60">
          <?= field_error('cta_label') ?>
        </div>
        <div class="field">
          <label for="cta_url">Button link</label>
          <input class="input <?= errors('cta_url') ? 'has-error' : '' ?>" id="cta_url" name="cta_url" value="<?= e($c('cta_url')) ?>" maxlength="255">
          <?= field_error('cta_url') ?>
        </div>
      <?php endif; ?>
    <?php endif; ?>

    <?php if ($type === 'taxonomy_grid'): $taxonomy = (string) $c('taxonomy', 'recipients'); ?>
      <div class="field">
        <label for="taxonomy">Taxonomy</label>
        <select class="select" id="taxonomy" name="taxonomy">
          <?php foreach (['recipients' => 'Recipients', 'occasions' => 'Occasions', 'interests' => 'Interests'] as $k => $lbl): ?>
            <option value="<?= e($k) ?>" <?= $taxonomy === $k ? 'selected' : '' ?>><?= e($lbl) ?></option>
          <?php endforeach; ?>
        </select>
        <?= field_error('taxonomy') ?>
      </div>
      <div class="field">
        <label for="limit">Maximum items</label>
        <input class="input <?= errors('limit') ? 'has-error' : '' ?>" id="limit" name="limit" type="number" min="1" max="30" value="<?= e($c('limit', '12')) ?>">
        <?= field_error('limit') ?>
      </div>
      <div class="field span-2">
        <label for="slugs">Show only these slugs <span class="muted">(optional, in this order)</span></label>
        <textarea class="textarea <?= errors('slugs') ? 'has-error' : '' ?>" id="slugs" name="slugs" rows="3" placeholder="mother, father, baby-girl"><?= e($c('slugs')) ?></textarea>
        <p class="hint">Separate with commas or new lines. Leave empty to show all active items.</p>
        <?= field_error('slugs') ?>
      </div>
    <?php endif; ?>

    <?php if ($hasImage): ?>
      <div class="field span-2">
        <label for="image">Image</label>
        <?php if (!empty($cfg['image'])): ?>
          <div class="row" style="margin-bottom:8px">
            <img src="<?= e(image_url($cfg['image'])) ?>" alt="" style="width:180px;height:100px;object-fit:cover;border-radius:8px;border:1px solid var(--line)">
            <label class="check"><input type="checkbox" name="remove_image" value="1"> <span>Remove image</span></label>
          </div>
        <?php endif; ?>
        <input class="input" id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp,image/gif">
        <p class="hint">JPEG, PNG, WebP or GIF up to 5 MB.</p>
        <?= field_error('image') ?>
      </div>
    <?php endif; ?>

    <?php if (!in_array($type, ['hero', 'products', 'collection', 'taxonomy_grid'], true)): ?>
      <div class="span-2 alert alert-info"><?= icon('info') ?><div>This section is filled automatically<?= $type === 'campaigns' ? ' from live seasonal and banner campaigns — manage them under Campaigns' : ($type === 'budget_grid' ? ' from the budget ranges' : '') ?>. Only the title and subtitle can be edited here.</div></div>
    <?php endif; ?>

    <div class="field span-2">
      <label class="check"><input type="checkbox" name="is_enabled" value="1" <?= $enabled ? 'checked' : '' ?>> <span>Show this section on the homepage</span></label>
    </div>
  </div>
  <div class="form-actions">
    <a class="btn btn-ghost" href="<?= e(admin_url('homepage')) ?>">Cancel</a>
    <button class="btn btn-primary" type="submit">Save section</button>
  </div>
</form>

<?php if (in_array($type, ['products', 'collection'], true)): ?>
<script type="application/json" id="slug-data"><?= json_encode($slugOptions, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
<script>
(function () {
  var select = document.querySelector('[data-source-select]');
  var list = document.getElementById('slug-options');
  var data = {};
  try { data = JSON.parse(document.getElementById('slug-data').textContent); } catch (e) {}
  function sync() {
    document.querySelectorAll('[data-source-for]').forEach(function (el) {
      el.hidden = el.getAttribute('data-source-for').split(' ').indexOf(select.value) === -1;
    });
    list.innerHTML = '';
    (data[select.value] || []).forEach(function (o) {
      var opt = document.createElement('option');
      opt.value = o.slug; opt.label = o.name;
      list.appendChild(opt);
    });
  }
  if (select) { select.addEventListener('change', sync); sync(); }
})();
</script>
<?php endif; ?>
