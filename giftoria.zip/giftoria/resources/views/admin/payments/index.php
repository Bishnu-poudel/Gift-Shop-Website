<?php
/** Vars: $filters, $payments, $summary, $total, $paginator, $gateways */
use App\Repositories\Admin\OrderAdminRepository;
?>
<div class="admin-page-head">
  <div>
    <h1>Payments</h1>
    <p>Every payment attempt with its gateway reference. Payments are only marked paid after server-side verification.</p>
  </div>
</div>

<div class="kpis">
  <div class="kpi"><p class="label">Attempts</p><div class="value"><?= number_format($total) ?></div><div class="sub">Matching filters</div></div>
  <div class="kpi"><p class="label">Captured</p><div class="value"><?= e(money($summary['captured'])) ?></div><div class="sub">Verified paid (incl. later refunded)</div></div>
  <div class="kpi"><p class="label">Failed</p><div class="value"><?= (int) $summary['failed'] ?></div><div class="sub">Gateway reported failure</div></div>
  <div class="kpi"><p class="label">Success rate</p><div class="value"><?= $total > 0 ? e(number_format((int) $summary['succeeded'] / $total * 100, 1)) . '%' : '—' ?></div><div class="sub"><?= (int) $summary['succeeded'] ?> verified ÷ <?= number_format($total) ?> attempts</div></div>
</div>

<form class="filter-bar" method="get" action="<?= e(admin_url('payments')) ?>">
  <div class="field"><label for="p-q">Search</label><input class="input" type="search" id="p-q" name="q" value="<?= e($filters['q']) ?>" placeholder="Order no., attempt ref, txn id"></div>
  <div class="field"><label for="p-g">Gateway</label>
    <select class="select" id="p-g" name="gateway">
      <option value="">Any gateway</option>
      <?php foreach ($gateways as $k => $label): ?><option value="<?= e($k) ?>" <?= $filters['gateway'] === $k ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="field"><label for="p-s">Status</label>
    <select class="select" id="p-s" name="status">
      <option value="">Any status</option>
      <?php foreach (OrderAdminRepository::PAYMENT_STATUSES as $s): ?><option value="<?= e($s) ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= e(status_label($s)) ?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="field"><label for="p-from">From</label><input class="input" type="date" id="p-from" name="from" value="<?= e($filters['from']) ?>"></div>
  <div class="field"><label for="p-to">To</label><input class="input" type="date" id="p-to" name="to" value="<?= e($filters['to']) ?>"></div>
  <button class="btn btn-primary btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
  <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('payments')) ?>">Reset</a>
</form>

<div class="card card-flush">
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Started</th><th>Order</th><th>Gateway</th><th>Attempt ref</th><th>Gateway txn</th><th class="num">Amount</th><th>Status</th><th>Verified</th></tr></thead>
      <tbody>
      <?php if (!$payments): ?><tr><td colspan="8" class="muted" style="padding:32px;text-align:center">No payment attempts found.</td></tr><?php endif; ?>
      <?php foreach ($payments as $p): ?>
        <tr>
          <td><?= e(local_date($p['created_at'])) ?></td>
          <td>
            <?php if (can('orders.view')): ?><a class="row-link" href="<?= e(admin_url('orders/' . (int) $p['order_id'])) ?>"><?= e($p['order_number']) ?></a><?php else: ?><?= e($p['order_number']) ?><?php endif; ?>
            <div class="muted small"><?= e($p['customer_name']) ?></div>
          </td>
          <td><?= e($gateways[$p['gateway']] ?? $p['gateway']) ?></td>
          <td><code><?= e($p['attempt_ref']) ?></code></td>
          <td><?= $p['gateway_txn_id'] ? '<code>' . e($p['gateway_txn_id']) . '</code>' : '<span class="muted">—</span>' ?></td>
          <td class="num"><?= e(money($p['amount'])) ?></td>
          <td><span class="status status-<?= e($p['status']) ?>"><?= e(status_label($p['status'])) ?></span><?php if ($p['gateway_status']): ?><div class="muted small"><?= e($p['gateway_status']) ?></div><?php endif; ?></td>
          <td><?= $p['verified_at'] ? e(local_date($p['verified_at'])) : '<span class="muted">—</span>' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?= $paginator->links() ?>
