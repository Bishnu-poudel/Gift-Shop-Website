<?php
/** @var array $campaigns @var App\Core\Paginator $paginator @var array $filters @var array $allowedTypes */
use App\Controllers\Admin\CampaignsController;

$types = CampaignsController::TYPES;
?>
<div class="admin-page-head">
  <div>
    <h1>Campaigns</h1>
    <p>Banners, seasonal promotions and landing pages. A campaign goes live between its start and end dates.</p>
  </div>
  <div class="admin-actions">
    <?php if ($allowedTypes): ?>
      <a class="btn btn-primary" href="<?= e(admin_url('campaigns/create')) ?>"><?= icon('plus', 'icon-sm') ?> New <?= count($allowedTypes) === 1 ? 'banner' : 'campaign' ?></a>
    <?php endif; ?>
  </div>
</div>

<?php if ($allowedTypes === ['banner']): ?>
  <div class="alert alert-info"><?= icon('info') ?><div>Your role can manage <strong>banner</strong> campaigns. Seasonal promos and landing pages need the Campaigns permission.</div></div>
<?php endif; ?>

<form class="filter-bar" method="get" action="<?= e(admin_url('campaigns')) ?>">
  <div class="field">
    <label for="f-q">Search</label>
    <input class="input" id="f-q" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Name or slug">
  </div>
  <div class="field">
    <label for="f-type">Type</label>
    <select class="select" id="f-type" name="type" data-autosubmit>
      <option value="">All types</option>
      <?php foreach ($types as $k => $label): ?><option value="<?= e($k) ?>" <?= $filters['type'] === $k ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="field">
    <label for="f-status">Status</label>
    <select class="select" id="f-status" name="status" data-autosubmit>
      <option value="">All statuses</option>
      <?php foreach (['live', 'scheduled', 'draft', 'ended'] as $s): ?><option value="<?= e($s) ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= e(status_label($s)) ?></option><?php endforeach; ?>
    </select>
  </div>
  <button class="btn btn-light btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
</form>

<div class="card card-flush">
  <?php if (!$campaigns): ?>
    <div style="padding:24px">
      <?= partial('components/empty-state', ['icon' => 'megaphone', 'title' => 'No campaigns yet', 'text' => 'Plan a seasonal promotion or a homepage banner.', 'actionUrl' => $allowedTypes ? admin_url('campaigns/create') : null, 'actionLabel' => 'Create campaign']) ?>
    </div>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead>
      <tr><th></th><th>Campaign</th><th>Type</th><th>Schedule (NPT)</th><th>Coupon</th><th class="num">Order</th><th>Status</th><th></th></tr>
    </thead>
    <tbody>
    <?php foreach ($campaigns as $c): $editable = in_array($c['type'], $allowedTypes, true); ?>
      <tr>
        <td style="width:60px">
          <?php if ($c['image']): ?><img class="thumb" src="<?= e(image_url($c['image'])) ?>" alt="" loading="lazy"><?php else: ?>
            <span class="thumb" style="display:inline-block;background:<?= e($c['theme_color'] ?: '#efe7da') ?>"></span><?php endif; ?>
        </td>
        <td>
          <?php if ($editable): ?><a class="row-link" href="<?= e(admin_url('campaigns/' . (int) $c['id'] . '/edit')) ?>"><?= e($c['name']) ?></a><?php else: ?><strong><?= e($c['name']) ?></strong><?php endif; ?>
          <div class="muted small"><?= e($c['headline'] ?: '/' . $c['slug']) ?></div>
        </td>
        <td><?= e($types[$c['type']] ?? $c['type']) ?></td>
        <td class="small">
          <?= $c['starts_at'] ? e(local_date($c['starts_at'])) : '<span class="muted">Immediately</span>' ?><br>
          <span class="muted">to</span> <?= $c['ends_at'] ? e(local_date($c['ends_at'])) : '<span class="muted">no end</span>' ?>
        </td>
        <td><?= $c['coupon_code'] ? '<code>' . e($c['coupon_code']) . '</code>' : '<span class="muted">—</span>' ?></td>
        <td class="num"><?= (int) $c['sort_order'] ?></td>
        <td><span class="status status-<?= e($c['status']) ?>"><?= e(status_label($c['status'])) ?></span></td>
        <td class="num">
          <?php if ($c['type'] === 'landing' && $c['status'] === 'live'): ?>
            <a class="btn btn-ghost btn-sm" href="<?= e(url('/campaign/' . $c['slug'])) ?>" target="_blank" rel="noopener"><?= icon('external', 'icon-sm') ?> View</a>
          <?php endif; ?>
          <?php if ($editable): ?>
            <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('campaigns/' . (int) $c['id'] . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
            <?php if ((int) $c['is_active'] === 1): ?>
              <form class="inline-form" method="post" action="<?= e(admin_url('campaigns/' . (int) $c['id'] . '/deactivate')) ?>" data-confirm="Unpublish “<?= e($c['name']) ?>”? It will be hidden from the storefront.">
                <?= csrf_field() ?><button class="btn btn-ghost btn-sm" type="submit">Unpublish</button>
              </form>
            <?php endif; ?>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>
<?= $paginator->links() ?>
