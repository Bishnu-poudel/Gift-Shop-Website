<?php
/** @var ?array $campaign @var array $allowedTypes @var array $coupons @var array $products */
use App\Controllers\Admin\CampaignsController;
use App\Services\CampaignService;

$isEdit = $campaign !== null;
$hasOld = (bool) errors();
$val = static function (string $key, mixed $default = '') use ($campaign, $hasOld) {
    if ($hasOld) {
        return old($key, $default);
    }
    return $campaign[$key] ?? $default;
};
$dt = static function (string $key) use ($campaign, $hasOld): string {
    if ($hasOld) {
        return (string) old($key, '');
    }
    return $campaign && $campaign[$key] ? local_date($campaign[$key], 'Y-m-d\TH:i') : '';
};
$selProducts = $hasOld
    ? array_map('intval', (array) old('product_ids', []))
    : array_map('intval', array_filter(explode(',', (string) ($campaign['product_ids'] ?? ''))));
$type = (string) $val('type', $allowedTypes[0] ?? 'banner');
$isActive = $hasOld ? (bool) old('is_active', false) : (bool) ($campaign['is_active'] ?? false);
$color = (string) $val('theme_color', '');
$body = (string) $val('body', '');
$paragraphs = array_filter(array_map('trim', preg_split('/\n\s*\n/', str_replace("\r\n", "\n", $body)) ?: []));
$action = $isEdit ? admin_url('campaigns/' . (int) $campaign['id']) : admin_url('campaigns');
?>
<div class="admin-page-head">
  <div>
    <h1><?= $isEdit ? 'Edit campaign' : 'New campaign' ?></h1>
    <p>Scheduling is by date: the campaign is live only between its start and end (Nepal time). Leave “Published” off to keep it as a draft.</p>
  </div>
  <div class="admin-actions">
    <?php if ($isEdit && $campaign['type'] === 'landing'): ?>
      <a class="btn btn-light" href="<?= e(url('/campaign/' . $campaign['slug'])) ?>" target="_blank" rel="noopener"><?= icon('external', 'icon-sm') ?> Public page</a>
    <?php endif; ?>
    <a class="btn btn-light" href="<?= e(admin_url('campaigns')) ?>">Back</a>
  </div>
</div>

<div class="admin-grid admin-grid-3-1">
  <form method="post" action="<?= e($action) ?>" enctype="multipart/form-data" class="card" data-loading>
    <?= csrf_field() ?>
    <div class="form-grid">
      <div class="field">
        <label for="name">Internal name</label>
        <input class="input <?= errors('name') ? 'has-error' : '' ?>" id="name" name="name" value="<?= e($val('name')) ?>" maxlength="120" required>
        <?= field_error('name') ?>
      </div>
      <div class="field">
        <label for="slug">Slug</label>
        <input class="input <?= errors('slug') ? 'has-error' : '' ?>" id="slug" name="slug" value="<?= e($val('slug')) ?>" maxlength="140" data-slug-from="#name" pattern="[a-z0-9]+(-[a-z0-9]+)*">
        <p class="hint">Landing pages are served at <code>/campaign/<span>slug</span></code>.</p>
        <?= field_error('slug') ?>
      </div>
      <div class="field">
        <label for="type">Type</label>
        <select class="select" id="type" name="type">
          <?php foreach (CampaignsController::TYPES as $k => $label): if (!in_array($k, $allowedTypes, true)) { continue; } ?>
            <option value="<?= e($k) ?>" <?= $type === $k ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
        <?= field_error('type') ?>
      </div>
      <div class="field">
        <label for="sort_order">Display order</label>
        <input class="input" id="sort_order" name="sort_order" type="number" step="1" value="<?= e($val('sort_order', '0')) ?>">
        <p class="hint">Lower numbers show first.</p>
        <?= field_error('sort_order') ?>
      </div>

      <div class="field span-2">
        <label for="headline">Headline</label>
        <input class="input" id="headline" name="headline" value="<?= e($val('headline')) ?>" maxlength="190">
        <?= field_error('headline') ?>
      </div>
      <div class="field span-2">
        <label for="subheadline">Subheadline</label>
        <input class="input" id="subheadline" name="subheadline" value="<?= e($val('subheadline')) ?>" maxlength="300">
        <?= field_error('subheadline') ?>
      </div>
      <div class="field span-2">
        <label for="body">Body text</label>
        <textarea class="textarea" id="body" name="body" rows="6" maxlength="20000"><?= e($body) ?></textarea>
        <p class="hint">Plain text. Leave a blank line between paragraphs. HTML is shown as text, not rendered.</p>
        <?= field_error('body') ?>
      </div>

      <div class="field span-2">
        <label for="image">Image</label>
        <?php if ($isEdit && $campaign['image']): ?>
          <div class="row" style="margin-bottom:8px">
            <img src="<?= e(image_url($campaign['image'])) ?>" alt="" style="width:160px;height:90px;object-fit:cover;border-radius:8px;border:1px solid var(--line)">
            <label class="check"><input type="checkbox" name="remove_image" value="1"> <span>Remove current image</span></label>
          </div>
        <?php endif; ?>
        <input class="input" id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp,image/gif">
        <p class="hint">JPEG, PNG, WebP or GIF up to 5 MB. Wide images (about 1600×700) work best.</p>
        <?= field_error('image') ?>
      </div>

      <div class="field">
        <label for="cta_label">Button label</label>
        <input class="input" id="cta_label" name="cta_label" value="<?= e($val('cta_label')) ?>" maxlength="60" placeholder="Shop the collection">
        <?= field_error('cta_label') ?>
      </div>
      <div class="field">
        <label for="cta_url">Button link</label>
        <input class="input <?= errors('cta_url') ? 'has-error' : '' ?>" id="cta_url" name="cta_url" value="<?= e($val('cta_url')) ?>" maxlength="255" placeholder="/gifts/occasion/dashain">
        <p class="hint">A path like <code>/shop</code> or a full <code>https://</code> URL.</p>
        <?= field_error('cta_url') ?>
      </div>

      <div class="field">
        <label for="coupon_id">Linked coupon</label>
        <select class="select" id="coupon_id" name="coupon_id">
          <option value="">No coupon</option>
          <?php foreach ($coupons as $cp): ?>
            <option value="<?= (int) $cp['id'] ?>" <?= (string) $val('coupon_id') === (string) $cp['id'] ? 'selected' : '' ?>><?= e($cp['code']) ?><?= (int) $cp['is_active'] ? '' : ' (inactive)' ?></option>
          <?php endforeach; ?>
        </select>
        <?= field_error('coupon_id') ?>
      </div>
      <div class="field">
        <label for="theme_color">Theme colour</label>
        <div class="input-group">
          <input type="color" aria-label="Pick colour" value="<?= e(preg_match('/^#[0-9a-fA-F]{6}$/', $color) ? $color : '#b4532a') ?>" data-color-picker style="width:48px;height:44px;border:1px solid var(--line);border-radius:8px;padding:2px;background:var(--paper)">
          <input class="input <?= errors('theme_color') ? 'has-error' : '' ?>" id="theme_color" name="theme_color" value="<?= e($color) ?>" maxlength="7" placeholder="#b4532a" data-color-text>
        </div>
        <?= field_error('theme_color') ?>
      </div>

      <div class="field span-2">
        <label for="product_ids">Featured products <span class="muted">(up to 24, shown on the landing page)</span></label>
        <select class="select" id="product_ids" name="product_ids[]" multiple size="8" style="height:auto;background-image:none">
          <?php foreach ($products as $p): ?>
            <option value="<?= (int) $p['id'] ?>" <?= in_array((int) $p['id'], $selProducts, true) ? 'selected' : '' ?>><?= e($p['name']) ?> (<?= e($p['sku']) ?>)</option>
          <?php endforeach; ?>
        </select>
        <p class="hint">Hold Ctrl (Cmd on Mac) to select several.</p>
        <?= field_error('product_ids') ?>
      </div>

      <div class="field">
        <label for="starts_at">Starts (Nepal time)</label>
        <input class="input" id="starts_at" name="starts_at" type="datetime-local" value="<?= e($dt('starts_at')) ?>">
        <?= field_error('starts_at') ?>
      </div>
      <div class="field">
        <label for="ends_at">Ends (Nepal time)</label>
        <input class="input <?= errors('ends_at') ? 'has-error' : '' ?>" id="ends_at" name="ends_at" type="datetime-local" value="<?= e($dt('ends_at')) ?>">
        <?= field_error('ends_at') ?>
      </div>
      <div class="field span-2">
        <label class="check"><input type="checkbox" name="is_active" value="1" <?= $isActive ? 'checked' : '' ?>> <span>Published — show on the storefront during the scheduled dates</span></label>
      </div>
    </div>
    <div class="form-actions">
      <a class="btn btn-ghost" href="<?= e(admin_url('campaigns')) ?>">Cancel</a>
      <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save campaign' : 'Create campaign' ?></button>
    </div>
  </form>

  <aside>
    <?php if ($isEdit): $status = CampaignService::statusOf($campaign); ?>
      <div class="card">
        <div class="card-head"><h2>Status</h2><span class="status status-<?= e($status) ?>"><?= e(status_label($status)) ?></span></div>
        <ul class="list-plain">
          <li><span>Starts</span><span><?= $campaign['starts_at'] ? e(local_date($campaign['starts_at'])) : 'Immediately' ?></span></li>
          <li><span>Ends</span><span><?= $campaign['ends_at'] ? e(local_date($campaign['ends_at'])) : 'No end date' ?></span></li>
          <li><span>Last updated</span><span><?= e(local_date($campaign['updated_at'])) ?></span></li>
        </ul>
      </div>
    <?php endif; ?>
    <div class="card" style="<?= $color && preg_match('/^#(?:[0-9a-fA-F]{3}){1,2}$/', $color) ? 'border-top:4px solid ' . e($color) : '' ?>">
      <div class="card-head"><h2>Preview</h2><span class="muted small">Saved content</span></div>
      <?php if ($isEdit && $campaign['image']): ?><img src="<?= e(image_url($campaign['image'])) ?>" alt="" style="width:100%;border-radius:8px;margin-bottom:12px"><?php endif; ?>
      <h3 style="font-size:1.25rem;margin:0 0 4px"><?= e($val('headline') ?: $val('name') ?: 'Headline') ?></h3>
      <?php if ($val('subheadline')): ?><p class="muted" style="margin:0 0 8px"><?= e($val('subheadline')) ?></p><?php endif; ?>
      <?php foreach (array_slice($paragraphs, 0, 3) as $para): ?><p class="small"><?= nl2br(e($para)) ?></p><?php endforeach; ?>
      <?php if ($val('cta_label')): ?><span class="btn btn-accent btn-sm"><?= e($val('cta_label')) ?></span><?php endif; ?>
    </div>
  </aside>
</div>

<script>
(function () {
  var picker = document.querySelector('[data-color-picker]');
  var text = document.querySelector('[data-color-text]');
  if (!picker || !text) return;
  picker.addEventListener('input', function () { text.value = picker.value; });
  text.addEventListener('input', function () { if (/^#[0-9a-fA-F]{6}$/.test(text.value)) picker.value = text.value; });
})();
</script>
