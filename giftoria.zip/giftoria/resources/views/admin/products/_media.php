<?php
/** Product images tab. Vars: $product, $maxImages */
$pid = (int) $product['id'];
$images = $product['images'];
$remaining = max(0, $maxImages - count($images));
?>
<div class="admin-grid admin-grid-3-1">
  <section class="card">
    <div class="card-head">
      <h2>Images</h2>
      <span class="muted small"><?= count($images) ?> of <?= (int) $maxImages ?> · drag to reorder, the first image is the primary image</span>
    </div>
    <?php if (!$images): ?>
      <?= partial('components/empty-state', ['icon' => 'image', 'title' => 'No images yet', 'text' => 'Upload at least one clear photo before publishing.']) ?>
    <?php else: ?>
      <form method="post" action="<?= e(admin_url('products/' . $pid . '/images/save')) ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="order" id="image-order" value="<?= e(implode(',', array_map(static fn ($i) => (int) $i['id'], $images))) ?>">
        <ul class="sortable-list image-manager" data-sortable data-input="image-order" style="grid-template-columns:repeat(auto-fill,minmax(190px,1fr))">
          <?php foreach ($images as $idx => $img): $iid = (int) $img['id']; ?>
            <li data-id="<?= $iid ?>" style="flex-direction:column;align-items:stretch;padding:var(--s-2)">
              <figure>
                <img src="<?= e(image_url($img['path'])) ?>" alt="<?= e($img['alt'] ?: $product['name']) ?>" loading="lazy">
                <figcaption>
                  <?php if ($idx === 0): ?><span class="badge badge-success">Primary</span><?php else: ?><span></span><?php endif; ?>
                  <span class="badge"><?= icon('grip', 'icon-sm') ?></span>
                </figcaption>
              </figure>
              <label class="sr-only" for="alt-<?= $iid ?>">Alt text for image <?= $idx + 1 ?></label>
              <input class="input" id="alt-<?= $iid ?>" name="alt[<?= $iid ?>]" value="<?= e($img['alt']) ?>" maxlength="190" placeholder="Alt text" style="min-height:36px;font-size:var(--fs-xs)">
              <div class="row" style="gap:4px;justify-content:space-between">
                <span class="row" style="gap:2px">
                  <button class="btn btn-ghost btn-sm" type="button" data-move="up" aria-label="Move earlier"><?= icon('arrow-up', 'icon-sm') ?></button>
                  <button class="btn btn-ghost btn-sm" type="button" data-move="down" aria-label="Move later"><?= icon('arrow-down', 'icon-sm') ?></button>
                </span>
                <span class="row" style="gap:2px">
                  <?php if ($idx !== 0): ?>
                    <button class="btn btn-ghost btn-sm" type="submit" form="img-primary-<?= $iid ?>" title="Make primary"><?= icon('star', 'icon-sm') ?><span class="sr-only">Make primary</span></button>
                  <?php endif; ?>
                  <button class="btn btn-ghost btn-sm" type="submit" form="img-delete-<?= $iid ?>" title="Delete image"><?= icon('trash', 'icon-sm') ?><span class="sr-only">Delete</span></button>
                </span>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
        <div class="form-actions">
          <button class="btn btn-primary" type="submit">Save order &amp; alt text</button>
        </div>
      </form>
      <?php foreach ($images as $img): $iid = (int) $img['id']; ?>
        <form id="img-primary-<?= $iid ?>" method="post" action="<?= e(admin_url('products/' . $pid . '/images/' . $iid . '/primary')) ?>" hidden><?= csrf_field() ?></form>
        <form id="img-delete-<?= $iid ?>" method="post" action="<?= e(admin_url('products/' . $pid . '/images/' . $iid . '/delete')) ?>" data-confirm="Delete this image permanently?" hidden><?= csrf_field() ?></form>
      <?php endforeach; ?>
    <?php endif; ?>
  </section>

  <section class="card">
    <div class="card-head"><h2>Upload images</h2></div>
    <?php if ($remaining === 0): ?>
      <p class="muted small">This product has the maximum of <?= (int) $maxImages ?> images. Delete one to upload more.</p>
    <?php else: ?>
      <form method="post" action="<?= e(admin_url('products/' . $pid . '/images')) ?>" enctype="multipart/form-data" data-loading>
        <?= csrf_field() ?>
        <div class="field">
          <label for="up-images">Choose images</label>
          <input class="input" id="up-images" name="images[]" type="file" accept="image/jpeg,image/png,image/webp,image/gif" multiple required>
          <p class="hint">JPEG, PNG, WebP or GIF, up to 5 MB each. <?= (int) $remaining ?> more allowed.</p>
        </div>
        <div class="field">
          <label for="up-alt">Alt text</label>
          <input class="input" id="up-alt" name="image_alt" maxlength="190" placeholder="<?= e($product['name']) ?>">
          <p class="hint">Describe the photo for screen readers. You can edit it per image later.</p>
        </div>
        <button class="btn btn-accent btn-block" type="submit"><?= icon('upload', 'icon-sm') ?> Upload</button>
      </form>
    <?php endif; ?>
  </section>
</div>
