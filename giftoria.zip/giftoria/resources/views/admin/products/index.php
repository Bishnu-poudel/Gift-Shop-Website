<?php
/** Vars: $products, $total, $paginator, $categories, $counts, $filters */
$statusTabs = ['' => 'All', 'active' => 'Active', 'draft' => 'Draft', 'inactive' => 'Inactive'];
$allCount = array_sum($counts);
?>
<div class="admin-page-head">
  <div>
    <h1>Products</h1>
    <p><?= e(number_format($allCount)) ?> products in the catalog · <?= e(number_format($counts['active'])) ?> live</p>
  </div>
  <div class="admin-actions">
    <?php if (can('inventory.manage')): ?><a class="btn btn-light" href="<?= e(admin_url('inventory')) ?>"><?= icon('boxes', 'icon-sm') ?> Inventory</a><?php endif; ?>
    <a class="btn btn-accent" href="<?= e(admin_url('products/create')) ?>"><?= icon('plus', 'icon-sm') ?> New product</a>
  </div>
</div>

<nav class="tabs" aria-label="Product status">
  <?php foreach ($statusTabs as $key => $label):
      $q = array_filter(['q' => $filters['q'], 'category' => $filters['category'] ?: null, 'stock' => $filters['stock'], 'sort' => $filters['sort'], 'status' => $key]);
      $n = $key === '' ? $allCount : ($counts[$key] ?? 0);
  ?>
    <a href="<?= e(admin_url('products') . ($q ? '?' . http_build_query($q) : '')) ?>" class="<?= $filters['status'] === $key ? 'is-active' : '' ?>"><?= e($label) ?> <span class="muted">(<?= e((string) $n) ?>)</span></a>
  <?php endforeach; ?>
</nav>

<form class="filter-bar" method="get" action="<?= e(admin_url('products')) ?>" role="search">
  <input type="hidden" name="status" value="<?= e($filters['status']) ?>">
  <div class="field">
    <label for="f-q">Search</label>
    <input class="input" id="f-q" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Name or SKU">
  </div>
  <div class="field">
    <label for="f-cat">Category</label>
    <select class="select" id="f-cat" name="category">
      <option value="">All categories</option>
      <?php foreach ($categories as $c): ?>
        <option value="<?= (int) $c['id'] ?>" <?= (int) $filters['category'] === (int) $c['id'] ? 'selected' : '' ?>><?= e(str_repeat('— ', (int) $c['depth']) . $c['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field">
    <label for="f-stock">Stock</label>
    <select class="select" id="f-stock" name="stock">
      <option value="">Any stock</option>
      <option value="in" <?= $filters['stock'] === 'in' ? 'selected' : '' ?>>In stock</option>
      <option value="low" <?= $filters['stock'] === 'low' ? 'selected' : '' ?>>Low stock</option>
      <option value="out" <?= $filters['stock'] === 'out' ? 'selected' : '' ?>>Out of stock</option>
    </select>
  </div>
  <div class="field">
    <label for="f-sort">Sort</label>
    <select class="select" id="f-sort" name="sort">
      <?php foreach (['newest' => 'Newest', 'name' => 'Name A–Z', 'price_asc' => 'Price: low to high', 'price_desc' => 'Price: high to low', 'popular' => 'Best selling'] as $k => $l): ?>
        <option value="<?= e($k) ?>" <?= $filters['sort'] === $k ? 'selected' : '' ?>><?= e($l) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <button class="btn btn-primary btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
  <?php if ($filters['q'] !== '' || $filters['category'] || $filters['stock'] !== ''): ?>
    <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('products') . ($filters['status'] ? '?status=' . urlencode($filters['status']) : '')) ?>">Clear</a>
  <?php endif; ?>
</form>

<?php if (!$products): ?>
  <?= partial('components/empty-state', [
      'icon' => 'gift',
      'title' => 'No products found',
      'text' => $filters['q'] !== '' || $filters['category'] || $filters['stock'] !== '' ? 'Try a different search or clear the filters.' : 'Add your first product to start selling.',
      'actionUrl' => admin_url('products/create'),
      'actionLabel' => 'New product',
  ]) ?>
<?php else: ?>
<div class="card card-flush">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th scope="col"><span class="sr-only">Image</span></th>
          <th scope="col">Product</th>
          <th scope="col">Category</th>
          <th scope="col" class="num">Price</th>
          <th scope="col" class="num">Stock</th>
          <th scope="col">Status</th>
          <th scope="col">Updated</th>
          <th scope="col"><span class="sr-only">Actions</span></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($products as $p):
          $stock = (int) $p['stock'];
          $editUrl = admin_url('products/' . (int) $p['id'] . '/edit');
      ?>
        <tr>
          <td><img class="thumb" src="<?= e(image_url($p['image'])) ?>" alt="<?= e($p['image_alt'] ?: $p['name']) ?>" loading="lazy" width="44" height="52"></td>
          <td>
            <a class="row-link" href="<?= e($editUrl) ?>"><?= e($p['name']) ?></a>
            <div class="muted small">SKU <?= e($p['sku']) ?>
              <?php if ((int) $p['is_featured']): ?> · <span class="badge badge-info">Featured</span><?php endif; ?>
              <?php if ((int) $p['is_bestseller']): ?> · <span class="badge badge-best">Bestseller</span><?php endif; ?>
            </div>
          </td>
          <td><?= e($p['category_name'] ?? '—') ?></td>
          <td class="num">
            <?php if ($p['sale_price'] !== null): ?>
              <strong><?= e(money($p['sale_price'])) ?></strong><br><s class="muted small"><?= e(money($p['price'])) ?></s>
            <?php else: ?>
              <?= e(money($p['price'])) ?>
            <?php endif; ?>
          </td>
          <td class="num">
            <?php if ($stock <= 0): ?>
              <span class="badge badge-danger"><?= e((string) $stock) ?> · Out</span>
            <?php elseif ($stock <= 5): ?>
              <span class="badge badge-warning"><?= e((string) $stock) ?> · Low</span>
            <?php else: ?>
              <?= e(number_format($stock)) ?>
            <?php endif; ?>
          </td>
          <td><span class="status status-<?= e($p['status']) ?>"><?= e(status_label($p['status'])) ?></span></td>
          <td class="muted small"><?= e(local_date($p['updated_at'], 'M j, Y')) ?></td>
          <td>
            <div class="row" style="gap:6px;flex-wrap:nowrap;justify-content:flex-end">
              <a class="btn btn-light btn-sm" href="<?= e($editUrl) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
              <?php if ($p['status'] !== 'active'): ?>
                <form method="post" action="<?= e(admin_url('products/' . (int) $p['id'] . '/status')) ?>" class="inline-form">
                  <?= csrf_field() ?><input type="hidden" name="status" value="active">
                  <button class="btn btn-ghost btn-sm" type="submit" title="Publish">Publish</button>
                </form>
              <?php else: ?>
                <form method="post" action="<?= e(admin_url('products/' . (int) $p['id'] . '/status')) ?>" class="inline-form" data-confirm="Deactivate this product? It will be hidden from the store.">
                  <?= csrf_field() ?><input type="hidden" name="status" value="inactive">
                  <button class="btn btn-ghost btn-sm" type="submit" title="Deactivate">Deactivate</button>
                </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<p class="muted small">Showing <?= e((string) count($products)) ?> of <?= e(number_format($total)) ?> products.</p>
<?= $paginator->links() ?>
<?php endif; ?>
