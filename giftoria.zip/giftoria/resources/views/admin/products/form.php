<?php
/**
 * Create / edit product. Vars: $product (null on create), $tab, $categories, $makers, $recipients, $occasions,
 * $interests, $generalTags, $preferenceTags, $agePresets, $maxImages
 */
$isEdit = $product !== null;
$pid = $isEdit ? (int) $product['id'] : 0;
// Only use flashed "old" input when it belongs to this form (a variant form error also flashes old input).
$hasOld = (bool) errors() && old('sku', null) !== null;
$val = static function (string $key, mixed $default = '') use ($product, $hasOld) {
    if ($hasOld) {
        $o = old($key, null);
        return is_scalar($o) ? (string) $o : '';
    }
    $v = $product[$key] ?? $default;
    return $v === null ? '' : (string) $v;
};
$checked = static function (string $key, bool $default = false) use ($product, $hasOld): string {
    $on = $hasOld ? in_array(old($key, ''), ['1', 'on', 'yes', 'true'], true) : (bool) ($product[$key] ?? $default);
    return $on ? 'checked' : '';
};
$selected = static function (string $key, array $current) use ($hasOld): array {
    return $hasOld ? array_map('intval', (array) old($key, [])) : $current;
};
$err = static fn (string $k): string => errors($k) ? 'has-error' : '';

$recipientSel = $selected('recipients', $product['recipient_ids'] ?? []);
$occasionSel = $selected('occasions', $product['occasion_ids'] ?? []);
$interestSel = $selected('interests', $product['interest_ids'] ?? []);
$tagSel = $hasOld ? array_map('intval', array_merge((array) old('tags', []), (array) old('pref_tags', []))) : ($product['tag_ids'] ?? []);

if ($hasOld) {
    $attrs = [];
    foreach ((array) old('attr_name', []) as $i => $n) {
        $attrs[] = ['name' => is_scalar($n) ? (string) $n : '', 'value' => is_scalar(old('attr_value', [])[$i] ?? '') ? (string) (old('attr_value', [])[$i] ?? '') : ''];
    }
} else {
    $attrs = $product['attributes'] ?? [];
}
$attrs = array_values(array_filter($attrs, static fn ($a) => $a['name'] !== '' || $a['value'] !== ''));
for ($i = 0; $i < 3; $i++) {
    $attrs[] = ['name' => '', 'value' => ''];
}
$status = $isEdit ? $product['status'] : 'draft';
$action = $isEdit ? admin_url('products/' . $pid) : admin_url('products');
?>
<div class="admin-page-head">
  <div>
    <p class="small"><a href="<?= e(admin_url('products')) ?>"><?= icon('chevron-left', 'icon-sm') ?> All products</a></p>
    <h1><?= e($isEdit ? $product['name'] : 'New product') ?></h1>
    <?php if ($isEdit): ?>
      <p>SKU <?= e($product['sku']) ?> · <span class="status status-<?= e($status) ?>"><?= e(status_label($status)) ?></span> · <?= e(number_format((int) $product['total_stock'])) ?> in stock · updated <?= e(local_date($product['updated_at'])) ?></p>
    <?php else: ?>
      <p>New products start as drafts. Publish when the details, images and stock are ready.</p>
    <?php endif; ?>
  </div>
  <?php if ($isEdit): ?>
  <div class="admin-actions">
    <?php if ($status === 'active'): ?>
      <a class="btn btn-light" href="<?= e(url('/product/' . $product['slug'])) ?>" target="_blank" rel="noopener"><?= icon('external', 'icon-sm') ?> View in store</a>
      <form method="post" action="<?= e(admin_url('products/' . $pid . '/status')) ?>" class="inline-form" data-confirm="Deactivate this product? It will be hidden from the store.">
        <?= csrf_field() ?><input type="hidden" name="status" value="inactive">
        <button class="btn btn-outline" type="submit"><?= icon('eye-off', 'icon-sm') ?> Deactivate</button>
      </form>
    <?php else: ?>
      <?php if ($status === 'inactive'): ?>
        <form method="post" action="<?= e(admin_url('products/' . $pid . '/status')) ?>" class="inline-form">
          <?= csrf_field() ?><input type="hidden" name="status" value="draft">
          <button class="btn btn-light" type="submit">Move to draft</button>
        </form>
      <?php endif; ?>
      <form method="post" action="<?= e(admin_url('products/' . $pid . '/status')) ?>" class="inline-form">
        <?= csrf_field() ?><input type="hidden" name="status" value="active">
        <button class="btn btn-accent" type="submit"><?= icon('check', 'icon-sm') ?> Publish</button>
      </form>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</div>

<?php if ($isEdit): ?>
<nav class="tabs" aria-label="Product sections">
  <a href="<?= e(admin_url('products/' . $pid . '/edit')) ?>" class="<?= $tab === 'details' ? 'is-active' : '' ?>">Details</a>
  <a href="<?= e(admin_url('products/' . $pid . '/edit?tab=media')) ?>" class="<?= $tab === 'media' ? 'is-active' : '' ?>">Images (<?= count($product['images']) ?>)</a>
  <a href="<?= e(admin_url('products/' . $pid . '/edit?tab=variants')) ?>" class="<?= $tab === 'variants' ? 'is-active' : '' ?>">Variants (<?= count($product['variants']) ?>)</a>
</nav>
<?php endif; ?>

<?php if ($isEdit && $tab === 'media'): ?>
  <?= partial('admin/products/_media', ['product' => $product, 'maxImages' => $maxImages]) ?>
<?php elseif ($isEdit && $tab === 'variants'): ?>
  <?= partial('admin/products/_variants', ['product' => $product]) ?>
<?php else: ?>

<form method="post" action="<?= e($action) ?>" enctype="multipart/form-data" data-loading novalidate>
  <?= csrf_field() ?>
  <div class="admin-grid admin-grid-3-1">
    <div>
      <section class="card">
        <div class="card-head"><h2>Basics</h2></div>
        <div class="form-grid">
          <div class="field span-2">
            <label for="p-name">Product name *</label>
            <input class="input <?= $err('name') ?>" id="p-name" name="name" value="<?= e($val('name')) ?>" required maxlength="190">
            <?= field_error('name') ?>
          </div>
          <div class="field">
            <label for="p-sku">SKU *</label>
            <input class="input <?= $err('sku') ?>" id="p-sku" name="sku" value="<?= e($val('sku')) ?>" required maxlength="60" pattern="[A-Za-z0-9._\-]+" autocomplete="off">
            <p class="hint">Letters, numbers, dot, dash and underscore. Must be unique.</p>
            <?= field_error('sku') ?>
          </div>
          <div class="field">
            <label for="p-slug">URL slug</label>
            <input class="input <?= $err('slug') ?>" id="p-slug" name="slug" value="<?= e($val('slug')) ?>" maxlength="200" data-slug-from="#p-name" placeholder="auto-from-name">
            <p class="hint">Leave empty to generate it from the name.</p>
            <?= field_error('slug') ?>
          </div>
          <div class="field span-2">
            <label for="p-short">Short description</label>
            <textarea class="textarea <?= $err('short_description') ?>" id="p-short" name="short_description" rows="2" maxlength="500" style="min-height:70px"><?= e($val('short_description')) ?></textarea>
            <p class="hint">Shown on product cards and search results (max 500 characters).</p>
            <?= field_error('short_description') ?>
          </div>
          <div class="field span-2">
            <label for="p-desc">Full description</label>
            <textarea class="textarea <?= $err('description') ?>" id="p-desc" name="description" rows="8"><?= e($val('description')) ?></textarea>
            <?= field_error('description') ?>
          </div>
        </div>
      </section>

      <section class="card">
        <div class="card-head"><h2>Pricing</h2></div>
        <div class="form-row-3">
          <div class="field">
            <label for="p-price">Price (NPR) *</label>
            <input class="input <?= $err('price') ?>" id="p-price" name="price" type="number" min="0" step="0.01" value="<?= e($val('price')) ?>" required>
            <?= field_error('price') ?>
          </div>
          <div class="field">
            <label for="p-sale">Sale price</label>
            <input class="input <?= $err('sale_price') ?>" id="p-sale" name="sale_price" type="number" min="0" step="0.01" value="<?= e($val('sale_price')) ?>">
            <p class="hint">Must be lower than the price. Empty = no sale.</p>
            <?= field_error('sale_price') ?>
          </div>
          <div class="field">
            <label for="p-cost">Cost price</label>
            <input class="input <?= $err('cost_price') ?>" id="p-cost" name="cost_price" type="number" min="0" step="0.01" value="<?= e($val('cost_price')) ?>">
            <p class="hint">Internal only, used for margin reports.</p>
            <?= field_error('cost_price') ?>
          </div>
        </div>
      </section>

      <section class="card">
        <div class="card-head"><h2>Age &amp; safety</h2></div>
        <div class="form-row-3">
          <div class="field">
            <label for="p-age-preset">Age preset</label>
            <select class="select" id="p-age-preset" name="age_preset">
              <option value="">Custom (use the fields)</option>
              <?php foreach ($agePresets as $label => [$min, $max]): ?>
                <option value="<?= (int) $min ?>-<?= (int) $max ?>"><?= e($label) ?></option>
              <?php endforeach; ?>
            </select>
            <p class="hint">Picking a preset fills the month fields.</p>
          </div>
          <div class="field">
            <label for="p-age-min">Minimum age (months)</label>
            <input class="input <?= $err('age_min_months') ?>" id="p-age-min" name="age_min_months" type="number" min="0" max="1200" value="<?= e($val('age_min_months')) ?>">
            <?= field_error('age_min_months') ?>
          </div>
          <div class="field">
            <label for="p-age-max">Maximum age (months)</label>
            <input class="input <?= $err('age_max_months') ?>" id="p-age-max" name="age_max_months" type="number" min="0" max="1200" value="<?= e($val('age_max_months')) ?>">
            <p class="hint">1200 = no upper limit. Empty = not age specific.</p>
            <?= field_error('age_max_months') ?>
          </div>
        </div>
        <div class="checkbox-grid mb-4">
          <label class="check"><input type="checkbox" name="has_small_parts" value="1" <?= $checked('has_small_parts') ?>> Contains small parts (choking hazard)</label>
          <label class="check"><input type="checkbox" name="gender_neutral" value="1" <?= $checked('gender_neutral', true) ?>> Gender neutral</label>
        </div>
        <?= field_error('has_small_parts') ?>
        <div class="field">
          <label for="p-safety">Safety information</label>
          <textarea class="textarea <?= $err('safety_info') ?>" id="p-safety" name="safety_info" rows="3"><?= e($val('safety_info')) ?></textarea>
          <p class="hint">Warnings, certifications and care instructions. Items for babies and toddlers are never shown in under-3 results if they contain small parts.</p>
          <?= field_error('safety_info') ?>
        </div>
      </section>

      <section class="card">
        <div class="card-head"><h2>Personalization &amp; gifting</h2></div>
        <div class="checkbox-grid mb-4">
          <label class="check"><input type="checkbox" name="is_personalizable" value="1" <?= $checked('is_personalizable') ?>> Can be personalized</label>
          <label class="check"><input type="checkbox" name="gift_wrap_available" value="1" <?= $checked('gift_wrap_available', true) ?>> Gift wrap available</label>
        </div>
        <div class="form-grid">
          <div class="field">
            <label for="p-plabel">Personalization label</label>
            <input class="input <?= $err('personalization_label') ?>" id="p-plabel" name="personalization_label" value="<?= e($val('personalization_label')) ?>" maxlength="120" placeholder="e.g. Name to engrave">
            <?= field_error('personalization_label') ?>
          </div>
          <div class="field">
            <label for="p-pmax">Maximum characters</label>
            <input class="input <?= $err('personalization_max_chars') ?>" id="p-pmax" name="personalization_max_chars" type="number" min="1" max="255" value="<?= e($val('personalization_max_chars')) ?>">
            <?= field_error('personalization_max_chars') ?>
          </div>
        </div>
      </section>

      <section class="card">
        <div class="card-head"><h2>Delivery</h2></div>
        <div class="checkbox-grid mb-4">
          <label class="check"><input type="checkbox" name="valley_only" value="1" <?= $checked('valley_only') ?>> Kathmandu Valley delivery only</label>
          <label class="check"><input type="checkbox" name="allow_backorder" value="1" <?= $checked('allow_backorder') ?>> Allow backorders when out of stock</label>
        </div>
        <div class="form-grid">
          <div class="field">
            <label for="p-lead">Lead time (days)</label>
            <input class="input <?= $err('lead_time_days') ?>" id="p-lead" name="lead_time_days" type="number" min="0" max="120" value="<?= e($val('lead_time_days', '0')) ?>">
            <p class="hint">Extra days needed before dispatch (e.g. made to order).</p>
            <?= field_error('lead_time_days') ?>
          </div>
          <div class="field">
            <label for="p-restr">Delivery restrictions</label>
            <input class="input <?= $err('delivery_restrictions') ?>" id="p-restr" name="delivery_restrictions" value="<?= e($val('delivery_restrictions')) ?>" maxlength="255" placeholder="e.g. Fragile, not shipped outside Bagmati">
            <?= field_error('delivery_restrictions') ?>
          </div>
        </div>
      </section>

      <section class="card">
        <div class="card-head"><h2>Specifications</h2></div>
        <div class="form-grid">
          <div class="field">
            <label for="p-mat">Materials</label>
            <input class="input <?= $err('materials') ?>" id="p-mat" name="materials" value="<?= e($val('materials')) ?>" maxlength="255">
            <?= field_error('materials') ?>
          </div>
          <div class="field">
            <label for="p-dim">Dimensions</label>
            <input class="input <?= $err('dimensions') ?>" id="p-dim" name="dimensions" value="<?= e($val('dimensions')) ?>" maxlength="120" placeholder="e.g. 20 × 15 × 8 cm">
            <?= field_error('dimensions') ?>
          </div>
          <div class="field">
            <label for="p-weight">Weight (grams)</label>
            <input class="input <?= $err('weight_grams') ?>" id="p-weight" name="weight_grams" type="number" min="0" value="<?= e($val('weight_grams')) ?>">
            <?= field_error('weight_grams') ?>
          </div>
          <div class="field">
            <label for="p-video">Video URL</label>
            <input class="input <?= $err('video_url') ?>" id="p-video" name="video_url" type="url" value="<?= e($val('video_url')) ?>" maxlength="255" placeholder="https://">
            <p class="hint">HTTPS links only (e.g. YouTube).</p>
            <?= field_error('video_url') ?>
          </div>
        </div>
        <h3 class="label mt-4">Attributes</h3>
        <p class="muted small">Extra facts shown in the product details table, e.g. "Origin: Bhaktapur".</p>
        <?= field_error('attributes') ?>
        <?php foreach ($attrs as $i => $a): ?>
          <div class="form-row mb-2">
            <input class="input" name="attr_name[]" value="<?= e($a['name']) ?>" maxlength="80" placeholder="Name" aria-label="Attribute <?= $i + 1 ?> name">
            <input class="input" name="attr_value[]" value="<?= e($a['value']) ?>" maxlength="255" placeholder="Value" aria-label="Attribute <?= $i + 1 ?> value">
          </div>
        <?php endforeach; ?>
        <p class="hint">Save to get more empty rows. Clear both fields to remove an attribute.</p>
      </section>

      <section class="card">
        <div class="card-head"><h2>Search engine listing</h2></div>
        <div class="field">
          <label for="p-seo-title">SEO title</label>
          <input class="input <?= $err('seo_title') ?>" id="p-seo-title" name="seo_title" value="<?= e($val('seo_title')) ?>" maxlength="190">
          <?= field_error('seo_title') ?>
        </div>
        <div class="field">
          <label for="p-seo-desc">SEO description</label>
          <textarea class="textarea <?= $err('seo_description') ?>" id="p-seo-desc" name="seo_description" rows="2" maxlength="300" style="min-height:70px"><?= e($val('seo_description')) ?></textarea>
          <?= field_error('seo_description') ?>
        </div>
      </section>
    </div>

    <div>
      <section class="card">
        <div class="card-head"><h2>Publishing</h2></div>
        <div class="field">
          <label for="p-status">Status</label>
          <select class="select <?= $err('status') ?>" id="p-status" name="status">
            <?php foreach (['draft' => 'Draft (hidden)', 'active' => 'Active (visible in store)', 'inactive' => 'Inactive (hidden)'] as $k => $l): ?>
              <option value="<?= e($k) ?>" <?= $val('status', 'draft') === $k ? 'selected' : '' ?>><?= e($l) ?></option>
            <?php endforeach; ?>
          </select>
          <?= field_error('status') ?>
        </div>
        <div class="stack" style="--gap:8px">
          <label class="check"><input type="checkbox" name="is_featured" value="1" <?= $checked('is_featured') ?>> Featured product</label>
          <label class="check"><input type="checkbox" name="is_bestseller" value="1" <?= $checked('is_bestseller') ?>> Mark as bestseller</label>
        </div>
        <div class="form-actions">
          <a class="btn btn-ghost" href="<?= e(admin_url('products')) ?>">Cancel</a>
          <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save changes' : 'Create product' ?></button>
        </div>
      </section>

      <section class="card">
        <div class="card-head"><h2>Organization</h2></div>
        <div class="field">
          <label for="p-cat">Category</label>
          <select class="select <?= $err('category_id') ?>" id="p-cat" name="category_id">
            <option value="">— None —</option>
            <?php foreach ($categories as $c): ?>
              <option value="<?= (int) $c['id'] ?>" <?= $val('category_id') === (string) $c['id'] ? 'selected' : '' ?>><?= e(str_repeat('— ', (int) $c['depth']) . $c['name']) ?><?= (int) $c['is_active'] ? '' : ' (inactive)' ?></option>
            <?php endforeach; ?>
          </select>
          <?= field_error('category_id') ?>
        </div>
        <div class="field">
          <label for="p-maker">Maker</label>
          <select class="select <?= $err('maker_id') ?>" id="p-maker" name="maker_id">
            <option value="">— None —</option>
            <?php foreach ($makers as $m): ?>
              <option value="<?= (int) $m['id'] ?>" <?= $val('maker_id') === (string) $m['id'] ? 'selected' : '' ?>><?= e($m['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <?= field_error('maker_id') ?>
        </div>
      </section>

      <?php
      $groups = [
          ['Recipients', 'recipients', $recipients, $recipientSel],
          ['Occasions', 'occasions', $occasions, $occasionSel],
          ['Interests', 'interests', $interests, $interestSel],
          ['Tags', 'tags', $generalTags, $tagSel],
          ['Preferences (Gift Finder)', 'pref_tags', $preferenceTags, $tagSel],
      ];
      ?>
      <section class="card">
        <div class="card-head"><h2>Gift matching</h2></div>
        <p class="muted small">Used by navigation, search and the Gift Finder.</p>
        <?php foreach ($groups as [$label, $name, $items, $sel]): ?>
          <fieldset class="perm-group">
            <legend class="sr-only"><?= e($label) ?></legend>
            <h4><?= e($label) ?></h4>
            <?php if (!$items): ?>
              <p class="muted small mb-0">None defined yet.</p>
            <?php else: ?>
              <div class="checkbox-grid" style="grid-template-columns:repeat(auto-fill,minmax(140px,1fr))">
                <?php foreach ($items as $it): ?>
                  <label class="check"><input type="checkbox" name="<?= e($name) ?>[]" value="<?= (int) $it['id'] ?>" <?= in_array((int) $it['id'], $sel, true) ? 'checked' : '' ?>> <?= e($it['name']) ?><?= isset($it['is_active']) && !(int) $it['is_active'] ? ' <span class="muted">(off)</span>' : '' ?></label>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </fieldset>
        <?php endforeach; ?>
      </section>

      <?php if (!$isEdit): ?>
      <section class="card">
        <div class="card-head"><h2>Stock &amp; images</h2></div>
        <div class="field">
          <label for="p-stock">Opening stock</label>
          <input class="input <?= $err('initial_stock') ?>" id="p-stock" name="initial_stock" type="number" min="0" value="<?= e(old('initial_stock', '0')) ?>">
          <p class="hint">Recorded as an "initial" inventory movement.</p>
          <?= field_error('initial_stock') ?>
        </div>
        <div class="field">
          <label for="p-images">Images</label>
          <input class="input" id="p-images" name="images[]" type="file" accept="image/jpeg,image/png,image/webp,image/gif" multiple>
          <p class="hint">JPEG, PNG, WebP or GIF, max 5 MB each. The first image becomes the primary image.</p>
        </div>
        <div class="field">
          <label for="p-alt">Image alt text</label>
          <input class="input" id="p-alt" name="image_alt" maxlength="190" placeholder="Defaults to the product name">
        </div>
      </section>
      <?php else: ?>
      <section class="card">
        <div class="card-head"><h2>Stock</h2></div>
        <ul class="list-plain">
          <li><span>Total on hand</span><strong><?= e(number_format((int) $product['total_stock'])) ?></strong></li>
          <li><span>Base product</span><span><?= e(number_format((int) ($product['base_inventory']['quantity'] ?? 0))) ?></span></li>
          <li><span>Variants</span><span><?= count($product['variants']) ?></span></li>
        </ul>
        <?php if (can('inventory.manage')): ?>
          <a class="btn btn-light btn-sm mt-4" href="<?= e(admin_url('inventory?q=' . urlencode($product['sku']))) ?>"><?= icon('boxes', 'icon-sm') ?> Manage stock</a>
        <?php endif; ?>
      </section>
      <?php endif; ?>
    </div>
  </div>
</form>
<script>
(function () {
  var preset = document.getElementById('p-age-preset');
  var min = document.getElementById('p-age-min');
  var max = document.getElementById('p-age-max');
  if (!preset || !min || !max) return;
  preset.addEventListener('change', function () {
    var m = /^(\d+)-(\d+)$/.exec(preset.value);
    if (m) { min.value = m[1]; max.value = m[2]; }
  });
  [min, max].forEach(function (el) { el.addEventListener('input', function () { preset.value = ''; }); });
})();
</script>
<?php endif; ?>
