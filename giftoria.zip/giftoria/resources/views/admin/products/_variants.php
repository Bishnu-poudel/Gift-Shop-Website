<?php
/** Product variants tab. Vars: $product */
$pid = (int) $product['id'];
$variants = $product['variants'];
$optionsText = static function (?string $json): string {
    $o = json_decode((string) $json, true);
    if (!is_array($o)) {
        return '';
    }
    $parts = [];
    foreach ($o as $k => $v) {
        if (is_scalar($v)) {
            $parts[] = $k . ': ' . $v;
        }
    }
    return implode('; ', $parts);
};
$hasNewOld = (bool) errors() && old('nv_sku', null) !== null;
$nv = static fn (string $k, string $d = '') => $hasNewOld ? (string) old($k, $d) : $d;
?>
<section class="card card-flush">
  <div class="card-head">
    <h2>Variants</h2>
    <span class="muted small">Base price <?= e(money($product['price'])) ?> · each variant keeps its own stock</span>
  </div>
  <?php if (!$variants): ?>
    <div style="padding:var(--s-6)">
      <p class="muted mb-0">No variants. The product is sold as a single item using the base stock. Add variants below for sizes, colours or editions.</p>
    </div>
  <?php else: ?>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th scope="col">Name</th>
          <th scope="col">SKU</th>
          <th scope="col">Options</th>
          <th scope="col" class="num">Price adj.</th>
          <th scope="col" class="num">Sort</th>
          <th scope="col">Active</th>
          <th scope="col" class="num">Stock</th>
          <th scope="col"><span class="sr-only">Actions</span></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($variants as $v): $vid = (int) $v['id']; $fid = 'variant-' . $vid; ?>
        <tr>
          <td><input class="input" form="<?= $fid ?>" name="v_name" value="<?= e($v['name']) ?>" maxlength="120" required aria-label="Variant name" style="min-width:140px"></td>
          <td><input class="input" form="<?= $fid ?>" name="v_sku" value="<?= e($v['sku']) ?>" maxlength="60" required aria-label="Variant SKU" style="min-width:120px"></td>
          <td><input class="input" form="<?= $fid ?>" name="v_options" value="<?= e($optionsText($v['options_json'])) ?>" placeholder="Color: Pink; Size: S" aria-label="Options" style="min-width:180px"></td>
          <td class="num"><input class="input" form="<?= $fid ?>" name="v_price_adjustment" type="number" step="0.01" value="<?= e($v['price_adjustment']) ?>" aria-label="Price adjustment" style="width:110px"></td>
          <td class="num"><input class="input" form="<?= $fid ?>" name="v_sort_order" type="number" value="<?= (int) $v['sort_order'] ?>" aria-label="Sort order" style="width:80px"></td>
          <td><label class="check"><input type="checkbox" form="<?= $fid ?>" name="v_active" value="1" <?= (int) $v['is_active'] ? 'checked' : '' ?>><span class="sr-only">Active</span></label></td>
          <td class="num">
            <?php if (can('inventory.manage') && $v['inventory_id']): ?>
              <a href="<?= e(admin_url('inventory/' . (int) $v['inventory_id'])) ?>" title="Adjust stock"><?= e(number_format((int) $v['stock'])) ?></a>
            <?php else: ?>
              <?= e(number_format((int) $v['stock'])) ?>
            <?php endif; ?>
            <div class="muted small"><?= e(money((float) $product['price'] + (float) $v['price_adjustment'])) ?></div>
          </td>
          <td>
            <div class="row" style="gap:4px;flex-wrap:nowrap">
              <button class="btn btn-light btn-sm" type="submit" form="<?= $fid ?>">Save</button>
              <button class="btn btn-ghost btn-sm" type="submit" form="<?= $fid ?>-delete" title="Delete variant"><?= icon('trash', 'icon-sm') ?><span class="sr-only">Delete</span></button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php foreach ($variants as $v): $vid = (int) $v['id']; $fid = 'variant-' . $vid; ?>
    <form id="<?= $fid ?>" method="post" action="<?= e(admin_url('products/' . $pid . '/variants/' . $vid)) ?>" hidden><?= csrf_field() ?></form>
    <form id="<?= $fid ?>-delete" method="post" action="<?= e(admin_url('products/' . $pid . '/variants/' . $vid . '/delete')) ?>" data-confirm="Delete variant &quot;<?= e($v['name']) ?>&quot;? Variants with stock or order history can only be deactivated." hidden><?= csrf_field() ?></form>
  <?php endforeach; ?>
  <?php endif; ?>
</section>

<section class="card">
  <div class="card-head"><h2>Add a variant</h2></div>
  <form method="post" action="<?= e(admin_url('products/' . $pid . '/variants')) ?>" data-loading>
    <?= csrf_field() ?>
    <div class="form-grid">
      <div class="field">
        <label for="nv-name">Name *</label>
        <input class="input <?= errors('nv_name') ? 'has-error' : '' ?>" id="nv-name" name="nv_name" value="<?= e($nv('nv_name')) ?>" maxlength="120" required placeholder="e.g. Pink / Small">
        <?= field_error('nv_name') ?>
      </div>
      <div class="field">
        <label for="nv-sku">SKU *</label>
        <input class="input <?= errors('nv_sku') ? 'has-error' : '' ?>" id="nv-sku" name="nv_sku" value="<?= e($nv('nv_sku', $product['sku'] . '-')) ?>" maxlength="60" required>
        <?= field_error('nv_sku') ?>
      </div>
      <div class="field span-2">
        <label for="nv-options">Options</label>
        <input class="input <?= errors('nv_options') ? 'has-error' : '' ?>" id="nv-options" name="nv_options" value="<?= e($nv('nv_options')) ?>" placeholder="Color: Pink; Size: S">
        <p class="hint">Separate options with semicolons, written as "Name: Value".</p>
        <?= field_error('nv_options') ?>
      </div>
      <div class="field">
        <label for="nv-adj">Price adjustment (NPR)</label>
        <input class="input <?= errors('nv_price_adjustment') ? 'has-error' : '' ?>" id="nv-adj" name="nv_price_adjustment" type="number" step="0.01" value="<?= e($nv('nv_price_adjustment', '0')) ?>">
        <p class="hint">Added to the base price; use a negative number for cheaper variants.</p>
        <?= field_error('nv_price_adjustment') ?>
      </div>
      <div class="field">
        <label for="nv-stock">Opening stock</label>
        <input class="input <?= errors('nv_stock') ? 'has-error' : '' ?>" id="nv-stock" name="nv_stock" type="number" min="0" value="<?= e($nv('nv_stock', '0')) ?>">
        <?= field_error('nv_stock') ?>
      </div>
      <div class="field">
        <label for="nv-sort">Sort order</label>
        <input class="input" id="nv-sort" name="nv_sort_order" type="number" value="<?= e($nv('nv_sort_order', (string) count($variants))) ?>">
        <?= field_error('nv_sort_order') ?>
      </div>
      <div class="field" style="align-self:end">
        <label class="check"><input type="checkbox" name="nv_active" value="1" <?= !$hasNewOld || old('nv_active', '') !== '' ? 'checked' : '' ?>> Active</label>
      </div>
    </div>
    <div class="form-actions">
      <button class="btn btn-accent" type="submit"><?= icon('plus', 'icon-sm') ?> Add variant</button>
    </div>
  </form>
</section>
