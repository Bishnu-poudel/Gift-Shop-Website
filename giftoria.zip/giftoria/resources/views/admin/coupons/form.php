<?php
/** @var ?array $coupon @var ?array $redemptions @var array $products @var array $categories */
$isEdit = $coupon !== null;
$hasOld = (bool) errors();
$val = static function (string $key, mixed $default = '') use ($coupon, $hasOld) {
    if ($hasOld) {
        return old($key, $default);
    }
    return $coupon[$key] ?? $default;
};
$dt = static function (string $key) use ($coupon, $hasOld): string {
    if ($hasOld) {
        return (string) old($key, '');
    }
    return $coupon && $coupon[$key] ? local_date($coupon[$key], 'Y-m-d\TH:i') : '';
};
$selected = static function (string $key) use ($coupon, $hasOld): array {
    if ($hasOld) {
        return array_map('intval', (array) old($key, []));
    }
    return array_map('intval', array_filter(explode(',', (string) ($coupon[$key] ?? ''))));
};
$selProducts = $selected('product_ids');
$selCategories = $selected('category_ids');
$type = (string) $val('type', 'percent');
$appliesTo = (string) $val('applies_to', 'all');
$isActive = $hasOld ? (bool) old('is_active', false) : (bool) ($coupon['is_active'] ?? true);
$catNames = array_column($categories, 'name', 'id');
$action = $isEdit ? admin_url('coupons/' . (int) $coupon['id']) : admin_url('coupons');
?>
<div class="admin-page-head">
  <div>
    <h1><?= $isEdit ? 'Edit coupon' : 'New coupon' ?></h1>
    <p>Dates are entered in Nepal time (Asia/Kathmandu) and stored in UTC.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light" href="<?= e(admin_url('coupons')) ?>">Back to coupons</a>
  </div>
</div>

<div class="admin-grid admin-grid-3-1">
  <form method="post" action="<?= e($action) ?>" class="card" data-loading>
    <?= csrf_field() ?>
    <div class="form-grid">
      <div class="field">
        <label for="code">Code</label>
        <input class="input <?= errors('code') ? 'has-error' : '' ?>" id="code" name="code" value="<?= e($val('code')) ?>" maxlength="40" required autocomplete="off" style="text-transform:uppercase;font-family:ui-monospace,monospace" placeholder="DASHAIN15">
        <p class="hint">Uppercase letters, numbers and hyphens. Must be unique.</p>
        <?= field_error('code') ?>
      </div>
      <div class="field">
        <label for="type">Discount type</label>
        <select class="select" id="type" name="type" data-coupon-type>
          <option value="percent" <?= $type === 'percent' ? 'selected' : '' ?>>Percentage off</option>
          <option value="fixed" <?= $type === 'fixed' ? 'selected' : '' ?>>Fixed amount off (NPR)</option>
          <option value="free_shipping" <?= $type === 'free_shipping' ? 'selected' : '' ?>>Free shipping</option>
        </select>
        <?= field_error('type') ?>
      </div>
      <div class="field span-2">
        <label for="description">Description <span class="muted">(internal, optional)</span></label>
        <input class="input" id="description" name="description" value="<?= e($val('description')) ?>" maxlength="255" placeholder="e.g. Dashain 2026 newsletter offer">
        <?= field_error('description') ?>
      </div>
      <div class="field" data-show-for-type="percent fixed">
        <label for="value">Value</label>
        <input class="input <?= errors('value') ? 'has-error' : '' ?>" id="value" name="value" type="number" step="0.01" min="0" value="<?= e($val('value')) ?>">
        <p class="hint">Percent: 1–100. Fixed: amount in NPR.</p>
        <?= field_error('value') ?>
      </div>
      <div class="field" data-show-for-type="percent">
        <label for="max_discount">Maximum discount (NPR) <span class="muted">optional</span></label>
        <input class="input" id="max_discount" name="max_discount" type="number" step="0.01" min="0" value="<?= e($val('max_discount')) ?>">
        <?= field_error('max_discount') ?>
      </div>
      <div class="field">
        <label for="min_subtotal">Minimum subtotal (NPR)</label>
        <input class="input" id="min_subtotal" name="min_subtotal" type="number" step="0.01" min="0" value="<?= e($val('min_subtotal', '0')) ?>">
        <?= field_error('min_subtotal') ?>
      </div>
      <div class="field">
        <label for="usage_limit">Total usage limit <span class="muted">blank = unlimited</span></label>
        <input class="input" id="usage_limit" name="usage_limit" type="number" step="1" min="1" value="<?= e($val('usage_limit')) ?>">
        <?= field_error('usage_limit') ?>
      </div>
      <div class="field">
        <label for="per_customer_limit">Uses per customer <span class="muted">blank = unlimited</span></label>
        <input class="input" id="per_customer_limit" name="per_customer_limit" type="number" step="1" min="1" value="<?= e($val('per_customer_limit')) ?>">
        <?= field_error('per_customer_limit') ?>
      </div>
      <div class="field">
        <label for="applies_to">Applies to</label>
        <select class="select" id="applies_to" name="applies_to" data-applies-to>
          <option value="all" <?= $appliesTo === 'all' ? 'selected' : '' ?>>Entire order</option>
          <option value="products" <?= $appliesTo === 'products' ? 'selected' : '' ?>>Specific products</option>
          <option value="categories" <?= $appliesTo === 'categories' ? 'selected' : '' ?>>Specific categories</option>
        </select>
        <?= field_error('applies_to') ?>
      </div>
      <div class="field span-2" data-show-for-scope="products">
        <label for="product_ids">Products</label>
        <select class="select" id="product_ids" name="product_ids[]" multiple size="8" style="height:auto;background-image:none">
          <?php foreach ($products as $p): ?>
            <option value="<?= (int) $p['id'] ?>" <?= in_array((int) $p['id'], $selProducts, true) ? 'selected' : '' ?>><?= e($p['name']) ?> (<?= e($p['sku']) ?>)</option>
          <?php endforeach; ?>
        </select>
        <p class="hint">Hold Ctrl (Cmd on Mac) to select several.</p>
        <?= field_error('product_ids') ?>
      </div>
      <div class="field span-2" data-show-for-scope="categories">
        <label for="category_ids">Categories</label>
        <select class="select" id="category_ids" name="category_ids[]" multiple size="8" style="height:auto;background-image:none">
          <?php foreach ($categories as $cat): ?>
            <option value="<?= (int) $cat['id'] ?>" <?= in_array((int) $cat['id'], $selCategories, true) ? 'selected' : '' ?>><?= $cat['parent_id'] ? e(($catNames[$cat['parent_id']] ?? '') . ' › ') : '' ?><?= e($cat['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <p class="hint">Products are matched by their own category.</p>
        <?= field_error('category_ids') ?>
      </div>
      <div class="field">
        <label for="starts_at">Starts (Nepal time)</label>
        <input class="input" id="starts_at" name="starts_at" type="datetime-local" value="<?= e($dt('starts_at')) ?>">
        <p class="hint">Blank = active immediately.</p>
        <?= field_error('starts_at') ?>
      </div>
      <div class="field">
        <label for="ends_at">Ends (Nepal time)</label>
        <input class="input <?= errors('ends_at') ? 'has-error' : '' ?>" id="ends_at" name="ends_at" type="datetime-local" value="<?= e($dt('ends_at')) ?>">
        <p class="hint">Blank = no expiry.</p>
        <?= field_error('ends_at') ?>
      </div>
      <div class="field span-2">
        <label class="check"><input type="checkbox" name="is_active" value="1" <?= $isActive ? 'checked' : '' ?>> <span>Active (can be redeemed within its schedule)</span></label>
      </div>
    </div>
    <div class="form-actions">
      <a class="btn btn-ghost" href="<?= e(admin_url('coupons')) ?>">Cancel</a>
      <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save changes' : 'Create coupon' ?></button>
    </div>
  </form>

  <aside>
    <?php if ($isEdit): $status = App\Controllers\Admin\CouponsController::statusOf($coupon); ?>
      <div class="card">
        <div class="card-head"><h2>Performance</h2><span class="status status-<?= e($status) ?>"><?= e(status_label($status)) ?></span></div>
        <ul class="list-plain">
          <li><span>Redemptions</span><strong><?= number_format((int) ($redemptions['n'] ?? 0)) ?></strong></li>
          <li><span>Total discount given</span><strong><?= e(money($redemptions['total'] ?? 0)) ?></strong></li>
          <li><span>Used count</span><strong><?= (int) $coupon['used_count'] ?><?= $coupon['usage_limit'] !== null ? ' / ' . (int) $coupon['usage_limit'] : '' ?></strong></li>
          <li><span>Created</span><span><?= e(local_date($coupon['created_at'])) ?></span></li>
        </ul>
      </div>
      <?php if ((int) $coupon['is_active'] === 1): ?>
        <form class="card danger-zone" method="post" action="<?= e(admin_url('coupons/' . (int) $coupon['id'] . '/deactivate')) ?>" data-confirm="Deactivate this coupon? Customers will no longer be able to use it.">
          <?= csrf_field() ?>
          <h3 style="font-size:1rem">Deactivate</h3>
          <p class="muted small">Stops new redemptions immediately. Orders that already used it are not affected.</p>
          <button class="btn btn-danger btn-sm" type="submit">Deactivate coupon</button>
        </form>
      <?php endif; ?>
    <?php else: ?>
      <div class="card">
        <div class="card-head"><h2>Tips</h2></div>
        <ul class="list-plain">
          <li>One coupon per order — coupons never stack.</li>
          <li>Link a coupon to a campaign to promote it on a landing page.</li>
          <li>Per-customer limits are checked by account and email.</li>
        </ul>
      </div>
    <?php endif; ?>
  </aside>
</div>

<script>
(function () {
  var type = document.querySelector('[data-coupon-type]');
  var scope = document.querySelector('[data-applies-to]');
  function sync() {
    document.querySelectorAll('[data-show-for-type]').forEach(function (el) {
      el.hidden = el.getAttribute('data-show-for-type').split(' ').indexOf(type.value) === -1;
    });
    document.querySelectorAll('[data-show-for-scope]').forEach(function (el) {
      el.hidden = el.getAttribute('data-show-for-scope') !== scope.value;
    });
  }
  if (type && scope) { type.addEventListener('change', sync); scope.addEventListener('change', sync); sync(); }
})();
</script>
