<?php
/** @var array $coupons @var App\Core\Paginator $paginator @var array $filters @var array $kpis @var int $total */
$typeLabel = static function (array $c): string {
    return match ($c['type']) {
        'percent' => rtrim(rtrim(number_format((float) $c['value'], 2), '0'), '.') . '% off',
        'fixed' => money($c['value']) . ' off',
        default => 'Free shipping',
    };
};
?>
<div class="admin-page-head">
  <div>
    <h1>Coupons</h1>
    <p>Discount codes for checkout. Only one coupon can be used per order.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-primary" href="<?= e(admin_url('coupons/create')) ?>"><?= icon('plus', 'icon-sm') ?> New coupon</a>
  </div>
</div>

<div class="kpis">
  <div class="kpi"><p class="label">Active now</p><div class="value"><?= (int) ($kpis['active_count'] ?? 0) ?></div></div>
  <div class="kpi"><p class="label">Scheduled</p><div class="value"><?= (int) ($kpis['scheduled_count'] ?? 0) ?></div></div>
  <div class="kpi"><p class="label">Redemptions</p><div class="value"><?= number_format((int) ($kpis['redemptions'] ?? 0)) ?></div><div class="sub">Excludes cancelled orders</div></div>
  <div class="kpi"><p class="label">Total discount given</p><div class="value"><?= e(money($kpis['discount_total'] ?? 0)) ?></div></div>
</div>

<form class="filter-bar" method="get" action="<?= e(admin_url('coupons')) ?>">
  <div class="field">
    <label for="f-q">Search</label>
    <input class="input" id="f-q" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Code or description">
  </div>
  <div class="field">
    <label for="f-status">Status</label>
    <select class="select" id="f-status" name="status" data-autosubmit>
      <option value="">All statuses</option>
      <?php foreach (App\Controllers\Admin\CouponsController::STATUSES as $s): ?>
        <option value="<?= e($s) ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= e(status_label($s)) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <button class="btn btn-light btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
  <?php if ($filters['q'] !== '' || $filters['status'] !== ''): ?>
    <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('coupons')) ?>">Clear</a>
  <?php endif; ?>
</form>

<div class="card card-flush">
  <?php if (!$coupons): ?>
    <div style="padding:24px">
      <?= partial('components/empty-state', ['icon' => 'tag', 'title' => 'No coupons found', 'text' => 'Create a coupon to reward customers or support a campaign.', 'actionUrl' => admin_url('coupons/create'), 'actionLabel' => 'Create coupon']) ?>
    </div>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead>
      <tr>
        <th>Code</th>
        <th>Discount</th>
        <th>Applies to</th>
        <th>Schedule (NPT)</th>
        <th class="num">Usage</th>
        <th class="num">Redemptions</th>
        <th class="num">Discount given</th>
        <th>Status</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($coupons as $c): ?>
      <tr>
        <td>
          <a class="row-link" href="<?= e(admin_url('coupons/' . (int) $c['id'] . '/edit')) ?>"><code><?= e($c['code']) ?></code></a>
          <?php if ($c['description']): ?><div class="muted small"><?= e(str_limit($c['description'], 60)) ?></div><?php endif; ?>
        </td>
        <td>
          <?= e($typeLabel($c)) ?>
          <?php if ((float) $c['min_subtotal'] > 0): ?><div class="muted small">Min <?= e(money($c['min_subtotal'])) ?></div><?php endif; ?>
          <?php if ($c['max_discount'] !== null): ?><div class="muted small">Cap <?= e(money($c['max_discount'])) ?></div><?php endif; ?>
        </td>
        <td>
          <?php if ($c['applies_to'] === 'all'): ?>Whole order
          <?php else: ?><?= e(ucfirst($c['applies_to'])) ?> (<?= count(array_filter(explode(',', (string) ($c['applies_to'] === 'products' ? $c['product_ids'] : $c['category_ids'])))) ?>)<?php endif; ?>
        </td>
        <td class="small">
          <?= $c['starts_at'] ? e(local_date($c['starts_at'])) : '<span class="muted">Immediately</span>' ?><br>
          <span class="muted">to</span> <?= $c['ends_at'] ? e(local_date($c['ends_at'])) : '<span class="muted">no end</span>' ?>
        </td>
        <td class="num">
          <?= (int) $c['used_count'] ?><?= $c['usage_limit'] !== null ? ' / ' . (int) $c['usage_limit'] : '' ?>
          <?php if ($c['per_customer_limit'] !== null): ?><div class="muted small"><?= (int) $c['per_customer_limit'] ?> per customer</div><?php endif; ?>
        </td>
        <td class="num"><?= number_format((int) $c['redemptions']) ?></td>
        <td class="num"><?= e(money($c['discount_total'])) ?></td>
        <td><span class="status status-<?= e($c['status']) ?>"><?= e(status_label($c['status'])) ?></span></td>
        <td class="num">
          <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('coupons/' . (int) $c['id'] . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
          <?php if ((int) $c['is_active'] === 1): ?>
            <form class="inline-form" method="post" action="<?= e(admin_url('coupons/' . (int) $c['id'] . '/deactivate')) ?>" data-confirm="Deactivate coupon <?= e($c['code']) ?>? Customers will no longer be able to use it.">
              <?= csrf_field() ?>
              <button class="btn btn-ghost btn-sm" type="submit">Deactivate</button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>
<?= $paginator->links() ?>
