<?php
/** @var array $ticket @var array $messages @var ?array $order @var array $history @var array $assignees */
use App\Controllers\Admin\TicketsController;

$hasOld = (bool) errors();
$styles = [
    'customer' => 'background:var(--paper);border:1px solid var(--line);margin-right:48px',
    'staff' => 'background:var(--info-tint);border:1px solid #c7d7e8;margin-left:48px',
    'internal' => 'background:var(--warning-tint);border:1px dashed #d9b866;margin-left:48px',
];
?>
<div class="admin-page-head">
  <div>
    <h1><?= e($ticket['subject']) ?></h1>
    <p>#<?= e($ticket['ticket_number']) ?> · <?= e(status_label($ticket['category'])) ?> · opened <?= e(local_date($ticket['created_at'])) ?>
      · <span class="status status-<?= e($ticket['status']) ?>"><?= e(ucfirst($ticket['status'])) ?></span></p>
  </div>
  <div class="admin-actions"><a class="btn btn-light" href="<?= e(admin_url('tickets')) ?>">All tickets</a></div>
</div>

<div class="admin-grid admin-grid-3-1">
  <div>
    <div class="card">
      <div class="card-head"><h2>Conversation</h2><span class="muted small"><?= count($messages) ?> message(s)</span></div>
      <?php if (!$messages): ?>
        <p class="muted small">No messages yet.</p>
      <?php endif; ?>
      <div class="stack">
        <?php foreach ($messages as $m):
            $kind = (int) $m['is_internal'] === 1 ? 'internal' : ($m['author_type'] === 'staff' ? 'staff' : 'customer');
            $who = $kind === 'customer' ? ($m['author_name'] ?: $ticket['name']) : ($m['author_name'] ?: 'Staff');
        ?>
          <div style="<?= $styles[$kind] ?>;border-radius:12px;padding:14px 16px">
            <div class="row-between" style="margin-bottom:6px">
              <strong class="small"><?= e($who) ?>
                <?php if ($kind === 'staff'): ?><span class="badge badge-info" style="margin-left:6px">Staff reply</span><?php endif; ?>
                <?php if ($kind === 'internal'): ?><span class="badge badge-warning" style="margin-left:6px"><?= icon('lock', 'icon-sm') ?> Internal note</span><?php endif; ?>
                <?php if ($kind === 'customer'): ?><span class="badge" style="margin-left:6px">Customer</span><?php endif; ?>
              </strong>
              <span class="muted small"><?= e(local_date($m['created_at'])) ?></span>
            </div>
            <div class="small" style="white-space:pre-line;overflow-wrap:anywhere"><?= e($m['body']) ?></div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <form class="card" method="post" action="<?= e(admin_url('tickets/' . (int) $ticket['id'] . '/reply')) ?>" data-loading>
      <?= csrf_field() ?>
      <div class="card-head"><h2>Reply</h2></div>
      <div class="field">
        <label for="body" class="sr-only">Message</label>
        <textarea class="textarea <?= errors('body') ? 'has-error' : '' ?>" id="body" name="body" rows="6" maxlength="5000" required placeholder="Write your reply to <?= e($ticket['name']) ?>…"><?= e($hasOld ? old('body') : '') ?></textarea>
        <?= field_error('body') ?>
      </div>
      <div class="row-between">
        <label class="check"><input type="checkbox" name="internal" value="1" <?= $hasOld && old('internal') ? 'checked' : '' ?>> <span><strong>Internal note</strong> — visible to staff only, no email is sent</span></label>
        <div class="row" style="gap:8px">
          <label for="status_after" class="small muted">Then set status</label>
          <select class="select" id="status_after" name="status_after" style="width:auto;min-height:40px">
            <option value="">Keep “<?= e(ucfirst($ticket['status'])) ?>”</option>
            <option value="pending" <?= !$hasOld && $ticket['status'] === 'open' ? 'selected' : '' ?>>Pending (awaiting customer)</option>
            <option value="open">Open</option>
            <option value="resolved">Resolved</option>
            <option value="closed">Closed</option>
          </select>
          <button class="btn btn-primary" type="submit"><?= icon('message', 'icon-sm') ?> Send</button>
        </div>
      </div>
      <?= field_error('status_after') ?>
      <p class="muted small" style="margin-top:8px">Public replies are emailed to <?= e($ticket['email']) ?>.</p>
    </form>
  </div>

  <aside>
    <form class="card" method="post" action="<?= e(admin_url('tickets/' . (int) $ticket['id'] . '/update')) ?>">
      <?= csrf_field() ?>
      <div class="card-head"><h2>Ticket</h2></div>
      <div class="field">
        <label for="status">Status</label>
        <select class="select" id="status" name="status">
          <?php foreach (TicketsController::STATUSES as $s): ?><option value="<?= e($s) ?>" <?= $ticket['status'] === $s ? 'selected' : '' ?>><?= e(ucfirst($s)) ?></option><?php endforeach; ?>
        </select>
        <?= field_error('status') ?>
      </div>
      <div class="field">
        <label for="priority">Priority</label>
        <select class="select" id="priority" name="priority">
          <?php foreach (TicketsController::PRIORITIES as $pr): ?><option value="<?= e($pr) ?>" <?= $ticket['priority'] === $pr ? 'selected' : '' ?>><?= e(ucfirst($pr)) ?></option><?php endforeach; ?>
        </select>
        <?= field_error('priority') ?>
      </div>
      <div class="field">
        <label for="assigned_to">Assignee</label>
        <select class="select" id="assigned_to" name="assigned_to">
          <option value="">Unassigned</option>
          <?php foreach ($assignees as $a): ?><option value="<?= (int) $a['id'] ?>" <?= (int) $ticket['assigned_to'] === (int) $a['id'] ? 'selected' : '' ?>><?= e($a['name']) ?><?= (int) $a['id'] === (int) (staff()['id'] ?? 0) ? ' (me)' : '' ?></option><?php endforeach; ?>
        </select>
        <p class="hint">Only active staff with the support permission are listed.</p>
        <?= field_error('assigned_to') ?>
      </div>
      <button class="btn btn-light btn-block" type="submit">Update ticket</button>
    </form>

    <div class="card">
      <div class="card-head"><h2>Customer</h2><?= $ticket['user_id'] ? '<span class="badge badge-info">Account</span>' : '<span class="badge">Guest</span>' ?></div>
      <ul class="list-plain">
        <li><span>Name</span><strong><?= e($ticket['name']) ?></strong></li>
        <li><span>Email</span><a href="mailto:<?= e($ticket['email']) ?>"><?= e($ticket['email']) ?></a></li>
        <?php if (!empty($ticket['account_phone'])): ?><li><span>Phone</span><span><?= e($ticket['account_phone']) ?></span></li><?php endif; ?>
        <?php if ($ticket['user_id'] && can('customers.view')): ?><li><span>Profile</span><a href="<?= e(admin_url('customers/' . (int) $ticket['user_id'])) ?>">View customer</a></li><?php endif; ?>
      </ul>
    </div>

    <?php if ($order): ?>
      <div class="card">
        <div class="card-head"><h2>Related order</h2><span class="status status-<?= e($order['status']) ?>"><?= e(status_label($order['status'])) ?></span></div>
        <ul class="list-plain">
          <li><span>Order</span><?php if (can('orders.view')): ?><a href="<?= e(admin_url('orders/' . (int) $order['id'])) ?>">#<?= e($order['order_number']) ?></a><?php else: ?><strong>#<?= e($order['order_number']) ?></strong><?php endif; ?></li>
          <li><span>Total</span><span><?= e(money($order['grand_total'])) ?></span></li>
          <li><span>Placed</span><span><?= e(local_date($order['created_at'], 'M j, Y')) ?></span></li>
        </ul>
      </div>
    <?php endif; ?>

    <?php if ($history): ?>
      <div class="card">
        <div class="card-head"><h2>Other tickets</h2></div>
        <ul class="list-plain">
          <?php foreach ($history as $h): ?>
            <li><a href="<?= e(admin_url('tickets/' . (int) $h['id'])) ?>"><?= e(str_limit($h['subject'], 34)) ?></a><span class="status status-<?= e($h['status']) ?>"><?= e(ucfirst($h['status'])) ?></span></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>
  </aside>
</div>
