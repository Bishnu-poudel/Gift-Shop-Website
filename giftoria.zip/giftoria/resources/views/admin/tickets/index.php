<?php
/** @var array $tickets @var App\Core\Paginator $paginator @var array $filters @var array $counts @var int $mineCount */
use App\Controllers\Admin\TicketsController;

$priorityStyle = ['urgent' => 'badge-danger', 'high' => 'badge-warning', 'normal' => '', 'low' => 'badge-info'];
?>
<div class="admin-page-head">
  <div>
    <h1>Support tickets</h1>
    <p>Open and waiting tickets first, most urgent on top.</p>
  </div>
  <div class="admin-actions">
    <a class="btn <?= $filters['mine'] ? 'btn-primary' : 'btn-light' ?>" href="<?= e(admin_url('tickets?mine=1')) ?>"><?= icon('user', 'icon-sm') ?> Assigned to me (<?= (int) $mineCount ?>)</a>
  </div>
</div>

<div class="kpis">
  <div class="kpi"><p class="label">Open</p><div class="value"><?= (int) ($counts['open_count'] ?? 0) ?></div><div class="sub">Waiting for us</div></div>
  <div class="kpi"><p class="label">Pending</p><div class="value"><?= (int) ($counts['pending_count'] ?? 0) ?></div><div class="sub">Waiting for the customer</div></div>
  <div class="kpi"><p class="label">High / urgent</p><div class="value"><?= (int) ($counts['high_count'] ?? 0) ?></div></div>
  <div class="kpi"><p class="label">Unassigned</p><div class="value"><a href="<?= e(admin_url('tickets?assigned=none')) ?>"><?= (int) ($counts['unassigned_count'] ?? 0) ?></a></div></div>
</div>

<form class="filter-bar" method="get" action="<?= e(admin_url('tickets')) ?>">
  <div class="field">
    <label for="f-q">Search</label>
    <input class="input" id="f-q" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Ticket #, subject, email">
  </div>
  <div class="field">
    <label for="f-status">Status</label>
    <select class="select" id="f-status" name="status" data-autosubmit>
      <option value="active" <?= $filters['status'] === 'active' ? 'selected' : '' ?>>Open &amp; pending</option>
      <option value="" <?= $filters['status'] === '' ? 'selected' : '' ?>>All statuses</option>
      <?php foreach (TicketsController::STATUSES as $s): ?><option value="<?= e($s) ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= e(ucfirst($s)) ?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="field">
    <label for="f-priority">Priority</label>
    <select class="select" id="f-priority" name="priority" data-autosubmit>
      <option value="">Any priority</option>
      <?php foreach (array_reverse(TicketsController::PRIORITIES) as $pr): ?><option value="<?= e($pr) ?>" <?= $filters['priority'] === $pr ? 'selected' : '' ?>><?= e(ucfirst($pr)) ?></option><?php endforeach; ?>
    </select>
  </div>
  <label class="check" style="align-self:center"><input type="checkbox" name="mine" value="1" <?= $filters['mine'] ? 'checked' : '' ?> data-autosubmit> <span>Assigned to me</span></label>
  <button class="btn btn-light btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
</form>

<div class="card card-flush">
  <?php if (!$tickets): ?>
    <div style="padding:24px"><?= partial('components/empty-state', ['icon' => 'message', 'title' => 'No tickets here', 'text' => 'Nothing matches these filters. Nice work!']) ?></div>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead><tr><th>Ticket</th><th>Customer</th><th>Category</th><th>Priority</th><th>Status</th><th>Assignee</th><th>Updated (NPT)</th></tr></thead>
    <tbody>
    <?php foreach ($tickets as $t): ?>
      <tr>
        <td style="min-width:220px">
          <a class="row-link" href="<?= e(admin_url('tickets/' . (int) $t['id'])) ?>"><?= e($t['subject']) ?></a>
          <div class="muted small">#<?= e($t['ticket_number']) ?> · <?= (int) $t['message_count'] ?> message(s)
            <?php if ($t['last_author'] === 'customer' && in_array($t['status'], ['open', 'pending'], true)): ?> · <strong style="color:var(--terracotta)">customer replied</strong><?php endif; ?>
          </div>
        </td>
        <td><?= e($t['name']) ?><div class="muted small"><?= e($t['email']) ?><?= $t['user_id'] ? '' : ' · guest' ?></div></td>
        <td><?= e(status_label($t['category'])) ?></td>
        <td><span class="badge <?= e($priorityStyle[$t['priority']] ?? '') ?>"><?= e(ucfirst($t['priority'])) ?></span></td>
        <td><span class="status status-<?= e($t['status']) ?>"><?= e(ucfirst($t['status'])) ?></span></td>
        <td><?= $t['assignee_name'] ? e($t['assignee_name']) : '<span class="muted">Unassigned</span>' ?></td>
        <td class="small" style="white-space:nowrap"><?= e(local_date($t['updated_at'])) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>
<?= $paginator->links() ?>
