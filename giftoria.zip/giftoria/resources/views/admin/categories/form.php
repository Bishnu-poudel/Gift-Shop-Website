<?php
/** Vars: $category (null on create), $parents, $blockedParents (ids), $presetParent, optional $productCount */
$isEdit = $category !== null;
$hasOld = (bool) errors() && old('name', null) !== null;
$val = static function (string $k, string $d = '') use ($category, $hasOld): string {
    if ($hasOld) {
        $o = old($k, null);
        return is_scalar($o) ? (string) $o : '';
    }
    $v = $category[$k] ?? $d;
    return $v === null ? '' : (string) $v;
};
$active = $hasOld ? old('is_active', '') !== '' : (bool) ($category['is_active'] ?? true);
$parentVal = $isEdit || $hasOld ? $val('parent_id') : ($presetParent ? (string) $presetParent : '');
$err = static fn (string $k): string => errors($k) ? 'has-error' : '';
?>
<div class="admin-page-head">
  <div>
    <p class="small"><a href="<?= e(admin_url('categories')) ?>"><?= icon('chevron-left', 'icon-sm') ?> All categories</a></p>
    <h1><?= e($isEdit ? $category['name'] : 'New category') ?></h1>
    <?php if ($isEdit): ?><p><?= (int) ($productCount ?? 0) ?> product(s) in this category</p><?php endif; ?>
  </div>
</div>

<form method="post" action="<?= e($isEdit ? admin_url('categories/' . (int) $category['id']) : admin_url('categories')) ?>" enctype="multipart/form-data" data-loading novalidate>
  <?= csrf_field() ?>
  <div class="admin-grid admin-grid-3-1">
    <div>
      <section class="card">
        <div class="card-head"><h2>Details</h2></div>
        <div class="form-grid">
          <div class="field">
            <label for="c-name">Name *</label>
            <input class="input <?= $err('name') ?>" id="c-name" name="name" value="<?= e($val('name')) ?>" maxlength="120" required>
            <?= field_error('name') ?>
          </div>
          <div class="field">
            <label for="c-slug">Slug</label>
            <input class="input <?= $err('slug') ?>" id="c-slug" name="slug" value="<?= e($val('slug')) ?>" maxlength="140" data-slug-from="#c-name" placeholder="auto-from-name">
            <p class="hint">Used in the URL. Leave empty to generate it.</p>
            <?= field_error('slug') ?>
          </div>
          <div class="field">
            <label for="c-parent">Parent category</label>
            <select class="select <?= $err('parent_id') ?>" id="c-parent" name="parent_id">
              <option value="">— Top level —</option>
              <?php foreach ($parents as $p): $blocked = in_array((int) $p['id'], $blockedParents, true); ?>
                <option value="<?= (int) $p['id'] ?>" <?= $parentVal === (string) $p['id'] ? 'selected' : '' ?> <?= $blocked ? 'disabled' : '' ?>><?= e(str_repeat('— ', (int) $p['depth']) . $p['name']) ?></option>
              <?php endforeach; ?>
            </select>
            <?= field_error('parent_id') ?>
          </div>
          <div class="field">
            <label for="c-sort">Sort order</label>
            <input class="input <?= $err('sort_order') ?>" id="c-sort" name="sort_order" type="number" value="<?= e($val('sort_order', '0')) ?>">
            <p class="hint">Lower numbers appear first.</p>
            <?= field_error('sort_order') ?>
          </div>
          <div class="field span-2">
            <label for="c-desc">Description</label>
            <textarea class="textarea <?= $err('description') ?>" id="c-desc" name="description" rows="4"><?= e($val('description')) ?></textarea>
            <?= field_error('description') ?>
          </div>
        </div>
      </section>
      <section class="card">
        <div class="card-head"><h2>Search engine listing</h2></div>
        <div class="field">
          <label for="c-seo-title">SEO title</label>
          <input class="input <?= $err('seo_title') ?>" id="c-seo-title" name="seo_title" value="<?= e($val('seo_title')) ?>" maxlength="190">
          <?= field_error('seo_title') ?>
        </div>
        <div class="field">
          <label for="c-seo-desc">SEO description</label>
          <textarea class="textarea <?= $err('seo_description') ?>" id="c-seo-desc" name="seo_description" rows="2" maxlength="300" style="min-height:70px"><?= e($val('seo_description')) ?></textarea>
          <?= field_error('seo_description') ?>
        </div>
      </section>
    </div>
    <div>
      <section class="card">
        <div class="card-head"><h2>Visibility</h2></div>
        <label class="check"><input type="checkbox" name="is_active" value="1" <?= $active ? 'checked' : '' ?>> Active (shown in the store)</label>
        <div class="form-actions">
          <a class="btn btn-ghost" href="<?= e(admin_url('categories')) ?>">Cancel</a>
          <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save changes' : 'Create category' ?></button>
        </div>
      </section>
      <section class="card">
        <div class="card-head"><h2>Image</h2></div>
        <?php if ($isEdit && $category['image']): ?>
          <div class="image-manager mb-4" style="grid-template-columns:140px">
            <figure><img src="<?= e(image_url($category['image'])) ?>" alt="<?= e($category['name']) ?>"></figure>
          </div>
          <label class="check mb-4"><input type="checkbox" name="remove_image" value="1"> Remove current image</label>
        <?php endif; ?>
        <div class="field">
          <label for="c-image"><?= $isEdit && $category['image'] ? 'Replace image' : 'Upload image' ?></label>
          <input class="input <?= $err('image') ?>" id="c-image" name="image" type="file" accept="image/jpeg,image/png,image/webp,image/gif">
          <p class="hint">JPEG, PNG, WebP or GIF up to 5 MB.</p>
          <?= field_error('image') ?>
        </div>
      </section>
      <?php if ($isEdit): ?>
      <section class="card danger-zone">
        <div class="card-head"><h2>Delete</h2></div>
        <?php if ((int) ($productCount ?? 0) > 0): ?>
          <p class="muted small mb-0">This category has <?= (int) $productCount ?> product(s). Move them to another category before deleting, or untick "Active" to hide it.</p>
        <?php else: ?>
          <p class="muted small">Subcategories, if any, move to the top level.</p>
          <button class="btn btn-danger btn-sm" type="submit" form="delete-category">Delete category</button>
        <?php endif; ?>
      </section>
      <?php endif; ?>
    </div>
  </div>
</form>
<?php if ($isEdit && (int) ($productCount ?? 0) === 0): ?>
<form id="delete-category" method="post" action="<?= e(admin_url('categories/' . (int) $category['id'] . '/delete')) ?>" data-confirm="Delete this category permanently?" hidden><?= csrf_field() ?></form>
<?php endif; ?>
