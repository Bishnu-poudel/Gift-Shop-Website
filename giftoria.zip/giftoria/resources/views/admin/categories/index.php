<?php
/** Vars: $categories (tree-ordered with depth, product_count, child_count) */
?>
<div class="admin-page-head">
  <div>
    <h1>Categories</h1>
    <p>Organise the catalog into a browsable tree. Categories with products cannot be deleted.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light" href="<?= e(admin_url('taxonomies/recipients')) ?>"><?= icon('tag', 'icon-sm') ?> Gift taxonomy</a>
    <a class="btn btn-accent" href="<?= e(admin_url('categories/create')) ?>"><?= icon('plus', 'icon-sm') ?> New category</a>
  </div>
</div>

<?php if (!$categories): ?>
  <?= partial('components/empty-state', ['icon' => 'layout', 'title' => 'No categories yet', 'text' => 'Create top-level categories such as Toys, Home & Living or Jewellery.', 'actionUrl' => admin_url('categories/create'), 'actionLabel' => 'New category']) ?>
<?php else: ?>
<div class="card card-flush">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th scope="col"><span class="sr-only">Image</span></th>
          <th scope="col">Name</th>
          <th scope="col">Slug</th>
          <th scope="col" class="num">Products</th>
          <th scope="col" class="num">Sort</th>
          <th scope="col">Status</th>
          <th scope="col"><span class="sr-only">Actions</span></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($categories as $c): $cid = (int) $c['id']; $depth = (int) $c['depth']; ?>
        <tr>
          <td><img class="thumb" src="<?= e(image_url($c['image'])) ?>" alt="" loading="lazy" width="44" height="52"></td>
          <td>
            <span style="padding-left:<?= $depth * 22 ?>px" class="row">
              <?php if ($depth > 0): ?><span class="muted" aria-hidden="true">└</span><?php endif; ?>
              <a class="row-link" href="<?= e(admin_url('categories/' . $cid . '/edit')) ?>"><?= e($c['name']) ?></a>
              <?php if ((int) $c['child_count'] > 0): ?><span class="muted small"><?= (int) $c['child_count'] ?> sub</span><?php endif; ?>
            </span>
          </td>
          <td class="muted small"><?= e($c['slug']) ?></td>
          <td class="num">
            <?php if (can('products.manage') && (int) $c['product_count'] > 0): ?>
              <a href="<?= e(admin_url('products?category=' . $cid)) ?>"><?= (int) $c['product_count'] ?></a>
            <?php else: ?>
              <?= (int) $c['product_count'] ?>
            <?php endif; ?>
          </td>
          <td class="num"><?= (int) $c['sort_order'] ?></td>
          <td><span class="status status-<?= (int) $c['is_active'] ? 'active' : 'inactive' ?>"><?= (int) $c['is_active'] ? 'Active' : 'Hidden' ?></span></td>
          <td>
            <div class="row" style="gap:4px;flex-wrap:nowrap;justify-content:flex-end">
              <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('categories/create?parent=' . $cid)) ?>" title="Add subcategory"><?= icon('plus', 'icon-sm') ?><span class="sr-only">Add subcategory</span></a>
              <a class="btn btn-light btn-sm" href="<?= e(admin_url('categories/' . $cid . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
              <?php if ((int) $c['product_count'] === 0): ?>
                <form method="post" action="<?= e(admin_url('categories/' . $cid . '/delete')) ?>" class="inline-form" data-confirm="Delete category &quot;<?= e($c['name']) ?>&quot;?<?= (int) $c['child_count'] ? ' Its subcategories will move to the top level.' : '' ?>">
                  <?= csrf_field() ?>
                  <button class="btn btn-ghost btn-sm" type="submit" title="Delete"><?= icon('trash', 'icon-sm') ?><span class="sr-only">Delete</span></button>
                </form>
              <?php else: ?>
                <button class="btn btn-ghost btn-sm" type="button" disabled title="Has products — cannot delete"><?= icon('trash', 'icon-sm') ?><span class="sr-only">Delete unavailable</span></button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>
