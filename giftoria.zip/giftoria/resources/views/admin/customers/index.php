<?php
/** Vars: $customers, $filters, $total, $paginator */
?>
<div class="admin-page-head">
  <div>
    <h1>Customers</h1>
    <p><?= number_format($total) ?> customer account<?= $total === 1 ? '' : 's' ?>. Totals count paid orders net of refunds.</p>
  </div>
</div>

<form class="filter-bar" method="get" action="<?= e(admin_url('customers')) ?>">
  <div class="field"><label for="c-q">Search</label><input class="input" type="search" id="c-q" name="q" value="<?= e($filters['q']) ?>" placeholder="Name, email or phone"></div>
  <div class="field"><label for="c-s">Status</label>
    <select class="select" id="c-s" name="status">
      <option value="">Any status</option>
      <?php foreach (['active', 'pending', 'inactive', 'deleted'] as $s): ?><option value="<?= e($s) ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= e(status_label($s)) ?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="field"><label for="c-sort">Sort</label>
    <select class="select" id="c-sort" name="sort">
      <option value="">Newest</option>
      <option value="spent" <?= $filters['sort'] === 'spent' ? 'selected' : '' ?>>Total spent</option>
      <option value="orders" <?= $filters['sort'] === 'orders' ? 'selected' : '' ?>>Order count</option>
      <option value="name" <?= $filters['sort'] === 'name' ? 'selected' : '' ?>>Name</option>
    </select>
  </div>
  <button class="btn btn-primary btn-sm" type="submit"><?= icon('search', 'icon-sm') ?> Search</button>
  <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('customers')) ?>">Reset</a>
</form>

<div class="card card-flush">
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Customer</th><th>Phone</th><th>Status</th><th class="num">Orders</th><th class="num">Total spent</th><th>Last order</th><th>Joined</th></tr></thead>
      <tbody>
      <?php if (!$customers): ?><tr><td colspan="7" class="muted" style="padding:32px;text-align:center">No customers found.</td></tr><?php endif; ?>
      <?php foreach ($customers as $c): ?>
        <tr>
          <td>
            <a class="row-link" href="<?= e(admin_url('customers/' . (int) $c['id'])) ?>"><?= e($c['name']) ?></a>
            <div class="muted small"><?= e($c['email']) ?><?= $c['email_verified_at'] ? '' : ' · unverified' ?></div>
          </td>
          <td><?= e($c['phone'] ?: '—') ?></td>
          <td><span class="status status-<?= e($c['status']) ?>"><?= e(status_label($c['status'])) ?></span></td>
          <td class="num"><?= (int) $c['order_count'] ?></td>
          <td class="num"><?= e(money($c['total_spent'])) ?></td>
          <td><?= $c['last_order_at'] ? e(local_date($c['last_order_at'], 'M j, Y')) : '<span class="muted">—</span>' ?></td>
          <td><?= e(local_date($c['created_at'], 'M j, Y')) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?= $paginator->links() ?>
