<?php
/** Vars: $customer, $profile, $newsletter, $addresses, $orders, $tickets, $wishlistCount, $recipientCount, $stats, $canEdit */
use App\Services\OrderStateMachine;

$c = $customer;
$yesNo = static fn ($v) => (int) $v ? 'Yes' : 'No';
?>
<div class="admin-page-head">
  <div>
    <p class="small"><a href="<?= e(admin_url('customers')) ?>">&larr; Customers</a></p>
    <h1><?= e($c['name']) ?></h1>
    <p>
      <?= e($c['email']) ?><?= $c['phone'] ? ' · ' . e($c['phone']) : '' ?> ·
      Joined <?= e(local_date($c['created_at'], 'M j, Y')) ?>
      <?= $c['last_login_at'] ? ' · Last sign-in ' . e(local_date($c['last_login_at'])) : '' ?>
    </p>
    <div class="row mt-2" style="gap:8px">
      <span class="status status-<?= e($c['status']) ?>"><?= e(status_label($c['status'])) ?></span>
      <span class="status <?= $c['email_verified_at'] ? 'status-active' : 'status-pending' ?>"><?= $c['email_verified_at'] ? 'Email verified' : 'Email unverified' ?></span>
    </div>
  </div>
</div>

<div class="kpis">
  <div class="kpi"><p class="label">Orders</p><div class="value"><?= (int) ($stats['orders'] ?? 0) ?></div><div class="sub"><?= (int) ($stats['paid_orders'] ?? 0) ?> paid</div></div>
  <div class="kpi"><p class="label">Total spent</p><div class="value"><?= e(money($stats['spent'] ?? 0)) ?></div><div class="sub">Paid, net of refunds</div></div>
  <div class="kpi"><p class="label">Wishlist items</p><div class="value"><?= (int) $wishlistCount ?></div><div class="sub"><?= (int) $recipientCount ?> saved gift recipients</div></div>
  <div class="kpi"><p class="label">Support tickets</p><div class="value"><?= count($tickets) ?></div><div class="sub"><?= count(array_filter($tickets, static fn ($t) => in_array($t['status'], ['open', 'pending'], true))) ?> open</div></div>
</div>

<div class="admin-grid admin-grid-3-1">
  <div>
    <?php if (can('orders.view')): ?>
    <div class="card card-flush">
      <div class="card-head"><h2>Orders</h2><a class="small" href="<?= e(admin_url('orders') . '?' . http_build_query(['q' => $c['email']])) ?>">Search all orders by email</a></div>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Order</th><th>Status</th><th>Payment</th><th class="num">Total</th><th>Placed</th></tr></thead>
          <tbody>
          <?php if (!$orders): ?><tr><td colspan="5" class="muted">No orders yet.</td></tr><?php endif; ?>
          <?php foreach ($orders as $o): ?>
            <tr>
              <td><a class="row-link" href="<?= e(admin_url('orders/' . (int) $o['id'])) ?>"><?= e($o['order_number']) ?></a></td>
              <td><span class="status status-<?= e($o['status']) ?>"><?= e(OrderStateMachine::ORDER_LABELS[$o['status']] ?? $o['status']) ?></span></td>
              <td><span class="status status-<?= e($o['payment_status']) ?>"><?= e(status_label($o['payment_status'])) ?></span> <span class="muted small"><?= e(strtoupper($o['payment_method'])) ?></span></td>
              <td class="num"><?= e(money($o['grand_total'])) ?></td>
              <td><?= e(local_date($o['created_at'])) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>

    <div class="card card-flush">
      <div class="card-head"><h2>Support tickets</h2><?php if (can('support.manage')): ?><a class="small" href="<?= e(admin_url('tickets')) ?>">Tickets</a><?php endif; ?></div>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Ticket</th><th>Subject</th><th>Status</th><th>Opened</th></tr></thead>
          <tbody>
          <?php if (!$tickets): ?><tr><td colspan="4" class="muted">No tickets.</td></tr><?php endif; ?>
          <?php foreach ($tickets as $t): ?>
            <tr>
              <td><?php if (can('support.manage')): ?><a class="row-link" href="<?= e(admin_url('tickets/' . (int) $t['id'])) ?>"><?= e($t['ticket_number']) ?></a><?php else: ?><?= e($t['ticket_number']) ?><?php endif; ?></td>
              <td><?= e(str_limit($t['subject'], 80)) ?></td>
              <td><span class="status status-<?= e($t['status']) ?>"><?= e(status_label($t['status'])) ?></span><?php if (in_array($t['priority'], ['high', 'urgent'], true)): ?> <span class="badge badge-danger"><?= e(ucfirst($t['priority'])) ?></span><?php endif; ?></td>
              <td><?= e(local_date($t['created_at'], 'M j, Y')) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h2>Saved addresses</h2></div>
      <?php if (!$addresses): ?><p class="muted">No saved addresses.</p><?php endif; ?>
      <div class="admin-grid admin-grid-2">
        <?php foreach ($addresses as $a): ?>
          <div class="perm-group mb-0">
            <h4><?= e($a['label'] ?: 'Address') ?><?= (int) $a['is_default'] ? ' <span class="badge badge-info">Default</span>' : '' ?></h4>
            <div class="small" style="line-height:1.6">
              <?= e($a['full_name']) ?> · <?= e($a['phone']) ?><br>
              <?= $a['street'] ? e($a['street']) . ($a['ward'] ? ', Ward ' . e($a['ward']) : '') . '<br>' : '' ?>
              <?= e($a['municipality']) ?>, <?= e($a['district']) ?>, <?= e($a['province']) ?>
              <?= $a['landmark'] ? '<br><span class="muted">Landmark: ' . e($a['landmark']) . '</span>' : '' ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <div>
    <div class="card">
      <div class="card-head"><h2>Consent &amp; preferences</h2></div>
      <ul class="list-plain">
        <li><span>Marketing emails</span><strong><?= $profile ? e($yesNo($profile['marketing_opt_in'])) : 'No' ?></strong></li>
        <li><span>Newsletter</span><strong><?= $newsletter ? e(status_label($newsletter['status'])) : 'Not subscribed' ?></strong></li>
        <?php if ($newsletter && $newsletter['consent_at']): ?><li><span>Consent recorded</span><span><?= e(local_date($newsletter['consent_at'])) ?></span></li><?php endif; ?>
        <?php if ($profile): ?>
          <li><span>Order update emails</span><span><?= e($yesNo($profile['notify_order_updates'])) ?></span></li>
          <li><span>Gift reminders</span><span><?= e($yesNo($profile['notify_gift_reminders'])) ?></span></li>
          <li><span>Wishlist alerts</span><span><?= e($yesNo($profile['notify_wishlist'])) ?></span></li>
          <li><span>Personalised recommendations</span><span><?= e($yesNo($profile['personalization_enabled'])) ?></span></li>
          <?php if ($profile['deletion_requested_at']): ?><li><span class="status status-cancelled">Deletion requested</span><span><?= e(local_date($profile['deletion_requested_at'])) ?></span></li><?php endif; ?>
        <?php endif; ?>
      </ul>
    </div>

    <?php if ($canEdit): ?>
    <div class="card">
      <div class="card-head"><h2>Edit account</h2></div>
      <?php if ($c['status'] === 'deleted'): ?>
        <p class="muted small">This account has been deleted and cannot be edited.</p>
      <?php else: ?>
      <form method="post" action="<?= e(admin_url('customers/' . (int) $c['id'])) ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="update">
        <div class="field"><label for="cu-name">Name</label><input class="input" id="cu-name" name="name" maxlength="120" required value="<?= e(old('name', $c['name'])) ?>"><?= field_error('name') ?></div>
        <div class="field"><label for="cu-phone">Phone</label><input class="input" type="tel" id="cu-phone" name="phone" maxlength="20" value="<?= e(old('phone', $c['phone'] ?? '')) ?>"><?= field_error('phone') ?></div>
        <div class="field"><label for="cu-status">Status</label>
          <select class="select" id="cu-status" name="status">
            <?php $curStatus = (string) old('status', $c['status'] === 'inactive' ? 'inactive' : 'active'); ?>
            <option value="active" <?= $curStatus === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= $curStatus === 'inactive' ? 'selected' : '' ?>>Inactive (cannot sign in)</option>
          </select><?= field_error('status') ?>
          <p class="hint">Email changes are made by the customer and require verification.</p>
        </div>
        <button class="btn btn-primary btn-sm btn-block" type="submit">Save changes</button>
      </form>
      <form method="post" action="<?= e(admin_url('customers/' . (int) $c['id'])) ?>" class="mt-4" data-confirm="Sign this customer out of every device?">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="revoke">
        <button class="btn btn-light btn-sm btn-block" type="submit"><?= icon('log-out', 'icon-sm') ?> Revoke all sessions</button>
      </form>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
