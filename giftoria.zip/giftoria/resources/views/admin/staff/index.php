<div class="admin-page-head">
  <div>
    <h1>Staff</h1>
    <p>Staff accounts are created by invitation. Roles you can assign are limited to permissions you hold.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-primary" href="<?= e(admin_url('staff/create')) ?>"><?= icon('plus', 'icon-sm') ?> Invite staff</a>
  </div>
</div>

<form class="filter-bar" method="get" action="<?= e(admin_url('staff')) ?>">
  <div class="field">
    <label for="f-q">Search</label>
    <input class="input" type="search" id="f-q" name="q" value="<?= e($filters['q']) ?>" placeholder="Name, email or employee ID">
  </div>
  <div class="field">
    <label for="f-status">Status</label>
    <select class="select" id="f-status" name="status" data-autosubmit>
      <option value="">All statuses</option>
      <?php foreach ($statuses as $s): ?>
        <option value="<?= e($s) ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= e(status_label($s)) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field">
    <label for="f-role">Role</label>
    <select class="select" id="f-role" name="role" data-autosubmit>
      <option value="">All roles</option>
      <?php foreach ($allRoles as $r): ?>
        <option value="<?= (int) $r['id'] ?>" <?= (int) $filters['role'] === (int) $r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <button class="btn btn-light" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
  <?php if ($filters['q'] !== '' || $filters['status'] !== '' || $filters['role']): ?>
    <a class="btn btn-ghost" href="<?= e(admin_url('staff')) ?>">Reset</a>
  <?php endif; ?>
</form>

<div class="card card-flush">
  <?php if (!$rows): ?>
    <div style="padding:var(--s-8)"><?= partial('components/empty-state', ['title' => 'No staff found', 'text' => 'Try a different filter or invite a new staff member.']) ?></div>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead>
      <tr><th>Name</th><th>Employee ID</th><th>Roles</th><th>Status</th><th>Last login</th><th></th></tr>
    </thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td>
          <a class="row-link" href="<?= e(admin_url('staff/' . (int) $r['id'])) ?>"><?= e($r['name']) ?></a>
          <div class="muted small"><?= e($r['email']) ?><?= $r['job_title'] ? ' · ' . e($r['job_title']) : '' ?></div>
        </td>
        <td><?= e($r['employee_id'] ?? '—') ?></td>
        <td><?= $r['role_names'] ? e($r['role_names']) : '<span class="muted">No roles</span>' ?></td>
        <td>
          <span class="status status-<?= e($r['status']) ?>"><?= e($r['status'] === 'pending' ? 'Invited' : status_label($r['status'])) ?></span>
          <?php if ((int) $r['must_change_password'] === 1 && $r['status'] === 'active'): ?><div class="muted small">Must change password</div><?php endif; ?>
        </td>
        <td><?= $r['last_login_at'] ? e(local_date($r['last_login_at'])) : '<span class="muted">Never</span>' ?></td>
        <td class="num"><a class="btn btn-ghost btn-sm" href="<?= e(admin_url('staff/' . (int) $r['id'])) ?>">View</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>
<?= $paginator->links() ?>
