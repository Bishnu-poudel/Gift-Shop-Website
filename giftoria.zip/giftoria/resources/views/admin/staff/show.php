<?php
/** Vars: $member, $roles, $activity, $history, $paginator, $isSelf, $blockReason, $inviteLink */
$uid = (int) $member['id'];
$canAct = !$isSelf && $blockReason === null;
$statusText = $member['status'] === 'pending' ? 'Invited · awaiting activation' : status_label($member['status']);
?>
<div class="admin-page-head">
  <div>
    <h1><?= e($member['name']) ?></h1>
    <p><?= e($member['employee_id'] ?? 'No employee ID') ?> · <?= e($member['email']) ?></p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light" href="<?= e(admin_url('staff')) ?>">All staff</a>
    <?php if ($isSelf || $blockReason === null): ?>
      <a class="btn btn-primary" href="<?= e(admin_url('staff/' . $uid . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
    <?php endif; ?>
  </div>
</div>

<?php if (!empty($inviteLink)): ?>
  <div class="alert alert-info" role="status"><?= icon('info') ?>
    <div style="flex:1">
      <strong>Local development only:</strong> invitation link (not shown in production).
      <input class="input mt-2" type="text" value="<?= e($inviteLink) ?>" readonly onfocus="this.select()" aria-label="Invitation link">
    </div>
  </div>
<?php endif; ?>

<?php if ($blockReason !== null): ?>
  <div class="alert alert-warning" role="status"><?= icon('lock') ?><div><?= e($blockReason) ?></div></div>
<?php endif; ?>

<div class="admin-grid admin-grid-3-1">
  <div>
    <div class="card">
      <div class="card-head"><h2>Profile</h2><span class="status status-<?= e($member['status']) ?>"><?= e($statusText) ?></span></div>
      <ul class="list-plain">
        <li><span class="muted">Email</span><span><?= e($member['email']) ?><?= $member['email_verified_at'] ? '' : ' <span class="badge badge-warning">Unverified</span>' ?></span></li>
        <li><span class="muted">Phone</span><span><?= e($member['phone'] ?: '—') ?></span></li>
        <li><span class="muted">Job title</span><span><?= e($member['job_title'] ?: '—') ?></span></li>
        <li><span class="muted">Department</span><span><?= e($member['department'] ?: '—') ?></span></li>
        <li><span class="muted">Invited by</span><span><?= e($member['invited_by_name'] ?: '—') ?></span></li>
        <li><span class="muted">Created</span><span><?= e(local_date($member['created_at'])) ?></span></li>
        <li><span class="muted">Last login</span><span><?= $member['last_login_at'] ? e(local_date($member['last_login_at'])) . ' · ' . e($member['last_login_ip'] ?? '') : 'Never' ?></span></li>
        <li><span class="muted">Password change required</span><span><?= (int) $member['must_change_password'] === 1 ? 'Yes' : 'No' ?></span></li>
      </ul>
    </div>

    <div class="card card-flush">
      <div class="card-head"><h2>Activity log</h2><span class="muted small">Actions performed by this staff member</span></div>
      <?php if (!$activity): ?>
        <p class="muted" style="padding:var(--s-5) var(--s-6)">No recorded activity yet.</p>
      <?php else: ?>
      <div style="overflow-x:auto">
      <table class="data-table">
        <thead><tr><th>When</th><th>Action</th><th>Entity</th><th>IP</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($activity as $a): ?>
          <tr>
            <td><?= e(local_date($a['created_at'])) ?></td>
            <td><code><?= e($a['action']) ?></code></td>
            <td><?= e(trim(($a['entity_type'] ?? '') . ($a['entity_id'] ? ' #' . $a['entity_id'] : ''))) ?: '—' ?></td>
            <td><?= e($a['ip'] ?? '') ?></td>
            <td class="num"><?php if (can('audit.view')): ?><a class="btn btn-ghost btn-sm" href="<?= e(admin_url('audit/' . (int) $a['id'])) ?>">Details</a><?php endif; ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
      <?php endif; ?>
    </div>
    <?= $paginator->links() ?>
  </div>

  <div>
    <div class="card">
      <div class="card-head"><h2>Roles</h2></div>
      <?php if (!$roles): ?>
        <p class="muted">No roles assigned.</p>
      <?php else: ?>
        <ul class="list-plain">
          <?php foreach ($roles as $r): ?>
            <li><span><?= e($r['name']) ?></span><?php if ((int) $r['is_active'] !== 1): ?><span class="status status-inactive">Role inactive</span><?php endif; ?></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
      <?php if ($isSelf): ?><p class="hint mt-4">You cannot change your own roles.</p><?php endif; ?>
    </div>

    <?php if ($canAct): ?>
    <div class="card">
      <div class="card-head"><h2>Access</h2></div>
      <div class="stack">
        <?php if ($member['status'] === 'pending'): ?>
          <form method="post" action="<?= e(admin_url('staff/' . $uid . '/resend-invite')) ?>">
            <?= csrf_field() ?>
            <button class="btn btn-light btn-block" type="submit"><?= icon('mail', 'icon-sm') ?> Resend invitation</button>
            <p class="hint">Any previous invitation link stops working.</p>
          </form>
        <?php endif; ?>

        <form method="post" action="<?= e(admin_url('staff/' . $uid . '/force-password')) ?>">
          <?= csrf_field() ?>
          <?php if ((int) $member['must_change_password'] === 1): ?>
            <input type="hidden" name="required" value="0">
            <button class="btn btn-light btn-block" type="submit">Remove password-change requirement</button>
          <?php else: ?>
            <input type="hidden" name="required" value="1">
            <button class="btn btn-light btn-block" type="submit"><?= icon('lock', 'icon-sm') ?> Require password change</button>
          <?php endif; ?>
        </form>

        <form method="post" action="<?= e(admin_url('staff/' . $uid . '/revoke-sessions')) ?>" data-confirm="Sign <?= e($member['name']) ?> out of every device?">
          <?= csrf_field() ?>
          <button class="btn btn-light btn-block" type="submit"><?= icon('log-out', 'icon-sm') ?> Revoke all sessions</button>
        </form>
      </div>
    </div>

    <div class="card danger-zone">
      <div class="card-head"><h2>Account status</h2></div>
      <?php if ($member['status'] === 'inactive'): ?>
        <form method="post" action="<?= e(admin_url('staff/' . $uid . '/status')) ?>" data-confirm="Reactivate this account?">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="activate">
          <button class="btn btn-accent btn-block" type="submit">Reactivate account</button>
        </form>
      <?php else: ?>
        <p class="small muted">Deactivating blocks sign-in immediately, ends all sessions and cancels pending invitation or reset links.</p>
        <form method="post" action="<?= e(admin_url('staff/' . $uid . '/status')) ?>" data-confirm="Deactivate <?= e($member['name']) ?>? They will be signed out everywhere.">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="deactivate">
          <button class="btn btn-danger btn-block" type="submit">Deactivate account</button>
        </form>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="card">
      <div class="card-head"><h2>Account history</h2></div>
      <?php if (!$history): ?>
        <p class="muted small">No changes recorded.</p>
      <?php else: ?>
        <ul class="timeline-admin">
          <?php foreach ($history as $h): ?>
            <li>
              <div><code><?= e($h['action']) ?></code></div>
              <div class="when"><?= e(local_date($h['created_at'])) ?><?= $h['actor_name'] ? ' · by ' . e($h['actor_name']) : '' ?></div>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </div>
  </div>
</div>
