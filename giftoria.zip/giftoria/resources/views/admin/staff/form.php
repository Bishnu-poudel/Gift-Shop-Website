<?php
/** Vars: $member (null = create), $assignable, $currentRoleIds, $lockedRoles, $isSelf */
$editing = $member !== null;
$action = $editing ? admin_url('staff/' . (int) $member['id']) : admin_url('staff');
$oldRoles = old('roles', null);
$selected = is_array($oldRoles) ? array_map('intval', $oldRoles) : $currentRoleIds;
$val = static fn (string $k) => old($k, $member[$k] ?? '');
?>
<div class="admin-page-head">
  <div>
    <h1><?= $editing ? 'Edit staff member' : 'Invite staff member' ?></h1>
    <p><?= $editing ? e($member['name']) . ' · ' . e($member['employee_id'] ?? '') : 'They will receive an email link to set their own password. You never see or choose it.' ?></p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light" href="<?= e($editing ? admin_url('staff/' . (int) $member['id']) : admin_url('staff')) ?>">Cancel</a>
  </div>
</div>

<form method="post" action="<?= e($action) ?>" data-loading novalidate>
  <?= csrf_field() ?>
  <div class="admin-grid admin-grid-3-1">
    <div class="card">
      <div class="card-head"><h2>Profile</h2></div>
      <div class="form-grid">
        <div class="field">
          <label for="name">Full name</label>
          <input class="input<?= errors('name') ? ' has-error' : '' ?>" id="name" name="name" value="<?= e($val('name')) ?>" required maxlength="120">
          <?= field_error('name') ?>
        </div>
        <div class="field">
          <label for="email">Work email</label>
          <input class="input<?= errors('email') ? ' has-error' : '' ?>" type="email" id="email" name="email" value="<?= e($val('email')) ?>" required maxlength="190">
          <?= field_error('email') ?>
        </div>
        <div class="field">
          <label for="phone">Phone</label>
          <input class="input<?= errors('phone') ? ' has-error' : '' ?>" type="tel" id="phone" name="phone" value="<?= e($val('phone')) ?>" maxlength="20" placeholder="98XXXXXXXX">
          <?= field_error('phone') ?>
        </div>
        <div class="field">
          <label for="job_title">Job title</label>
          <input class="input<?= errors('job_title') ? ' has-error' : '' ?>" id="job_title" name="job_title" value="<?= e($val('job_title')) ?>" maxlength="100">
          <?= field_error('job_title') ?>
        </div>
        <div class="field">
          <label for="department">Department</label>
          <input class="input<?= errors('department') ? ' has-error' : '' ?>" id="department" name="department" value="<?= e($val('department')) ?>" maxlength="100">
          <?= field_error('department') ?>
        </div>
        <?php if ($editing): ?>
        <div class="field">
          <label>Employee ID</label>
          <input class="input" value="<?= e($member['employee_id'] ?? 'Assigned on save') ?>" readonly>
          <p class="hint">Generated automatically and never reused.</p>
        </div>
        <?php else: ?>
        <div class="field">
          <label>Employee ID</label>
          <input class="input" value="Generated automatically (EMP-0001 style)" readonly>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h2>Roles</h2></div>
      <?php if ($isSelf): ?>
        <div class="alert alert-info"><?= icon('info') ?><div>You cannot change your own roles. Ask another administrator.</div></div>
        <ul class="list-plain">
          <?php foreach (($currentRoles ?? []) as $r): ?><li><?= e($r['name']) ?></li><?php endforeach; ?>
        </ul>
      <?php else: ?>
        <?= field_error('roles') ?>
        <?php if (!$assignable): ?>
          <p class="muted">There are no roles you are allowed to assign.</p>
        <?php endif; ?>
        <div class="stack" style="--gap:8px">
          <?php foreach ($assignable as $r): ?>
            <label class="check">
              <input type="checkbox" name="roles[]" value="<?= (int) $r['id'] ?>" <?= in_array((int) $r['id'], $selected, true) ? 'checked' : '' ?>>
              <span><strong><?= e($r['name']) ?></strong><?php if ((int) $r['is_system'] === 1): ?> <span class="badge">System</span><?php endif; ?>
                <?php if ($r['description']): ?><br><span class="muted small"><?= e($r['description']) ?></span><?php endif; ?></span>
            </label>
          <?php endforeach; ?>
        </div>
        <?php if ($lockedRoles): ?>
          <div class="alert alert-warning mt-4"><?= icon('lock') ?><div>Also holds roles you cannot change here (not assignable by you, or inactive):
            <?= e(implode(', ', array_map(static fn ($r) => $r['name'], $lockedRoles))) ?>. These are kept unchanged.</div></div>
        <?php endif; ?>
        <p class="hint mt-4">Only roles whose permissions you hold are listed. The Super Admin role can only be assigned by a Super Admin.</p>
      <?php endif; ?>
    </div>
  </div>

  <div class="form-actions">
    <a class="btn btn-light" href="<?= e($editing ? admin_url('staff/' . (int) $member['id']) : admin_url('staff')) ?>">Cancel</a>
    <button class="btn btn-primary" type="submit"><?= $editing ? 'Save changes' : 'Create & send invitation' ?></button>
  </div>
</form>
