<?php
/** Vars: $returns, $status, $counts, $paginator */
use App\Controllers\Admin\ReturnsController;
use App\Services\OrderStateMachine;
?>
<div class="admin-page-head">
  <div>
    <h1>Returns</h1>
    <p>Approve requests, mark parcels received (restocks items and marks the order returned), then refund via Refunds.</p>
  </div>
</div>

<nav class="tabs" aria-label="Return status">
  <a href="<?= e(admin_url('returns')) ?>" class="<?= $status === '' ? 'is-active' : '' ?>">All</a>
  <?php foreach (ReturnsController::STATUSES as $s): ?>
    <a href="<?= e(admin_url('returns') . '?status=' . $s) ?>" class="<?= $status === $s ? 'is-active' : '' ?>"><?= e(status_label($s)) ?> (<?= (int) $counts[$s] ?>)</a>
  <?php endforeach; ?>
</nav>

<div class="card card-flush">
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Request</th><th>Order</th><th>Reason</th><th>Status</th><th style="min-width:260px">Update</th></tr></thead>
      <tbody>
      <?php if (!$returns): ?><tr><td colspan="5" class="muted" style="padding:32px;text-align:center">No return requests.</td></tr><?php endif; ?>
      <?php foreach ($returns as $r):
          $next = ReturnsController::FLOW[$r['status']] ?? [];
      ?>
        <tr>
          <td>#<?= (int) $r['id'] ?><div class="muted small"><?= e(local_date($r['created_at'])) ?></div></td>
          <td>
            <?php if (can('orders.view')): ?><a class="row-link" href="<?= e(admin_url('orders/' . (int) $r['order_id'])) ?>"><?= e($r['order_number']) ?></a><?php else: ?><?= e($r['order_number']) ?><?php endif; ?>
            <div class="muted small"><?= e($r['customer_name']) ?> · <?= e($r['email']) ?></div>
            <div class="small"><span class="status status-<?= e($r['order_status']) ?>"><?= e(OrderStateMachine::ORDER_LABELS[$r['order_status']] ?? $r['order_status']) ?></span></div>
          </td>
          <td class="small">
            <strong><?= e($r['reason']) ?></strong>
            <?php if ($r['details']): ?><div style="white-space:pre-wrap"><?= e(str_limit($r['details'], 400)) ?></div><?php endif; ?>
            <?php if ($r['staff_note']): ?><div class="muted mt-2">Staff note: <?= e($r['staff_note']) ?></div><?php endif; ?>
          </td>
          <td>
            <span class="status status-<?= e($r['status']) ?>"><?= e(status_label($r['status'])) ?></span>
            <?php if ($r['handled_by_name']): ?><div class="muted small">by <?= e($r['handled_by_name']) ?></div><?php endif; ?>
          </td>
          <td>
            <?php if ($next): ?>
              <form method="post" action="<?= e(admin_url('returns/' . (int) $r['id'])) ?>" data-confirm="Update this return request?">
                <?= csrf_field() ?>
                <div class="input-group">
                  <label class="sr-only" for="rs-<?= (int) $r['id'] ?>">New status</label>
                  <select class="select" id="rs-<?= (int) $r['id'] ?>" name="status">
                    <?php foreach ($next as $s): ?><option value="<?= e($s) ?>"><?= e(status_label($s)) ?></option><?php endforeach; ?>
                  </select>
                  <button class="btn btn-primary btn-sm" type="submit">Save</button>
                </div>
                <label class="sr-only" for="rn-<?= (int) $r['id'] ?>">Staff note</label>
                <input class="input mt-2" id="rn-<?= (int) $r['id'] ?>" name="staff_note" maxlength="500" placeholder="Staff note (optional)">
              </form>
            <?php else: ?>
              <span class="muted small">No further action</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?= $paginator->links() ?>
