<?php
/** @var array $questions @var App\Core\Paginator $paginator @var array $filters @var array $counts @var string $tab */
?>
<?= partial('admin/reviews/_tabs', ['tab' => $tab, 'counts' => $counts]) ?>

<form class="filter-bar" method="get" action="<?= e(admin_url('reviews/questions')) ?>">
  <div class="field">
    <label for="f-q">Search</label>
    <input class="input" id="f-q" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Product or question">
  </div>
  <div class="field">
    <label for="f-status">Status</label>
    <select class="select" id="f-status" name="status" data-autosubmit>
      <option value="">All (pending first)</option>
      <?php foreach (['pending', 'published', 'rejected'] as $s): ?><option value="<?= e($s) ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= e(ucfirst($s)) ?></option><?php endforeach; ?>
    </select>
  </div>
  <button class="btn btn-light btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
</form>

<?php if (!$questions): ?>
  <div class="card"><?= partial('components/empty-state', ['icon' => 'message', 'title' => 'No questions found', 'text' => 'Questions asked on product pages appear here for answering.']) ?></div>
<?php else: ?>
  <?php foreach ($questions as $q): $fieldKey = 'answer_' . (int) $q['id']; $err = errors($fieldKey); ?>
    <article class="card" style="<?= $q['status'] === 'pending' ? 'border-left:4px solid var(--warning)' : '' ?>">
      <div class="card-head">
        <div>
          <div class="row" style="gap:8px">
            <strong><?= e($q['name']) ?></strong>
            <span class="status status-<?= e($q['status']) ?>"><?= e(ucfirst($q['status'])) ?></span>
            <?php if ($q['user_id']): ?><span class="badge badge-info">Customer</span><?php endif; ?>
          </div>
          <div class="muted small" style="margin-top:4px">
            on <a href="<?= e(url('/product/' . $q['product_slug'])) ?>" target="_blank" rel="noopener"><?= e($q['product_name']) ?></a> · <?= e(local_date($q['created_at'])) ?>
            <?php if ($q['answered_by_name']): ?> · answered by <?= e($q['answered_by_name']) ?><?php endif; ?>
          </div>
        </div>
      </div>
      <p style="margin:0 0 12px;white-space:pre-line"><strong>Q:</strong> <?= e($q['question']) ?></p>
      <form method="post" action="<?= e(admin_url('reviews/questions/' . (int) $q['id'])) ?>">
        <?= csrf_field() ?>
        <div class="field">
          <label for="answer-<?= (int) $q['id'] ?>">Answer</label>
          <textarea class="textarea <?= $err ? 'has-error' : '' ?>" id="answer-<?= (int) $q['id'] ?>" name="answer" rows="3" maxlength="5000"><?= e($err ? old('answer', '') : (string) $q['answer']) ?></textarea>
          <?= field_error($fieldKey) ?>
        </div>
        <div class="row" style="gap:8px;justify-content:flex-end">
          <button class="btn btn-ghost btn-sm" type="submit" name="status" value="pending">Save as pending</button>
          <button class="btn btn-light btn-sm" type="submit" name="status" value="rejected" formnovalidate><?= icon('x', 'icon-sm') ?> Reject</button>
          <button class="btn btn-primary btn-sm" type="submit" name="status" value="published"><?= icon('check', 'icon-sm') ?> <?= $q['status'] === 'published' ? 'Update answer' : 'Publish answer' ?></button>
        </div>
      </form>
    </article>
  <?php endforeach; ?>
<?php endif; ?>
<?= $paginator->links() ?>
