<?php /** Vars: $tab, $counts */ ?>
<div class="admin-page-head">
  <div>
    <h1>Reviews &amp; Q&amp;A</h1>
    <p>Moderate customer reviews and answer product questions. Only approved reviews appear on the storefront and count towards ratings.</p>
  </div>
</div>
<nav class="tabs" aria-label="Reviews sections">
  <a href="<?= e(admin_url('reviews')) ?>" class="<?= $tab === 'reviews' ? 'is-active' : '' ?>">Reviews<?php if ((int) ($counts['pending_reviews'] ?? 0) > 0): ?> <span class="badge badge-warning"><?= (int) $counts['pending_reviews'] ?> pending</span><?php endif; ?></a>
  <a href="<?= e(admin_url('reviews/questions')) ?>" class="<?= $tab === 'questions' ? 'is-active' : '' ?>">Questions<?php if ((int) ($counts['pending_questions'] ?? 0) > 0): ?> <span class="badge badge-warning"><?= (int) $counts['pending_questions'] ?> pending</span><?php endif; ?></a>
</nav>
