<?php
/** @var array $reviews @var App\Core\Paginator $paginator @var array $filters @var array $counts @var string $tab */
?>
<?= partial('admin/reviews/_tabs', ['tab' => $tab, 'counts' => $counts]) ?>

<form class="filter-bar" method="get" action="<?= e(admin_url('reviews')) ?>">
  <div class="field">
    <label for="f-q">Search</label>
    <input class="input" id="f-q" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="Product or review text">
  </div>
  <div class="field">
    <label for="f-status">Status</label>
    <select class="select" id="f-status" name="status" data-autosubmit>
      <option value="">All (pending first)</option>
      <?php foreach (['pending', 'approved', 'rejected'] as $s): ?><option value="<?= e($s) ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= e(ucfirst($s)) ?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="field">
    <label for="f-rating">Rating</label>
    <select class="select" id="f-rating" name="rating" data-autosubmit>
      <option value="">Any rating</option>
      <?php for ($i = 5; $i >= 1; $i--): ?><option value="<?= $i ?>" <?= $filters['rating'] === $i ? 'selected' : '' ?>><?= $i ?> star<?= $i > 1 ? 's' : '' ?></option><?php endfor; ?>
    </select>
  </div>
  <div class="field">
    <label for="f-verified">Purchase</label>
    <select class="select" id="f-verified" name="verified" data-autosubmit>
      <option value="">All</option>
      <option value="1" <?= $filters['verified'] === '1' ? 'selected' : '' ?>>Verified buyers</option>
      <option value="0" <?= $filters['verified'] === '0' ? 'selected' : '' ?>>Not verified</option>
    </select>
  </div>
  <button class="btn btn-light btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
</form>

<?php if (!$reviews): ?>
  <div class="card"><?= partial('components/empty-state', ['icon' => 'star', 'title' => 'No reviews found', 'text' => 'Customer reviews waiting for moderation appear here.']) ?></div>
<?php else: ?>
  <?php foreach ($reviews as $r): ?>
    <article class="card" style="<?= $r['status'] === 'pending' ? 'border-left:4px solid var(--warning)' : '' ?>">
      <div class="card-head">
        <div>
          <div class="row" style="gap:8px">
            <span class="rating"><span class="stars" aria-hidden="true"><?php for ($i = 1; $i <= 5; $i++): ?><?= str_replace('<svg class="icon', '<svg class="icon' . ($i <= (int) $r['rating'] ? ' filled' : ''), icon('star')) ?><?php endfor; ?></span></span>
            <strong aria-label="Rated <?= (int) $r['rating'] ?> out of 5"><?= (int) $r['rating'] ?>/5</strong>
            <span class="status status-<?= e($r['status']) ?>"><?= e(ucfirst($r['status'])) ?></span>
            <?php if ((int) $r['is_verified'] === 1): ?><span class="badge badge-success"><?= icon('check', 'icon-sm') ?> Verified purchase</span><?php endif; ?>
          </div>
          <div class="muted small" style="margin-top:4px">
            <a href="<?= e(url('/product/' . $r['product_slug'])) ?>" target="_blank" rel="noopener"><?= e($r['product_name']) ?></a>
            · by <?= e($r['customer_name']) ?> (<?= e($r['customer_email']) ?>) · <?= e(local_date($r['created_at'])) ?>
            <?php if ($r['moderator_name']): ?> · moderated by <?= e($r['moderator_name']) ?><?php endif; ?>
          </div>
        </div>
        <div class="row" style="gap:6px">
          <?php if ($r['status'] !== 'approved'): ?>
            <form class="inline-form" method="post" action="<?= e(admin_url('reviews/' . (int) $r['id'] . '/moderate')) ?>">
              <?= csrf_field() ?><input type="hidden" name="status" value="approved">
              <button class="btn btn-primary btn-sm" type="submit"><?= icon('check', 'icon-sm') ?> Approve</button>
            </form>
          <?php endif; ?>
          <?php if ($r['status'] !== 'rejected'): ?>
            <form class="inline-form" method="post" action="<?= e(admin_url('reviews/' . (int) $r['id'] . '/moderate')) ?>" data-confirm="Reject this review? It will be hidden from the product page.">
              <?= csrf_field() ?><input type="hidden" name="status" value="rejected">
              <button class="btn btn-light btn-sm" type="submit"><?= icon('x', 'icon-sm') ?> Reject</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
      <?php if ($r['title']): ?><h3 style="font-size:1rem;margin:0 0 6px"><?= e($r['title']) ?></h3><?php endif; ?>
      <p class="small" style="margin:0;white-space:pre-line"><?= e($r['body']) ?></p>
    </article>
  <?php endforeach; ?>
<?php endif; ?>
<?= $paginator->links() ?>
