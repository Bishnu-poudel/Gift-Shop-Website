<?php
/** Vars: $refunds, $filters, $counts, $paginator, $canManage */
use App\Controllers\Admin\RefundsController;
?>
<div class="admin-page-head">
  <div>
    <h1>Refunds</h1>
    <p>eSewa and Khalti refunds are executed in the merchant portal. Record the portal reference here to complete them.</p>
  </div>
</div>

<nav class="tabs" aria-label="Refund status">
  <a href="<?= e(admin_url('refunds')) ?>" class="<?= $filters['status'] === '' ? 'is-active' : '' ?>">All</a>
  <?php foreach (RefundsController::STATUSES as $s): ?>
    <a href="<?= e(admin_url('refunds') . '?status=' . $s) ?>" class="<?= $filters['status'] === $s ? 'is-active' : '' ?>"><?= e(status_label($s)) ?> (<?= (int) $counts[$s] ?>)</a>
  <?php endforeach; ?>
</nav>

<div class="admin-grid <?= $canManage ? 'admin-grid-3-1' : '' ?>">
  <div>
    <form class="filter-bar" method="get" action="<?= e(admin_url('refunds')) ?>">
      <?php if ($filters['status'] !== ''): ?><input type="hidden" name="status" value="<?= e($filters['status']) ?>"><?php endif; ?>
      <div class="field"><label for="rf-q">Order number</label><input class="input" type="search" id="rf-q" name="q" value="<?= e($filters['q']) ?>"></div>
      <button class="btn btn-primary btn-sm" type="submit"><?= icon('search', 'icon-sm') ?> Search</button>
    </form>

    <div class="card card-flush">
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Refund</th><th>Order</th><th class="num">Amount</th><th>Status</th><th>Details</th><?php if ($canManage): ?><th>Action</th><?php endif; ?></tr></thead>
          <tbody>
          <?php if (!$refunds): ?><tr><td colspan="6" class="muted" style="padding:32px;text-align:center">No refunds found.</td></tr><?php endif; ?>
          <?php foreach ($refunds as $r): ?>
            <tr>
              <td>#<?= (int) $r['id'] ?><div class="muted small"><?= e(local_date($r['created_at'])) ?></div></td>
              <td>
                <?php if (can('orders.view')): ?><a class="row-link" href="<?= e(admin_url('orders/' . (int) $r['order_id'])) ?>"><?= e($r['order_number']) ?></a><?php else: ?><?= e($r['order_number']) ?><?php endif; ?>
                <div class="muted small"><?= e($r['customer_name']) ?> · <?= e(strtoupper($r['gateway'] ?? $r['payment_method'])) ?></div>
                <div class="muted small">Paid <?= e(money($r['grand_total'])) ?> · refunded <?= e(money($r['refunded_total'])) ?></div>
              </td>
              <td class="num"><strong><?= e(money($r['amount'])) ?></strong></td>
              <td><span class="status status-<?= e($r['status']) ?>"><?= e(status_label($r['status'])) ?></span></td>
              <td class="small">
                <?= e($r['reason'] ?: '—') ?>
                <div class="muted">Requested by <?= e($r['requested_by_name'] ?? 'System') ?></div>
                <?php if ($r['processed_by_name']): ?><div class="muted"><?= e(status_label($r['status'])) ?> by <?= e($r['processed_by_name']) ?> · <?= e(local_date($r['processed_at'])) ?></div><?php endif; ?>
                <?php if ($r['gateway_reference']): ?><div>Ref: <code><?= e($r['gateway_reference']) ?></code></div><?php endif; ?>
              </td>
              <?php if ($canManage): ?>
              <td style="min-width:220px">
                <?php if ($r['status'] === 'requested'): ?>
                  <form method="post" action="<?= e(admin_url('refunds/' . (int) $r['id'] . '/approve')) ?>" class="inline-form" data-confirm="Approve refund #<?= (int) $r['id'] ?> for <?= e(money($r['amount'])) ?>?">
                    <?= csrf_field() ?><button class="btn btn-primary btn-sm" type="submit">Approve</button>
                  </form>
                <?php endif; ?>
                <?php if ($r['status'] === 'approved'): ?>
                  <form method="post" action="<?= e(admin_url('refunds/' . (int) $r['id'] . '/complete')) ?>" data-confirm="Confirm the refund was sent in the gateway portal?">
                    <?= csrf_field() ?>
                    <label class="sr-only" for="ref-<?= (int) $r['id'] ?>">Portal reference</label>
                    <div class="input-group">
                      <input class="input" id="ref-<?= (int) $r['id'] ?>" name="gateway_reference" maxlength="120" required placeholder="Portal reference">
                      <button class="btn btn-accent btn-sm" type="submit">Complete</button>
                    </div>
                  </form>
                <?php endif; ?>
                <?php if (in_array($r['status'], ['requested', 'approved'], true)): ?>
                  <details class="mt-2">
                    <summary class="small">Reject</summary>
                    <form method="post" action="<?= e(admin_url('refunds/' . (int) $r['id'] . '/reject')) ?>" class="mt-2" data-confirm="Reject this refund?">
                      <?= csrf_field() ?>
                      <input class="input" name="note" maxlength="500" placeholder="Reason (saved as an internal note)">
                      <button class="btn btn-light btn-sm mt-2" type="submit">Reject refund</button>
                    </form>
                  </details>
                <?php endif; ?>
              </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?= $paginator->links() ?>
  </div>

  <?php if ($canManage): ?>
  <div>
    <div class="card">
      <div class="card-head"><h2>New refund request</h2></div>
      <form method="post" action="<?= e(admin_url('refunds')) ?>" data-confirm="Create this refund request?">
        <?= csrf_field() ?>
        <div class="field"><label for="nr-order">Order number</label><input class="input" id="nr-order" name="order_number" maxlength="30" required value="<?= e(old('order_number')) ?>" placeholder="GFT-…"><?= field_error('order_number') ?></div>
        <div class="field"><label for="nr-amount">Amount (NPR)</label><input class="input" type="number" id="nr-amount" name="amount" step="0.01" min="0.01" required value="<?= e(old('amount')) ?>"><?= field_error('amount') ?></div>
        <div class="field"><label for="nr-reason">Reason</label><textarea class="textarea" id="nr-reason" name="reason" maxlength="500" rows="3" required><?= e(old('reason')) ?></textarea><?= field_error('reason') ?></div>
        <p class="muted small">The amount may not exceed what was paid minus completed and open refunds.</p>
        <button class="btn btn-primary btn-block btn-sm" type="submit">Create request</button>
      </form>
    </div>
  </div>
  <?php endif; ?>
</div>
