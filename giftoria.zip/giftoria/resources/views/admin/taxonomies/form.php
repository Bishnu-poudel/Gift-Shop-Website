<?php
/** Generic taxonomy form. Vars: $type, $cfg, $types, $row (null on create), optional $usage */
$isEdit = $row !== null;
$titleCol = $cfg['title'];
$hasOld = (bool) errors() && old($titleCol, null) !== null;
$val = static function (string $k, array $f) use ($row, $hasOld): string {
    if ($hasOld) {
        $o = old($k, null);
        return is_scalar($o) ? (string) $o : '';
    }
    if ($row !== null) {
        return $row[$k] === null ? '' : (string) $row[$k];
    }
    return isset($f['default']) && !is_bool($f['default']) ? (string) $f['default'] : '';
};
$isChecked = static function (string $k, array $f) use ($row, $hasOld): bool {
    if ($hasOld) {
        return in_array(old($k, ''), ['1', 'on', 'yes', 'true'], true);
    }
    return $row !== null ? (bool) $row[$k] : (bool) ($f['default'] ?? false);
};
$action = $isEdit ? admin_url('taxonomies/' . $type . '/' . (int) $row['id']) : admin_url('taxonomies/' . $type);
$hasImage = isset($cfg['fields']['image']);
$main = array_filter($cfg['fields'], static fn ($f) => !in_array($f['type'], ['bool', 'image'], true));
$bools = array_filter($cfg['fields'], static fn ($f) => $f['type'] === 'bool');
?>
<div class="admin-page-head">
  <div>
    <p class="small"><a href="<?= e(admin_url('taxonomies/' . $type)) ?>"><?= icon('chevron-left', 'icon-sm') ?> <?= e($cfg['label']) ?></a></p>
    <h1><?= e($isEdit ? $row[$titleCol] : 'New ' . $cfg['singular']) ?></h1>
    <?php if ($isEdit && $cfg['usage']): ?><p>Assigned to <?= (int) ($usage ?? 0) ?> product(s)</p><?php else: ?><p><?= e($cfg['intro']) ?></p><?php endif; ?>
  </div>
</div>

<?= partial('admin/taxonomies/_tabs', ['types' => $types, 'type' => $type]) ?>

<form method="post" action="<?= e($action) ?>" <?= $hasImage ? 'enctype="multipart/form-data"' : '' ?> data-loading novalidate>
  <?= csrf_field() ?>
  <div class="admin-grid admin-grid-3-1">
    <section class="card">
      <div class="card-head"><h2><?= e(ucfirst($cfg['singular'])) ?> details</h2></div>
      <div class="form-grid">
        <?php foreach ($main as $col => $f):
            $id = 'tx-' . $col;
            $cls = errors($col) ? 'has-error' : '';
            $required = isset($f['rules']) && str_contains($f['rules'], 'required');
        ?>
          <div class="field <?= !empty($f['span']) ? 'span-2' : '' ?>">
            <label for="<?= e($id) ?>"><?= e($f['label']) ?><?= $required ? ' *' : '' ?></label>
            <?php if ($f['type'] === 'select'): ?>
              <select class="select <?= $cls ?>" id="<?= e($id) ?>" name="<?= e($col) ?>">
                <?php foreach ($f['options'] as $ov => $ol): ?>
                  <option value="<?= e($ov) ?>" <?= $val($col, $f) === (string) $ov ? 'selected' : '' ?>><?= e($ol) ?></option>
                <?php endforeach; ?>
              </select>
            <?php elseif ($f['type'] === 'textarea' || $f['type'] === 'synonyms'): ?>
              <textarea class="textarea <?= $cls ?>" id="<?= e($id) ?>" name="<?= e($col) ?>" rows="<?= (int) ($f['rows'] ?? 3) ?>" style="min-height:<?= (int) ($f['rows'] ?? 3) * 26 ?>px"><?= e($val($col, $f)) ?></textarea>
            <?php elseif ($f['type'] === 'maps'): ?>
              <textarea class="textarea <?= $cls ?>" id="<?= e($id) ?>" name="<?= e($col) ?>" rows="3" style="min-height:80px;font-family:ui-monospace,Consolas,monospace" placeholder="<?= e($f['placeholder'] ?? '') ?>"><?= e($val($col, $f)) ?></textarea>
            <?php elseif ($f['type'] === 'number' || $f['type'] === 'money'): ?>
              <input class="input <?= $cls ?>" id="<?= e($id) ?>" name="<?= e($col) ?>" type="number" <?= $f['type'] === 'money' ? 'step="0.01" min="0"' : 'step="1"' ?> value="<?= e($val($col, $f)) ?>" <?= $required ? 'required' : '' ?>>
            <?php elseif ($f['type'] === 'slug'): ?>
              <input class="input <?= $cls ?>" id="<?= e($id) ?>" name="<?= e($col) ?>" value="<?= e($val($col, $f)) ?>" data-slug-from="#tx-<?= e($titleCol) ?>" placeholder="auto-from-<?= e($titleCol) ?>">
            <?php else: ?>
              <input class="input <?= $cls ?>" id="<?= e($id) ?>" name="<?= e($col) ?>" value="<?= e($val($col, $f)) ?>" placeholder="<?= e($f['placeholder'] ?? '') ?>" <?= $required ? 'required' : '' ?>>
            <?php endif; ?>
            <?php if (!empty($f['hint'])): ?><p class="hint"><?= e($f['hint']) ?></p><?php elseif ($f['type'] === 'slug'): ?><p class="hint">Leave empty to generate it automatically.</p><?php endif; ?>
            <?= field_error($col) ?>
          </div>
        <?php endforeach; ?>
      </div>
      <?php if ($type === 'synonyms'): ?>
        <div class="code-block mt-2">Examples
little princess  →  recipient:baby-girl,interest:princess-toys,agemonths:12-36
handmade gift    →  pref:handmade
custom name gift →  flag:personalized
first bday       →  occasion:first-birthday,category:toys</div>
      <?php endif; ?>
    </section>

    <div>
      <section class="card">
        <div class="card-head"><h2>Save</h2></div>
        <?php if ($bools): ?>
          <div class="stack mb-4">
            <?php foreach ($bools as $col => $f): ?>
              <label class="check"><input type="checkbox" name="<?= e($col) ?>" value="1" <?= $isChecked($col, $f) ? 'checked' : '' ?>> <?= e($f['label']) ?></label>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <div class="form-actions">
          <a class="btn btn-ghost" href="<?= e(admin_url('taxonomies/' . $type)) ?>">Cancel</a>
          <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save changes' : 'Create ' . e($cfg['singular']) ?></button>
        </div>
      </section>

      <?php if ($hasImage): ?>
      <section class="card">
        <div class="card-head"><h2>Image</h2></div>
        <?php if ($isEdit && !empty($row['image'])): ?>
          <div class="image-manager mb-4" style="grid-template-columns:140px">
            <figure><img src="<?= e(image_url($row['image'])) ?>" alt="<?= e($row[$titleCol]) ?>"></figure>
          </div>
          <label class="check mb-4"><input type="checkbox" name="remove_image" value="1"> Remove current image</label>
        <?php endif; ?>
        <div class="field">
          <label for="tx-image"><?= $isEdit && !empty($row['image']) ? 'Replace image' : 'Upload image' ?></label>
          <input class="input <?= errors('image') ? 'has-error' : '' ?>" id="tx-image" name="image" type="file" accept="image/jpeg,image/png,image/webp,image/gif">
          <p class="hint">JPEG, PNG, WebP or GIF up to 5 MB.</p>
          <?= field_error('image') ?>
        </div>
      </section>
      <?php endif; ?>

      <?php if ($isEdit): ?>
      <section class="card danger-zone">
        <div class="card-head"><h2>Delete</h2></div>
        <p class="muted small"><?= $cfg['usage'] && (int) ($usage ?? 0) > 0 ? 'This ' . e($cfg['singular']) . ' will be removed from ' . (int) $usage . ' product(s). Products themselves are not deleted.' : 'This cannot be undone.' ?></p>
        <button class="btn btn-danger btn-sm" type="submit" form="delete-term">Delete <?= e($cfg['singular']) ?></button>
      </section>
      <?php endif; ?>
    </div>
  </div>
</form>
<?php if ($isEdit): ?>
<form id="delete-term" method="post" action="<?= e(admin_url('taxonomies/' . $type . '/' . (int) $row['id'] . '/delete')) ?>" data-confirm="Delete this <?= e($cfg['singular']) ?> permanently?" hidden><?= csrf_field() ?></form>
<?php endif; ?>
