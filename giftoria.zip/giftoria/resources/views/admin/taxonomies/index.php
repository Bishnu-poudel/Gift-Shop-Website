<?php
/** Vars: $type, $cfg, $types, $rows, $q */
$headers = [
    'image' => '', 'name' => 'Name', 'label' => 'Label', 'phrase' => 'Phrase', 'slug' => 'Slug', 'audience' => 'Audience',
    'ages' => 'Ages', 'months' => 'Months', 'amounts' => 'Range', 'usage' => 'Products', 'sort_order' => 'Sort',
    'is_active' => 'Status', 'is_seasonal' => 'Seasonal', 'is_featured' => 'Featured', 'type' => 'Type',
    'location' => 'Location', 'maps_to' => 'Maps to',
];
$numCols = ['usage', 'sort_order'];
$titleCol = $cfg['title'];
?>
<div class="admin-page-head">
  <div>
    <h1>Gift taxonomy</h1>
    <p><?= e($cfg['intro']) ?></p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-accent" href="<?= e(admin_url('taxonomies/' . $type . '/create')) ?>"><?= icon('plus', 'icon-sm') ?> New <?= e($cfg['singular']) ?></a>
  </div>
</div>

<?= partial('admin/taxonomies/_tabs', ['types' => $types, 'type' => $type]) ?>

<form class="filter-bar" method="get" action="<?= e(admin_url('taxonomies/' . $type)) ?>" role="search">
  <div class="field">
    <label for="t-q">Search <?= e(mb_strtolower($cfg['label'])) ?></label>
    <input class="input" id="t-q" type="search" name="q" value="<?= e($q) ?>" placeholder="<?= e(ucfirst($titleCol)) ?>">
  </div>
  <button class="btn btn-primary btn-sm" type="submit"><?= icon('search', 'icon-sm') ?> Search</button>
  <?php if ($q !== ''): ?><a class="btn btn-ghost btn-sm" href="<?= e(admin_url('taxonomies/' . $type)) ?>">Clear</a><?php endif; ?>
</form>

<?php if (!$rows): ?>
  <?= partial('components/empty-state', [
      'icon' => 'tag',
      'title' => $q !== '' ? 'No matches' : 'No ' . mb_strtolower($cfg['label']) . ' yet',
      'text' => $q !== '' ? 'Try a different search.' : 'Create the first ' . $cfg['singular'] . ' to use it across the store.',
      'actionUrl' => admin_url('taxonomies/' . $type . '/create'),
      'actionLabel' => 'New ' . $cfg['singular'],
  ]) ?>
<?php else: ?>
<div class="card card-flush">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <?php foreach ($cfg['list'] as $col): ?>
            <th scope="col" class="<?= in_array($col, $numCols, true) ? 'num' : '' ?>"><?= $col === 'image' ? '<span class="sr-only">Image</span>' : e($headers[$col] ?? ucfirst($col)) ?></th>
          <?php endforeach; ?>
          <th scope="col"><span class="sr-only">Actions</span></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($rows as $r): $rid = (int) $r['id']; $editUrl = admin_url('taxonomies/' . $type . '/' . $rid . '/edit'); ?>
        <tr>
          <?php foreach ($cfg['list'] as $col): ?>
            <td class="<?= in_array($col, $numCols, true) ? 'num' : '' ?>">
              <?php switch ($col):
                  case 'image': ?>
                  <img class="thumb" src="<?= e(image_url($r['image'] ?? null)) ?>" alt="" loading="lazy" width="44" height="52">
                  <?php break;
                  case $titleCol: ?>
                  <a class="row-link" href="<?= e($editUrl) ?>"><?= e($r[$col]) ?></a>
                  <?php if (!empty($r['synonyms'])): ?><div class="muted small"><?= e(str_limit($r['synonyms'], 70)) ?></div><?php endif; ?>
                  <?php break;
                  case 'ages': ?>
                  <?= e($r['age_min_months'] === null && $r['age_max_months'] === null ? '—' : age_range_label($r['age_min_months'] !== null ? (int) $r['age_min_months'] : null, $r['age_max_months'] !== null ? (int) $r['age_max_months'] : null)) ?>
                  <?php break;
                  case 'months': ?>
                  <?= e((int) $r['min_months'] . '–' . (int) $r['max_months']) ?> <span class="muted small">(<?= e(age_range_label((int) $r['min_months'], (int) $r['max_months'])) ?>)</span>
                  <?php break;
                  case 'amounts': ?>
                  <?= e(money($r['min_amount'])) ?> – <?= $r['max_amount'] !== null ? e(money($r['max_amount'])) : 'and above' ?>
                  <?php break;
                  case 'usage': ?>
                  <?= (int) $r['usage_count'] ?>
                  <?php break;
                  case 'is_active': ?>
                  <span class="status status-<?= (int) $r['is_active'] ? 'active' : 'inactive' ?>"><?= (int) $r['is_active'] ? 'Active' : 'Hidden' ?></span>
                  <?php break;
                  case 'is_seasonal':
                  case 'is_featured': ?>
                  <?= (int) $r[$col] ? '<span class="badge badge-info">Yes</span>' : '<span class="muted">—</span>' ?>
                  <?php break;
                  case 'type': ?>
                  <span class="badge <?= $r['type'] === 'preference' ? 'badge-best' : '' ?>"><?= e(ucfirst((string) $r['type'])) ?></span>
                  <?php break;
                  case 'audience': ?>
                  <?= e(ucfirst((string) $r['audience'])) ?>
                  <?php break;
                  case 'maps_to': ?>
                  <div class="row" style="gap:4px">
                    <?php foreach (array_filter(explode(',', (string) $r['maps_to'])) as $m): ?><span class="badge"><?= e(trim($m)) ?></span><?php endforeach; ?>
                  </div>
                  <?php break;
                  case 'slug': ?>
                  <span class="muted small"><?= e($r['slug']) ?></span>
                  <?php break;
                  default: ?>
                  <?= e($r[$col] ?? '—') ?>
              <?php endswitch; ?>
            </td>
          <?php endforeach; ?>
          <td>
            <div class="row" style="gap:4px;flex-wrap:nowrap;justify-content:flex-end">
              <a class="btn btn-light btn-sm" href="<?= e($editUrl) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
              <form method="post" action="<?= e(admin_url('taxonomies/' . $type . '/' . $rid . '/delete')) ?>" class="inline-form" data-confirm="Delete &quot;<?= e($r[$titleCol]) ?>&quot;?<?= !empty($r['usage_count']) ? ' It will be removed from ' . (int) $r['usage_count'] . ' product(s).' : '' ?>">
                <?= csrf_field() ?>
                <button class="btn btn-ghost btn-sm" type="submit" title="Delete"><?= icon('trash', 'icon-sm') ?><span class="sr-only">Delete</span></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<p class="muted small"><?= count($rows) ?> <?= e(mb_strtolower($cfg['label'])) ?></p>
<?php endif; ?>
