<?php /** Vars: $types, $type */ ?>
<nav class="tabs" aria-label="Taxonomy types">
  <?php foreach ($types as $key => $t): ?>
    <a href="<?= e(admin_url('taxonomies/' . $key)) ?>" class="<?= $key === $type ? 'is-active' : '' ?>" <?= $key === $type ? 'aria-current="page"' : '' ?>><?= e($t['label']) ?></a>
  <?php endforeach; ?>
</nav>
