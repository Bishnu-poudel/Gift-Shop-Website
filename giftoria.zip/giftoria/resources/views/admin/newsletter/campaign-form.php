<?php
/** @var ?array $campaign */
$isEdit = $campaign !== null;
$hasOld = (bool) errors();
$val = static fn (string $k, string $d = '') => $hasOld ? (string) old($k, $d) : (string) ($campaign[$k] ?? $d);
$action = $isEdit ? admin_url('newsletter/campaigns/' . (int) $campaign['id']) : admin_url('newsletter/campaigns');
$starter = "<h1>Hello from Giftoria</h1>\n<p>Thoughtful, handmade gifts for everyone you love.</p>\n<p><a href=\"" . url('/shop') . "\">Browse new arrivals</a></p>";
?>
<div class="admin-page-head">
  <div>
    <h1><?= $isEdit ? 'Edit email campaign' : 'Compose email campaign' ?></h1>
    <p>Sent to all subscribed, consented addresses that are not suppressed. An unsubscribe link is added to every message automatically.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light" href="<?= e($isEdit ? admin_url('newsletter/campaigns/' . (int) $campaign['id']) : admin_url('newsletter/campaigns')) ?>">Back</a>
  </div>
</div>

<div class="admin-grid admin-grid-3-1">
  <form class="card" method="post" action="<?= e($action) ?>" data-loading>
    <?= csrf_field() ?>
    <div class="form-grid">
      <div class="field">
        <label for="name">Internal name</label>
        <input class="input <?= errors('name') ? 'has-error' : '' ?>" id="name" name="name" value="<?= e($val('name')) ?>" maxlength="120" required placeholder="Tihar 2026 gift guide">
        <?= field_error('name') ?>
      </div>
      <div class="field">
        <label for="subject">Subject line</label>
        <input class="input <?= errors('subject') ? 'has-error' : '' ?>" id="subject" name="subject" value="<?= e($val('subject')) ?>" maxlength="190" required>
        <?= field_error('subject') ?>
      </div>
      <div class="field span-2">
        <label for="body_html">Body (HTML)</label>
        <textarea class="textarea <?= errors('body_html') ? 'has-error' : '' ?>" id="body_html" name="body_html" rows="18" required style="font-family:ui-monospace,Consolas,monospace;font-size:0.85rem"><?= e($val('body_html', $isEdit ? '' : $starter)) ?></textarea>
        <p class="hint">Safe HTML only. Scripts, forms, embedded frames, event attributes (onclick…) and javascript: links are removed when you save.</p>
        <?= field_error('body_html') ?>
      </div>
    </div>
    <div class="form-actions">
      <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save draft' : 'Save draft & preview' ?></button>
    </div>
  </form>
  <aside>
    <div class="card">
      <div class="card-head"><h2>Allowed HTML</h2></div>
      <p class="small">Headings (h1–h4), paragraphs, bold/italic, links, lists, images, tables, blockquotes and simple inline styles.</p>
      <div class="code-block">&lt;p&gt;Text with &lt;strong&gt;bold&lt;/strong&gt;&lt;/p&gt;
&lt;a href="https://…"&gt;Link&lt;/a&gt;
&lt;img src="https://…/banner.jpg" alt="…" width="560"&gt;</div>
    </div>
    <div class="card">
      <div class="card-head"><h2>Before sending</h2></div>
      <ul class="list-plain">
        <li>Preview the email</li>
        <li>Send a test to your own inbox</li>
        <li>Check every link</li>
      </ul>
    </div>
  </aside>
</div>
