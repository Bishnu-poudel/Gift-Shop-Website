<?php
/** @var array $subscribers @var App\Core\Paginator $paginator @var array $filters @var array $stats @var string $tab */
?>
<?= partial('admin/newsletter/_tabs', ['tab' => $tab, 'stats' => $stats]) ?>

<form class="filter-bar" method="get" action="<?= e(admin_url('newsletter')) ?>">
  <div class="field">
    <label for="f-q">Search email</label>
    <input class="input" id="f-q" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="name@example.com">
  </div>
  <div class="field">
    <label for="f-status">Status</label>
    <select class="select" id="f-status" name="status" data-autosubmit>
      <option value="">All</option>
      <option value="subscribed" <?= $filters['status'] === 'subscribed' ? 'selected' : '' ?>>Subscribed</option>
      <option value="unsubscribed" <?= $filters['status'] === 'unsubscribed' ? 'selected' : '' ?>>Unsubscribed</option>
    </select>
  </div>
  <button class="btn btn-light btn-sm" type="submit"><?= icon('search', 'icon-sm') ?> Search</button>
  <span class="muted small" style="margin-left:auto">CSV export includes only subscribed, consented and non-suppressed addresses.</span>
</form>

<div class="card card-flush">
  <?php if (!$subscribers): ?>
    <div style="padding:24px"><?= partial('components/empty-state', ['icon' => 'mail', 'title' => 'No subscribers found', 'text' => 'Sign-ups from the storefront footer and account settings appear here.']) ?></div>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead><tr><th>Email</th><th>Source</th><th>Consent (NPT)</th><th>Joined</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($subscribers as $s): ?>
      <tr>
        <td>
          <strong><?= e($s['email']) ?></strong>
          <?php if ($s['user_id']): ?><span class="badge badge-info" style="margin-left:6px">Customer</span><?php endif; ?>
        </td>
        <td><?= e($s['source'] ?: '—') ?></td>
        <td class="small"><?= $s['consent_at'] ? e(local_date($s['consent_at'])) : '<span class="badge badge-warning">No consent record</span>' ?></td>
        <td class="small"><?= e(local_date($s['created_at'], 'M j, Y')) ?></td>
        <td>
          <span class="status status-<?= e($s['status']) ?>"><?= e(status_label($s['status'])) ?></span>
          <?php if ($s['suppressed']): ?><span class="badge badge-danger" style="margin-left:4px">Suppressed</span><?php endif; ?>
          <?php if ($s['unsubscribed_at']): ?><div class="muted small"><?= e(local_date($s['unsubscribed_at'], 'M j, Y')) ?></div><?php endif; ?>
        </td>
        <td class="num">
          <?php if ($s['status'] === 'subscribed'): ?>
            <form class="inline-form" method="post" action="<?= e(admin_url('newsletter/unsubscribe')) ?>" data-confirm="Unsubscribe <?= e($s['email']) ?>? The address will be added to the suppression list.">
              <?= csrf_field() ?>
              <input type="hidden" name="email" value="<?= e($s['email']) ?>">
              <button class="btn btn-ghost btn-sm" type="submit">Unsubscribe</button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>
<?= $paginator->links() ?>
