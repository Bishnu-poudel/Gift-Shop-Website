<?php
/** @var array $campaigns @var App\Core\Paginator $paginator @var array $stats @var string $tab @var int $audience */
?>
<?= partial('admin/newsletter/_tabs', ['tab' => $tab, 'stats' => $stats]) ?>

<div class="card card-flush">
  <div class="card-head">
    <h2>Email campaigns</h2>
    <span class="muted small">Current audience: <?= number_format($audience) ?> address(es)</span>
  </div>
  <?php if (!$campaigns): ?>
    <div style="padding:24px"><?= partial('components/empty-state', ['icon' => 'mail', 'title' => 'No email campaigns yet', 'text' => 'Compose a newsletter, preview it and send yourself a test first.', 'actionUrl' => admin_url('newsletter/campaigns/create'), 'actionLabel' => 'Compose campaign']) ?></div>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead><tr><th>Campaign</th><th>Segment</th><th>Status</th><th class="num">Recipients</th><th class="num">Delivered</th><th>Sent (NPT)</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($campaigns as $c): ?>
      <tr>
        <td>
          <a class="row-link" href="<?= e(admin_url('newsletter/campaigns/' . (int) $c['id'])) ?>"><?= e($c['name']) ?></a>
          <div class="muted small"><?= e(str_limit($c['subject'], 70)) ?></div>
        </td>
        <td><?= e(status_label($c['segment'])) ?></td>
        <td><span class="status status-<?= e($c['status'] === 'sent' ? 'completed' : ($c['status'] === 'sending' ? 'processing' : 'draft')) ?>"><?= e(status_label($c['status'])) ?></span></td>
        <td class="num"><?= $c['status'] === 'draft' ? '—' : number_format((int) $c['recipients_count']) ?></td>
        <td class="num"><?= $c['status'] === 'draft' ? '—' : number_format((int) $c['sent_count']) ?></td>
        <td class="small"><?= $c['sent_at'] ? e(local_date($c['sent_at'])) : '<span class="muted">—</span>' ?></td>
        <td class="num">
          <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('newsletter/campaigns/' . (int) $c['id'])) ?>"><?= icon('eye', 'icon-sm') ?> Open</a>
          <?php if ($c['status'] === 'draft'): ?>
            <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('newsletter/campaigns/' . (int) $c['id'] . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>
<?= $paginator->links() ?>
