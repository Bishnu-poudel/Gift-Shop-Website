<?php
/** @var array $counts @var array $carts @var App\Core\Paginator $paginator @var array $stats @var string $tab */
?>
<?= partial('admin/newsletter/_tabs', ['tab' => $tab, 'stats' => $stats]) ?>

<div class="admin-grid admin-grid-3-1">
  <div>
    <div class="card card-flush">
      <div class="card-head"><h2>Signed-in carts idle for more than 24 hours</h2><span class="muted small"><?= number_format((int) ($counts['idle'] ?? 0)) ?> cart(s)</span></div>
      <?php if (!$carts): ?>
        <div style="padding:24px"><?= partial('components/empty-state', ['icon' => 'bag', 'title' => 'No abandoned carts', 'text' => 'Carts of signed-in customers that have items and no activity for 24 hours appear here.']) ?></div>
      <?php else: ?>
      <div style="overflow-x:auto">
      <table class="data-table">
        <thead><tr><th>Customer</th><th class="num">Items</th><th class="num">Current value</th><th>Last activity (NPT)</th><th>Reminder</th></tr></thead>
        <tbody>
        <?php foreach ($carts as $c): ?>
          <tr>
            <td><strong><?= e($c['name']) ?></strong><div class="muted small"><?= e($c['email']) ?></div></td>
            <td class="num"><?= (int) $c['items'] ?></td>
            <td class="num"><?= e(money($c['value'])) ?></td>
            <td class="small"><?= e(local_date($c['updated_at'])) ?></td>
            <td>
              <?php if ($c['reminder_sent_at']): ?>
                <span class="status status-completed">Sent</span><div class="muted small"><?= e(local_date($c['reminder_sent_at'])) ?></div>
              <?php else: ?>
                <span class="status status-pending">Queued</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
      <?php endif; ?>
    </div>
    <?= $paginator->links() ?>
  </div>
  <aside>
    <div class="card">
      <div class="card-head"><h2>Reminder status</h2></div>
      <ul class="list-plain">
        <li><span>Idle carts (&gt; 24 h)</span><strong><?= number_format((int) ($counts['idle'] ?? 0)) ?></strong></li>
        <li><span>Waiting for a reminder</span><strong><?= number_format((int) ($counts['pending'] ?? 0)) ?></strong></li>
        <li><span>Reminder already sent</span><strong><?= number_format((int) ($counts['reminded'] ?? 0)) ?></strong></li>
      </ul>
    </div>
    <div class="card">
      <div class="card-head"><h2>How sending works</h2></div>
      <p class="small">Reminders are sent by the scheduled job, not from this page. Each cart gets at most one reminder, and only customers who are not on the suppression list receive it.</p>
      <div class="code-block">php bin/console.php cron</div>
      <p class="muted small" style="margin-top:8px">Schedule it hourly (Windows Task Scheduler or cron).</p>
    </div>
  </aside>
</div>
