<?php
/** @var array $campaign @var string $previewHtml @var int $audience @var string $staffEmail */
$isDraft = $campaign['status'] === 'draft';
$statusClass = $campaign['status'] === 'sent' ? 'completed' : ($campaign['status'] === 'sending' ? 'processing' : 'draft');
?>
<div class="admin-page-head">
  <div>
    <h1><?= e($campaign['name']) ?></h1>
    <p>Subject: <strong><?= e($campaign['subject']) ?></strong> · <span class="status status-<?= e($statusClass) ?>"><?= e(status_label($campaign['status'])) ?></span></p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light" href="<?= e(admin_url('newsletter/campaigns')) ?>">All campaigns</a>
    <?php if ($isDraft): ?>
      <a class="btn btn-light" href="<?= e(admin_url('newsletter/campaigns/' . (int) $campaign['id'] . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
    <?php endif; ?>
  </div>
</div>

<div class="admin-grid admin-grid-3-1">
  <div class="card card-flush">
    <div class="card-head" style="padding-bottom:16px"><h2>Preview</h2><span class="muted small">Rendered in a sandbox — scripts cannot run</span></div>
    <iframe title="Email preview" sandbox="" srcdoc="<?= e($previewHtml) ?>" style="width:100%;height:720px;border:0;border-top:1px solid var(--line);background:#fff"></iframe>
  </div>

  <aside>
    <?php if ($isDraft): ?>
      <form class="card" method="post" action="<?= e(admin_url('newsletter/campaigns/' . (int) $campaign['id'] . '/test')) ?>" data-loading>
        <?= csrf_field() ?>
        <div class="card-head"><h2>Send a test</h2></div>
        <p class="small">Sends this email to your own address only: <strong><?= e($staffEmail ?: 'no email on file') ?></strong></p>
        <button class="btn btn-light btn-block" type="submit" <?= $staffEmail === '' ? 'disabled' : '' ?>><?= icon('mail', 'icon-sm') ?> Send test to me</button>
      </form>

      <form class="card" method="post" action="<?= e(admin_url('newsletter/campaigns/' . (int) $campaign['id'] . '/send')) ?>" data-confirm="Send “<?= e($campaign['subject']) ?>” to <?= (int) $audience ?> subscriber(s) now? This cannot be undone." data-loading>
        <?= csrf_field() ?>
        <div class="card-head"><h2>Send campaign</h2></div>
        <ul class="list-plain">
          <li><span>Segment</span><strong>All subscribers</strong></li>
          <li><span>Recipients now</span><strong><?= number_format($audience) ?></strong></li>
        </ul>
        <p class="muted small">Only subscribed addresses with recorded consent that are not on the suppression list. Each message includes a personal unsubscribe link.</p>
        <button class="btn btn-accent btn-block" type="submit" <?= $audience === 0 ? 'disabled' : '' ?>><?= icon('zap', 'icon-sm') ?> Send to <?= number_format($audience) ?> subscriber(s)</button>
      </form>
    <?php else: ?>
      <div class="card">
        <div class="card-head"><h2>Delivery</h2></div>
        <ul class="list-plain">
          <li><span>Recipients</span><strong><?= number_format((int) $campaign['recipients_count']) ?></strong></li>
          <li><span>Delivered (sent or logged)</span><strong><?= number_format((int) $campaign['sent_count']) ?></strong></li>
          <li><span>Not delivered</span><strong><?= number_format(max(0, (int) $campaign['recipients_count'] - (int) $campaign['sent_count'])) ?></strong></li>
          <li><span>Sent at</span><span><?= $campaign['sent_at'] ? e(local_date($campaign['sent_at'])) : '—' ?></span></li>
        </ul>
        <p class="muted small">“Logged” means mail was in development log mode and recorded in the outbox without leaving the server.</p>
      </div>
    <?php endif; ?>
    <div class="card">
      <div class="card-head"><h2>Details</h2></div>
      <ul class="list-plain">
        <li><span>Created</span><span><?= e(local_date($campaign['created_at'])) ?></span></li>
        <li><span>Segment</span><span><?= e(status_label($campaign['segment'])) ?></span></li>
      </ul>
    </div>
  </aside>
</div>
