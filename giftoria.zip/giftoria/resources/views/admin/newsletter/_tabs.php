<?php
/** Shared header for the newsletter module. Vars: $tab, $stats */
$tabs = [
    'subscribers' => ['Subscribers', 'newsletter'],
    'campaigns' => ['Email campaigns', 'newsletter/campaigns'],
    'suppressions' => ['Suppression list', 'newsletter/suppressions'],
    'abandoned' => ['Abandoned carts', 'newsletter/abandoned-carts'],
];
$stats = $stats ?? [];
?>
<div class="admin-page-head">
  <div>
    <h1>Newsletter</h1>
    <p>Opt-in subscribers, email campaigns and suppression handling. Unsubscribed or suppressed addresses never receive marketing email.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light" href="<?= e(admin_url('newsletter/export')) ?>"><?= icon('download', 'icon-sm') ?> Export CSV</a>
    <a class="btn btn-primary" href="<?= e(admin_url('newsletter/campaigns/create')) ?>"><?= icon('mail', 'icon-sm') ?> New email campaign</a>
  </div>
</div>

<?php if ($stats): ?>
<div class="kpis">
  <div class="kpi"><p class="label">Subscribed</p><div class="value"><?= number_format((int) ($stats['subscribed'] ?? 0)) ?></div><div class="sub">+<?= number_format((int) ($stats['new_30d'] ?? 0)) ?> sign-ups in 30 days</div></div>
  <div class="kpi"><p class="label">Mailable audience</p><div class="value"><?= number_format((int) ($stats['mailable'] ?? 0)) ?></div><div class="sub">Subscribed, consented, not suppressed</div></div>
  <div class="kpi"><p class="label">Unsubscribed</p><div class="value"><?= number_format((int) ($stats['unsubscribed'] ?? 0)) ?></div></div>
  <div class="kpi"><p class="label">Suppressed</p><div class="value"><?= number_format((int) ($stats['suppressed'] ?? 0)) ?></div></div>
</div>
<?php endif; ?>

<nav class="tabs" aria-label="Newsletter sections">
  <?php foreach ($tabs as $key => [$label, $path]): ?>
    <a href="<?= e(admin_url($path)) ?>" class="<?= ($tab ?? '') === $key ? 'is-active' : '' ?>" <?= ($tab ?? '') === $key ? 'aria-current="page"' : '' ?>><?= e($label) ?></a>
  <?php endforeach; ?>
</nav>
