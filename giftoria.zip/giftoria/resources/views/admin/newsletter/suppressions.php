<?php
/** @var array $rows @var App\Core\Paginator $paginator @var string $q @var array $stats @var string $tab */
?>
<?= partial('admin/newsletter/_tabs', ['tab' => $tab, 'stats' => $stats]) ?>

<div class="alert alert-info"><?= icon('info') ?><div>Suppressed addresses never receive marketing email (newsletters, reminders, abandoned-cart emails), even if they are still on another list. An address is removed from this list only when the person subscribes again themselves.</div></div>

<form class="filter-bar" method="get" action="<?= e(admin_url('newsletter/suppressions')) ?>">
  <div class="field">
    <label for="f-q">Search email</label>
    <input class="input" id="f-q" type="search" name="q" value="<?= e($q) ?>">
  </div>
  <button class="btn btn-light btn-sm" type="submit"><?= icon('search', 'icon-sm') ?> Search</button>
</form>

<div class="card card-flush">
  <?php if (!$rows): ?>
    <div style="padding:24px"><?= partial('components/empty-state', ['icon' => 'shield', 'title' => 'Suppression list is empty', 'text' => 'Addresses that unsubscribe are added here automatically.']) ?></div>
  <?php else: ?>
  <table class="data-table">
    <thead><tr><th>Email</th><th>Reason</th><th>Added (NPT)</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><strong><?= e($r['email']) ?></strong></td>
        <td><?= e(status_label((string) ($r['reason'] ?: 'unspecified'))) ?></td>
        <td class="small"><?= e(local_date($r['created_at'])) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>
<?= $paginator->links() ?>
