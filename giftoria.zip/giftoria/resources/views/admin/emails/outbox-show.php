<?php
/** Vars: $message, $body, $statuses */
$cls = ['logged' => 'pending', 'sent' => 'completed', 'failed' => 'failed'];
?>
<div class="admin-page-head">
  <div>
    <h1><?= e($message['subject']) ?></h1>
    <p>Outbox message #<?= (int) $message['id'] ?> · <?= e(local_date($message['created_at'])) ?></p>
  </div>
  <div class="admin-actions"><a class="btn btn-light" href="<?= e(admin_url('emails/outbox')) ?>">Back to outbox</a></div>
</div>

<div class="admin-grid admin-grid-3-1">
  <div class="card">
    <div class="card-head"><h2>Message preview</h2><span class="muted small">Sandboxed · links and one-time tokens are disabled/redacted</span></div>
    <iframe title="Email message preview" sandbox="" referrerpolicy="no-referrer"
            style="width:100%;height:640px;border:1px solid var(--line);border-radius:var(--r-md);background:#fff"
            srcdoc="<?= e($body) ?>"></iframe>
  </div>
  <div class="card">
    <div class="card-head"><h2>Delivery</h2></div>
    <ul class="list-plain">
      <li><span class="muted">To</span><span><?= e($message['to_email']) ?></span></li>
      <li><span class="muted">Template</span><span><?= $message['template_key'] ? '<code>' . e($message['template_key']) . '</code>' : '—' ?></span></li>
      <li><span class="muted">Status</span><span class="status status-<?= e($cls[$message['status']] ?? 'draft') ?>"><?= e($message['status']) ?></span></li>
    </ul>
    <p class="small mt-4"><?= e($statuses[$message['status']] ?? '') ?></p>
    <?php if ($message['status'] === 'logged'): ?>
      <div class="alert alert-warning"><?= icon('alert') ?><div>This message was <strong>not sent</strong>. It was recorded because the application is in development mail mode (<code>MAIL_MODE=log</code>).</div></div>
    <?php elseif ($message['status'] === 'sent'): ?>
      <p class="muted small">"Sent" means the SMTP server accepted the message. Inbox delivery is not guaranteed.</p>
    <?php endif; ?>
    <?php if ($message['error']): ?>
      <label class="label mt-4">Error</label>
      <div class="code-block"><?= e($message['error']) ?></div>
    <?php endif; ?>
  </div>
</div>
