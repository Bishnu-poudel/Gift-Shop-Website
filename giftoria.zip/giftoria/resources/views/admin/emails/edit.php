<?php /** Vars: $template, $vars, $samples, $previewSubject, $previewHtml */ ?>
<div class="admin-page-head">
  <div>
    <h1><?= e($template['name']) ?></h1>
    <p><code><?= e($template['template_key']) ?></code> · last updated <?= e(local_date($template['updated_at'])) ?></p>
  </div>
  <div class="admin-actions"><a class="btn btn-light" href="<?= e(admin_url('emails')) ?>">All templates</a></div>
</div>

<div class="admin-grid admin-grid-2">
  <form method="post" action="<?= e(admin_url('emails/' . (int) $template['id'])) ?>" class="card" data-loading novalidate>
    <?= csrf_field() ?>
    <div class="card-head"><h2>Content</h2></div>
    <div class="field">
      <label for="subject">Subject</label>
      <input class="input<?= errors('subject') ? ' has-error' : '' ?>" id="subject" name="subject" value="<?= e(old('subject', $template['subject'])) ?>" required maxlength="190" data-preview-subject>
      <?= field_error('subject') ?>
    </div>
    <div class="field">
      <label for="body_html">Body (HTML)</label>
      <textarea class="textarea<?= errors('body_html') ? ' has-error' : '' ?>" id="body_html" name="body_html" rows="18" required spellcheck="false" style="font-family:ui-monospace,Consolas,monospace;font-size:.8rem" data-preview-body><?= e(old('body_html', $template['body_html'])) ?></textarea>
      <p class="hint">Scripts, <code>on*</code> event attributes and <code>javascript:</code> links are removed when you save. The store header/footer layout is added automatically.</p>
      <?= field_error('body_html') ?>
    </div>
    <div class="field">
      <label>Available variables</label>
      <div class="row" style="gap:6px">
        <?php foreach ($vars as $v): ?><code class="chip" style="font-size:.75rem">{{<?= e($v) ?>}}</code><?php endforeach; ?>
      </div>
      <p class="hint"><code>{{name}}</code> inserts escaped text. <code>{{{name}}}</code> inserts raw HTML and is only meant for store-generated blocks such as <code>items_table</code>.</p>
    </div>
    <div class="form-actions">
      <a class="btn btn-light" href="<?= e(admin_url('emails')) ?>">Cancel</a>
      <button class="btn btn-primary" type="submit">Save template</button>
    </div>
  </form>

  <div class="card">
    <div class="card-head"><h2>Preview</h2><span class="muted small">Sample data · updates as you type</span></div>
    <p class="small"><strong>Subject:</strong> <span data-preview-subject-out><?= e($previewSubject) ?></span></p>
    <iframe title="Email preview" sandbox="" referrerpolicy="no-referrer" data-preview-frame
            style="width:100%;height:560px;border:1px solid var(--line);border-radius:var(--r-md);background:#fff"
            srcdoc="<?= e($previewHtml) ?>"></iframe>
  </div>
</div>

<script type="application/json" id="email-preview-samples"><?= json_encode($samples, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
<script>
(function () {
  var body = document.querySelector('[data-preview-body]');
  var subj = document.querySelector('[data-preview-subject]');
  var frame = document.querySelector('[data-preview-frame]');
  var subjOut = document.querySelector('[data-preview-subject-out]');
  var samples = {};
  try { samples = JSON.parse(document.getElementById('email-preview-samples').textContent || '{}'); } catch (e) {}
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function render(tpl, plain) {
    tpl = tpl.replace(/\{\{\{\s*(\w+)\s*\}\}\}/g, function (_, k) { return samples[k] != null ? String(samples[k]) : ''; });
    return tpl.replace(/\{\{\s*(\w+)\s*\}\}/g, function (_, k) { var v = samples[k] != null ? String(samples[k]) : ''; return plain ? v : esc(v); });
  }
  var t;
  function update() {
    clearTimeout(t);
    t = setTimeout(function () {
      // The iframe is sandboxed without allow-scripts, so nothing typed here can execute.
      if (frame && body) frame.srcdoc = render(body.value, false);
      if (subjOut && subj) subjOut.textContent = render(subj.value, true);
    }, 250);
  }
  if (body) body.addEventListener('input', update);
  if (subj) subj.addEventListener('input', update);
})();
</script>
