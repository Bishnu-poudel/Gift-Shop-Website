<?php
/** Vars: $rows, $paginator, $filters, $statuses, $mailMode */
$cls = ['logged' => 'pending', 'sent' => 'completed', 'failed' => 'failed'];
$short = ['logged' => 'Logged · not sent', 'sent' => 'Sent', 'failed' => 'Failed'];
?>
<div class="admin-page-head">
  <div>
    <h1>Email outbox</h1>
    <p>Every outgoing email is recorded here with an honest delivery status.</p>
  </div>
  <div class="admin-actions"><a class="btn btn-light" href="<?= e(admin_url('emails')) ?>">Templates</a></div>
</div>

<?php if ($mailMode !== 'smtp'): ?>
  <div class="alert alert-warning"><?= icon('alert') ?><div><strong>Development mail mode is active.</strong> "Logged" messages were recorded only; nothing was delivered to the recipient.</div></div>
<?php endif; ?>

<form class="filter-bar" method="get" action="<?= e(admin_url('emails/outbox')) ?>">
  <div class="field">
    <label for="f-q">Search</label>
    <input class="input" type="search" id="f-q" name="q" value="<?= e($filters['q']) ?>" placeholder="Recipient, subject or template">
  </div>
  <div class="field">
    <label for="f-status">Status</label>
    <select class="select" id="f-status" name="status" data-autosubmit>
      <option value="">All statuses</option>
      <?php foreach ($statuses as $key => $label): ?>
        <option value="<?= e($key) ?>" <?= $filters['status'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <button class="btn btn-light" type="submit"><?= icon('filter', 'icon-sm') ?> Filter</button>
</form>

<div class="card card-flush">
  <?php if (!$rows): ?>
    <p class="muted" style="padding:var(--s-6)">No messages match.</p>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead><tr><th>When</th><th>To</th><th>Subject</th><th>Template</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td class="small"><?= e(local_date($r['created_at'])) ?></td>
        <td class="small"><?= e($r['to_email']) ?></td>
        <td><?= e(str_limit($r['subject'], 70)) ?></td>
        <td class="small"><?= $r['template_key'] ? '<code>' . e($r['template_key']) . '</code>' : '<span class="muted">—</span>' ?></td>
        <td>
          <span class="status status-<?= e($cls[$r['status']] ?? 'draft') ?>" title="<?= e($statuses[$r['status']] ?? $r['status']) ?>"><?= e($short[$r['status']] ?? $r['status']) ?></span>
          <?php if ($r['status'] === 'failed' && $r['error']): ?><div class="muted small"><?= e(str_limit($r['error'], 60)) ?></div><?php endif; ?>
        </td>
        <td class="num"><a class="btn btn-ghost btn-sm" href="<?= e(admin_url('emails/outbox/' . (int) $r['id'])) ?>">View</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>
<?= $paginator->links() ?>
