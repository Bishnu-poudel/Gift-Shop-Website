<?php /** Vars: $templates, $outboxCounts, $mailMode */ ?>
<div class="admin-page-head">
  <div>
    <h1>Email templates</h1>
    <p>Transactional emails sent by the store. Use <code>{{variable}}</code> placeholders; values are HTML-escaped automatically.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light" href="<?= e(admin_url('emails/outbox')) ?>"><?= icon('mail', 'icon-sm') ?> Outbox</a>
  </div>
</div>

<?php if ($mailMode !== 'smtp'): ?>
  <div class="alert alert-warning"><?= icon('alert') ?><div><strong>Development mail mode.</strong> Emails are written to the outbox with status "logged" and are <strong>not</strong> sent to recipients. Set <code>MAIL_MODE=smtp</code> to deliver real email.</div></div>
<?php endif; ?>

<div class="kpis">
  <div class="kpi"><p class="label">Templates</p><div class="value"><?= count($templates) ?></div></div>
  <div class="kpi"><p class="label">Logged (not sent)</p><div class="value"><?= (int) ($outboxCounts['logged'] ?? 0) ?></div></div>
  <div class="kpi"><p class="label">Sent</p><div class="value"><?= (int) ($outboxCounts['sent'] ?? 0) ?></div></div>
  <div class="kpi"><p class="label">Failed</p><div class="value"><?= (int) ($outboxCounts['failed'] ?? 0) ?></div></div>
</div>

<div class="card card-flush">
  <?php if (!$templates): ?>
    <div style="padding:var(--s-8)"><?= partial('components/empty-state', ['icon' => 'mail', 'title' => 'No templates', 'text' => 'Email templates are created by the installer / seeder.']) ?></div>
  <?php else: ?>
  <div style="overflow-x:auto">
  <table class="data-table">
    <thead><tr><th>Template</th><th>Subject</th><th>Last updated</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($templates as $t): ?>
      <tr>
        <td><a class="row-link" href="<?= e(admin_url('emails/' . (int) $t['id'] . '/edit')) ?>"><?= e($t['name']) ?></a><div class="muted small"><code><?= e($t['template_key']) ?></code></div></td>
        <td class="small"><?= e(str_limit($t['subject'], 80)) ?></td>
        <td class="small"><?= e(local_date($t['updated_at'])) ?></td>
        <td class="num"><a class="btn btn-ghost btn-sm" href="<?= e(admin_url('emails/' . (int) $t['id'] . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>
</div>
