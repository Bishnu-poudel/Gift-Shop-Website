<?php
/**
 * Vars: $range, $filters, $categories, $group, $sales, $today, $pending, $lowStock, $topProducts, $topCategories,
 * $series, $growth, $customers, $coupons, $paymentStats, $refunds, $conversion, $canSeeCost, $canAudit, $activity, $recentOrders
 */
use App\Repositories\Admin\OrderAdminRepository;

$fmtLabel = static fn (string $p) => $group === 'month' ? date('M Y', strtotime($p . '-01')) : date('M j', strtotime($p));
$revenueChart = [
    'type' => 'line',
    'labels' => array_map($fmtLabel, array_keys($series)),
    'datasets' => [['label' => $filters['category_id'] ? 'Category item revenue (NPR)' : 'Net paid revenue (NPR)', 'data' => array_map(static fn ($s) => round($s['revenue'], 2), array_values($series))]],
];
$ordersChart = [
    'type' => 'bar',
    'labels' => array_map($fmtLabel, array_keys($series)),
    'datasets' => [['label' => 'Paid orders', 'data' => array_map(static fn ($s) => $s['orders'], array_values($series)), 'color' => '#5f705a']],
];
$growthChart = [
    'type' => 'bar',
    'labels' => array_map(static fn ($d) => date('M j', strtotime($d)), array_keys($growth)),
    'datasets' => [['label' => 'New customers', 'data' => array_values($growth), 'color' => '#35577a']],
];
$pendingTotal = array_sum($pending);
$newCustomers = array_sum($growth);
$totalRevenue = array_sum(array_column($series, 'revenue'));
$visits = (int) $conversion['visits'];
$ratio = static function (int $num, int $den): string {
    return $den > 0 ? number_format($num / $den * 100, 1) . '%' : '—';
};
$rangeLabel = date('M j, Y', strtotime($range['from'])) . ' – ' . date('M j, Y', strtotime($range['to']));
?>
<div class="admin-page-head">
  <div>
    <h1>Dashboard</h1>
    <p>Showing <?= e($rangeLabel) ?> (<?= (int) $range['days'] ?> days, Nepal time). All figures are calculated from recorded orders, payments and counters.</p>
  </div>
  <div class="admin-actions">
    <?php if (can('orders.create')): ?><a class="btn btn-light btn-sm" href="<?= e(admin_url('orders/create')) ?>"><?= icon('plus', 'icon-sm') ?> Manual order</a><?php endif; ?>
    <?php if (can('reports.view')): ?><a class="btn btn-primary btn-sm" href="<?= e(admin_url('reports') . '?' . http_build_query(['from' => $range['from'], 'to' => $range['to']])) ?>"><?= icon('chart', 'icon-sm') ?> Full reports</a><?php endif; ?>
  </div>
</div>

<form class="filter-bar" method="get" action="<?= e(admin_url()) ?>">
  <div class="field"><label for="f-from">From</label><input class="input" type="date" id="f-from" name="from" value="<?= e($range['from']) ?>"></div>
  <div class="field"><label for="f-to">To</label><input class="input" type="date" id="f-to" name="to" value="<?= e($range['to']) ?>"></div>
  <div class="field"><label for="f-cat">Category (chart &amp; bestsellers)</label>
    <select class="select" id="f-cat" name="category_id">
      <option value="">All categories</option>
      <?php foreach ($categories as $c): ?>
        <option value="<?= (int) $c['id'] ?>" <?= (int) $filters['category_id'] === (int) $c['id'] ? 'selected' : '' ?>><?= $c['parent_id'] ? '— ' : '' ?><?= e($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="field"><label for="f-pm">Payment method (sales)</label>
    <select class="select" id="f-pm" name="payment_method">
      <option value="">All methods</option>
      <?php foreach (OrderAdminRepository::PAYMENT_METHODS as $k => $label): ?>
        <option value="<?= e($k) ?>" <?= $filters['payment_method'] === $k ? 'selected' : '' ?>><?= e($label) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <button class="btn btn-primary btn-sm" type="submit"><?= icon('filter', 'icon-sm') ?> Apply</button>
  <a class="btn btn-ghost btn-sm" href="<?= e(admin_url()) ?>">Reset</a>
</form>

<div class="kpis">
  <div class="kpi">
    <p class="label">Net paid sales</p>
    <div class="value"><?= e(money($sales['net'])) ?></div>
    <div class="sub"><?= (int) $sales['orders'] ?> paid orders<?= $sales['refunded'] > 0 ? ' · ' . e(money($sales['refunded'])) . ' refunded' : '' ?></div>
  </div>
  <div class="kpi">
    <p class="label">Orders today</p>
    <div class="value"><?= (int) $today['total'] ?></div>
    <div class="sub"><?= (int) $today['placed'] ?> confirmed or beyond</div>
  </div>
  <div class="kpi">
    <p class="label">Average order value</p>
    <div class="value"><?= $sales['aov'] !== null ? e(money($sales['aov'])) : '—' ?></div>
    <div class="sub"><?= $sales['aov'] !== null ? 'Net paid sales ÷ paid orders' : 'No paid orders in range' ?></div>
  </div>
  <div class="kpi">
    <p class="label">Awaiting fulfilment</p>
    <div class="value"><?= (int) $pendingTotal ?></div>
    <div class="sub"><?= (int) $pending['confirmed'] ?> confirmed · <?= (int) $pending['processing'] ?> processing · <?= (int) $pending['packed'] ?> packed</div>
  </div>
</div>

<div class="kpis">
  <div class="kpi">
    <p class="label">Customers</p>
    <div class="value"><?= (int) $customers['total'] ?></div>
    <div class="sub"><?= (int) $newCustomers ?> new in range</div>
  </div>
  <div class="kpi">
    <p class="label">Orders ÷ visits</p>
    <?php if ($visits === 0): ?>
      <div class="value">—</div><div class="sub">Not enough data</div>
    <?php else: ?>
      <div class="value"><?= e($ratio((int) $conversion['orders'], $visits)) ?></div>
      <div class="sub"><?= number_format((int) $conversion['orders']) ?> orders ÷ <?= number_format($visits) ?> visits</div>
    <?php endif; ?>
  </div>
  <div class="kpi">
    <p class="label">Open refunds</p>
    <div class="value"><?= (int) $refunds['open_n'] ?></div>
    <div class="sub"><?= e(money($refunds['open_amount'])) ?> requested or approved</div>
  </div>
  <div class="kpi">
    <p class="label">Low-stock items</p>
    <div class="value"><?= count($lowStock) ?><?= count($lowStock) >= 8 ? '+' : '' ?></div>
    <div class="sub">At or below threshold</div>
  </div>
</div>

<div class="card">
  <div class="card-head">
    <h2>Revenue over time</h2>
    <span class="muted small"><?= e(money($totalRevenue)) ?> in range · grouped by <?= e($group) ?><?= $filters['category_id'] ? ' · item line totals for the selected category' : '' ?></span>
  </div>
  <?php if ($totalRevenue <= 0): ?>
    <p class="muted">No paid revenue recorded for this range and filter.</p>
  <?php endif; ?>
  <div class="chart-box"><canvas data-chart='<?= json_attr($revenueChart) ?>' aria-label="Revenue over time chart" role="img"></canvas></div>
  <div class="chart-box mt-4" style="height:160px"><canvas data-chart='<?= json_attr($ordersChart) ?>' aria-label="Paid orders per period chart" role="img"></canvas></div>
</div>

<div class="admin-grid admin-grid-2">
  <div class="card card-flush">
    <div class="card-head"><h2>Bestselling products</h2><span class="muted small">Units in confirmed orders</span></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Product</th><th class="num">Units</th><th class="num">Revenue</th><?php if ($canSeeCost): ?><th class="num">Margin</th><?php endif; ?></tr></thead>
        <tbody>
        <?php if (!$topProducts): ?><tr><td colspan="4" class="muted">No sales in this range.</td></tr><?php endif; ?>
        <?php foreach ($topProducts as $p): ?>
          <tr>
            <td><?= e($p['name']) ?><?php if ($p['sku']): ?><div class="muted small"><?= e($p['sku']) ?></div><?php endif; ?></td>
            <td class="num"><?= (int) $p['units'] ?></td>
            <td class="num"><?= e(money($p['revenue'])) ?></td>
            <?php if ($canSeeCost): ?>
              <td class="num"><?= (int) $p['missing_cost'] > 0 ? '<span class="muted" title="Some items have no cost price">n/a</span>' : e(money((float) $p['revenue'] - (float) $p['cost'])) ?></td>
            <?php endif; ?>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card card-flush">
    <div class="card-head"><h2>Best categories</h2><span class="muted small">Item revenue in confirmed orders</span></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Category</th><th class="num">Orders</th><th class="num">Units</th><th class="num">Revenue</th></tr></thead>
        <tbody>
        <?php if (!$topCategories): ?><tr><td colspan="4" class="muted">No sales in this range.</td></tr><?php endif; ?>
        <?php foreach ($topCategories as $c): ?>
          <tr><td><?= e($c['name']) ?></td><td class="num"><?= (int) $c['orders'] ?></td><td class="num"><?= (int) $c['units'] ?></td><td class="num"><?= e(money($c['revenue'])) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="admin-grid admin-grid-2">
  <div class="card">
    <div class="card-head"><h2>Customer growth</h2><span class="muted small"><?= (int) $newCustomers ?> new accounts</span></div>
    <div class="chart-box" style="height:220px"><canvas data-chart='<?= json_attr($growthChart) ?>' aria-label="New customers per day chart" role="img"></canvas></div>
  </div>

  <div class="card">
    <div class="card-head"><h2>Measured storefront activity</h2><span class="muted small">From daily counters</span></div>
    <?php if ($visits === 0): ?>
      <p class="muted">Not enough data — no visits were recorded in this range.</p>
    <?php endif; ?>
    <ul class="list-plain">
      <li><span>Visits (one per session per day)</span><strong><?= number_format($visits) ?></strong></li>
      <li><span>Searches</span><strong><?= number_format((int) $conversion['searches']) ?></strong></li>
      <li><span>Add-to-cart actions</span><strong><?= number_format((int) $conversion['add_to_cart']) ?></strong></li>
      <li><span>Orders placed</span><strong><?= number_format((int) $conversion['orders']) ?></strong></li>
      <li><span>Add-to-cart ÷ visits</span><strong><?= $visits > 0 ? e($ratio((int) $conversion['add_to_cart'], $visits)) . ' <span class="muted small">(' . number_format((int) $conversion['add_to_cart']) . ' ÷ ' . number_format($visits) . ')</span>' : 'Not enough data' ?></strong></li>
      <li><span>Orders ÷ visits</span><strong><?= $visits > 0 ? e($ratio((int) $conversion['orders'], $visits)) . ' <span class="muted small">(' . number_format((int) $conversion['orders']) . ' ÷ ' . number_format($visits) . ')</span>' : 'Not enough data' ?></strong></li>
    </ul>
  </div>
</div>

<div class="admin-grid admin-grid-2">
  <div class="card card-flush">
    <div class="card-head"><h2>Payment attempts by gateway</h2><?php if (can('payments.view')): ?><a class="small" href="<?= e(admin_url('payments')) ?>">All payments</a><?php endif; ?></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Gateway</th><th class="num">Attempts</th><th class="num">Succeeded</th><th class="num">Failed</th><th class="num">Abandoned</th><th class="num">Success rate</th></tr></thead>
        <tbody>
        <?php if (!$paymentStats): ?><tr><td colspan="6" class="muted">No payment attempts in this range.</td></tr><?php endif; ?>
        <?php foreach ($paymentStats as $g): ?>
          <tr>
            <td><?= e(strtoupper($g['gateway'])) ?></td>
            <td class="num"><?= (int) $g['attempts'] ?></td>
            <td class="num"><?= (int) $g['succeeded'] ?></td>
            <td class="num"><?= (int) $g['failed'] ?></td>
            <td class="num"><?= (int) $g['abandoned'] ?><?= (int) $g['open_attempts'] ? ' <span class="muted small">+' . (int) $g['open_attempts'] . ' open</span>' : '' ?></td>
            <td class="num"><?= e($ratio((int) $g['succeeded'], (int) $g['attempts'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h2>Refunds</h2><?php if (can('refunds.manage') || can('payments.view')): ?><a class="small" href="<?= e(admin_url('refunds')) ?>">Manage refunds</a><?php endif; ?></div>
    <ul class="list-plain">
      <?php foreach ($refunds['by_status'] as $status => $r): ?>
        <li><span class="status status-<?= e($status) ?>"><?= e(status_label($status)) ?></span><span><?= (int) $r['n'] ?> · <strong><?= e(money($r['amount'])) ?></strong></span></li>
      <?php endforeach; ?>
    </ul>
    <p class="muted small mt-2">Refunds created in the selected range.</p>
  </div>
</div>

<div class="admin-grid admin-grid-2">
  <div class="card card-flush">
    <div class="card-head"><h2>Coupon performance</h2><?php if (can('coupons.manage')): ?><a class="small" href="<?= e(admin_url('coupons')) ?>">Coupons</a><?php endif; ?></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Code</th><th class="num">Uses</th><th class="num">Discount given</th><th class="num">Order revenue</th></tr></thead>
        <tbody>
        <?php if (!$coupons): ?><tr><td colspan="4" class="muted">No coupon redemptions in this range.</td></tr><?php endif; ?>
        <?php foreach ($coupons as $c): ?>
          <tr><td><strong><?= e($c['code']) ?></strong></td><td class="num"><?= (int) $c['uses'] ?></td><td class="num"><?= e(money($c['discount'])) ?></td><td class="num"><?= e(money($c['revenue'])) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card card-flush">
    <div class="card-head"><h2>Low stock</h2><?php if (can('inventory.manage')): ?><a class="small" href="<?= e(admin_url('inventory')) ?>">Inventory</a><?php endif; ?></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Item</th><th class="num">On hand</th><th class="num">Threshold</th></tr></thead>
        <tbody>
        <?php if (!$lowStock): ?><tr><td colspan="3" class="muted">All active products are above their thresholds.</td></tr><?php endif; ?>
        <?php foreach ($lowStock as $s): ?>
          <tr>
            <td><?= e($s['name']) ?><?= $s['variant_name'] ? ' — ' . e($s['variant_name']) : '' ?><div class="muted small"><?= e($s['sku']) ?></div></td>
            <td class="num"><span class="status <?= (int) $s['quantity'] <= 0 ? 'status-failed' : 'status-pending' ?>"><?= (int) $s['quantity'] ?></span></td>
            <td class="num"><?= (int) $s['low_stock_threshold'] ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php if ($canAudit): ?>
<div class="card">
  <div class="card-head"><h2>Recent activity</h2><a class="small" href="<?= e(admin_url('audit')) ?>">Audit log</a></div>
  <?php if (!$activity): ?><p class="muted">No activity recorded yet.</p><?php endif; ?>
  <ul class="timeline-admin">
    <?php foreach ($activity as $a): ?>
      <li>
        <strong><?= e($a['user_name'] ?? 'System') ?></strong> · <?= e($a['action']) ?>
        <?php if ($a['entity_type']): ?><span class="muted"><?= e($a['entity_type']) ?><?= $a['entity_id'] ? ' #' . (int) $a['entity_id'] : '' ?></span><?php endif; ?>
        <div class="when"><?= e(local_date($a['created_at'])) ?></div>
      </li>
    <?php endforeach; ?>
  </ul>
</div>
<?php elseif ($recentOrders): ?>
<div class="card card-flush">
  <div class="card-head"><h2>Recent orders</h2><a class="small" href="<?= e(admin_url('orders')) ?>">All orders</a></div>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Order</th><th>Customer</th><th>Status</th><th>Payment</th><th class="num">Total</th><th>Placed</th></tr></thead>
      <tbody>
      <?php foreach ($recentOrders as $o): ?>
        <tr>
          <td><a class="row-link" href="<?= e(admin_url('orders/' . (int) $o['id'])) ?>"><?= e($o['order_number']) ?></a></td>
          <td><?= e($o['customer_name']) ?></td>
          <td><span class="status status-<?= e($o['status']) ?>"><?= e(status_label($o['status'])) ?></span></td>
          <td><span class="status status-<?= e($o['payment_status']) ?>"><?= e(status_label($o['payment_status'])) ?></span> <span class="muted small"><?= e(strtoupper($o['payment_method'])) ?></span></td>
          <td class="num"><?= e(money($o['grand_total'])) ?></td>
          <td><?= e(local_date($o['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>
