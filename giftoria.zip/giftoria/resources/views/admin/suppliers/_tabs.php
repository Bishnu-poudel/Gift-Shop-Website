<?php /** Vars: $active ('suppliers'|'orders') */ ?>
<nav class="tabs" aria-label="Purchasing">
  <a href="<?= e(admin_url('suppliers')) ?>" class="<?= $active === 'suppliers' ? 'is-active' : '' ?>">Suppliers</a>
  <a href="<?= e(admin_url('suppliers/purchase-orders')) ?>" class="<?= $active === 'orders' ? 'is-active' : '' ?>">Purchase orders</a>
</nav>
