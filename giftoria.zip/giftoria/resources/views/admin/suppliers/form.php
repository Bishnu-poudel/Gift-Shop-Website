<?php
/** Vars: $supplier (null on create), optional $poCount */
$isEdit = $supplier !== null;
$hasOld = (bool) errors() && old('name', null) !== null;
$val = static function (string $k, string $d = '') use ($supplier, $hasOld): string {
    if ($hasOld) {
        $o = old($k, null);
        return is_scalar($o) ? (string) $o : '';
    }
    $v = $supplier[$k] ?? $d;
    return $v === null ? '' : (string) $v;
};
$active = $hasOld ? old('is_active', '') !== '' : (bool) ($supplier['is_active'] ?? true);
$err = static fn (string $k): string => errors($k) ? 'has-error' : '';
?>
<div class="admin-page-head">
  <div>
    <p class="small"><a href="<?= e(admin_url('suppliers')) ?>"><?= icon('chevron-left', 'icon-sm') ?> Suppliers</a></p>
    <h1><?= e($isEdit ? $supplier['name'] : 'New supplier') ?></h1>
    <?php if ($isEdit): ?><p><?= (int) ($poCount ?? 0) ?> purchase order(s) · added <?= e(local_date($supplier['created_at'], 'M j, Y')) ?></p><?php endif; ?>
  </div>
  <?php if ($isEdit && (int) $supplier['is_active']): ?>
  <div class="admin-actions">
    <a class="btn btn-light" href="<?= e(admin_url('suppliers/purchase-orders/create?supplier=' . (int) $supplier['id'])) ?>"><?= icon('clipboard', 'icon-sm') ?> New purchase order</a>
  </div>
  <?php endif; ?>
</div>

<form method="post" action="<?= e($isEdit ? admin_url('suppliers/' . (int) $supplier['id']) : admin_url('suppliers')) ?>" data-loading novalidate>
  <?= csrf_field() ?>
  <div class="admin-grid admin-grid-3-1">
    <section class="card">
      <div class="card-head"><h2>Supplier details</h2></div>
      <div class="form-grid">
        <div class="field span-2">
          <label for="s-name">Business name *</label>
          <input class="input <?= $err('name') ?>" id="s-name" name="name" value="<?= e($val('name')) ?>" maxlength="120" required>
          <?= field_error('name') ?>
        </div>
        <div class="field">
          <label for="s-contact">Contact person</label>
          <input class="input <?= $err('contact_name') ?>" id="s-contact" name="contact_name" value="<?= e($val('contact_name')) ?>" maxlength="120">
          <?= field_error('contact_name') ?>
        </div>
        <div class="field">
          <label for="s-phone">Phone</label>
          <input class="input <?= $err('phone') ?>" id="s-phone" name="phone" type="tel" value="<?= e($val('phone')) ?>" maxlength="30">
          <?= field_error('phone') ?>
        </div>
        <div class="field">
          <label for="s-email">Email</label>
          <input class="input <?= $err('email') ?>" id="s-email" name="email" type="email" value="<?= e($val('email')) ?>" maxlength="190">
          <?= field_error('email') ?>
        </div>
        <div class="field">
          <label for="s-address">Address</label>
          <input class="input <?= $err('address') ?>" id="s-address" name="address" value="<?= e($val('address')) ?>" maxlength="255">
          <?= field_error('address') ?>
        </div>
        <div class="field span-2">
          <label for="s-notes">Notes</label>
          <textarea class="textarea <?= $err('notes') ?>" id="s-notes" name="notes" rows="4" placeholder="Payment terms, lead times, minimum order…"><?= e($val('notes')) ?></textarea>
          <?= field_error('notes') ?>
        </div>
      </div>
    </section>
    <div>
      <section class="card">
        <div class="card-head"><h2>Status</h2></div>
        <label class="check"><input type="checkbox" name="is_active" value="1" <?= $active ? 'checked' : '' ?>> Active supplier</label>
        <p class="hint muted small mt-2">Inactive suppliers cannot receive new purchase orders.</p>
        <div class="form-actions">
          <a class="btn btn-ghost" href="<?= e(admin_url('suppliers')) ?>">Cancel</a>
          <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save changes' : 'Add supplier' ?></button>
        </div>
      </section>
      <?php if ($isEdit): ?>
      <section class="card danger-zone">
        <div class="card-head"><h2><?= (int) ($poCount ?? 0) > 0 ? 'Deactivate' : 'Delete' ?></h2></div>
        <p class="muted small"><?= (int) ($poCount ?? 0) > 0 ? 'Suppliers with purchase orders are deactivated rather than deleted, to keep purchasing history intact.' : 'This supplier has no purchase orders and can be deleted.' ?></p>
        <button class="btn btn-danger btn-sm" type="submit" form="delete-supplier"><?= (int) ($poCount ?? 0) > 0 ? 'Deactivate supplier' : 'Delete supplier' ?></button>
      </section>
      <?php endif; ?>
    </div>
  </div>
</form>
<?php if ($isEdit): ?>
<form id="delete-supplier" method="post" action="<?= e(admin_url('suppliers/' . (int) $supplier['id'] . '/delete')) ?>" data-confirm="<?= (int) ($poCount ?? 0) > 0 ? 'Deactivate this supplier?' : 'Delete this supplier permanently?' ?>" hidden><?= csrf_field() ?></form>
<?php endif; ?>
