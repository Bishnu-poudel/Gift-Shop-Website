<?php /** Vars: $suppliers, $q */ ?>
<div class="admin-page-head">
  <div>
    <h1>Suppliers &amp; purchasing</h1>
    <p>Who you buy from, and the purchase orders that bring stock in.</p>
  </div>
  <div class="admin-actions">
    <a class="btn btn-light" href="<?= e(admin_url('suppliers/purchase-orders/create')) ?>"><?= icon('clipboard', 'icon-sm') ?> New purchase order</a>
    <a class="btn btn-accent" href="<?= e(admin_url('suppliers/create')) ?>"><?= icon('plus', 'icon-sm') ?> New supplier</a>
  </div>
</div>

<?= partial('admin/suppliers/_tabs', ['active' => 'suppliers']) ?>

<form class="filter-bar" method="get" action="<?= e(admin_url('suppliers')) ?>" role="search">
  <div class="field">
    <label for="s-q">Search</label>
    <input class="input" id="s-q" type="search" name="q" value="<?= e($q) ?>" placeholder="Supplier or contact">
  </div>
  <button class="btn btn-primary btn-sm" type="submit"><?= icon('search', 'icon-sm') ?> Search</button>
  <?php if ($q !== ''): ?><a class="btn btn-ghost btn-sm" href="<?= e(admin_url('suppliers')) ?>">Clear</a><?php endif; ?>
</form>

<?php if (!$suppliers): ?>
  <?= partial('components/empty-state', ['icon' => 'truck', 'title' => $q !== '' ? 'No matching suppliers' : 'No suppliers yet', 'text' => 'Add the artisans, wholesalers and brands you buy stock from.', 'actionUrl' => admin_url('suppliers/create'), 'actionLabel' => 'New supplier']) ?>
<?php else: ?>
<div class="card card-flush">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th scope="col">Supplier</th>
          <th scope="col">Contact</th>
          <th scope="col">Phone</th>
          <th scope="col" class="num">Open POs</th>
          <th scope="col" class="num">All POs</th>
          <th scope="col">Status</th>
          <th scope="col"><span class="sr-only">Actions</span></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($suppliers as $s): $sid = (int) $s['id']; ?>
        <tr>
          <td>
            <a class="row-link" href="<?= e(admin_url('suppliers/' . $sid . '/edit')) ?>"><?= e($s['name']) ?></a>
            <?php if ($s['address']): ?><div class="muted small"><?= e(str_limit($s['address'], 60)) ?></div><?php endif; ?>
          </td>
          <td>
            <?= e($s['contact_name'] ?: '—') ?>
            <?php if ($s['email']): ?><div class="small"><a href="mailto:<?= e($s['email']) ?>"><?= e($s['email']) ?></a></div><?php endif; ?>
          </td>
          <td><?= $s['phone'] ? '<a href="tel:' . e(preg_replace('/[^0-9+]/', '', (string) $s['phone'])) . '">' . e($s['phone']) . '</a>' : '—' ?></td>
          <td class="num"><?= (int) $s['open_po_count'] ?></td>
          <td class="num">
            <?php if ((int) $s['po_count'] > 0): ?><a href="<?= e(admin_url('suppliers/purchase-orders?supplier=' . $sid)) ?>"><?= (int) $s['po_count'] ?></a><?php else: ?>0<?php endif; ?>
          </td>
          <td><span class="status status-<?= (int) $s['is_active'] ? 'active' : 'inactive' ?>"><?= (int) $s['is_active'] ? 'Active' : 'Inactive' ?></span></td>
          <td>
            <div class="row" style="gap:4px;flex-wrap:nowrap;justify-content:flex-end">
              <?php if ((int) $s['is_active']): ?>
                <a class="btn btn-ghost btn-sm" href="<?= e(admin_url('suppliers/purchase-orders/create?supplier=' . $sid)) ?>" title="New purchase order"><?= icon('plus', 'icon-sm') ?> PO</a>
              <?php endif; ?>
              <a class="btn btn-light btn-sm" href="<?= e(admin_url('suppliers/' . $sid . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
              <form method="post" action="<?= e(admin_url('suppliers/' . $sid . '/delete')) ?>" class="inline-form" data-confirm="<?= (int) $s['po_count'] > 0 ? 'This supplier has purchase orders, so it will be deactivated instead of deleted. Continue?' : 'Delete this supplier?' ?>">
                <?= csrf_field() ?>
                <button class="btn btn-ghost btn-sm" type="submit" title="Delete"><?= icon('trash', 'icon-sm') ?><span class="sr-only">Delete</span></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>
