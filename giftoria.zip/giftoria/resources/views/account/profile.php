<?php
/** @var array $user @var array $profile @var int $recipientCount */
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <h1>Profile &amp; security</h1>
      <p class="muted">Signed in as <?= e($user['email']) ?></p>
    </div>

    <section class="panel" aria-labelledby="profile-heading">
      <div class="panel-head"><h2 id="profile-heading">Your details</h2></div>
      <form method="post" action="<?= e(url('/account/profile')) ?>" data-loading novalidate>
        <?= csrf_field() ?>
        <div class="field">
          <label for="name">Full name</label>
          <input class="input<?= errors('name') ? ' has-error' : '' ?>" id="name" name="name" autocomplete="name" maxlength="120" required value="<?= e(old('name', $user['name'])) ?>">
          <?= field_error('name') ?>
        </div>
        <div class="form-row">
          <div class="field">
            <label for="phone">Mobile number <span class="muted">(optional)</span></label>
            <input class="input<?= errors('phone') ? ' has-error' : '' ?>" id="phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="20" placeholder="98XXXXXXXX" value="<?= e(old('phone', (string) $user['phone'])) ?>">
            <p class="hint">Used only for delivery updates about your orders.</p>
            <?= field_error('phone') ?>
          </div>
          <div class="field">
            <label for="birthday">Birthday <span class="muted">(optional)</span></label>
            <input class="input<?= errors('birthday') ? ' has-error' : '' ?>" id="birthday" name="birthday" type="date" max="<?= e(local_today()) ?>" value="<?= e(old('birthday', (string) ($profile['birthday'] ?? ''))) ?>">
            <?= field_error('birthday') ?>
          </div>
        </div>
        <div class="field">
          <label for="email">Email</label>
          <input class="input" id="email" type="email" value="<?= e($user['email']) ?>" disabled>
          <p class="hint">To change your sign-in email, please <a href="<?= e(url('/account/support/new')) ?>">contact support</a>.</p>
        </div>
        <button class="btn btn-primary" type="submit">Save details</button>
      </form>
    </section>

    <section class="panel" aria-labelledby="password-heading">
      <div class="panel-head"><h2 id="password-heading">Change password</h2></div>
      <form method="post" action="<?= e(url('/account/password')) ?>" data-loading novalidate>
        <?= csrf_field() ?>
        <div class="field">
          <label for="current_password">Current password</label>
          <input class="input<?= errors('current_password') ? ' has-error' : '' ?>" id="current_password" name="current_password" type="password" autocomplete="current-password" required>
          <?= field_error('current_password') ?>
        </div>
        <div class="form-row">
          <div class="field">
            <label for="password">New password</label>
            <input class="input<?= errors('password') ? ' has-error' : '' ?>" id="password" name="password" type="password" autocomplete="new-password" minlength="8" maxlength="128" required>
            <p class="hint">At least 8 characters.</p>
            <?= field_error('password') ?>
          </div>
          <div class="field">
            <label for="password_confirmation">Confirm new password</label>
            <input class="input" id="password_confirmation" name="password_confirmation" type="password" autocomplete="new-password" minlength="8" maxlength="128" required>
          </div>
        </div>
        <p class="small muted">Changing your password signs you out on all other devices.</p>
        <button class="btn btn-primary" type="submit">Update password</button>
      </form>
    </section>

    <section class="panel" aria-labelledby="delete-heading">
      <div class="panel-head"><h2 id="delete-heading">Delete my account</h2></div>
      <?php if (!empty($profile['deletion_requested_at'])): ?>
        <div class="alert alert-info" role="status"><?= icon('info') ?><div>You requested deletion on <?= e(local_date($profile['deletion_requested_at'], 'M j, Y')) ?>. Our team will confirm by email once it is complete.</div></div>
      <?php else: ?>
        <p class="small">We will delete your account and personal data within 30 days. Invoices for past orders are kept in anonymised form where the law requires it. Orders that are still on their way will be completed first.</p>
      <?php endif; ?>
      <form method="post" action="<?= e(url('/account/delete-request')) ?>" data-confirm="Send a request to delete your account?">
        <?= csrf_field() ?>
        <?php if (empty($profile['deletion_requested_at'])): ?>
          <div class="field">
            <label for="reason">Anything you would like to tell us? <span class="muted">(optional)</span></label>
            <textarea class="textarea" id="reason" name="reason" rows="3" maxlength="1000"><?= e(old('reason')) ?></textarea>
            <?= field_error('reason') ?>
          </div>
        <?php endif; ?>
        <?php if ($recipientCount > 0): ?>
          <label class="check" style="margin-bottom:12px">
            <input type="checkbox" name="remove_recipients" value="1">
            <span>Also remove my <?= (int) $recipientCount ?> saved gift recipient<?= $recipientCount === 1 ? '' : 's' ?> (and their reminders) right now</span>
          </label>
        <?php endif; ?>
        <label class="check" style="margin-bottom:16px">
          <input type="checkbox" name="confirm" value="1" required>
          <span>I understand my account, wishlists and Gift Center will be permanently deleted.</span>
        </label>
        <?= field_error('confirm') ?>
        <button class="btn btn-danger" type="submit"><?= empty($profile['deletion_requested_at']) ? 'Request account deletion' : 'Update request' ?></button>
      </form>
    </section>
  </div>
</div>
