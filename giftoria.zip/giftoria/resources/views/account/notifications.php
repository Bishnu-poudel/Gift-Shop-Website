<?php
/** @var array $user @var array $profile @var int $feedbackCount */
$opts = [
    'notify_order_updates' => ['Order updates', 'Shipping and delivery emails for your orders. Order confirmations and payment receipts are always sent.'],
    'notify_gift_reminders' => ['Gift reminders', 'Emails before the birthdays and occasions you save in your Gift Center.'],
    'notify_wishlist' => ['Wishlist alerts', 'Occasional emails when something on your wishlist is back in stock or on sale.'],
    'marketing_opt_in' => ['Newsletter', 'New arrivals, seasonal gift guides and offers. About twice a month.'],
];
$checked = static fn (string $k): bool => (int) ($profile[$k] ?? 0) === 1;
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <h1>Notifications &amp; privacy</h1>
      <p class="muted">Choose what we email you about and how we personalise suggestions.</p>
    </div>

    <form method="post" action="<?= e(url('/account/notifications')) ?>" data-loading>
      <?= csrf_field() ?>
      <section class="panel" aria-labelledby="email-prefs">
        <div class="panel-head"><h2 id="email-prefs">Emails</h2></div>
        <div class="stack">
          <?php foreach ($opts as $key => [$label, $hint]): ?>
            <label class="check" for="<?= e($key) ?>">
              <input type="checkbox" id="<?= e($key) ?>" name="<?= e($key) ?>" value="1" <?= $checked($key) ? 'checked' : '' ?>>
              <span><strong><?= e($label) ?></strong><br><span class="muted"><?= e($hint) ?></span></span>
            </label>
          <?php endforeach; ?>
        </div>
      </section>

      <section class="panel" aria-labelledby="personal-prefs">
        <div class="panel-head"><h2 id="personal-prefs">Personalised recommendations</h2></div>
        <label class="check" for="personalization_enabled">
          <input type="checkbox" id="personalization_enabled" name="personalization_enabled" value="1" <?= $checked('personalization_enabled') ? 'checked' : '' ?>>
          <span><strong>Use my activity to improve suggestions</strong><br>
            <span class="muted">When on, the Gift Finder learns from the gifts you like, hide or save. When off, suggestions use only the answers you give each time.</span></span>
        </label>
      </section>

      <button class="btn btn-primary" type="submit">Save preferences</button>
    </form>

    <section class="panel" aria-labelledby="history-heading" style="margin-top:24px">
      <div class="panel-head"><h2 id="history-heading">Recommendation history</h2></div>
      <p class="small">We have <?= (int) $feedbackCount ?> saved signal<?= $feedbackCount === 1 ? '' : 's' ?> (likes, hides and saves) linked to your account. Clearing them resets your Gift Finder history; your wishlists are not affected.</p>
      <form method="post" action="<?= e(url('/account/notifications/clear-history')) ?>" data-confirm="Clear your recommendation history? This cannot be undone.">
        <?= csrf_field() ?>
        <button class="btn btn-outline" type="submit" <?= $feedbackCount === 0 ? 'disabled' : '' ?>><?= icon('trash', 'icon-sm') ?> Clear my recommendation history</button>
      </form>
    </section>
  </div>
</div>
