<?php
/** @var array $address @var array $provinces */
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <a class="link-arrow small" href="<?= e(url('/account/addresses')) ?>"><?= icon('chevron-left') ?> All addresses</a>
      <h1>Edit address</h1>
    </div>
    <section class="panel">
      <form method="post" action="<?= e(url('/account/addresses/' . (int) $address['id'])) ?>" data-loading novalidate>
        <?= csrf_field() ?>
        <?= partial('account/addresses/_form', ['provinces' => $provinces, 'address' => $address, 'prefix' => 'edit']) ?>
        <div class="row">
          <button class="btn btn-primary" type="submit">Save changes</button>
          <a class="btn btn-ghost" href="<?= e(url('/account/addresses')) ?>">Cancel</a>
        </div>
      </form>
    </section>
  </div>
</div>
