<?php
/** @var array $addresses @var array $provinces @var int $max */
$canAdd = count($addresses) < $max;
$openForm = $canAdd && (errors() || !$addresses);
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <h1>My addresses</h1>
      <p class="muted">Save delivery addresses for yourself and the people you send gifts to (up to <?= (int) $max ?>).</p>
    </div>

    <?php if ($addresses): ?>
      <div class="grid grid-2" style="gap:16px;margin-bottom:24px">
        <?php foreach ($addresses as $a): ?>
          <article class="address-card<?= (int) $a['is_default'] ? ' is-default' : '' ?>">
            <div class="row-between" style="margin-bottom:8px">
              <strong><?= e($a['label'] ?: 'Address') ?></strong>
              <?php if ((int) $a['is_default']): ?><span class="badge badge-success">Default</span><?php endif; ?>
            </div>
            <p class="mb-0">
              <?= e($a['full_name']) ?><br>
              <?= e($a['phone']) ?><br>
              <?php if ($a['street']): ?><?= e($a['street']) ?><br><?php endif; ?>
              <?= e($a['municipality']) ?><?= $a['ward'] ? '-' . e($a['ward']) : '' ?>, <?= e($a['district']) ?><br>
              <?= e($a['province']) ?> Province
              <?php if ($a['landmark']): ?><br><span class="muted">Near <?= e($a['landmark']) ?></span><?php endif; ?>
            </p>
            <div class="row" style="gap:8px;margin-top:16px">
              <a class="btn btn-outline btn-sm" href="<?= e(url('/account/addresses/' . (int) $a['id'] . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
              <?php if (!(int) $a['is_default']): ?>
                <form method="post" action="<?= e(url('/account/addresses/' . (int) $a['id'] . '/default')) ?>">
                  <?= csrf_field() ?><button class="btn btn-ghost btn-sm" type="submit">Set as default</button>
                </form>
              <?php endif; ?>
              <form method="post" action="<?= e(url('/account/addresses/' . (int) $a['id'] . '/delete')) ?>" data-confirm="Remove this address?">
                <?= csrf_field() ?><button class="btn btn-ghost btn-sm" type="submit" aria-label="Remove address <?= e($a['label'] ?: $a['full_name']) ?>"><?= icon('trash', 'icon-sm') ?> Remove</button>
              </form>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <?= partial('components/empty-state', ['icon' => 'map-pin', 'title' => 'No saved addresses', 'text' => 'Add an address to check out faster next time.']) ?>
      <div style="height:24px"></div>
    <?php endif; ?>

    <?php if ($canAdd): ?>
      <section class="panel" id="add-address" aria-labelledby="add-address-heading">
        <details <?= $openForm ? 'open' : '' ?>>
          <summary class="panel-head" style="cursor:pointer;margin-bottom:0"><h2 id="add-address-heading"><?= icon('plus') ?> Add a new address</h2></summary>
          <form method="post" action="<?= e(url('/account/addresses')) ?>" style="margin-top:24px" data-loading novalidate>
            <?= csrf_field() ?>
            <?= partial('account/addresses/_form', ['provinces' => $provinces, 'prefix' => 'new']) ?>
            <button class="btn btn-primary" type="submit">Save address</button>
          </form>
        </details>
      </section>
    <?php else: ?>
      <div class="alert alert-info" role="status"><?= icon('info') ?><div>You have saved the maximum of <?= (int) $max ?> addresses. Remove one to add another.</div></div>
    <?php endif; ?>
  </div>
</div>
