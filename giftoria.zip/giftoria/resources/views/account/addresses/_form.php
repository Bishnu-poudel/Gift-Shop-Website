<?php
/**
 * Address form fields (Nepal format). Vars: $provinces (config nepal.provinces), optional $address (row being edited),
 * $prefix (id prefix for multiple forms on one page)
 */
use App\Controllers\Account\AddressController;

$a = $address ?? [];
$prefix = $prefix ?? 'addr';
$v = static fn (string $k): string => (string) old($k, (string) ($a[$k] ?? ''));
$province = $v('province');
$district = $v('district');
$err = static fn (string $k): string => errors($k) ? ' has-error' : '';
?>
<div class="form-row">
  <div class="field">
    <label for="<?= e($prefix) ?>-full_name">Recipient's full name</label>
    <input class="input<?= $err('full_name') ?>" id="<?= e($prefix) ?>-full_name" name="full_name" autocomplete="name" maxlength="120" required value="<?= e($v('full_name')) ?>">
    <?= field_error('full_name') ?>
  </div>
  <div class="field">
    <label for="<?= e($prefix) ?>-phone">Mobile number</label>
    <input class="input<?= $err('phone') ?>" id="<?= e($prefix) ?>-phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="20" placeholder="98XXXXXXXX" required value="<?= e($v('phone')) ?>">
    <p class="hint">The courier will call this number on delivery.</p>
    <?= field_error('phone') ?>
  </div>
</div>
<div class="form-row">
  <div class="field">
    <label for="<?= e($prefix) ?>-province">Province</label>
    <select class="select<?= $err('province') ?>" id="<?= e($prefix) ?>-province" name="province" required
            data-province-select data-district-target="<?= e($prefix) ?>-district" data-districts="<?= json_attr($provinces) ?>">
      <option value="">Select province</option>
      <?php foreach (array_keys($provinces) as $p): ?>
        <option value="<?= e($p) ?>" <?= $province === $p ? 'selected' : '' ?>><?= e($p) ?></option>
      <?php endforeach; ?>
    </select>
    <?= field_error('province') ?>
  </div>
  <div class="field">
    <label for="<?= e($prefix) ?>-district">District</label>
    <select class="select<?= $err('district') ?>" id="<?= e($prefix) ?>-district" name="district" required data-selected="<?= e($district) ?>">
      <option value="">Select district</option>
      <?php foreach ((array) ($provinces[$province] ?? []) as $d): ?>
        <option value="<?= e($d) ?>" <?= $district === $d ? 'selected' : '' ?>><?= e($d) ?></option>
      <?php endforeach; ?>
    </select>
    <?= field_error('district') ?>
  </div>
</div>
<div class="form-row">
  <div class="field">
    <label for="<?= e($prefix) ?>-municipality">Municipality / rural municipality</label>
    <input class="input<?= $err('municipality') ?>" id="<?= e($prefix) ?>-municipality" name="municipality" maxlength="100" placeholder="e.g. Lalitpur Metropolitan City" required value="<?= e($v('municipality')) ?>">
    <?= field_error('municipality') ?>
  </div>
  <div class="field">
    <label for="<?= e($prefix) ?>-ward">Ward no. <span class="muted">(optional)</span></label>
    <input class="input<?= $err('ward') ?>" id="<?= e($prefix) ?>-ward" name="ward" type="number" inputmode="numeric" min="1" max="35" value="<?= e($v('ward')) ?>">
    <?= field_error('ward') ?>
  </div>
</div>
<div class="form-row">
  <div class="field">
    <label for="<?= e($prefix) ?>-street">Street / tole <span class="muted">(optional)</span></label>
    <input class="input<?= $err('street') ?>" id="<?= e($prefix) ?>-street" name="street" maxlength="190" autocomplete="address-line1" value="<?= e($v('street')) ?>">
    <?= field_error('street') ?>
  </div>
  <div class="field">
    <label for="<?= e($prefix) ?>-landmark">Nearby landmark <span class="muted">(optional)</span></label>
    <input class="input<?= $err('landmark') ?>" id="<?= e($prefix) ?>-landmark" name="landmark" maxlength="190" placeholder="e.g. opposite Patan Hospital gate" value="<?= e($v('landmark')) ?>">
    <?= field_error('landmark') ?>
  </div>
</div>
<div class="form-row">
  <div class="field">
    <label for="<?= e($prefix) ?>-label">Label <span class="muted">(optional)</span></label>
    <input class="input<?= $err('label') ?>" id="<?= e($prefix) ?>-label" name="label" maxlength="50" list="<?= e($prefix) ?>-labels" placeholder="Home, Office…" value="<?= e($v('label')) ?>">
    <datalist id="<?= e($prefix) ?>-labels">
      <?php foreach (AddressController::LABELS as $l): ?><option value="<?= e($l) ?>"></option><?php endforeach; ?>
    </datalist>
    <?= field_error('label') ?>
  </div>
  <div class="field" style="display:flex;align-items:flex-end">
    <?php if (empty($a['is_default'])): ?>
      <label class="check"><input type="checkbox" name="is_default" value="1" <?= old('is_default') ? 'checked' : '' ?>> <span>Make this my default address</span></label>
    <?php else: ?>
      <span class="badge badge-success">Default address</span>
    <?php endif; ?>
  </div>
</div>
