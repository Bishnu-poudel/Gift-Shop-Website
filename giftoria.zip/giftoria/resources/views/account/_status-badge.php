<?php
/** Order status badge. Vars: $status (orders.status) */
use App\Services\OrderStateMachine;

$status = (string) ($status ?? '');
$class = match ($status) {
    'delivered' => 'badge-success',
    'pending_payment', 'return_requested', 'refund_pending' => 'badge-warning',
    'cancelled', 'returned', 'refunded' => 'badge-danger',
    'confirmed', 'processing', 'packed', 'shipped', 'out_for_delivery' => 'badge-info',
    default => '',
};
?><span class="badge <?= e($class) ?>"><?= e(OrderStateMachine::ORDER_LABELS[$status] ?? status_label($status)) ?></span>
