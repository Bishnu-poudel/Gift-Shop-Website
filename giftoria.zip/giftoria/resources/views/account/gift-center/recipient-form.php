<?php
/**
 * Create/edit a gift recipient.
 * @var ?array $recipient @var array $recipientTypes @var array $ageRanges @var array $interests @var array $prefTags @var array $relationships
 */
use App\Services\ReminderService;

$r = $recipient ?? [];
$isEdit = !empty($r['id']);
$action = $isEdit ? url('/account/gift-center/recipients/' . (int) $r['id']) : url('/account/gift-center/recipients');
$v = static fn (string $k): string => (string) old($k, (string) ($r[$k] ?? ''));
$hasOld = errors() !== [] && errors() !== null;
$selInterests = $hasOld ? (array) old('interests', []) : ReminderService::csv($r['interests'] ?? null);
$selPrefs = $hasOld ? (array) old('preferences', []) : ReminderService::csv($r['preferences'] ?? null);
$err = static fn (string $k): string => errors($k) ? ' has-error' : '';
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <a class="link-arrow small" href="<?= e(url('/account/gift-center')) ?>"><?= icon('chevron-left') ?> Gift Center</a>
      <h1><?= $isEdit ? 'Edit ' . e($r['name']) : 'Add a gift recipient' ?></h1>
      <p class="muted">Everything except the name is optional. We use these details only to suggest gifts and remind you of occasions — they are never shared.</p>
    </div>

    <form method="post" action="<?= e($action) ?>" data-loading novalidate>
      <?= csrf_field() ?>
      <section class="panel">
        <div class="form-row">
          <div class="field">
            <label for="name">Name or nickname</label>
            <input class="input<?= $err('name') ?>" id="name" name="name" maxlength="80" required placeholder="e.g. Aama, Priya, Little Aarav" value="<?= e($v('name')) ?>">
            <?= field_error('name') ?>
          </div>
          <div class="field">
            <label for="relationship">Relationship</label>
            <input class="input<?= $err('relationship') ?>" id="relationship" name="relationship" maxlength="60" list="relationship-list" value="<?= e($v('relationship')) ?>">
            <datalist id="relationship-list"><?php foreach ($relationships as $rel): ?><option value="<?= e($rel) ?>"></option><?php endforeach; ?></datalist>
            <?= field_error('relationship') ?>
          </div>
        </div>
        <div class="form-row-3">
          <div class="field">
            <label for="recipient_slug">They are a…</label>
            <select class="select<?= $err('recipient_slug') ?>" id="recipient_slug" name="recipient_slug">
              <option value="">Choose</option>
              <?php foreach ($recipientTypes as $t): ?><option value="<?= e($t['slug']) ?>" <?= $v('recipient_slug') === $t['slug'] ? 'selected' : '' ?>><?= e($t['name']) ?></option><?php endforeach; ?>
            </select>
            <?= field_error('recipient_slug') ?>
          </div>
          <div class="field">
            <label for="age_range_slug">Age range</label>
            <select class="select<?= $err('age_range_slug') ?>" id="age_range_slug" name="age_range_slug">
              <option value="">Choose</option>
              <?php foreach ($ageRanges as $a): ?><option value="<?= e($a['slug']) ?>" <?= $v('age_range_slug') === $a['slug'] ? 'selected' : '' ?>><?= e($a['label']) ?></option><?php endforeach; ?>
            </select>
            <?= field_error('age_range_slug') ?>
          </div>
          <div class="field">
            <label for="birthday">Birthday</label>
            <input class="input<?= $err('birthday') ?>" id="birthday" name="birthday" type="date" max="<?= e(local_today()) ?>" value="<?= e($v('birthday')) ?>">
            <p class="hint">Adds it to your upcoming occasions.</p>
            <?= field_error('birthday') ?>
          </div>
        </div>
      </section>

      <section class="panel">
        <fieldset>
          <legend class="label">Interests <span class="muted">(choose up to 15)</span></legend>
          <div class="chips">
            <?php foreach ($interests as $i => $it): $id = 'int-' . $i; ?>
              <span>
                <input class="chip-input" type="checkbox" id="<?= e($id) ?>" name="interests[]" value="<?= e($it['slug']) ?>" <?= in_array($it['slug'], $selInterests, true) ? 'checked' : '' ?>>
                <label class="chip" for="<?= e($id) ?>"><?= e($it['name']) ?></label>
              </span>
            <?php endforeach; ?>
          </div>
          <?= field_error('interests') ?>
        </fieldset>
        <?php if ($prefTags): ?>
          <fieldset style="margin-top:24px">
            <legend class="label">Gift style preferences</legend>
            <div class="chips">
              <?php foreach ($prefTags as $i => $t): $id = 'pref-' . $i; ?>
                <span>
                  <input class="chip-input" type="checkbox" id="<?= e($id) ?>" name="preferences[]" value="<?= e($t['slug']) ?>" <?= in_array($t['slug'], $selPrefs, true) ? 'checked' : '' ?>>
                  <label class="chip" for="<?= e($id) ?>"><?= e($t['name']) ?></label>
                </span>
              <?php endforeach; ?>
            </div>
            <?= field_error('preferences') ?>
          </fieldset>
        <?php endif; ?>
        <div class="field" style="margin-top:24px">
          <label for="notes">Notes <span class="muted">(only you can see these)</span></label>
          <textarea class="textarea<?= $err('notes') ?>" id="notes" name="notes" rows="3" maxlength="1000" placeholder="Sizes, favourite colours, things they already have…"><?= e($v('notes')) ?></textarea>
          <?= field_error('notes') ?>
        </div>
      </section>

      <div class="row">
        <button class="btn btn-primary" type="submit"><?= $isEdit ? 'Save changes' : 'Save recipient' ?></button>
        <a class="btn btn-ghost" href="<?= e(url('/account/gift-center')) ?>">Cancel</a>
      </div>
    </form>
  </div>
</div>
