<?php
/**
 * @var array $recipients @var array $reminders @var array $upcoming @var bool $remindersEnabled
 * @var array $labels @var array $occasions @var bool $canAddRecipient
 */
use App\Services\ReminderService;

$initials = static function (string $name): string {
    $parts = preg_split('/\s+/', trim($name)) ?: [];
    $s = '';
    foreach (array_slice($parts, 0, 2) as $p) {
        $s .= mb_strtoupper(mb_substr($p, 0, 1));
    }
    return $s ?: '?';
};
$when = static fn (int $d): string => $d === 0 ? 'Today' : ($d === 1 ? 'Tomorrow' : 'In ' . $d . ' days');
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <div class="row-between">
        <h1 style="margin-bottom:0">Gift Center</h1>
        <?php if ($canAddRecipient): ?><a class="btn btn-primary btn-sm" href="<?= e(url('/account/gift-center/recipients')) ?>"><?= icon('plus', 'icon-sm') ?> Add recipient</a><?php endif; ?>
      </div>
      <p class="muted">Save the people you buy for, get ideas that fit them, and never miss a birthday again.</p>
    </div>

    <?php if (!$remindersEnabled): ?>
      <div class="alert alert-info" role="status"><?= icon('bell') ?>
        <div>Reminder emails are turned off. <a href="<?= e(url('/account/notifications')) ?>">Turn on gift reminders</a> to get an email before each occasion.</div>
      </div>
    <?php endif; ?>

    <section class="panel" aria-labelledby="upcoming-heading">
      <div class="panel-head"><h2 id="upcoming-heading">Upcoming occasions <span class="small muted">(next 60 days)</span></h2></div>
      <?php if (!$upcoming): ?>
        <p class="muted mb-0">Nothing in the next 60 days. Add birthdays to your recipients or create a reminder below.</p>
      <?php else: ?>
        <ul class="timeline">
          <?php foreach ($upcoming as $u): ?>
            <li>
              <div class="row-between">
                <div>
                  <strong><?= e($u['title']) ?></strong>
                  <?php if ($u['type'] === 'reminder' && $u['recipient']): ?><span class="small muted"> · for <?= e($u['recipient']['name']) ?></span><?php endif; ?><br>
                  <span class="small muted"><?= e(date('D, M j', strtotime($u['date']))) ?> · <?= e($when((int) $u['days_until'])) ?></span>
                </div>
                <a class="btn btn-light btn-sm" href="<?= e($u['finder_url']) ?>"><?= icon('sparkles', 'icon-sm') ?> Find gifts</a>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </section>

    <section aria-labelledby="recipients-heading" style="margin-bottom:24px">
      <h2 id="recipients-heading" style="font-size:1.4rem">Your people</h2>
      <?php if (!$recipients): ?>
        <?= partial('components/empty-state', [
            'icon' => 'users', 'title' => 'No recipients yet',
            'text' => 'Add someone you often buy for — their age, interests and birthday help us suggest gifts they will love. We only ask for what helps with gift ideas.',
            'actionUrl' => url('/account/gift-center/recipients'), 'actionLabel' => 'Add your first recipient',
        ]) ?>
      <?php else: ?>
        <div class="grid grid-3" style="gap:16px">
          <?php foreach ($recipients as $r):
              $ints = array_map(static fn ($s) => $labels['interests'][$s] ?? null, ReminderService::csv($r['interests']));
              $ints = array_values(array_filter($ints)); ?>
            <article class="recipient-card">
              <div class="row" style="flex-wrap:nowrap">
                <span class="avatar" aria-hidden="true"><?= e($initials((string) $r['name'])) ?></span>
                <div>
                  <h3 style="font-size:1.1rem;margin:0"><?= e($r['name']) ?></h3>
                  <span class="small muted"><?= e(implode(' · ', array_filter([
                      $r['relationship'],
                      $r['recipient_slug'] ? ($labels['recipients'][$r['recipient_slug']] ?? null) : null,
                      $r['age_range_slug'] ? ($labels['ages'][$r['age_range_slug']] ?? null) : null,
                  ]))) ?></span>
                </div>
              </div>
              <?php if ($r['birthday']): ?><p class="small mb-0"><?= icon('cake', 'icon-sm') ?> Birthday <?= e(date('F j', strtotime($r['birthday']))) ?></p><?php endif; ?>
              <?php if ($ints): ?>
                <div class="chips">
                  <?php foreach (array_slice($ints, 0, 4) as $label): ?><span class="badge"><?= e($label) ?></span><?php endforeach; ?>
                  <?php if (count($ints) > 4): ?><span class="badge">+<?= count($ints) - 4 ?></span><?php endif; ?>
                </div>
              <?php endif; ?>
              <div class="row" style="gap:6px;margin-top:auto">
                <a class="btn btn-primary btn-sm" href="<?= e($r['finder_url']) ?>"><?= icon('sparkles', 'icon-sm') ?> Find gifts</a>
                <a class="btn btn-outline btn-sm" href="<?= e(url('/account/gift-center/recipients/' . (int) $r['id'] . '/ideas')) ?>"><?= icon('heart', 'icon-sm') ?> Saved ideas<?= (int) $r['idea_count'] ? ' (' . (int) $r['idea_count'] . ')' : '' ?></a>
              </div>
              <div class="row" style="gap:6px">
                <a class="btn btn-ghost btn-sm" href="<?= e(url('/account/gift-center/recipients/' . (int) $r['id'] . '/edit')) ?>"><?= icon('edit', 'icon-sm') ?> Edit</a>
                <form method="post" action="<?= e(url('/account/gift-center/recipients/' . (int) $r['id'] . '/delete')) ?>" data-confirm="Remove <?= e($r['name']) ?>? Their reminders and saved ideas will also be deleted.">
                  <?= csrf_field() ?>
                  <button class="btn btn-ghost btn-sm" type="submit" aria-label="Delete <?= e($r['name']) ?>"><?= icon('trash', 'icon-sm') ?> Delete</button>
                </form>
              </div>
            </article>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>

    <section class="panel" id="reminders" aria-labelledby="reminders-heading">
      <div class="panel-head"><h2 id="reminders-heading">Reminders</h2></div>
      <?php if ($reminders): ?>
        <div class="table-wrap" style="margin-bottom:24px">
          <table class="table">
            <thead><tr><th scope="col">Occasion</th><th scope="col">Date</th><th scope="col">Email</th><th scope="col"><span class="sr-only">Actions</span></th></tr></thead>
            <tbody>
              <?php foreach ($reminders as $rem): ?>
                <tr>
                  <td>
                    <strong><?= e($rem['title']) ?></strong>
                    <?php if ($rem['recipient_name']): ?><br><span class="small muted">for <?= e($rem['recipient_name']) ?></span><?php endif; ?>
                    <?php if ($rem['occasion_slug'] && isset($labels['occasions'][$rem['occasion_slug']])): ?><br><span class="badge"><?= e($labels['occasions'][$rem['occasion_slug']]) ?></span><?php endif; ?>
                  </td>
                  <td>
                    <?= $rem['next_date'] ? e(date('M j, Y', strtotime($rem['next_date']))) : '<span class="muted">Passed</span>' ?>
                    <br><span class="small muted"><?= (int) $rem['recurring_yearly'] ? 'Every year' : 'Once' ?></span>
                  </td>
                  <td>
                    <?php if ((int) $rem['is_active']): ?>
                      <span class="badge badge-success">On</span><br><span class="small muted"><?= (int) $rem['remind_days_before'] ?> day<?= (int) $rem['remind_days_before'] === 1 ? '' : 's' ?> before</span>
                    <?php else: ?>
                      <span class="badge">Paused</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <div class="row" style="gap:4px;justify-content:flex-end">
                      <form method="post" action="<?= e(url('/account/gift-center/reminders/' . (int) $rem['id'] . '/toggle')) ?>">
                        <?= csrf_field() ?><button class="btn btn-ghost btn-sm" type="submit"><?= (int) $rem['is_active'] ? 'Pause' : 'Resume' ?></button>
                      </form>
                      <form method="post" action="<?= e(url('/account/gift-center/reminders/' . (int) $rem['id'] . '/delete')) ?>" data-confirm="Delete this reminder?">
                        <?= csrf_field() ?><button class="btn btn-ghost btn-sm" type="submit" aria-label="Delete reminder <?= e($rem['title']) ?>"><?= icon('trash', 'icon-sm') ?></button>
                      </form>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>

      <h3 style="font-size:1.1rem">Add a reminder</h3>
      <form method="post" action="<?= e(url('/account/gift-center/reminders')) ?>" data-loading novalidate>
        <?= csrf_field() ?>
        <div class="form-row">
          <div class="field">
            <label for="rem-title">What is the occasion?</label>
            <input class="input<?= errors('title') ? ' has-error' : '' ?>" id="rem-title" name="title" maxlength="120" required placeholder="e.g. Aama’s birthday, our anniversary" value="<?= e(old('title')) ?>">
            <?= field_error('title') ?>
          </div>
          <div class="field">
            <label for="rem-date">Date</label>
            <input class="input<?= errors('event_date') ? ' has-error' : '' ?>" id="rem-date" name="event_date" type="date" required value="<?= e(old('event_date')) ?>">
            <?= field_error('event_date') ?>
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label for="rem-recipient">For <span class="muted">(optional)</span></label>
            <select class="select" id="rem-recipient" name="gift_recipient_id">
              <option value="">No one in particular</option>
              <?php foreach ($recipients as $r): ?><option value="<?= (int) $r['id'] ?>" <?= (string) old('gift_recipient_id') === (string) $r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?>
            </select>
            <?= field_error('gift_recipient_id') ?>
          </div>
          <div class="field">
            <label for="rem-occasion">Type of occasion <span class="muted">(optional)</span></label>
            <select class="select" id="rem-occasion" name="occasion_slug">
              <option value="">Other</option>
              <?php foreach ($occasions as $o): ?><option value="<?= e($o['slug']) ?>" <?= old('occasion_slug') === $o['slug'] ? 'selected' : '' ?>><?= e($o['name']) ?></option><?php endforeach; ?>
            </select>
            <?= field_error('occasion_slug') ?>
          </div>
        </div>
        <div class="form-row">
          <div class="field">
            <label for="rem-days">Email me this many days before</label>
            <input class="input<?= errors('remind_days_before') ? ' has-error' : '' ?>" id="rem-days" name="remind_days_before" type="number" min="1" max="30" required value="<?= e(old('remind_days_before', '7')) ?>">
            <?= field_error('remind_days_before') ?>
          </div>
          <div class="field" style="display:flex;align-items:flex-end">
            <label class="check"><input type="checkbox" name="recurring_yearly" value="1" <?= old('title') === '' || old('recurring_yearly') ? 'checked' : '' ?>> <span>Repeat every year</span></label>
          </div>
        </div>
        <button class="btn btn-primary" type="submit"><?= icon('bell', 'icon-sm') ?> Save reminder</button>
      </form>
    </section>
  </div>
</div>
