<?php
/** @var array $lists @var array $current @var int $defaultId @var array $items @var array $recipients @var bool $canCreate */
$isDefault = (int) $current['id'] === $defaultId;
$savedIds = array_map(static fn ($p) => (int) $p['id'], $items);
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <h1><?= e($current['name']) ?></h1>
      <p class="muted">
        <?= count($items) ?> saved gift<?= count($items) === 1 ? '' : 's' ?>
        <?php if ($current['recipient_name']): ?> · ideas for <?= e($current['recipient_name']) ?><?php endif; ?>
      </p>
    </div>

    <?php if (count($lists) > 1 || $canCreate): ?>
      <nav class="chips" aria-label="Your wishlists" style="margin-bottom:24px">
        <?php foreach ($lists as $l): ?>
          <a class="chip<?= (int) $l['id'] === (int) $current['id'] ? ' is-active' : '' ?>" href="<?= e(url('/account/wishlist', ['list' => (int) $l['id']])) ?>"<?= (int) $l['id'] === (int) $current['id'] ? ' aria-current="page"' : '' ?>>
            <?= $l['gift_recipient_id'] ? icon('user', 'icon-sm') : icon('heart', 'icon-sm') ?>
            <?= e($l['name']) ?> <span class="muted">(<?= (int) $l['item_count'] ?>)</span>
          </a>
        <?php endforeach; ?>
      </nav>
    <?php endif; ?>

    <?php if (!$items): ?>
      <?= partial('components/empty-state', [
          'icon' => 'heart',
          'title' => $isDefault ? 'Your wishlist is empty' : 'No saved ideas yet',
          'text' => $current['recipient_name']
              ? 'Tap the heart on any gift while browsing, then move it here — or let the Gift Finder suggest ideas for ' . $current['recipient_name'] . '.'
              : 'Tap the heart on any gift to save it here for later.',
          'actionUrl' => $current['gift_recipient_id'] ? url('/account/gift-center') : url('/shop'),
          'actionLabel' => $current['gift_recipient_id'] ? 'Back to Gift Center' : 'Browse gifts',
      ]) ?>
    <?php else: ?>
      <div class="product-grid cols-3">
        <?php foreach ($items as $i => $p): $active = ($p['status'] ?? 'active') === 'active'; ?>
          <div>
            <?= partial('components/product-card', ['p' => $p, 'saved' => in_array((int) $p['id'], $savedIds, true), 'lazy' => $i > 2]) ?>
            <div class="row" style="gap:6px;margin-top:8px">
              <?php if ($active): ?>
                <form method="post" action="<?= e(url('/account/wishlist/move-to-cart/' . (int) $p['id'])) ?>">
                  <?= csrf_field() ?>
                  <input type="hidden" name="wishlist_id" value="<?= (int) $current['id'] ?>">
                  <button class="btn btn-primary btn-sm" type="submit"><?= icon('bag', 'icon-sm') ?> Move to bag</button>
                </form>
              <?php else: ?>
                <span class="small muted">No longer available</span>
              <?php endif; ?>
              <form method="post" action="<?= e(url('/account/wishlist/items/' . (int) $p['wishlist_item_id'] . '/remove')) ?>">
                <?= csrf_field() ?>
                <button class="btn btn-ghost btn-sm" type="submit" aria-label="Remove <?= e($p['name']) ?> from this list"><?= icon('trash', 'icon-sm') ?> Remove</button>
              </form>
            </div>
            <p class="xsmall muted" style="margin-top:4px">Saved <?= e(local_date($p['saved_at'], 'M j, Y')) ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="grid grid-2" style="gap:24px;margin-top:32px">
      <?php if ($canCreate): ?>
        <section class="panel" aria-labelledby="new-list-heading">
          <div class="panel-head"><h2 id="new-list-heading" style="font-size:1.2rem">Create a new list</h2></div>
          <form method="post" action="<?= e(url('/account/wishlists')) ?>" novalidate>
            <?= csrf_field() ?>
            <div class="field">
              <label for="list-name">List name</label>
              <input class="input<?= errors('name') ? ' has-error' : '' ?>" id="list-name" name="name" maxlength="100" required placeholder="e.g. Dashain gifts" value="<?= e(old('name')) ?>">
              <?= field_error('name') ?>
            </div>
            <?php if ($recipients): ?>
              <div class="field">
                <label for="list-recipient">For a saved recipient <span class="muted">(optional)</span></label>
                <select class="select" id="list-recipient" name="gift_recipient_id">
                  <option value="">No one in particular</option>
                  <?php foreach ($recipients as $r): ?><option value="<?= (int) $r['id'] ?>"><?= e($r['name']) ?></option><?php endforeach; ?>
                </select>
                <?= field_error('gift_recipient_id') ?>
              </div>
            <?php endif; ?>
            <button class="btn btn-outline" type="submit"><?= icon('plus', 'icon-sm') ?> Create list</button>
          </form>
        </section>
      <?php endif; ?>
      <?php if (!$isDefault): ?>
        <section class="panel" aria-labelledby="delete-list-heading">
          <div class="panel-head"><h2 id="delete-list-heading" style="font-size:1.2rem">Manage this list</h2></div>
          <p class="small muted">Deleting “<?= e($current['name']) ?>” removes the list and its saved items. The gifts themselves are not affected.</p>
          <form method="post" action="<?= e(url('/account/wishlists/' . (int) $current['id'] . '/delete')) ?>" data-confirm="Delete this list and its saved items?">
            <?= csrf_field() ?>
            <button class="btn btn-ghost" type="submit"><?= icon('trash', 'icon-sm') ?> Delete list</button>
          </form>
        </section>
      <?php endif; ?>
    </div>
  </div>
</div>
