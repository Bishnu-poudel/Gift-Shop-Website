<?php
/** Account sidebar. Usage: partial('account/layout-nav') inside <div class="container account-layout">. */
$links = [
    ['/account', 'Overview', 'home', true],
    ['/account/orders', 'Orders', 'package', false],
    ['/account/wishlist', 'Wishlist', 'heart', false],
    ['/account/gift-center', 'Gift Center', 'gift', false],
    ['/account/addresses', 'Addresses', 'map-pin', false],
    ['/account/support', 'Support', 'message', false],
    ['/account/profile', 'Profile & security', 'lock', false],
    ['/account/notifications', 'Notifications', 'bell', false],
];
$path = request()?->path ?? '';
?>
<nav class="account-nav no-print" aria-label="My account">
  <?php foreach ($links as [$href, $label, $ico, $exact]):
      $isActive = $exact ? $path === $href : ($path === $href || str_starts_with($path, $href . '/'));
      if ($href === '/account/wishlist' && str_starts_with($path, '/account/wishlists')) { $isActive = true; } ?>
    <a href="<?= e(url($href)) ?>" class="<?= $isActive ? 'is-active' : '' ?>"<?= $isActive ? ' aria-current="page"' : '' ?>><?= icon($ico, 'icon-sm') ?> <?= e($label) ?></a>
  <?php endforeach; ?>
  <form method="post" action="<?= e(url('/logout')) ?>" style="margin-top:8px">
    <?= csrf_field() ?>
    <button type="submit" class="btn btn-ghost btn-sm" style="width:100%;justify-content:flex-start"><?= icon('log-out', 'icon-sm') ?> Sign out</button>
  </form>
</nav>
