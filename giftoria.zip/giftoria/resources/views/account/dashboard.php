<?php
/** @var array $user @var array $profile @var int $orderCount @var int $wishlistCount @var array $upcoming @var array $recentOrders @var int $openTickets */
$first = explode(' ', trim((string) $user['name']))[0] ?: 'there';
$hour = (int) local_date(gmdate('Y-m-d H:i:s'), 'G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <h1><?= e($greeting) ?>, <?= e($first) ?></h1>
      <p class="muted">Manage your orders, saved gifts and the people you shop for.</p>
    </div>

    <?php if (!empty($profile['deletion_requested_at'])): ?>
      <div class="alert alert-warning" role="status"><?= icon('alert') ?><div>You asked us to delete your account on <?= e(local_date($profile['deletion_requested_at'], 'M j, Y')) ?>. Our team is processing it.</div></div>
    <?php endif; ?>

    <div class="stat-row" style="margin-bottom:24px">
      <a class="stat" href="<?= e(url('/account/orders')) ?>"><strong><?= (int) $orderCount ?></strong><span>Orders</span></a>
      <a class="stat" href="<?= e(url('/account/wishlist')) ?>"><strong><?= (int) $wishlistCount ?></strong><span>Saved gifts</span></a>
      <a class="stat" href="<?= e(url('/account/gift-center')) ?>"><strong><?= count($upcoming) ?></strong><span>Occasions in 30 days</span></a>
    </div>

    <section class="panel" aria-labelledby="recent-orders">
      <div class="panel-head">
        <h2 id="recent-orders">Recent orders</h2>
        <?php if ($recentOrders): ?><a class="link-arrow" href="<?= e(url('/account/orders')) ?>">All orders <?= icon('arrow-right') ?></a><?php endif; ?>
      </div>
      <?php if (!$recentOrders): ?>
        <p class="muted">You have not placed any orders yet.</p>
        <a class="btn btn-primary" href="<?= e(url('/gift-finder')) ?>"><?= icon('sparkles', 'icon-sm') ?> Find a gift</a>
      <?php else: ?>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th scope="col">Order</th><th scope="col">Date</th><th scope="col">Items</th><th scope="col">Status</th><th scope="col" style="text-align:right">Total</th></tr></thead>
            <tbody>
              <?php foreach ($recentOrders as $o): ?>
                <tr>
                  <td><a href="<?= e(url('/account/orders/' . $o['order_number'])) ?>"><strong><?= e($o['order_number']) ?></strong></a></td>
                  <td><?= e(local_date($o['created_at'], 'M j, Y')) ?></td>
                  <td><?= (int) $o['item_count'] ?></td>
                  <td><?= partial('account/_status-badge', ['status' => $o['status']]) ?></td>
                  <td style="text-align:right"><?= e(money($o['grand_total'])) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </section>

    <section class="panel" aria-labelledby="upcoming-heading">
      <div class="panel-head">
        <h2 id="upcoming-heading">Coming up</h2>
        <a class="link-arrow" href="<?= e(url('/account/gift-center')) ?>">Gift Center <?= icon('arrow-right') ?></a>
      </div>
      <?php if (!$upcoming): ?>
        <p class="muted">No birthdays or occasions in the next 30 days. Save the people you buy for and we will remind you in good time.</p>
        <a class="btn btn-outline btn-sm" href="<?= e(url('/account/gift-center/recipients')) ?>"><?= icon('plus', 'icon-sm') ?> Add a recipient</a>
      <?php else: ?>
        <ul class="timeline">
          <?php foreach (array_slice($upcoming, 0, 5) as $u): ?>
            <li>
              <div class="row-between">
                <div>
                  <strong><?= e($u['title']) ?></strong><br>
                  <span class="small muted"><?= e(date('l, M j', strtotime($u['date']))) ?> · <?= $u['days_until'] === 0 ? 'today' : ($u['days_until'] === 1 ? 'tomorrow' : 'in ' . (int) $u['days_until'] . ' days') ?></span>
                </div>
                <a class="btn btn-light btn-sm" href="<?= e($u['finder_url']) ?>"><?= icon('sparkles', 'icon-sm') ?> Find gifts</a>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>
    </section>

    <section class="panel" aria-labelledby="quick-links">
      <div class="panel-head"><h2 id="quick-links">Quick links</h2></div>
      <div class="grid grid-3" style="gap:12px">
        <a class="btn btn-outline" href="<?= e(url('/account/addresses')) ?>"><?= icon('map-pin', 'icon-sm') ?> Addresses</a>
        <a class="btn btn-outline" href="<?= e(url('/account/support')) ?>"><?= icon('message', 'icon-sm') ?> Support<?= $openTickets ? ' (' . (int) $openTickets . ' open)' : '' ?></a>
        <a class="btn btn-outline" href="<?= e(url('/account/profile')) ?>"><?= icon('lock', 'icon-sm') ?> Profile &amp; security</a>
        <a class="btn btn-outline" href="<?= e(url('/account/notifications')) ?>"><?= icon('bell', 'icon-sm') ?> Notifications</a>
        <a class="btn btn-outline" href="<?= e(url('/gift-finder')) ?>"><?= icon('sparkles', 'icon-sm') ?> Gift Finder</a>
        <a class="btn btn-outline" href="<?= e(url('/cart')) ?>"><?= icon('bag', 'icon-sm') ?> My bag</a>
      </div>
    </section>
  </div>
</div>
