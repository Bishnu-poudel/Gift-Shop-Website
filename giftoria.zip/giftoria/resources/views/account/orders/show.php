<?php
/**
 * @var array $order @var array $items @var ?array $shipping @var ?array $billing @var array $history @var array $shipments
 * @var bool $canPay @var bool $canReturn @var ?array $returnRequest @var array $returnReasons @var int $returnDays
 * @var int[] $reviewed @var bool $canReview
 */
use App\Services\OrderStateMachine;

$addr = static function (?array $a): string {
    if (!$a) {
        return '';
    }
    $lines = [e($a['full_name']), e($a['phone'])];
    if ($a['street']) {
        $lines[] = e($a['street']);
    }
    $lines[] = e($a['municipality']) . ($a['ward'] ? '-' . e($a['ward']) : '') . ', ' . e($a['district']);
    $lines[] = e($a['province']) . ' Province';
    if ($a['landmark']) {
        $lines[] = '<span class="muted">Near ' . e($a['landmark']) . '</span>';
    }
    return implode('<br>', $lines);
};
$payLabels = ['esewa' => 'eSewa', 'khalti' => 'Khalti', 'cod' => 'Cash on delivery'];
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <a class="link-arrow small" href="<?= e(url('/account/orders')) ?>"><?= icon('chevron-left') ?> All orders</a>
      <div class="row-between">
        <h1 style="margin-bottom:0">Order <?= e($order['order_number']) ?></h1>
        <?= partial('account/_status-badge', ['status' => $order['status']]) ?>
      </div>
      <p class="muted">Placed <?= e(local_date($order['created_at'])) ?></p>
    </div>

    <?php if ($canPay): ?>
      <div class="alert alert-warning" role="status"><?= icon('alert') ?>
        <div class="row-between" style="width:100%">
          <span>We have not received payment for this order yet<?= $order['expires_at'] ? ' — please pay by ' . e(local_date($order['expires_at'], 'M j, g:i A')) : '' ?>.</span>
          <a class="btn btn-accent btn-sm" href="<?= e(url('/checkout/pay/' . $order['order_number'])) ?>"><?= icon('wallet', 'icon-sm') ?> Pay now</a>
        </div>
      </div>
    <?php endif; ?>

    <div class="row no-print" style="gap:8px;margin-bottom:24px">
      <a class="btn btn-outline btn-sm" href="<?= e(url('/account/orders/' . $order['order_number'] . '/invoice')) ?>" target="_blank" rel="noopener"><?= icon('printer', 'icon-sm') ?> Invoice</a>
      <form method="post" action="<?= e(url('/account/orders/' . $order['order_number'] . '/reorder')) ?>" data-loading>
        <?= csrf_field() ?><button class="btn btn-outline btn-sm" type="submit"><?= icon('refresh', 'icon-sm') ?> Buy again</button>
      </form>
      <a class="btn btn-ghost btn-sm" href="<?= e(url('/account/support/new', ['order' => $order['order_number']])) ?>"><?= icon('message', 'icon-sm') ?> Get help with this order</a>
    </div>

    <section class="panel" aria-labelledby="items-heading">
      <div class="panel-head"><h2 id="items-heading">Items</h2></div>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th scope="col">Item</th><th scope="col">Qty</th><th scope="col" style="text-align:right">Total</th></tr></thead>
          <tbody>
            <?php foreach ($items as $it): ?>
              <tr>
                <td>
                  <div class="row" style="flex-wrap:nowrap;align-items:flex-start">
                    <img src="<?= e(image_url($it['image'])) ?>" alt="" width="56" height="70" loading="lazy" style="width:56px;height:70px;object-fit:cover;border-radius:8px;flex:none">
                    <div>
                      <?php if ($it['slug']): ?><a href="<?= e(url('/product/' . $it['slug'])) ?>"><strong><?= e($it['name']) ?></strong></a><?php else: ?><strong><?= e($it['name']) ?></strong><?php endif; ?>
                      <?php if ($it['variant_name']): ?><div class="small muted"><?= e($it['variant_name']) ?></div><?php endif; ?>
                      <?php if ($it['personalization']): ?><div class="small">Personalisation: “<?= e($it['personalization']) ?>”</div><?php endif; ?>
                      <div class="small muted"><?= e(money($it['unit_price'])) ?> each</div>
                      <?php if ($canReview && $it['product_id'] && $it['slug']): ?>
                        <?php if (in_array((int) $it['product_id'], $reviewed, true)): ?>
                          <span class="small muted"><?= icon('check', 'icon-sm') ?> Reviewed</span>
                        <?php else: ?>
                          <a class="small" href="<?= e(url('/product/' . $it['slug']) . '#reviews') ?>"><?= icon('star', 'icon-sm') ?> Write a review</a>
                        <?php endif; ?>
                      <?php endif; ?>
                    </div>
                  </div>
                </td>
                <td><?= (int) $it['quantity'] ?></td>
                <td style="text-align:right"><?= e(money($it['line_total'])) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div style="max-width:340px;margin-left:auto;margin-top:16px">
        <div class="summary-row"><span>Subtotal</span><span><?= e(money($order['subtotal'])) ?></span></div>
        <?php if ((float) $order['discount_total'] > 0): ?>
          <div class="summary-row"><span>Discount<?= $order['coupon_code'] ? ' (' . e($order['coupon_code']) . ')' : '' ?></span><span class="discount">−<?= e(money($order['discount_total'])) ?></span></div>
        <?php endif; ?>
        <div class="summary-row"><span>Delivery</span><span><?= (float) $order['shipping_total'] > 0 ? e(money($order['shipping_total'])) : 'Free' ?></span></div>
        <?php if ((float) $order['gift_wrap_total'] > 0): ?>
          <div class="summary-row"><span>Gift wrap</span><span><?= e(money($order['gift_wrap_total'])) ?></span></div>
        <?php endif; ?>
        <div class="summary-row total"><span>Total</span><span><?= e(money($order['grand_total'])) ?></span></div>
        <?php if ((float) $order['refunded_total'] > 0): ?>
          <div class="summary-row"><span>Refunded</span><span><?= e(money($order['refunded_total'])) ?></span></div>
        <?php endif; ?>
        <p class="small muted" style="margin-top:8px">Payment method: <?= e($payLabels[$order['payment_method']] ?? $order['payment_method']) ?> · Payment <?= e(strtolower(status_label((string) $order['payment_status']))) ?></p>
      </div>
    </section>

    <div class="grid grid-2" style="gap:24px">
      <section class="panel" aria-labelledby="ship-heading">
        <div class="panel-head"><h2 id="ship-heading">Delivery</h2></div>
        <p class="small"><?= $addr($shipping) ?: '<span class="muted">No address recorded.</span>' ?></p>
        <?php if ($order['requested_delivery_date']): ?><p class="small"><strong>Requested date:</strong> <?= e(date('M j, Y', strtotime($order['requested_delivery_date']))) ?></p><?php endif; ?>
        <?php if ((int) $order['gift_wrap']): ?><p class="small"><?= icon('gift', 'icon-sm') ?> Gift wrapped</p><?php endif; ?>
        <?php if ($order['gift_message']): ?><p class="small"><strong>Gift message:</strong> “<?= e($order['gift_message']) ?>”</p><?php endif; ?>
        <?php if ($billing): ?>
          <h3 style="font-size:1rem;margin-top:16px">Billing address</h3>
          <p class="small mb-0"><?= $addr($billing) ?></p>
        <?php endif; ?>
      </section>

      <section class="panel" aria-labelledby="track-heading">
        <div class="panel-head"><h2 id="track-heading">Tracking</h2></div>
        <?php foreach ($shipments as $s): ?>
          <div class="small" style="margin-bottom:12px">
            <strong><?= e($s['carrier'] ?: 'Courier') ?></strong>
            <?php if ($s['tracking_number']): ?> · <?= e($s['tracking_number']) ?><?php endif; ?><br>
            <?php if ($s['shipped_at']): ?>Shipped <?= e(local_date($s['shipped_at'], 'M j, g:i A')) ?><?php endif; ?>
            <?php if ($s['delivered_at']): ?> · Delivered <?= e(local_date($s['delivered_at'], 'M j, g:i A')) ?><?php endif; ?>
            <?php if ($s['tracking_url'] && preg_match('#^https?://#i', (string) $s['tracking_url'])): ?>
              <br><a href="<?= e($s['tracking_url']) ?>" target="_blank" rel="noopener nofollow">Track parcel <?= icon('external', 'icon-sm') ?></a>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
        <?php if ($history): ?>
          <ol class="timeline" aria-label="Order status history">
            <?php foreach (array_reverse($history) as $h): ?>
              <li><div><strong><?= e(OrderStateMachine::ORDER_LABELS[$h['to_status']] ?? status_label((string) $h['to_status'])) ?></strong><br>
                <span class="muted"><?= e(local_date($h['created_at'], 'M j, Y g:i A')) ?></span></div></li>
            <?php endforeach; ?>
          </ol>
        <?php else: ?>
          <p class="small muted">No updates yet.</p>
        <?php endif; ?>
      </section>
    </div>

    <?php if ($returnRequest): ?>
      <section class="panel" aria-labelledby="return-heading">
        <div class="panel-head"><h2 id="return-heading">Return request</h2><span class="badge badge-info"><?= e(status_label((string) $returnRequest['status'])) ?></span></div>
        <p class="small mb-0"><strong>Reason:</strong> <?= e($returnRequest['reason']) ?> · requested <?= e(local_date($returnRequest['created_at'], 'M j, Y')) ?></p>
        <?php if ($returnRequest['details']): ?><p class="small"><?= nl2br(e($returnRequest['details'])) ?></p><?php endif; ?>
        <?php if ($returnRequest['staff_note']): ?><p class="small"><strong>Our reply:</strong> <?= e($returnRequest['staff_note']) ?></p><?php endif; ?>
      </section>
    <?php elseif ($canReturn): ?>
      <section class="panel no-print" aria-labelledby="return-form-heading">
        <details <?= errors('reason') || errors('details') ? 'open' : '' ?>>
          <summary class="panel-head" style="cursor:pointer;margin-bottom:0"><h2 id="return-form-heading"><?= icon('undo') ?> Request a return</h2></summary>
          <p class="small muted" style="margin-top:16px">Returns are accepted within <?= (int) $returnDays ?> days of delivery. Personalised items can only be returned if they arrived damaged or incorrect. <a href="<?= e(url('/pages/returns')) ?>">Returns policy</a></p>
          <form method="post" action="<?= e(url('/account/orders/' . $order['order_number'] . '/return')) ?>" data-confirm="Submit a return request for this order?" data-loading>
            <?= csrf_field() ?>
            <div class="field">
              <label for="reason">Reason</label>
              <select class="select<?= errors('reason') ? ' has-error' : '' ?>" id="reason" name="reason" required>
                <option value="">Select a reason</option>
                <?php foreach ($returnReasons as $k => $label): ?><option value="<?= e($k) ?>" <?= old('reason') === $k ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?>
              </select>
              <?= field_error('reason') ?>
            </div>
            <div class="field">
              <label for="details">Details <span class="muted">(optional)</span></label>
              <textarea class="textarea" id="details" name="details" rows="3" maxlength="1000" placeholder="Tell us what happened"><?= e(old('details')) ?></textarea>
              <?= field_error('details') ?>
            </div>
            <button class="btn btn-primary" type="submit">Submit return request</button>
          </form>
        </details>
      </section>
    <?php endif; ?>
  </div>
</div>
