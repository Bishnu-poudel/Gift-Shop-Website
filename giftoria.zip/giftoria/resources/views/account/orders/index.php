<?php
/** @var array $orders @var App\Core\Paginator $paginator @var int $total */
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <h1>My orders</h1>
      <?php if ($total): ?><p class="muted"><?= (int) $total ?> order<?= $total === 1 ? '' : 's' ?></p><?php endif; ?>
    </div>

    <?php if (!$orders): ?>
      <?= partial('components/empty-state', [
          'icon' => 'package', 'title' => 'No orders yet',
          'text' => 'When you place an order it will appear here, with delivery tracking and invoices.',
          'actionUrl' => url('/gift-finder'), 'actionLabel' => 'Find a gift',
      ]) ?>
    <?php else: ?>
      <div class="stack">
        <?php foreach ($orders as $o): ?>
          <article class="panel" style="margin-bottom:0;padding:20px">
            <div class="row-between" style="align-items:flex-start">
              <div class="row" style="align-items:flex-start;flex-wrap:nowrap">
                <img src="<?= e(image_url($o['image'])) ?>" alt="" width="64" height="80" loading="lazy" style="width:64px;height:80px;object-fit:cover;border-radius:8px;flex:none">
                <div>
                  <h2 style="font-size:1.05rem;margin:0 0 4px"><a href="<?= e(url('/account/orders/' . $o['order_number'])) ?>"><?= e($o['order_number']) ?></a></h2>
                  <p class="small muted mb-0">Placed <?= e(local_date($o['created_at'], 'M j, Y')) ?> · <?= (int) $o['item_count'] ?> item<?= (int) $o['item_count'] === 1 ? '' : 's' ?></p>
                  <p class="small mb-0"><?= e(str_limit((string) $o['item_names'], 90)) ?></p>
                </div>
              </div>
              <div style="text-align:right">
                <?= partial('account/_status-badge', ['status' => $o['status']]) ?>
                <p class="mb-0" style="margin-top:6px"><strong><?= e(money($o['grand_total'])) ?></strong></p>
              </div>
            </div>
            <div class="row" style="gap:8px;margin-top:12px">
              <a class="btn btn-outline btn-sm" href="<?= e(url('/account/orders/' . $o['order_number'])) ?>">View details</a>
              <?php if ($o['status'] === 'pending_payment' && in_array($o['payment_method'], ['esewa', 'khalti'], true)): ?>
                <a class="btn btn-accent btn-sm" href="<?= e(url('/account/orders/' . $o['order_number'])) ?>">Complete payment</a>
              <?php endif; ?>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
      <?= $paginator->links() ?>
    <?php endif; ?>
  </div>
</div>
