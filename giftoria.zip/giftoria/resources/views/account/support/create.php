<?php
/** @var array $categories @var array $orders @var string $preselectOrder */
$selectedOrder = (string) old('order_id', '');
if ($selectedOrder === '' && $preselectOrder !== '') {
    foreach ($orders as $o) {
        if ($o['order_number'] === $preselectOrder) {
            $selectedOrder = (string) $o['id'];
        }
    }
}
$selectedCategory = (string) old('category', $selectedOrder !== '' ? 'order' : 'general');
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <a class="link-arrow small" href="<?= e(url('/account/support')) ?>"><?= icon('chevron-left') ?> Support</a>
      <h1>How can we help?</h1>
      <p class="muted">Tell us what you need and we will reply by email and here in your account.</p>
    </div>
    <section class="panel">
      <form method="post" action="<?= e(url('/account/support/new')) ?>" data-loading novalidate>
        <?= csrf_field() ?>
        <div class="form-row">
          <div class="field">
            <label for="category">Topic</label>
            <select class="select<?= errors('category') ? ' has-error' : '' ?>" id="category" name="category" required>
              <?php foreach ($categories as $k => $label): ?><option value="<?= e($k) ?>" <?= $selectedCategory === $k ? 'selected' : '' ?>><?= e($label) ?></option><?php endforeach; ?>
            </select>
            <?= field_error('category') ?>
          </div>
          <div class="field">
            <label for="order_id">Related order <span class="muted">(optional)</span></label>
            <select class="select<?= errors('order_id') ? ' has-error' : '' ?>" id="order_id" name="order_id">
              <option value="">Not about a specific order</option>
              <?php foreach ($orders as $o): ?>
                <option value="<?= (int) $o['id'] ?>" <?= $selectedOrder === (string) $o['id'] ? 'selected' : '' ?>><?= e($o['order_number']) ?> — <?= e(local_date($o['created_at'], 'M j, Y')) ?> — <?= e(money($o['grand_total'])) ?></option>
              <?php endforeach; ?>
            </select>
            <?= field_error('order_id') ?>
          </div>
        </div>
        <div class="field">
          <label for="subject">Subject</label>
          <input class="input<?= errors('subject') ? ' has-error' : '' ?>" id="subject" name="subject" maxlength="190" required value="<?= e(old('subject')) ?>">
          <?= field_error('subject') ?>
        </div>
        <div class="field">
          <label for="message">Message</label>
          <textarea class="textarea<?= errors('message') ? ' has-error' : '' ?>" id="message" name="message" rows="6" maxlength="5000" required><?= e(old('message')) ?></textarea>
          <p class="hint">Please do not include card numbers, passwords or eSewa/Khalti PINs.</p>
          <?= field_error('message') ?>
        </div>
        <button class="btn btn-primary" type="submit"><?= icon('mail', 'icon-sm') ?> Send request</button>
      </form>
    </section>
  </div>
</div>
