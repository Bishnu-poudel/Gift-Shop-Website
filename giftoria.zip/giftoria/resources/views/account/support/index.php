<?php
/** @var array $tickets @var array $categories */
use App\Controllers\Account\SupportController;

$badge = static fn (string $s): string => match ($s) {
    'open' => 'badge-info', 'pending' => 'badge-warning', 'resolved' => 'badge-success', default => '',
};
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <div class="row-between">
        <h1 style="margin-bottom:0">Support</h1>
        <a class="btn btn-primary btn-sm" href="<?= e(url('/account/support/new')) ?>"><?= icon('plus', 'icon-sm') ?> New request</a>
      </div>
      <p class="muted">Questions about an order, delivery or a gift? We reply Sunday–Friday, 10am–6pm.</p>
    </div>

    <?php if (!$tickets): ?>
      <?= partial('components/empty-state', [
          'icon' => 'message', 'title' => 'No support requests',
          'text' => 'If something is not right with an order, or you need help choosing a gift, we are happy to help.',
          'actionUrl' => url('/account/support/new'), 'actionLabel' => 'Contact support',
      ]) ?>
    <?php else: ?>
      <div class="panel" style="padding:8px 16px">
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th scope="col">Request</th><th scope="col">Topic</th><th scope="col">Status</th><th scope="col">Updated</th></tr></thead>
            <tbody>
              <?php foreach ($tickets as $t): ?>
                <tr>
                  <td>
                    <a href="<?= e(url('/account/support/' . $t['ticket_number'])) ?>"><strong><?= e($t['subject']) ?></strong></a><br>
                    <span class="small muted"><?= e($t['ticket_number']) ?><?= $t['order_number'] ? ' · ' . e($t['order_number']) : '' ?> · <?= (int) $t['message_count'] ?> message<?= (int) $t['message_count'] === 1 ? '' : 's' ?></span>
                    <?php if ($t['last_author'] === 'staff' && in_array($t['status'], ['open', 'pending'], true)): ?><br><span class="badge badge-info">New reply</span><?php endif; ?>
                  </td>
                  <td class="small"><?= e($categories[$t['category']] ?? status_label((string) $t['category'])) ?></td>
                  <td><span class="badge <?= e($badge((string) $t['status'])) ?>"><?= e(SupportController::STATUS_LABELS[$t['status']] ?? status_label((string) $t['status'])) ?></span></td>
                  <td class="small"><?= e(local_date($t['updated_at'], 'M j, Y')) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    <?php endif; ?>
  </div>
</div>
