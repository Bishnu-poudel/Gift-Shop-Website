<?php
/** @var array $ticket @var array $messages @var array $categories */
use App\Controllers\Account\SupportController;

$storeName = (string) setting('store_name', config('app.name'));
?>
<div class="container account-layout">
  <?= partial('account/layout-nav') ?>
  <div>
    <div class="page-head" style="padding-top:0">
      <a class="link-arrow small" href="<?= e(url('/account/support')) ?>"><?= icon('chevron-left') ?> Support</a>
      <div class="row-between">
        <h1 style="margin-bottom:0"><?= e($ticket['subject']) ?></h1>
        <span class="badge <?= $ticket['status'] === 'resolved' ? 'badge-success' : ($ticket['status'] === 'pending' ? 'badge-warning' : ($ticket['status'] === 'open' ? 'badge-info' : '')) ?>"><?= e(SupportController::STATUS_LABELS[$ticket['status']] ?? status_label((string) $ticket['status'])) ?></span>
      </div>
      <p class="muted">
        <?= e($ticket['ticket_number']) ?> · <?= e($categories[$ticket['category']] ?? status_label((string) $ticket['category'])) ?>
        <?php if ($ticket['order_number']): ?> · <a href="<?= e(url('/account/orders/' . $ticket['order_number'])) ?>"><?= e($ticket['order_number']) ?></a><?php endif; ?>
        · opened <?= e(local_date($ticket['created_at'], 'M j, Y')) ?>
      </p>
    </div>

    <section class="panel" aria-label="Conversation">
      <ol class="stack" style="list-style:none;padding:0;margin:0">
        <?php foreach ($messages as $m): $staffMsg = $m['author_type'] === 'staff'; ?>
          <li style="padding:16px;border-radius:12px;background:<?= $staffMsg ? 'var(--ivory)' : 'transparent' ?>;border:1px solid var(--line)">
            <div class="row-between small" style="margin-bottom:8px">
              <strong><?= $staffMsg ? e($storeName) . ' support' : 'You' ?></strong>
              <span class="muted"><?= e(local_date($m['created_at'], 'M j, Y g:i A')) ?></span>
            </div>
            <div style="white-space:pre-wrap;overflow-wrap:anywhere"><?= e($m['body']) ?></div>
          </li>
        <?php endforeach; ?>
      </ol>
    </section>

    <?php if ($ticket['status'] === 'closed'): ?>
      <div class="alert alert-info" role="status"><?= icon('info') ?><div>This request is closed. <a href="<?= e(url('/account/support/new')) ?>">Open a new request</a> if you still need help.</div></div>
    <?php else: ?>
      <section class="panel" aria-labelledby="reply-heading">
        <div class="panel-head"><h2 id="reply-heading" style="font-size:1.2rem">Reply</h2></div>
        <?php if ($ticket['status'] === 'resolved'): ?><p class="small muted">We marked this as resolved. Replying will reopen it.</p><?php endif; ?>
        <form method="post" action="<?= e(url('/account/support/' . $ticket['ticket_number'] . '/reply')) ?>" data-loading novalidate>
          <?= csrf_field() ?>
          <div class="field">
            <label for="message" class="sr-only">Your message</label>
            <textarea class="textarea<?= errors('message') ? ' has-error' : '' ?>" id="message" name="message" rows="4" maxlength="5000" required><?= e(old('message')) ?></textarea>
            <?= field_error('message') ?>
          </div>
          <button class="btn btn-primary" type="submit">Send reply</button>
        </form>
      </section>
    <?php endif; ?>
  </div>
</div>
