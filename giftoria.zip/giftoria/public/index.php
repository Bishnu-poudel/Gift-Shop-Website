<?php
declare(strict_types=1);

// Front controller. Every non-file request is routed here by public/.htaccess.

require dirname(__DIR__) . '/bootstrap/app.php';

use App\Core\Kernel;
use App\Core\Request;
use App\Core\Router;

$router = new Router();
require BASE_PATH . '/routes/web.php';
require BASE_PATH . '/routes/admin.php';

$request = Request::capture();
(new Kernel($router))->handle($request)->send();
