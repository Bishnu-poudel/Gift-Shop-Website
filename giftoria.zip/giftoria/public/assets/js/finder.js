/* Gift Finder wizard: step navigation, age options by recipient audience, summary. */
(function () {
  'use strict';
  const form = document.getElementById('finder-form');
  if (!form) return;
  const steps = Array.from(form.querySelectorAll('.finder-step'));
  const bars = Array.from(document.querySelectorAll('.finder-progress span'));
  const prev = form.querySelector('[data-prev]');
  const next = form.querySelector('[data-next]');
  const skip = form.querySelector('[data-skip]');
  const label = form.querySelector('[data-step-label]');
  let current = 0;

  function audience() {
    const r = form.querySelector('input[name="recipient"]:checked');
    return r ? r.dataset.audience : null;
  }
  function filterAges() {
    const a = audience();
    const childish = a === 'baby' || a === 'child' || a === 'teen';
    form.querySelectorAll('[data-age-audience]').forEach(card => {
      const show = !a || a === 'any' || (childish ? card.dataset.ageAudience === 'child' : card.dataset.ageAudience === 'adult');
      card.hidden = !show;
      if (!show) { const i = card.querySelector('input'); if (i.checked) i.checked = false; }
    });
  }
  function textOf(input) {
    const l = form.querySelector('label[for="' + input.id + '"]');
    return l ? l.textContent.trim() : input.value;
  }
  function summary() {
    const box = form.querySelector('[data-summary]');
    const parts = [];
    form.querySelectorAll('input:checked').forEach(i => { if (i.name !== 'strict_interests' && i.value !== '') parts.push(textOf(i)); });
    const ci = form.querySelector('#custom_interest').value.trim(); if (ci) parts.push('“' + ci + '”');
    const mn = form.querySelector('#min_price').value, mx = form.querySelector('#max_price').value;
    if (mn || mx) parts.push('NPR ' + (mn || 0) + '–' + (mx || 'any'));
    const d = form.querySelector('#district').value; if (d) parts.push('Deliver to ' + d);
    const dd = form.querySelector('#delivery_date').value; if (dd) parts.push('By ' + dd);
    box.innerHTML = '';
    (parts.length ? parts : ['Anything — show me popular gifts']).forEach(p => {
      const s = document.createElement('span'); s.className = 'chip is-active'; s.textContent = p; box.appendChild(s);
    });
  }
  function show(i) {
    current = Math.max(0, Math.min(steps.length - 1, i));
    steps.forEach((s, j) => s.classList.toggle('is-active', j === current));
    bars.forEach((b, j) => b.classList.toggle('is-done', j <= current));
    prev.hidden = current === 0;
    const last = current === steps.length - 1;
    next.hidden = last; skip.hidden = last;
    label.textContent = 'Step ' + (current + 1) + ' of ' + steps.length;
    if (current === 3) filterAges();
    if (last) summary();
    const h = steps[current].querySelector('h2');
    if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
    window.scrollTo({ top: form.getBoundingClientRect().top + window.scrollY - 140, behavior: 'smooth' });
  }
  next.addEventListener('click', () => show(current + 1));
  skip.addEventListener('click', () => {
    steps[current].querySelectorAll('input[type=radio]').forEach(i => { i.checked = false; });
    show(current + 1);
  });
  prev.addEventListener('click', () => show(current - 1));
  // Single-choice steps advance automatically.
  form.addEventListener('change', (e) => {
    const t = e.target;
    if (t.type === 'radio' && ['recipient', 'occasion', 'age'].includes(t.name)) setTimeout(() => show(current + 1), 220);
    if (t.name === 'budget') {
      const custom = form.querySelector('[data-custom-range]');
      custom.hidden = !t.matches('[data-custom-budget]');
      if (!t.matches('[data-custom-budget]')) { form.querySelector('#min_price').value = ''; form.querySelector('#max_price').value = ''; setTimeout(() => show(current + 1), 220); }
    }
  });
  // Do not submit empty params (keeps result URLs short and shareable).
  form.addEventListener('submit', () => {
    form.querySelectorAll('input, select').forEach(el => {
      if ((el.type === 'radio' || el.type === 'checkbox') ? !el.checked : el.value === '') el.disabled = true;
    });
  });
  if (form.querySelector('#min_price').value || form.querySelector('#max_price').value) {
    form.querySelector('[data-custom-budget]').checked = true;
    form.querySelector('[data-custom-range]').hidden = false;
  }
  show(0);
})();
