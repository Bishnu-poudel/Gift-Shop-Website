/* Giftoria storefront behaviour — progressive enhancement; every feature works without JS via normal forms. */
(function () {
  'use strict';

  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  const base = (document.body.dataset.base || '/').replace(/\/$/, '');
  const csrf = () => (document.querySelector('meta[name="csrf-token"]') || {}).content || '';

  async function postJSON(url, data) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-Token': csrf(), 'X-Requested-With': 'XMLHttpRequest' },
      credentials: 'same-origin',
      body: JSON.stringify(data || {})
    });
    let body = {};
    try { body = await res.json(); } catch (e) { /* non-JSON */ }
    return { ok: res.ok, status: res.status, body };
  }
  async function postForm(form) {
    const res = await fetch(form.action, {
      method: 'POST',
      headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': csrf() },
      credentials: 'same-origin',
      body: new FormData(form)
    });
    let body = {};
    try { body = await res.json(); } catch (e) { /* non-JSON */ }
    return { ok: res.ok, status: res.status, body };
  }

  // Toasts
  function toast(message, isError, link) {
    const region = $('[data-toasts]');
    if (!region) return;
    const t = document.createElement('div');
    t.className = 'toast' + (isError ? ' is-error' : '');
    t.setAttribute('role', isError ? 'alert' : 'status');
    t.textContent = message;
    if (link) {
      const a = document.createElement('a');
      a.href = link.href; a.textContent = link.label; a.style.marginLeft = 'auto';
      t.appendChild(a);
    }
    region.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; }, 3800);
    setTimeout(() => t.remove(), 4200);
  }
  window.Giftoria = { toast, postJSON, postForm, base };

  function setCartCount(n) {
    $$('[data-cart-count]').forEach(el => { el.textContent = n; el.dataset.count = n; });
  }

  // Drawer (mobile nav / admin sidebar) and filters drawer
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-drawer-open]')) { document.body.classList.add('drawer-open'); }
    if (e.target.closest('[data-drawer-close]')) { document.body.classList.remove('drawer-open', 'filters-open'); }
    if (e.target.closest('[data-filters-open]')) { document.body.classList.add('filters-open'); }
    if (e.target.closest('[data-filters-close]')) { document.body.classList.remove('filters-open'); }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.body.classList.remove('drawer-open', 'filters-open');
      closeMegas();
      closeSuggest();
    }
  });

  // Mega menus: hover on desktop, click/keyboard everywhere
  function closeMegas(except) {
    $$('[data-mega].is-open').forEach(li => {
      if (li !== except) { li.classList.remove('is-open'); const b = $('button', li); if (b) b.setAttribute('aria-expanded', 'false'); }
    });
  }
  $$('[data-mega]').forEach(li => {
    const btn = $('button', li);
    let timer;
    const open = () => { clearTimeout(timer); closeMegas(li); li.classList.add('is-open'); btn.setAttribute('aria-expanded', 'true'); };
    const close = () => { timer = setTimeout(() => { li.classList.remove('is-open'); btn.setAttribute('aria-expanded', 'false'); }, 140); };
    btn.addEventListener('click', () => li.classList.contains('is-open') ? (li.classList.remove('is-open'), btn.setAttribute('aria-expanded', 'false')) : open());
    if (window.matchMedia('(hover: hover)').matches) {
      li.addEventListener('mouseenter', open);
      li.addEventListener('mouseleave', close);
    }
    li.addEventListener('focusout', (e) => { if (!li.contains(e.relatedTarget)) close(); });
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('[data-mega]')) closeMegas(); });

  // Live search suggestions
  const searchForm = $('[data-live-search]');
  let suggestAbort, activeIndex = -1;
  function closeSuggest() { const p = $('#suggest-panel'); if (p) { p.classList.remove('is-open'); p.innerHTML = ''; } activeIndex = -1; }
  if (searchForm) {
    const input = $('input[name="q"]', searchForm);
    const panel = $('#suggest-panel', searchForm);
    let t;
    input.addEventListener('input', () => {
      clearTimeout(t);
      const q = input.value.trim();
      if (q.length < 2) { closeSuggest(); return; }
      t = setTimeout(async () => {
        if (suggestAbort) suggestAbort.abort();
        suggestAbort = new AbortController();
        try {
          const res = await fetch(base + '/search/suggest?q=' + encodeURIComponent(q), { headers: { Accept: 'application/json' }, signal: suggestAbort.signal });
          const data = await res.json();
          renderSuggest(panel, data, q);
        } catch (err) { /* aborted or offline */ }
      }, 180);
    });
    input.addEventListener('keydown', (e) => {
      const items = $$('.suggest-item', panel);
      if (!items.length) return;
      if (e.key === 'ArrowDown') { e.preventDefault(); activeIndex = (activeIndex + 1) % items.length; }
      else if (e.key === 'ArrowUp') { e.preventDefault(); activeIndex = (activeIndex - 1 + items.length) % items.length; }
      else if (e.key === 'Enter' && activeIndex >= 0) { e.preventDefault(); window.location = items[activeIndex].href; return; }
      else return;
      items.forEach((it, i) => it.classList.toggle('is-active', i === activeIndex));
    });
    document.addEventListener('click', (e) => { if (!searchForm.contains(e.target)) closeSuggest(); });
  }
  function esc(s) { const d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
  function renderSuggest(panel, data, q) {
    let html = '';
    if (data.shortcuts && data.shortcuts.length) {
      html += '<h5>Shortcuts</h5>' + data.shortcuts.map(s => '<a class="suggest-item" role="option" href="' + esc(s.url) + '">' + esc(s.label) + '</a>').join('');
    }
    if (data.products && data.products.length) {
      html += '<h5>Gifts</h5>' + data.products.map(p => '<a class="suggest-item" role="option" href="' + esc(p.url) + '"><img src="' + esc(p.image) + '" alt="" loading="lazy"><span>' + esc(p.name) + '</span><span class="price">' + esc(p.price) + '</span></a>').join('');
    }
    html += '<a class="suggest-item" role="option" href="' + base + '/search?q=' + encodeURIComponent(q) + '"><strong>See all results for “' + esc(q) + '”</strong></a>';
    panel.innerHTML = html;
    panel.classList.add('is-open');
    activeIndex = -1;
  }

  // Add to cart (AJAX with graceful fallback)
  document.addEventListener('submit', async (e) => {
    const form = e.target.closest('[data-add-to-cart]');
    if (!form) return;
    e.preventDefault();
    const btn = $('button[type="submit"]', form);
    if (btn) btn.classList.add('is-loading');
    try {
      const r = await postForm(form);
      if (r.ok) {
        setCartCount(r.body.count);
        toast(r.body.message || 'Added to your bag', false, { href: base + '/cart', label: 'View bag' });
      } else {
        toast((r.body && r.body.message) || 'Could not add this item.', true);
      }
    } catch (err) {
      form.removeAttribute('data-add-to-cart');
      form.submit();
    } finally {
      if (btn) btn.classList.remove('is-loading');
    }
  });

  // Wishlist hearts
  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-wishlist]');
    if (!btn) return;
    e.preventDefault();
    const payload = { product_id: btn.dataset.wishlist };
    if (btn.dataset.wishlistList) payload.wishlist_id = btn.dataset.wishlistList;
    const r = await postJSON(base + '/wishlist/toggle', payload);
    if (r.status === 401) { window.location = base + '/login'; return; }
    if (!r.ok) { toast((r.body && r.body.message) || 'Could not update your wishlist.', true); return; }
    $$('[data-wishlist="' + btn.dataset.wishlist + '"]').forEach(b => {
      b.classList.toggle('is-saved', !!r.body.saved);
      b.setAttribute('aria-pressed', r.body.saved ? 'true' : 'false');
    });
    toast(r.body.saved ? 'Saved to your wishlist' : 'Removed from your wishlist');
  });

  // Gift Finder feedback
  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-feedback]');
    if (!btn) return;
    const action = btn.dataset.feedback;
    const card = btn.closest('.product-card');
    const r = await postJSON(base + '/gift-finder/feedback', { product_id: btn.dataset.product, action: action, criteria: window.GIFT_FINDER_CRITERIA || {} });
    if (!r.ok) { toast((r.body && r.body.message) || 'Could not save feedback.', true); return; }
    if (action === 'hide' && card) { card.classList.add('is-hidden'); setTimeout(() => card.remove(), 300); toast('Hidden. We will not show it again.'); return; }
    if (action === 'more_like_this' && r.body.redirect) { window.location = r.body.redirect; return; }
    if (card) {
      $$('[data-feedback="like"],[data-feedback="dislike"]', card).forEach(b => b.classList.remove('is-on'));
      btn.classList.add('is-on');
    }
    toast(action === 'like' ? 'Thanks — we will show more like this.' : 'Got it — we will show fewer like this.');
  });

  // Quantity steppers
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-qty-step]');
    if (!b) return;
    const input = b.parentElement.querySelector('input');
    const min = parseInt(input.min || '1', 10), max = parseInt(input.max || '99', 10);
    const v = Math.min(max, Math.max(min, (parseInt(input.value, 10) || min) + parseInt(b.dataset.qtyStep, 10)));
    input.value = v;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  });
  // Auto-submit (sort selects, cart qty)
  document.addEventListener('change', (e) => {
    const el = e.target.closest('[data-autosubmit]');
    if (el && el.form) el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit();
  });

  // Confirm dialogs
  document.addEventListener('submit', (e) => {
    const f = e.target.closest('[data-confirm]');
    if (f && !window.confirm(f.dataset.confirm)) e.preventDefault();
  }, true);
  // Loading state on normal forms
  document.addEventListener('submit', (e) => {
    const f = e.target;
    if (e.defaultPrevented || !f.matches('[data-loading]')) return;
    const b = $('button[type="submit"]', f);
    if (b) setTimeout(() => b.classList.add('is-loading'), 0);
  });

  // Product gallery: thumbnails + click-to-zoom following the pointer
  const gallery = $('[data-gallery]');
  if (gallery) {
    const main = $('.gallery-main', gallery);
    const mainImg = $('img', main);
    $$('.gallery-thumbs button', gallery).forEach(btn => btn.addEventListener('click', () => {
      $$('.gallery-thumbs button', gallery).forEach(b => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      mainImg.src = btn.dataset.src;
      mainImg.alt = btn.dataset.alt || mainImg.alt;
      main.classList.remove('is-zoomed');
    }));
    main.addEventListener('click', () => main.classList.toggle('is-zoomed'));
    main.addEventListener('mousemove', (e) => {
      if (!main.classList.contains('is-zoomed')) return;
      const r = main.getBoundingClientRect();
      mainImg.style.transformOrigin = ((e.clientX - r.left) / r.width * 100) + '% ' + ((e.clientY - r.top) / r.height * 100) + '%';
    });
  }

  // Variant select updates price/stock display
  const variantSelect = $('[data-variant-select]');
  if (variantSelect) {
    const priceEl = $('[data-price-now]');
    variantSelect.addEventListener('change', () => {
      const opt = variantSelect.selectedOptions[0];
      if (opt && opt.dataset.price && priceEl) priceEl.textContent = opt.dataset.price;
      const stockEl = $('[data-variant-stock]');
      if (stockEl && opt) stockEl.textContent = opt.dataset.stockLabel || '';
    });
  }

  // Character counter for personalization
  $$('[data-maxchars]').forEach(input => {
    const out = document.getElementById(input.dataset.counter);
    const update = () => { if (out) out.textContent = input.value.length + ' / ' + input.dataset.maxchars; };
    input.addEventListener('input', update); update();
  });

  // Province -> district dependent selects
  $$('[data-province-select]').forEach(prov => {
    const target = document.getElementById(prov.dataset.districtTarget);
    const map = JSON.parse(prov.dataset.districts || '{}');
    const fill = (keep) => {
      const current = keep ? target.value || target.dataset.selected : '';
      target.innerHTML = '<option value="">Select district</option>';
      (map[prov.value] || []).forEach(d => {
        const o = document.createElement('option'); o.value = d; o.textContent = d;
        if (d === current) o.selected = true;
        target.appendChild(o);
      });
    };
    prov.addEventListener('change', () => { fill(false); target.dispatchEvent(new Event('change', { bubbles: true })); });
    if (prov.value) fill(true);
  });

  // Back-to-results etc. handled server-side. Mark JS available.
  document.documentElement.classList.add('js');
})();
