/* Giftoria admin helpers (requires app.js). */
(function () {
  'use strict';
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));

  /*
   * Charts: <canvas data-chart='{"type":"line","labels":[...],"datasets":[{"label":"Revenue","data":[...]}]}'></canvas>
   * Colors are applied automatically from the brand palette. Chart.js is loaded when the layout sets $useCharts = true.
   */
  const palette = ['#b4532a', '#5f705a', '#b88a3e', '#5b3a4a', '#35577a', '#8f3f1e', '#7a6f63'];
  function initCharts() {
    if (!window.Chart) return;
    Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;
    Chart.defaults.color = '#7a6f63';
    $$('canvas[data-chart]').forEach((canvas) => {
      let cfg;
      try { cfg = JSON.parse(canvas.dataset.chart); } catch (e) { return; }
      const type = cfg.type || 'line';
      const datasets = (cfg.datasets || []).map((d, i) => {
        const c = d.color || palette[i % palette.length];
        const multi = type === 'doughnut' || type === 'pie';
        return Object.assign({
          borderColor: multi ? '#fffdf9' : c,
          backgroundColor: multi ? (cfg.labels || []).map((_, j) => palette[j % palette.length]) : (type === 'line' ? c + '22' : c),
          borderWidth: type === 'line' ? 2 : 1,
          tension: 0.3,
          fill: type === 'line',
          pointRadius: 2,
          borderRadius: type === 'bar' ? 6 : 0,
          maxBarThickness: 36
        }, d);
      });
      new Chart(canvas, {
        type,
        data: { labels: cfg.labels || [], datasets },
        options: Object.assign({
          responsive: true,
          maintainAspectRatio: false,
          interaction: { mode: 'index', intersect: false },
          plugins: { legend: { display: datasets.length > 1 || type === 'doughnut', position: 'bottom' } },
          scales: (type === 'doughnut' || type === 'pie') ? {} : { y: { beginAtZero: true, grid: { color: '#efe7da' } }, x: { grid: { display: false } } }
        }, cfg.options || {})
      });
    });
  }
  window.addEventListener('load', initCharts);

  /*
   * Drag-to-reorder: <ul class="sortable-list" data-sortable data-input="order_input_id"><li data-id="3">..</li></ul>
   * Writes the comma-separated id order into the hidden input so a normal form POST saves it.
   */
  $$('[data-sortable]').forEach((list) => {
    const input = document.getElementById(list.dataset.input);
    let dragged = null;
    const sync = () => { if (input) input.value = $$('li[data-id]', list).map(li => li.dataset.id).join(','); };
    $$('li[data-id]', list).forEach((li) => {
      li.draggable = true;
      li.addEventListener('dragstart', () => { dragged = li; li.classList.add('dragging'); });
      li.addEventListener('dragend', () => { li.classList.remove('dragging'); dragged = null; sync(); });
      li.addEventListener('dragover', (e) => {
        e.preventDefault();
        if (!dragged || dragged === li) return;
        const r = li.getBoundingClientRect();
        li.parentNode.insertBefore(dragged, (e.clientY - r.top) > r.height / 2 ? li.nextSibling : li);
      });
      // Keyboard alternative: buttons with data-move="up|down"
      $$('[data-move]', li).forEach((b) => b.addEventListener('click', (e) => {
        e.preventDefault();
        if (b.dataset.move === 'up' && li.previousElementSibling) li.parentNode.insertBefore(li, li.previousElementSibling);
        if (b.dataset.move === 'down' && li.nextElementSibling) li.parentNode.insertBefore(li.nextElementSibling, li);
        sync();
        b.focus();
      }));
    });
    sync();
  });

  // Range inputs with live value: <input type="range" data-range-output="id">
  $$('input[type="range"][data-range-output]').forEach((r) => {
    const out = document.getElementById(r.dataset.rangeOutput);
    const upd = () => { if (out) out.textContent = r.value; };
    r.addEventListener('input', upd); upd();
  });

  // Select-all checkbox: <input type="checkbox" data-check-all="name[]">
  $$('[data-check-all]').forEach((all) => all.addEventListener('change', () => {
    $$('input[type="checkbox"][name="' + all.dataset.checkAll + '"]').forEach((c) => { if (!c.disabled) c.checked = all.checked; });
  }));

  // Slug autofill: <input data-slug-source="#name">
  $$('[data-slug-from]').forEach((slug) => {
    const src = document.querySelector(slug.dataset.slugFrom);
    if (!src) return;
    let touched = slug.value !== '';
    slug.addEventListener('input', () => { touched = true; });
    src.addEventListener('input', () => {
      if (touched) return;
      slug.value = src.value.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    });
  });
})();
