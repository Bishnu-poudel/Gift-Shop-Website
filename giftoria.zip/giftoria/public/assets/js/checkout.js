/* Checkout: saved-address fill, billing toggle, live server-side quote (shipping, wrap, COD availability). */
(function () {
  'use strict';
  const form = document.getElementById('checkout-form');
  if (!form) return;
  const set = (name, value) => { const el = form.elements[name]; if (el) el.value = value == null ? '' : value; };

  function fillAddress(radio) {
    let a; try { a = JSON.parse(radio.dataset.address); } catch (e) { return; }
    set('full_name', a.full_name); set('ship_phone', a.phone); set('municipality', a.municipality);
    set('ward', a.ward); set('street', a.street); set('landmark', a.landmark);
    const prov = form.elements.province; const dist = form.elements.district;
    prov.value = a.province; dist.dataset.selected = a.district;
    prov.dispatchEvent(new Event('change', { bubbles: true }));
    dist.value = a.district;
    quote();
  }
  form.querySelectorAll('input[name="_saved_address"]').forEach(r => r.addEventListener('change', () => fillAddress(r)));

  const billingToggle = form.querySelector('[data-toggle-billing]');
  if (billingToggle) billingToggle.addEventListener('change', () => { form.querySelector('[data-billing]').hidden = !billingToggle.checked; });

  let pending;
  async function quote() {
    clearTimeout(pending);
    pending = setTimeout(async () => {
      const r = await window.Giftoria.postJSON(form.dataset.quoteUrl, {
        district: form.elements.district.value,
        gift_wrap: form.elements.gift_wrap && form.elements.gift_wrap.checked ? 1 : 0,
        email: form.elements.email.value
      });
      if (!r.ok) return;
      const q = r.body;
      const put = (k, v) => { const el = form.querySelector('[data-q="' + k + '"]'); if (el) el.textContent = v || ''; };
      put('subtotal', q.subtotal); put('shipping', q.shipping); put('total', q.total); put('zone', q.zone);
      if (q.vat) put('vat', q.vat);
      put('estimate', q.estimate ? 'Estimated delivery: ' + q.estimate : '');
      const disc = form.querySelector('[data-row="discount"]'); if (disc) { disc.hidden = !q.discount; put('discount', q.discount); }
      const wrap = form.querySelector('[data-row="gift_wrap"]'); if (wrap) { wrap.hidden = !q.gift_wrap; put('gift_wrap', q.gift_wrap); }
      form.querySelectorAll('[data-method]').forEach(opt => {
        const ok = q.methods.includes(opt.dataset.method);
        opt.hidden = !ok;
        const input = opt.querySelector('input');
        if (!ok && input.checked) input.checked = false;
      });
      if (!form.querySelector('input[name="payment_method"]:checked')) {
        const first = form.querySelector('[data-method]:not([hidden]) input'); if (first) first.checked = true;
      }
      const issues = form.querySelector('[data-quote-issues]');
      issues.innerHTML = '';
      (q.issues || []).forEach(m => { const d = document.createElement('div'); d.className = 'alert alert-warning small'; d.textContent = m; issues.appendChild(d); });
    }, 150);
  }
  form.addEventListener('change', (e) => { if (e.target.matches('[data-quote]')) quote(); });
  if (form.elements.district.value) quote();
})();
