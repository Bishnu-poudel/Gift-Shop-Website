<?php
declare(strict_types=1);

/**
 * Admin > System: staff, roles & permissions, settings, email templates, audit log.
 * Loaded inside the /admin prefix group with 'staff' middleware already applied.
 * Every route carries a can: permission; controllers re-check with Gate::authorize() on POST.
 * NOTE: there is intentionally no public (non-staff) route that creates staff or grants roles.
 *
 * @var App\Core\Router $router
 */

use App\Controllers\Admin\AuditController;
use App\Controllers\Admin\EmailTemplatesController;
use App\Controllers\Admin\RolesController;
use App\Controllers\Admin\SettingsController;
use App\Controllers\Admin\StaffController;

// Staff
$router->get('/staff', [StaffController::class, 'index'], ['can:staff.manage']);
$router->get('/staff/create', [StaffController::class, 'create'], ['can:staff.manage']);
$router->post('/staff', [StaffController::class, 'store'], ['can:staff.manage']);
$router->get('/staff/{id:\d+}', [StaffController::class, 'show'], ['can:staff.manage']);
$router->get('/staff/{id:\d+}/edit', [StaffController::class, 'edit'], ['can:staff.manage']);
$router->post('/staff/{id:\d+}', [StaffController::class, 'update'], ['can:staff.manage']);
$router->post('/staff/{id:\d+}/status', [StaffController::class, 'status'], ['can:staff.manage']);
$router->post('/staff/{id:\d+}/revoke-sessions', [StaffController::class, 'revokeSessions'], ['can:staff.manage']);
$router->post('/staff/{id:\d+}/resend-invite', [StaffController::class, 'resendInvite'], ['can:staff.manage']);
$router->post('/staff/{id:\d+}/force-password', [StaffController::class, 'forcePassword'], ['can:staff.manage']);

// Roles & permissions
$router->get('/roles', [RolesController::class, 'index'], ['can:roles.manage']);
$router->get('/roles/create', [RolesController::class, 'create'], ['can:roles.manage']);
$router->post('/roles', [RolesController::class, 'store'], ['can:roles.manage']);
$router->get('/roles/{id:\d+}/edit', [RolesController::class, 'edit'], ['can:roles.manage']);
$router->post('/roles/{id:\d+}', [RolesController::class, 'update'], ['can:roles.manage']);
$router->post('/roles/{id:\d+}/toggle', [RolesController::class, 'toggle'], ['can:roles.manage']);
$router->post('/roles/{id:\d+}/delete', [RolesController::class, 'destroy'], ['can:roles.manage']);

// Settings
$router->get('/settings', [SettingsController::class, 'store'], ['can:settings.manage']);
$router->post('/settings/store', [SettingsController::class, 'saveStore'], ['can:settings.manage']);
$router->get('/settings/checkout', [SettingsController::class, 'checkout'], ['can:settings.manage']);
$router->post('/settings/checkout', [SettingsController::class, 'saveCheckout'], ['can:settings.manage']);
$router->get('/settings/payments', [SettingsController::class, 'payments'], ['can:settings.manage']);
$router->get('/settings/billing', [App\Controllers\Admin\BillingSettingsController::class, 'show'], ['can:settings.manage']);
$router->post('/settings/billing', [App\Controllers\Admin\BillingSettingsController::class, 'save'], ['can:settings.manage']);
$router->post('/settings/billing/remove-logo', [App\Controllers\Admin\BillingSettingsController::class, 'removeLogo'], ['can:settings.manage']);
$router->get('/settings/zones', [SettingsController::class, 'zones'], ['can:settings.manage']);
$router->get('/settings/zones/create', [SettingsController::class, 'zoneCreate'], ['can:settings.manage']);
$router->post('/settings/zones', [SettingsController::class, 'zoneStore'], ['can:settings.manage']);
$router->get('/settings/zones/{id:\d+}/edit', [SettingsController::class, 'zoneEdit'], ['can:settings.manage']);
$router->post('/settings/zones/{id:\d+}', [SettingsController::class, 'zoneUpdate'], ['can:settings.manage']);
$router->post('/settings/zones/{id:\d+}/delete', [SettingsController::class, 'zoneDelete'], ['can:settings.manage']);

// Email templates & outbox
$router->get('/emails', [EmailTemplatesController::class, 'index'], ['can:content.manage']);
$router->get('/emails/{id:\d+}/edit', [EmailTemplatesController::class, 'edit'], ['can:content.manage']);
$router->post('/emails/{id:\d+}', [EmailTemplatesController::class, 'update'], ['can:content.manage']);
$router->get('/emails/outbox', [EmailTemplatesController::class, 'outbox'], ['can:content.manage']);
$router->get('/emails/outbox/{id:\d+}', [EmailTemplatesController::class, 'outboxShow'], ['can:content.manage']);

// Audit log (read-only)
$router->get('/audit', [AuditController::class, 'index'], ['can:audit.view']);
$router->get('/audit/{id:\d+}', [AuditController::class, 'show'], ['can:audit.view']);
