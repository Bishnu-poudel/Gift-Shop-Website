<?php
declare(strict_types=1);

/**
 * Admin: marketing, content & support. Paths are relative to /admin; the 'staff' middleware is
 * applied by the enclosing group. Every route carries its own can: check and POST handlers
 * re-check with Gate::authorize().
 *
 * @var App\Core\Router $router
 */

use App\Controllers\Admin\CampaignsController;
use App\Controllers\Admin\CouponsController;
use App\Controllers\Admin\HomepageController;
use App\Controllers\Admin\NewsletterController;
use App\Controllers\Admin\RecommendationsController;
use App\Controllers\Admin\ReviewsController;
use App\Controllers\Admin\TicketsController;

// Coupons
$router->get('/coupons', [CouponsController::class, 'index'], ['can:coupons.manage']);
$router->get('/coupons/create', [CouponsController::class, 'create'], ['can:coupons.manage']);
$router->post('/coupons', [CouponsController::class, 'store'], ['can:coupons.manage']);
$router->get('/coupons/{id:\d+}/edit', [CouponsController::class, 'edit'], ['can:coupons.manage']);
$router->post('/coupons/{id:\d+}', [CouponsController::class, 'update'], ['can:coupons.manage']);
$router->post('/coupons/{id:\d+}/deactivate', [CouponsController::class, 'deactivate'], ['can:coupons.manage']);

// Campaigns, banners & landing pages
$router->get('/campaigns', [CampaignsController::class, 'index'], ['can:campaigns.manage|banners.manage']);
$router->get('/campaigns/create', [CampaignsController::class, 'create'], ['can:campaigns.manage|banners.manage']);
$router->post('/campaigns', [CampaignsController::class, 'store'], ['can:campaigns.manage|banners.manage']);
$router->get('/campaigns/{id:\d+}/edit', [CampaignsController::class, 'edit'], ['can:campaigns.manage|banners.manage']);
$router->post('/campaigns/{id:\d+}', [CampaignsController::class, 'update'], ['can:campaigns.manage|banners.manage']);
$router->post('/campaigns/{id:\d+}/deactivate', [CampaignsController::class, 'deactivate'], ['can:campaigns.manage|banners.manage']);

// Newsletter & email campaigns
$router->get('/newsletter', [NewsletterController::class, 'index'], ['can:newsletter.manage']);
$router->get('/newsletter/export', [NewsletterController::class, 'export'], ['can:newsletter.manage']);
$router->post('/newsletter/unsubscribe', [NewsletterController::class, 'unsubscribe'], ['can:newsletter.manage']);
$router->get('/newsletter/suppressions', [NewsletterController::class, 'suppressions'], ['can:newsletter.manage']);
$router->get('/newsletter/abandoned-carts', [NewsletterController::class, 'abandonedCarts'], ['can:newsletter.manage']);
$router->get('/newsletter/campaigns', [NewsletterController::class, 'campaigns'], ['can:newsletter.manage']);
$router->get('/newsletter/campaigns/create', [NewsletterController::class, 'createCampaign'], ['can:newsletter.manage']);
$router->post('/newsletter/campaigns', [NewsletterController::class, 'storeCampaign'], ['can:newsletter.manage']);
$router->get('/newsletter/campaigns/{id:\d+}', [NewsletterController::class, 'showCampaign'], ['can:newsletter.manage']);
$router->get('/newsletter/campaigns/{id:\d+}/edit', [NewsletterController::class, 'editCampaign'], ['can:newsletter.manage']);
$router->post('/newsletter/campaigns/{id:\d+}', [NewsletterController::class, 'updateCampaign'], ['can:newsletter.manage']);
$router->post('/newsletter/campaigns/{id:\d+}/test', [NewsletterController::class, 'sendTest'], ['can:newsletter.manage']);
$router->post('/newsletter/campaigns/{id:\d+}/send', [NewsletterController::class, 'send'], ['can:newsletter.manage']);

// Homepage builder
$router->get('/homepage', [HomepageController::class, 'index'], ['can:homepage.edit']);
$router->post('/homepage/reorder', [HomepageController::class, 'reorder'], ['can:homepage.edit']);
$router->post('/homepage/{id:\d+}/toggle', [HomepageController::class, 'toggle'], ['can:homepage.edit']);
$router->get('/homepage/{id:\d+}/edit', [HomepageController::class, 'edit'], ['can:homepage.edit']);
$router->post('/homepage/{id:\d+}', [HomepageController::class, 'update'], ['can:homepage.edit']);

// Gift Finder rules (recommendation weights, test console, insights)
$router->get('/recommendations', [RecommendationsController::class, 'index'], ['can:recommendations.manage']);
$router->post('/recommendations/weights', [RecommendationsController::class, 'saveWeights'], ['can:recommendations.manage']);
$router->get('/recommendations/insights', [RecommendationsController::class, 'insights'], ['can:recommendations.manage']);

// Reviews & product questions
$router->get('/reviews', [ReviewsController::class, 'index'], ['can:reviews.manage']);
$router->post('/reviews/{id:\d+}/moderate', [ReviewsController::class, 'moderate'], ['can:reviews.manage']);
$router->get('/reviews/questions', [ReviewsController::class, 'questions'], ['can:reviews.manage']);
$router->post('/reviews/questions/{id:\d+}', [ReviewsController::class, 'answer'], ['can:reviews.manage']);

// Support tickets
$router->get('/tickets', [TicketsController::class, 'index'], ['can:support.manage']);
$router->get('/tickets/{id:\d+}', [TicketsController::class, 'show'], ['can:support.manage']);
$router->post('/tickets/{id:\d+}/reply', [TicketsController::class, 'reply'], ['can:support.manage']);
$router->post('/tickets/{id:\d+}/update', [TicketsController::class, 'updateTicket'], ['can:support.manage']);
