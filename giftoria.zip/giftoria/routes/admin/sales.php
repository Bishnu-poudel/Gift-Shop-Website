<?php
declare(strict_types=1);

/**
 * Admin: Dashboard, Sales (orders, payments, refunds, returns), Customers, Reports.
 * Loaded inside the /admin group with 'staff' middleware already applied.
 * Sensitive POST actions re-check permissions inside the controller (Gate::authorize).
 *
 * @var App\Core\Router $router
 */

use App\Controllers\Admin\CustomersController;
use App\Controllers\Admin\DashboardController;
use App\Controllers\Admin\OrdersController;
use App\Controllers\Admin\PaymentsController;
use App\Controllers\Admin\RefundsController;
use App\Controllers\Admin\ReportsController;
use App\Controllers\Admin\ReturnsController;

// Dashboard
$router->get('/', [DashboardController::class, 'index'], ['can:dashboard.view']);

// Orders (static paths before {id} routes)
$router->get('/orders', [OrdersController::class, 'index'], ['can:orders.view']);
$router->get('/orders/export', [OrdersController::class, 'export'], ['can:orders.view']);
$router->get('/orders/create', [OrdersController::class, 'create'], ['can:orders.create']);
$router->post('/orders/create', [OrdersController::class, 'store'], ['can:orders.create']);
$router->get('/orders/{id:\d+}', [OrdersController::class, 'show'], ['can:orders.view']);
$router->get('/orders/{id:\d+}/invoice', [OrdersController::class, 'invoice'], ['can:orders.view']);
$router->post('/orders/{id:\d+}/status', [OrdersController::class, 'updateStatus'], ['can:orders.edit_status|orders.cancel']);
$router->post('/orders/{id:\d+}/notes', [OrdersController::class, 'addNote'], ['can:orders.edit_status|support.manage']);
$router->post('/orders/{id:\d+}/shipment', [OrdersController::class, 'saveShipment'], ['can:orders.edit_status']);
$router->post('/orders/{id:\d+}/recheck', [OrdersController::class, 'recheckPayment'], ['can:payments.view|orders.edit_status']);

// Payments
$router->get('/payments', [PaymentsController::class, 'index'], ['can:payments.view']);

// Refunds
$router->get('/refunds', [RefundsController::class, 'index'], ['can:refunds.manage|payments.view']);
$router->post('/refunds', [RefundsController::class, 'store'], ['can:refunds.manage']);
$router->post('/refunds/{id:\d+}/approve', [RefundsController::class, 'approve'], ['can:refunds.manage']);
$router->post('/refunds/{id:\d+}/reject', [RefundsController::class, 'reject'], ['can:refunds.manage']);
$router->post('/refunds/{id:\d+}/complete', [RefundsController::class, 'complete'], ['can:refunds.manage']);

// Returns
$router->get('/returns', [ReturnsController::class, 'index'], ['can:support.manage|refunds.manage']);
$router->post('/returns/{id:\d+}', [ReturnsController::class, 'update'], ['can:support.manage|refunds.manage']);

// Customers
$router->get('/customers', [CustomersController::class, 'index'], ['can:customers.view']);
$router->get('/customers/{id:\d+}', [CustomersController::class, 'show'], ['can:customers.view']);
$router->post('/customers/{id:\d+}', [CustomersController::class, 'update'], ['can:customers.edit']);

// Reports
$router->get('/reports', [ReportsController::class, 'index'], ['can:reports.view']);
$router->get('/reports/export-finance', [ReportsController::class, 'exportFinance'], ['can:finance.export']);
$router->get('/reports/export/{type:[a-z]+}', [ReportsController::class, 'export'], ['can:reports.view']);
