<?php
declare(strict_types=1);

/**
 * Admin: Catalog & Inventory. Loaded inside the /admin group with 'staff' middleware.
 *
 * @var App\Core\Router $router
 */

use App\Controllers\Admin\CategoriesController;
use App\Controllers\Admin\InventoryController;
use App\Controllers\Admin\ProductsController;
use App\Controllers\Admin\PurchaseOrdersController;
use App\Controllers\Admin\SuppliersController;
use App\Controllers\Admin\TaxonomiesController;

// Products
$p = ['can:products.manage'];
$router->get('/products', [ProductsController::class, 'index'], $p);
$router->get('/products/create', [ProductsController::class, 'create'], $p);
$router->post('/products', [ProductsController::class, 'store'], $p);
$router->get('/products/{id:\d+}/edit', [ProductsController::class, 'edit'], $p);
$router->post('/products/{id:\d+}', [ProductsController::class, 'update'], $p);
$router->post('/products/{id:\d+}/status', [ProductsController::class, 'status'], $p);
$router->post('/products/{id:\d+}/images', [ProductsController::class, 'uploadImages'], $p);
$router->post('/products/{id:\d+}/images/save', [ProductsController::class, 'saveImages'], $p);
$router->post('/products/{id:\d+}/images/{imageId:\d+}/primary', [ProductsController::class, 'primaryImage'], $p);
$router->post('/products/{id:\d+}/images/{imageId:\d+}/delete', [ProductsController::class, 'deleteImage'], $p);
$router->post('/products/{id:\d+}/variants', [ProductsController::class, 'storeVariant'], $p);
$router->post('/products/{id:\d+}/variants/{variantId:\d+}', [ProductsController::class, 'updateVariant'], $p);
$router->post('/products/{id:\d+}/variants/{variantId:\d+}/delete', [ProductsController::class, 'deleteVariant'], $p);

// Categories
$c = ['can:categories.manage'];
$router->get('/categories', [CategoriesController::class, 'index'], $c);
$router->get('/categories/create', [CategoriesController::class, 'create'], $c);
$router->post('/categories', [CategoriesController::class, 'store'], $c);
$router->get('/categories/{id:\d+}/edit', [CategoriesController::class, 'edit'], $c);
$router->post('/categories/{id:\d+}', [CategoriesController::class, 'update'], $c);
$router->post('/categories/{id:\d+}/delete', [CategoriesController::class, 'destroy'], $c);

// Gift taxonomies (type is whitelisted in the controller)
$router->get('/taxonomies', [TaxonomiesController::class, 'home'], $c);
$router->get('/taxonomies/{type:[a-z-]+}', [TaxonomiesController::class, 'index'], $c);
$router->get('/taxonomies/{type:[a-z-]+}/create', [TaxonomiesController::class, 'create'], $c);
$router->post('/taxonomies/{type:[a-z-]+}', [TaxonomiesController::class, 'store'], $c);
$router->get('/taxonomies/{type:[a-z-]+}/{id:\d+}/edit', [TaxonomiesController::class, 'edit'], $c);
$router->post('/taxonomies/{type:[a-z-]+}/{id:\d+}', [TaxonomiesController::class, 'update'], $c);
$router->post('/taxonomies/{type:[a-z-]+}/{id:\d+}/delete', [TaxonomiesController::class, 'destroy'], $c);

// Inventory
$i = ['can:inventory.manage'];
$router->get('/inventory', [InventoryController::class, 'index'], $i);
$router->get('/inventory/movements', [InventoryController::class, 'movements'], $i);
$router->get('/inventory/{id:\d+}', [InventoryController::class, 'show'], $i);
$router->post('/inventory/{id:\d+}/adjust', [InventoryController::class, 'adjust'], $i);
$router->post('/inventory/{id:\d+}/settings', [InventoryController::class, 'settings'], $i);

// Suppliers & purchase orders (POs live under /suppliers so the sidebar item stays highlighted)
$s = ['can:suppliers.manage'];
$router->get('/suppliers', [SuppliersController::class, 'index'], $s);
$router->get('/suppliers/create', [SuppliersController::class, 'create'], $s);
$router->post('/suppliers', [SuppliersController::class, 'store'], $s);
$router->get('/suppliers/{id:\d+}/edit', [SuppliersController::class, 'edit'], $s);
$router->post('/suppliers/{id:\d+}', [SuppliersController::class, 'update'], $s);
$router->post('/suppliers/{id:\d+}/delete', [SuppliersController::class, 'destroy'], $s);

$router->get('/suppliers/purchase-orders', [PurchaseOrdersController::class, 'index'], $s);
$router->get('/suppliers/purchase-orders/create', [PurchaseOrdersController::class, 'create'], $s);
$router->post('/suppliers/purchase-orders', [PurchaseOrdersController::class, 'store'], $s);
$router->get('/suppliers/purchase-orders/{id:\d+}', [PurchaseOrdersController::class, 'show'], $s);
$router->get('/suppliers/purchase-orders/{id:\d+}/edit', [PurchaseOrdersController::class, 'edit'], $s);
$router->post('/suppliers/purchase-orders/{id:\d+}', [PurchaseOrdersController::class, 'update'], $s);
$router->post('/suppliers/purchase-orders/{id:\d+}/status', [PurchaseOrdersController::class, 'status'], $s);
$router->post('/suppliers/purchase-orders/{id:\d+}/receive', [PurchaseOrdersController::class, 'receive'], $s);

unset($p, $c, $i, $s);
