<?php
declare(strict_types=1);

/** @var App\Core\Router $router */

use App\Controllers\Account\AccountController;
use App\Controllers\Account\AddressController;
use App\Controllers\Account\GiftCenterController;
use App\Controllers\Account\OrdersController;
use App\Controllers\Account\ReviewController;
use App\Controllers\Account\SupportController;
use App\Controllers\WishlistController;

// Product reviews (customer must be signed in)
$router->post('/product/{slug}/review', [ReviewController::class, 'store'], ['auth']);

$router->group('/account', ['auth'], static function ($router): void {
    // Overview, profile & security, notifications, deletion
    $router->get('/', [AccountController::class, 'dashboard']);
    $router->get('/profile', [AccountController::class, 'profile']);
    $router->post('/profile', [AccountController::class, 'updateProfile']);
    $router->post('/password', [AccountController::class, 'updatePassword']);
    $router->get('/notifications', [AccountController::class, 'notifications']);
    $router->post('/notifications', [AccountController::class, 'updateNotifications']);
    $router->post('/notifications/clear-history', [AccountController::class, 'clearHistory']);
    $router->post('/delete-request', [AccountController::class, 'deleteRequest']);

    // Wishlists
    $router->get('/wishlist', [WishlistController::class, 'index']);
    $router->post('/wishlists', [WishlistController::class, 'createList']);
    $router->post('/wishlists/{id:\d+}/delete', [WishlistController::class, 'deleteList']);
    $router->post('/wishlist/items/{id:\d+}/remove', [WishlistController::class, 'removeItem']);
    $router->post('/wishlist/move-to-cart/{productId:\d+}', [WishlistController::class, 'moveToCart']);

    // Addresses
    $router->get('/addresses', [AddressController::class, 'index']);
    $router->post('/addresses', [AddressController::class, 'store']);
    $router->get('/addresses/{id:\d+}/edit', [AddressController::class, 'edit']);
    $router->post('/addresses/{id:\d+}', [AddressController::class, 'update']);
    $router->post('/addresses/{id:\d+}/delete', [AddressController::class, 'destroy']);
    $router->post('/addresses/{id:\d+}/default', [AddressController::class, 'makeDefault']);

    // Orders
    $router->get('/orders', [OrdersController::class, 'index']);
    $router->get('/orders/{number:[A-Za-z0-9-]+}', [OrdersController::class, 'show']);
    $router->get('/orders/{number:[A-Za-z0-9-]+}/invoice', [OrdersController::class, 'invoice']);
    $router->post('/orders/{number:[A-Za-z0-9-]+}/return', [OrdersController::class, 'requestReturn']);
    $router->post('/orders/{number:[A-Za-z0-9-]+}/reorder', [OrdersController::class, 'reorder']);

    // Gift Center
    $router->get('/gift-center', [GiftCenterController::class, 'index']);
    $router->get('/gift-center/recipients', [GiftCenterController::class, 'createRecipient']);
    $router->post('/gift-center/recipients', [GiftCenterController::class, 'storeRecipient']);
    $router->get('/gift-center/recipients/{id:\d+}/edit', [GiftCenterController::class, 'editRecipient']);
    $router->get('/gift-center/recipients/{id:\d+}/ideas', [GiftCenterController::class, 'recipientIdeas']);
    $router->post('/gift-center/recipients/{id:\d+}', [GiftCenterController::class, 'updateRecipient']);
    $router->post('/gift-center/recipients/{id:\d+}/delete', [GiftCenterController::class, 'deleteRecipient']);
    $router->post('/gift-center/reminders', [GiftCenterController::class, 'storeReminder']);
    $router->post('/gift-center/reminders/{id:\d+}/delete', [GiftCenterController::class, 'deleteReminder']);
    $router->post('/gift-center/reminders/{id:\d+}/toggle', [GiftCenterController::class, 'toggleReminder']);

    // Support (the literal /new route must come before /{number})
    $router->get('/support', [SupportController::class, 'index']);
    $router->get('/support/new', [SupportController::class, 'create']);
    $router->post('/support/new', [SupportController::class, 'store']);
    // (Router regex segments cannot contain "}", so no {6} quantifier here; the controller checks the format.)
    $router->get('/support/{number:TKT-[A-Z0-9]+}', [SupportController::class, 'show']);
    $router->post('/support/{number:TKT-[A-Z0-9]+}/reply', [SupportController::class, 'reply']);
});
