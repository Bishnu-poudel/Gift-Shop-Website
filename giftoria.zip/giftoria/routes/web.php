<?php
declare(strict_types=1);

/** @var App\Core\Router $router */

use App\Controllers\AuthController;
use App\Controllers\CartController;
use App\Controllers\CatalogController;
use App\Controllers\CheckoutController;
use App\Controllers\GiftFinderController;
use App\Controllers\HomeController;
use App\Controllers\InstallController;
use App\Controllers\NewsletterController;
use App\Controllers\PageController;
use App\Controllers\PaymentController;
use App\Controllers\ProductController;
use App\Controllers\SearchController;
use App\Controllers\SeoController;
use App\Controllers\WishlistController;

$router->get('/', [HomeController::class, 'index']);

// Catalog & discovery
$router->get('/shop', [CatalogController::class, 'shop']);
$router->get('/category/{slug}', [CatalogController::class, 'category']);
$router->get('/gifts/for/{slug}', [CatalogController::class, 'recipient']);
$router->get('/gifts/occasion/{slug}', [CatalogController::class, 'occasion']);
$router->get('/gifts/interest/{slug}', [CatalogController::class, 'interest']);
$router->get('/bestsellers', [CatalogController::class, 'bestsellers']);
$router->get('/new-arrivals', [CatalogController::class, 'newArrivals']);
$router->get('/personalized-gifts', [CatalogController::class, 'personalized']);
$router->get('/makers/{slug}', [CatalogController::class, 'maker']);
$router->get('/campaign/{slug}', [CatalogController::class, 'campaign']);
$router->get('/product/{slug}', [ProductController::class, 'show']);
$router->post('/product/{slug}/question', [ProductController::class, 'question']);

// Search
$router->get('/search', [SearchController::class, 'index']);
$router->get('/search/suggest', [SearchController::class, 'suggest']);

// Gift Finder
$router->get('/gift-finder', [GiftFinderController::class, 'index']);
$router->get('/gift-finder/results', [GiftFinderController::class, 'results']);
$router->post('/gift-finder/feedback', [GiftFinderController::class, 'feedback']);

// Cart
$router->get('/cart', [CartController::class, 'index']);
$router->get('/cart/summary', [CartController::class, 'summary']);
$router->post('/cart/add', [CartController::class, 'add']);
$router->post('/cart/update', [CartController::class, 'update']);
$router->post('/cart/remove', [CartController::class, 'remove']);
$router->post('/cart/save-for-later', [CartController::class, 'saveForLater']);
$router->post('/cart/coupon', [CartController::class, 'coupon']);
$router->post('/cart/gift-options', [CartController::class, 'giftOptions']);

// Checkout & payments
$router->get('/checkout', [CheckoutController::class, 'index']);
$router->post('/checkout', [CheckoutController::class, 'place']);
$router->post('/checkout/quote', [CheckoutController::class, 'quote']);
$router->get('/checkout/pay/{number}', [CheckoutController::class, 'pay']);
$router->post('/checkout/pay/{number}', [CheckoutController::class, 'startPayment']);
$router->get('/order/{number}', [CheckoutController::class, 'orderStatus']);
$router->get('/order/{number}/bill', [CheckoutController::class, 'bill']);
$router->post('/order/{number}/recheck', [CheckoutController::class, 'recheck']);
$router->post('/order/{number}/create-account', [CheckoutController::class, 'createAccount']);
$router->get('/payment/esewa/success/{ref}', [PaymentController::class, 'esewaSuccess']);
$router->get('/payment/esewa/failure/{ref}', [PaymentController::class, 'esewaFailure']);
$router->get('/payment/khalti/return', [PaymentController::class, 'khaltiReturn']);
$router->any('/payment/simulator/{gateway}/{ref}', [PaymentController::class, 'simulator']);

// Customer authentication
$router->get('/login', [AuthController::class, 'loginForm'], ['guest']);
$router->post('/login', [AuthController::class, 'login'], ['guest']);
$router->post('/logout', [AuthController::class, 'logout']);
$router->get('/register', [AuthController::class, 'registerForm'], ['guest']);
$router->post('/register', [AuthController::class, 'register'], ['guest']);
$router->get('/verify-email/{token}', [AuthController::class, 'verify']);
$router->get('/verify-email', [AuthController::class, 'verifyNotice']);
$router->post('/verify-email/resend', [AuthController::class, 'resendVerification']);
$router->get('/forgot-password', [AuthController::class, 'forgotForm']);
$router->post('/forgot-password', [AuthController::class, 'forgot']);
$router->get('/reset-password/{token}', [AuthController::class, 'resetForm']);
$router->post('/reset-password/{token}', [AuthController::class, 'reset']);

// Wishlist (heart toggles work everywhere; the wishlist pages live in routes/account.php)
$router->post('/wishlist/toggle', [WishlistController::class, 'toggle']);

// Newsletter
$router->post('/newsletter', [NewsletterController::class, 'subscribe']);
$router->get('/newsletter/unsubscribe/{token}', [NewsletterController::class, 'unsubscribe']);

// Content pages
$router->get('/contact', [PageController::class, 'contact']);
$router->post('/contact', [PageController::class, 'submitContact']);
$router->get('/pages/{slug}', [PageController::class, 'show']);

// SEO
$router->get('/sitemap.xml', [SeoController::class, 'sitemap']);
$router->get('/robots.txt', [SeoController::class, 'robots']);

// One-time installer (disabled once installed)
$router->get('/install', [InstallController::class, 'form']);
$router->post('/install', [InstallController::class, 'install']);

// Customer account, Gift Center, orders, support (separate file)
require __DIR__ . '/account.php';
