<?php
declare(strict_types=1);

/**
 * Admin panel routes. Mounted under ADMIN_PATH (default /admin).
 * Every protected route uses the 'staff' middleware plus a 'can:<permission>' check, and
 * controllers re-check permissions for sensitive actions (Gate::authorize). Hiding a button is
 * never the only protection.
 *
 * Module route files live in routes/admin/*.php and are loaded inside the protected group.
 *
 * @var App\Core\Router $router
 */

use App\Controllers\Admin\AdminAuthController;

$adminPrefix = '/' . trim((string) config('app.admin_path', 'admin'), '/');

$router->group($adminPrefix, [], function ($router) {
    $router->get('/login', [AdminAuthController::class, 'loginForm'], ['staff.guest']);
    $router->post('/login', [AdminAuthController::class, 'login'], ['staff.guest']);
    $router->post('/logout', [AdminAuthController::class, 'logout']);
    $router->get('/forgot-password', [AdminAuthController::class, 'forgotForm'], ['staff.guest']);
    $router->post('/forgot-password', [AdminAuthController::class, 'forgot'], ['staff.guest']);
    $router->get('/reset-password/{token}', [AdminAuthController::class, 'resetForm']);
    $router->post('/reset-password/{token}', [AdminAuthController::class, 'reset']);
    $router->get('/invite/{token}', [AdminAuthController::class, 'inviteForm']);
    $router->post('/invite/{token}', [AdminAuthController::class, 'acceptInvite']);
    $router->get('/password', [AdminAuthController::class, 'passwordForm'], ['staff']);
    $router->post('/password/update', [AdminAuthController::class, 'updatePassword'], ['staff']);
});

$router->group($adminPrefix, ['staff'], function ($router) {
    foreach (glob(__DIR__ . '/admin/*.php') ?: [] as $file) {
        require $file;
    }
});
