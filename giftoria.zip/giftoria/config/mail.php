<?php

return [
    // log = write to email_outbox + storage/mail (nothing is sent); smtp = deliver via SMTP
    'mode' => env('MAIL_MODE', 'log'),
    'host' => env('MAIL_HOST', ''),
    'port' => (int) env('MAIL_PORT', 587),
    'username' => (string) env('MAIL_USERNAME', ''),
    'password' => (string) env('MAIL_PASSWORD', ''),
    'encryption' => env('MAIL_ENCRYPTION', 'tls'), // tls | ssl | none
    'from_address' => env('MAIL_FROM_ADDRESS', 'hello@giftoria.local'),
    'from_name' => env('MAIL_FROM_NAME', 'Giftoria'),
];
