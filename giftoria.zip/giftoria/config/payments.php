<?php

/*
 | Payment gateway configuration. Secrets come only from environment variables.
 | Endpoints follow the official docs:
 |   eSewa ePay v2  https://developer.esewa.com.np/pages/Epay
 |   Khalti KPG-2   https://docs.khalti.com/khalti-epayment/
 */

$esewaLive = env('ESEWA_ENV', 'test') === 'production';
$khaltiLive = env('KHALTI_ENV', 'test') === 'production';

return [
    'esewa' => [
        'enabled' => (bool) env('ESEWA_ENABLED', true),
        'environment' => $esewaLive ? 'production' : 'test',
        // Empty values fall back to eSewa's public sandbox credentials in test mode only.
        'product_code' => (string) (env('ESEWA_PRODUCT_CODE') ?: ($esewaLive ? '' : 'EPAYTEST')),
        // The public eSewa sandbox key is documented by eSewa; production keys must come from .env.
        'secret_key' => (string) (env('ESEWA_SECRET_KEY') ?: ($esewaLive ? '' : '8gBm/:&EnhH.1/q')),
        'form_url' => $esewaLive
            ? 'https://epay.esewa.com.np/api/epay/main/v2/form'
            : 'https://rc-epay.esewa.com.np/api/epay/main/v2/form',
        'status_url' => $esewaLive
            ? 'https://esewa.com.np/api/epay/transaction/status/'
            : 'https://rc.esewa.com.np/api/epay/transaction/status/',
    ],
    'khalti' => [
        'enabled' => (bool) env('KHALTI_ENABLED', true),
        'environment' => $khaltiLive ? 'production' : 'test',
        'secret_key' => (string) env('KHALTI_SECRET_KEY', ''),
        'base_url' => $khaltiLive ? 'https://khalti.com/api/v2/' : 'https://dev.khalti.com/api/v2/',
    ],
    'cod' => [
        'enabled' => (bool) env('COD_ENABLED', true),
    ],
    // Simulator for local development ONLY (never available when APP_ENV=production).
    // It exercises the exact same verification code path through a fake HTTP client.
    'simulator' => (bool) env('PAYMENT_SIMULATOR', false) && env('APP_ENV', 'local') !== 'production',
];
