<?php

/*
 | Permission catalogue and default roles (seeded by bin/console.php seed / install).
 | Roles are editable in Admin > Roles; this file only defines the initial state.
 */

return [
    'permissions' => [
        'Dashboard' => [
            'dashboard.view' => 'View dashboard',
            'reports.view' => 'View reports',
            'finance.export' => 'Export financial reports',
        ],
        'Customers' => [
            'customers.view' => 'View customers',
            'customers.edit' => 'Edit customers',
        ],
        'Catalog' => [
            'products.manage' => 'Manage products',
            'categories.manage' => 'Manage categories & taxonomies',
            'inventory.manage' => 'Manage inventory',
            'suppliers.manage' => 'Manage suppliers & purchase orders',
        ],
        'Sales' => [
            'orders.view' => 'View orders',
            'orders.edit_status' => 'Edit order status',
            'orders.cancel' => 'Cancel orders',
            'orders.create' => 'Create manual orders',
            'refunds.manage' => 'Manage refunds',
            'payments.view' => 'View payment records',
        ],
        'Marketing' => [
            'coupons.manage' => 'Manage coupons',
            'campaigns.manage' => 'Manage campaigns',
            'banners.manage' => 'Manage banners',
            'homepage.edit' => 'Edit homepage content',
            'newsletter.manage' => 'Manage newsletter & email campaigns',
            'recommendations.manage' => 'Manage gift recommendation rules',
        ],
        'Support' => [
            'reviews.manage' => 'Manage customer reviews & questions',
            'support.manage' => 'Manage support tickets & returns',
        ],
        'System' => [
            'staff.manage' => 'Manage staff',
            'roles.manage' => 'Manage roles and permissions',
            'settings.manage' => 'Manage site settings',
            'audit.view' => 'View audit logs',
            'content.manage' => 'Manage email templates & pages',
        ],
    ],

    // slug => [name, description, permissions ('*' = all, handled by Gate for super-admin)]
    'roles' => [
        'super-admin' => ['Super Admin', 'Full, unrestricted access. Controls privileged access.', ['*']],
        'administrator' => ['Administrator', 'Runs the store day to day; cannot manage roles or grant Super Admin.', [
            'dashboard.view', 'reports.view', 'customers.view', 'customers.edit', 'products.manage', 'categories.manage',
            'inventory.manage', 'suppliers.manage', 'orders.view', 'orders.edit_status', 'orders.cancel', 'orders.create',
            'payments.view', 'coupons.manage', 'campaigns.manage', 'banners.manage', 'homepage.edit', 'newsletter.manage',
            'recommendations.manage', 'reviews.manage', 'support.manage', 'staff.manage', 'settings.manage', 'audit.view', 'content.manage',
        ]],
        'sales-manager' => ['Sales Manager', 'Owns orders, refunds approval and sales reporting.', [
            'dashboard.view', 'reports.view', 'customers.view', 'orders.view', 'orders.edit_status', 'orders.cancel',
            'orders.create', 'refunds.manage', 'payments.view', 'coupons.manage',
        ]],
        'sales-staff' => ['Sales Staff', 'Processes orders.', ['dashboard.view', 'customers.view', 'orders.view', 'orders.edit_status']],
        'marketing-manager' => ['Marketing Manager', 'Campaigns, coupons, homepage and newsletters.', [
            'dashboard.view', 'reports.view', 'coupons.manage', 'campaigns.manage', 'banners.manage', 'homepage.edit',
            'newsletter.manage', 'recommendations.manage',
        ]],
        'marketing-staff' => ['Marketing Staff', 'Banners and campaign content.', ['dashboard.view', 'campaigns.manage', 'banners.manage']],
        'inventory-manager' => ['Inventory Manager', 'Stock, suppliers and purchase orders.', ['dashboard.view', 'inventory.manage', 'suppliers.manage', 'reports.view']],
        'warehouse-staff' => ['Warehouse Staff', 'Receives and adjusts stock.', ['dashboard.view', 'inventory.manage']],
        'fulfillment-staff' => ['Order Fulfillment Staff', 'Packs and ships orders.', ['dashboard.view', 'orders.view', 'orders.edit_status']],
        'customer-support' => ['Customer Support', 'Tickets, returns and customer lookups.', ['dashboard.view', 'customers.view', 'orders.view', 'support.manage', 'reviews.manage']],
        'finance-manager' => ['Finance Manager', 'Payments, refunds and financial exports.', ['dashboard.view', 'reports.view', 'orders.view', 'payments.view', 'refunds.manage', 'finance.export']],
        'finance-staff' => ['Finance Staff', 'Views payments and reports.', ['dashboard.view', 'reports.view', 'orders.view', 'payments.view']],
        'content-manager' => ['Content Manager', 'Homepage, banners and email templates.', ['dashboard.view', 'homepage.edit', 'banners.manage', 'content.manage', 'reviews.manage']],
        'product-manager' => ['Product Manager', 'Catalog and taxonomy management.', ['dashboard.view', 'products.manage', 'categories.manage', 'inventory.manage', 'recommendations.manage']],
        'analyst' => ['Analyst', 'Read-only reporting.', ['dashboard.view', 'reports.view']],
        'auditor' => ['Read-only Auditor', 'Reads orders, payments and audit trail; cannot change anything.', ['dashboard.view', 'reports.view', 'orders.view', 'payments.view', 'audit.view', 'customers.view']],
    ],
];
