<?php

return [
    'host' => env('DB_HOST', '127.0.0.1'),
    'port' => (int) env('DB_PORT', 3306),
    'database' => env('DB_DATABASE', 'giftoria'),
    'username' => env('DB_USERNAME', 'root'),
    'password' => (string) env('DB_PASSWORD', ''),
];
