<?php

return [
    'name' => env('APP_NAME', 'Giftoria'),
    'tagline' => env('APP_TAGLINE', 'Thoughtful gifts, beautifully found'),
    'env' => env('APP_ENV', 'local'),
    'debug' => (bool) env('APP_DEBUG', false),
    'url' => rtrim((string) env('APP_URL', 'http://localhost/giftoria'), '/'),
    'admin_path' => trim((string) env('ADMIN_PATH', 'admin'), '/'),
    'timezone' => 'Asia/Kathmandu',
    'currency' => 'NPR',
    'currency_symbol' => 'NPR',
    'force_https' => (bool) env('FORCE_HTTPS', false),
    'session_name' => 'GIFTORIA_SID',
    'session_lifetime' => (int) env('SESSION_LIFETIME', 120), // minutes idle
    'cache_enabled' => (bool) env('CACHE_ENABLED', true),
    'install_token' => (string) env('INSTALL_TOKEN', ''),
    'payment_timeout_minutes' => (int) env('PAYMENT_TIMEOUT_MINUTES', 90),
    'ai' => [
        // Optional AI re-ranking provider. The rule-based engine never depends on it.
        'provider' => env('AI_PROVIDER', ''),
        'api_key' => env('AI_API_KEY', ''),
        'model' => env('AI_MODEL', 'claude-haiku-4-5-20251001'),
    ],
];
