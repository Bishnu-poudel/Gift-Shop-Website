# Payments: eSewa and Khalti

Both integrations follow the official documentation (checked October 2026):
- eSewa ePay v2: https://developer.esewa.com.np/pages/Epay
- Khalti Web Checkout (KPG-2): https://docs.khalti.com/khalti-epayment/

Code lives in `app/Services/PaymentService.php` and `app/Services/Payments/`.

## Principles

1. **The server decides when an order is paid.** Reaching a success or return URL never marks an order paid. `PaymentService::applyVerification()` requires a server-to-server status check (eSewa Status Check API / Khalti lookup) to report success **and** the amount and reference to match what we stored.
2. **Idempotency:**
   - Each payment attempt has a unique `attempt_ref`.
   - `(gateway, gateway_txn_id)` is UNIQUE.
   - Verification locks the payment row and the order row (`SELECT … FOR UPDATE`). A repeated callback for an already-paid attempt is logged as `duplicate_ignored` and changes nothing.
   - Stock is reserved when the order is created, never by a payment callback, so callbacks cannot deduct stock twice.
3. **Safe retries.** A failed or cancelled payment can be retried from the order page (`/checkout/pay/{order}`). Each retry creates a new attempt on the **same** order, never a new order. The customer may switch between eSewa and Khalti.
4. **Timeouts.** Unpaid online orders hold stock for `PAYMENT_TIMEOUT_MINUTES` (default 90). Before the cron job cancels an order and releases its stock, it re-verifies every open attempt with the gateway.
   - If a payment succeeds *after* expiry, the order is reinstated when stock allows.
   - Otherwise a refund request is created automatically.
5. **No secrets in the browser.**
   - The Khalti secret key is only used server-side.
   - eSewa signatures are generated on the server.
   - Logs and `payment_events` are redacted.
   - We never store wallet PINs, OTPs or passwords.

## eSewa (ePay v2)

| | Test | Production |
|---|---|---|
| Form URL | `https://rc-epay.esewa.com.np/api/epay/main/v2/form` | `https://epay.esewa.com.np/api/epay/main/v2/form` |
| Status check | `https://rc.esewa.com.np/api/epay/transaction/status/` | `https://esewa.com.np/api/epay/transaction/status/` |
| Product code | `EPAYTEST` | from eSewa onboarding |
| Secret key | eSewa's published sandbox key (built in) | from eSewa onboarding |

**Flow:**
1. On the order's pay page the customer chooses eSewa.
2. We create a payment attempt (`transaction_uuid` = `GFT-YYMMDD-XXXXXX-N`).
3. We render an auto-submitting form with `amount`, `tax_amount=0`, `product_service_charge=0`, `product_delivery_charge=0`, `total_amount`, `transaction_uuid`, `product_code`, `success_url`, `failure_url` and `signed_field_names=total_amount,transaction_uuid,product_code`.
   - The signature is `base64(HMAC-SHA256("total_amount=…,transaction_uuid=…,product_code=…", secret))`.
4. eSewa redirects to `/payment/esewa/success/{ref}?data=<base64 JSON>`. We check the response signature and log the result.
5. We then call the **Status Check API**. Only `COMPLETE` with the matching `total_amount` marks the order paid.
6. `/payment/esewa/failure/{ref}` also calls the Status Check API, because eSewa sends pending payments there too.

**Test it:**
1. Keep `ESEWA_ENV=test` and leave `ESEWA_PRODUCT_CODE` and `ESEWA_SECRET_KEY` empty.
2. Place an order and choose eSewa.
3. Log in on the eSewa test page with the sandbox eSewa ID and password listed on eSewa's developer site (for example `9806800001`, password `Nepal@123`, MPIN `1122`, token `123456`; check the site, because eSewa changes these).
4. You return to the order page, which shows "Payment verified".

Status mapping: `COMPLETE`→paid, `PENDING`/`AMBIGUOUS`→pending, `CANCELED`→cancelled, `NOT_FOUND`→failed, `FULL_REFUND`→refunded, `PARTIAL_REFUND`→partially_refunded.

## Khalti (KPG-2)

| | Sandbox | Production |
|---|---|---|
| Base URL | `https://dev.khalti.com/api/v2/` | `https://khalti.com/api/v2/` |
| Auth header | `Authorization: Key <secret>` (secret from test-admin.khalti.com) | secret from admin.khalti.com |

**Flow:**
1. We `POST epayment/initiate/` with `return_url`, `website_url`, `amount` (in **paisa**), `purchase_order_id` (= our attempt ref), `purchase_order_name` and `customer_info`.
2. We store the returned `pidx` and redirect the customer to `payment_url`.
3. The customer comes back to `/payment/khalti/return?pidx=…&status=…`. We **ignore** the query-string status and `POST epayment/lookup/ {pidx}`.
4. Only `Completed` with `total_amount == expected paisa` marks the order paid.

Status mapping: `Pending`/`Initiated`→pending, `User canceled`→cancelled, `Expired`→expired, `Refunded`→refunded, `Partially Refunded`→partially_refunded.

**Test it:**
1. Sign up at https://test-admin.khalti.com/#/join/merchant (the login OTP is `987654`).
2. Copy the sandbox *live secret key* into `KHALTI_SECRET_KEY` and keep `KHALTI_ENV=test`.
3. Pay with test Khalti ID `9800000000`–`9800000005`, MPIN `1111`, OTP `987654`.

## Local simulator (offline)

Set `PAYMENT_SIMULATOR=true`. It is ignored when `APP_ENV=production`.

- The pay buttons open `/payment/simulator/...`, where you choose success, pending or cancel. You can also tick "report a wrong amount".
- The gateway classes then verify through `SimulatorHttpClient` instead of cURL, so the same verification, amount checks and idempotency logic run.

## Refunds

Neither gateway's public checkout API is used to send refunds automatically. Refunds are made in the eSewa or Khalti merchant portal and tracked here:

1. A refund request is created in one of three ways: automatically when a paid order is cancelled, from a return, or manually in **Admin → Refunds**.
2. A user with `refunds.manage` approves it.
3. After refunding in the merchant portal, they click **Complete** and enter the gateway reference.
4. The system then updates `refunded_total`, the payment status (`partially_refunded`/`refunded`) and the order status, and emails the customer.

All steps are audit-logged.

## Going live

1. Finish eSewa merchant onboarding and Khalti KYC, and receive your production credentials.
2. Set `ESEWA_ENV=production`, `ESEWA_PRODUCT_CODE`, `ESEWA_SECRET_KEY`, `KHALTI_ENV=production` and `KHALTI_SECRET_KEY` in the server's `.env` (never in git).
3. Set `APP_ENV=production`, `APP_DEBUG=false`, `FORCE_HTTPS=true` and an HTTPS `APP_URL`. The return URLs are built from `APP_URL`.
4. Make one small real payment with each gateway and confirm it appears verified in **Admin → Payments** (with its event log). Then refund it from the portal and record it.
