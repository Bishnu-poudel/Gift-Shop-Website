# Production deployment & security checklist

## Hosting

- PHP 8.2+ with the extensions listed in the README, MySQL 8 / MariaDB 10.4+, and HTTPS.
- **Point the web server's document root at `giftoria/public/`.** The root `.htaccess` is a fallback for shared hosting. With a proper vhost, the rest of the project (`app/`, `config/`, `storage/`, `.env`) sits outside the web root.
- Apache example:
  ```apache
  <VirtualHost *:443>
      ServerName shop.example.com
      DocumentRoot /var/www/giftoria/public
      <Directory /var/www/giftoria/public>
          AllowOverride All
          Require all granted
      </Directory>
      SSLEngine on
      # SSLCertificateFile / SSLCertificateKeyFile …
  </VirtualHost>
  ```
- Nginx: `root /var/www/giftoria/public; location / { try_files $uri /index.php?$query_string; }`, and pass `.php` requests to PHP-FPM. Deny `location ~ /\.` and deny PHP execution under `/uploads/`.
- Writable by the web user: `storage/` (logs, cache, sessions, mail) and `public/uploads/`. Nothing else.

## Checklist before launch

**Configuration**
- [ ] `APP_ENV=production`, `APP_DEBUG=false`, `FORCE_HTTPS=true`, and `APP_URL=https://…`
- [ ] Unique, strong `DB_PASSWORD`, and a dedicated DB user limited to the `giftoria` database (SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX)
- [ ] `INSTALL_TOKEN` removed or rotated after installation; `storage/installed.lock` present
- [ ] `MAIL_MODE=smtp` with working SMTP; check that the outbox shows *Sent*
- [ ] Production payment credentials in `.env` only (see `docs/PAYMENTS.md`); `PAYMENT_SIMULATOR` unset
- [ ] `.env` permissions `600`; `.env` not in version control (`.gitignore` covers it)

**Content and data**
- [ ] Demo customers, staff and products removed (or install without `--demo`)
- [ ] Store details, delivery zones, COD limit and gift-wrap fee set in Admin → Settings
- [ ] Policy pages reviewed by a lawyer (`resources/views/storefront/pages/`)
- [ ] `ADMIN_PATH` changed from `admin` if you want a less guessable URL (security by obscurity only; RBAC is the real control)

**Operations**
- [ ] Cron set up: `*/10 * * * * php /var/www/giftoria/bin/console.php cron`
- [ ] Backups scheduled and a restore tested (see below)
- [ ] Uptime and error monitoring watching `storage/logs/*.log`

## Security controls implemented

| Area | Control |
|---|---|
| SQL injection | PDO with native prepared statements everywhere. Identifiers are whitelisted (`Database::ident`). |
| XSS | All template output goes through `e()`. User HTML is stripped (`strip_tags`). Admin email and campaign HTML is sanitised and previewed in sandboxed iframes. JSON-LD is encoded with `JSON_HEX_TAG`. |
| CSRF | A per-session token is required on **every** POST by the kernel (form field or `X-CSRF-Token` header). Cookies are SameSite=Lax. |
| Sessions | HttpOnly and Secure (on HTTPS) cookies, strict mode, ID regenerated at login and logout, idle timeout, and `session_version` to revoke all sessions on password change or deactivation. |
| Passwords | `password_hash()` (bcrypt/argon per PHP default) with rehash on login. Reset, verify and invite tokens are random 32-byte values stored as SHA-256 and time-limited (reset 1 h, verify 48 h, invite 72 h). |
| Account enumeration | Login, registration and password reset give the same response whether or not the email exists. Registering an existing email triggers an email to the owner. |
| Brute force | Per email+IP and per-IP login throttling, plus rate limits on registration, reset, contact, checkout, coupons, payment callbacks and feedback. |
| Authorization | `staff` and `can:` route middleware, re-checked with `Gate::authorize` in sensitive controllers. Delegation rules stop anyone granting permissions they don't hold, and only a Super Admin can grant Super Admin. Customers and staff use separate guards. |
| Admin escalation | No public route creates staff or roles. The installer refuses to run once installed. There is no backdoor account. |
| Payments | Server-side verification, amount and reference matching, idempotent state changes, unique gateway transaction ids, and secrets only in `.env`. |
| Money | `DECIMAL(12,2)`. Every total is recomputed on the server; browser totals are never trusted. |
| Inventory | Row-locked transactional stock changes, no negative stock (unless backorders are allowed), and every movement logged. |
| Uploads | 5 MB limit, MIME sniffing with `finfo` plus `getimagesize`, random file names, a fixed target folder, and PHP execution disabled in `public/uploads`. |
| Path traversal | Uploads are deleted only inside `public/uploads` (`realpath` check). Views and templates come from fixed names. |
| Errors | Generic error pages in production. Details are logged to `storage/logs` with secrets redacted. |
| Headers | `X-Content-Type-Options`, `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy`, `Permissions-Policy`, and HSTS when `FORCE_HTTPS`. |
| Audit | `audit_logs` records staff writes, role and permission changes, payments, refunds, logins and denied access. |
| Privacy | Marketing is opt-in with unsubscribe links and a suppression list. Personalization can be turned off and its history cleared. Customers can request account deletion. |

## Backups & restore

**Back up daily (and before upgrades):**
```bash
mysqldump --single-transaction --routines -u giftoria -p giftoria | gzip > /backups/giftoria-$(date +%F).sql.gz
tar czf /backups/giftoria-uploads-$(date +%F).tgz -C /var/www/giftoria/public uploads
```
- Keep at least 14 daily and 8 weekly copies, stored off-server and encrypted.
- Back up `.env` separately in a secrets manager, not alongside the database dumps.

**Restore:**
```bash
gunzip -c giftoria-2026-10-11.sql.gz | mysql -u giftoria -p giftoria
tar xzf giftoria-uploads-2026-10-11.tgz -C /var/www/giftoria/public
php bin/console.php cache:clear
```

On XAMPP you can use phpMyAdmin (Export / Import) and copy `public/uploads` manually.

## Upgrades

1. Back up.
2. Deploy the new code.
3. Run `php bin/console.php migrate` to apply new SQL files in `database/migrations/` in order.
4. Run `php bin/console.php cache:clear`.
