# Troubleshooting

**Every page except the homepage shows "Not Found" (Apache 404)**

`mod_rewrite` or `.htaccess` overrides are disabled.
1. In `C:\xampp\apache\conf\httpd.conf`, make sure `LoadModule rewrite_module modules/mod_rewrite.so` is not commented out.
2. In the `<Directory "C:/xampp/htdocs">` block, set `AllowOverride All`.
3. Restart Apache.

**Styles and images are missing, or links point to the wrong place**

`APP_URL` in `.env` must exactly match the address you use, with no trailing slash, for example `http://localhost/giftoria`. If you serve the site from a different folder name, update `APP_URL`.

**"SQLSTATE[HY000] [2002]" or "Access denied"**

- MySQL isn't running in the XAMPP Control Panel, or `DB_*` in `.env` is wrong.
- XAMPP's default is user `root` with an empty password on port 3306.
- If port 3306 is taken by another MySQL, change XAMPP's port or `DB_PORT`.

**`php` is not recognised in the terminal**

Use the full path, `C:\xampp\php\php.exe bin\console.php …`, or add `C:\xampp\php` to your PATH.

**The installer says "already installed"**

That is by design once a Super Admin exists. To start over on a development machine only:
1. Drop the database in phpMyAdmin.
2. Delete `storage/installed.lock`.
3. Run `php bin/console.php install --demo` again.

**"Your session expired. Please refresh the page" (419)**

- The CSRF token is missing or stale, for example when a form was left open across a server restart. Refresh and resubmit.
- If it happens on every form, check that `storage/sessions` is writable and that cookies aren't blocked for `localhost`.

**Emails never arrive**

- With `MAIL_MODE=log`, emails are only recorded. Read them in **Admin → Email templates → Outbox** or in `storage/mail/`.
- For real delivery, set `MAIL_MODE=smtp` and the `MAIL_*` values.
- Failures are recorded in the outbox with the SMTP error.

**eSewa page shows an error, or the order never confirms**

- `APP_URL` must be reachable from *your browser*; eSewa only redirects the browser. `localhost` works.
- The server needs outgoing HTTPS to `rc.esewa.com.np` for the status check. Check that the PHP `curl` and `openssl` extensions are enabled.
- Use **Check payment status** on the order page, or **Re-check payment** in Admin → Orders.
- Read the attempt's event log in Admin → Orders → order → Payments.

**Khalti says "Invalid token"**

`KHALTI_SECRET_KEY` must be the *sandbox live secret key* from test-admin.khalti.com while `KHALTI_ENV=test`, and the production key only when `KHALTI_ENV=production`.

**Payments without internet (development)**

Set `PAYMENT_SIMULATOR=true` (it is ignored in production).

**Gift Finder or search returns nothing**

- Products must be `active`, in stock (or allow backorders), and tagged with recipients, occasions, interests and age ranges (Admin → Products).
- For babies and toddlers, products need an explicit age range starting at or below the chosen age, and `has_small_parts` off. This is a deliberate safety rule.
- Add phrases in **Admin → Gift taxonomy → Search synonyms**.
- Use **Admin → Gift Finder rules → Test console** to see exactly why products rank as they do.

**Changes in the admin don't appear on the site**

Catalog data is cached for a few minutes and invalidated automatically on edits. If anything looks stale, run `php bin/console.php cache:clear`.

**Uploads fail**

- Allowed formats are JPEG, PNG, WebP and GIF up to 5 MB.
- Also check `upload_max_filesize` and `post_max_size` in `C:\xampp\php\php.ini`, and that `public/uploads` is writable.

**Where are the logs?**

- `storage/logs/app-YYYY-MM-DD.log` (application errors).
- `payments-*.log` (payment warnings).
- `mail-*.log`.
- `php-error.log`.
