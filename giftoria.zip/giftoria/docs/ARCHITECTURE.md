# Architecture

## Request lifecycle

```
Browser → Apache (.htaccess) → public/index.php
  → bootstrap/app.php (autoload, .env, config, helpers)
  → Router (routes/web.php, account.php, admin.php, admin/*.php)
  → Kernel: force-HTTPS → session → CSRF check on POST → middleware (auth|staff|can:perm)
  → Controller → Services / Repositories → PDO (prepared statements)
  → View (resources/views, escaped with e()) inside a layout → Response (+ security headers)
```

Customers and staff use **separate authentication guards** on the same `users` table (`type = customer | staff`), each with its own session key. Public registration can only create `customer` rows.

## Database entities

Defined in `database/migrations/001_core_schema.sql`: 68 InnoDB tables, utf8mb4, foreign keys, indexes, DECIMAL money columns and UTC timestamps.

| Domain | Tables | Notes |
|---|---|---|
| Identity | `users`, `customer_profiles`, `staff_profiles`, `addresses`, `user_tokens`, `rate_limits` | Tokens are stored as SHA-256 hashes. `session_version` revokes sessions. |
| RBAC | `roles`, `permissions`, `role_permissions`, `user_roles` | Many-to-many. The Super Admin role implicitly holds every permission. |
| Catalog | `categories` (tree), `makers`, `products`, `product_variants`, `product_images`, `product_attributes`, `tags` (general and preference) | Age suitability is stored as `products.age_min_months` / `age_max_months` together with `has_small_parts` (this is the brief's *productageranges*). |
| Gift taxonomy | `recipients`, `occasions`, `interests` with `product_recipients`, `product_occasions`, `product_interests`; `product_tags`, `age_ranges`, `budget_ranges`, `search_synonyms` | Recipients carry an implied age range (baby girl = 0–24 months). |
| Inventory | `inventory` (per product/variant, with `variant_id` 0 = base), `inventory_movements`, `suppliers`, `purchase_orders`, `purchase_order_items` | Every change is a movement linked to a user, order or purchase order. |
| Shopping | `carts`, `cart_items`, `wishlists`, `wishlist_items` | Carts hold no prices. |
| Gift Center | `gift_recipients`, `gift_reminders`, `gift_finder_sessions`, `recommendation_feedback` | |
| Marketing | `coupons`, `coupon_redemptions`, `campaigns`, `newsletter_subscriptions`, `email_suppressions`, `email_campaigns` | |
| Orders | `orders`, `order_items` (price and cost snapshots), `order_addresses`, `order_status_history`, `order_notes`, `shipments`, `delivery_zones` | |
| Payments | `payments` (one row per attempt), `payment_events`, `refunds`, `return_requests` | `UNIQUE(gateway, gateway_txn_id)` |
| Support | `reviews`, `product_questions`, `support_tickets`, `ticket_messages` | |
| System | `audit_logs`, `site_settings`, `homepage_sections`, `email_templates`, `email_outbox`, `analytics_daily`, `schema_migrations` | |

**Key relationships:**
- `orders.user_id → users` (nullable for guests); `order_items.product_id → products` (SET NULL, so history survives product deletion).
- `payments.order_id → orders`; `refunds.order_id → orders`; `coupon_redemptions (coupon, order)`.
- Product taxonomy joins cascade on product delete. `inventory_movements.product_id → products`.

## Gift Finder recommendation engine

`app/Services/Recommendation/`

1. **Normalize** (`RecommendationEngine::normalize`):
   - Validates the slugs against the database.
   - Maps a free-text custom interest through `QueryParser` (synonyms, typo correction with Levenshtein distance ≤ 1–2, singularization).
   - Derives the age range from the explicit choice, or else from the recipient's implied range.
   - Resolves the budget range.
2. **Hard constraints (SQL)** in `candidates()`. A product must:
   - be active;
   - be in stock or allow backorders;
   - be tagged for the recipient (or for "anyone else");
   - be within budget;
   - be deliverable to the district (valley-only items);
   - not be hidden by this shopper;
   - match the selected interests, only if the shopper chose "only these interests";
   - pass the age suitability check in `ProductRepository::ageCondition`. **For ranges starting under 36 months** this is a safety rule: the product must declare an age range, its minimum age must be at or below the youngest selected age, and it must have no small parts.
3. **Score** (`Scorer`), using weights editable in Admin → Gift Finder rules:

   | Component | Default weight | How points are earned |
   |---|---|---|
   | Recipient | 25 | Exact match, or 60% for "anyone else" items |
   | Interest | 25 | 70% for one matched interest, rising to 100% as more match. Matching custom keywords also counts. |
   | Occasion | 15 | Full points if tagged; half if the product has no occasion data; 15% if it is tagged for other occasions |
   | Age | 15 | 60–100% by how much of the requested range the product covers; half if unknown |
   | Budget | 10 | Full points when inside the range |
   | Preferences | 5 | Share of the requested preferences matched (handmade, eco-friendly, …) |
   | Popularity | 5 | Logarithm of real sales, combined with verified rating once a product has 3 or more reviews |

   - Components the shopper didn't ask about are left out of the denominator. The score is `earned ÷ possible × 100`.
   - **Feedback adjustments** (only if personalization is enabled): disliked −25, liked +5, liked category +2. "More like this" adds +6 for the same category and +3 per shared interest (up to +9).
4. **Post-filter** on the requested delivery date, using zone transit days plus making time and skipping Saturdays. Results are sorted by score with stable tie-breakers (sales, then id).
5. **Explain.** Each card shows "Why it fits" reasons and the match score.
6. **No results.** If nothing matches, "only these interests" and then the budget (by 50%) are relaxed, and the page says so. **Age-safety rules are never relaxed.** Suggestions are interests that have products for this recipient and age.

Search (`SearchService`) uses the same parser for queries such as "princess gifts under NPR 2,000" and "educational toys for toddlers", combined with MySQL FULLTEXT and LIKE matching, URL filters that always override parsed values, and explained relaxation.

The engine is entirely rule-based and does not depend on any AI service.

## Order and payment state machines

`app/Services/OrderStateMachine.php`, enforced in `OrderService::transition()` and `PaymentService::applyVerification()`.

```
Order: pending_payment → confirmed → processing → packed → shipped → (out_for_delivery) → delivered
       pending_payment|confirmed|processing|packed → cancelled → (refund_pending → refunded, if paid)
       delivered → return_requested → returned → refund_pending → refunded
       return_requested → delivered (return rejected)

Payment: initiated → pending → paid → refund_pending → partially_refunded / refunded
         initiated|pending → failed | cancelled | expired
         failed|cancelled|expired → paid  (only through verified late success)
```

**Side effects:**
- *confirmed* increases product sales counts.
- *cancelled* releases stock (exactly once, via the `stock_released` flag), restores the coupon usage count, and creates a refund request if the order was paid.
- *returned* restocks the items.
- *delivered* on a COD order records the cash payment.
- Customer emails are sent for shipped, delivered, cancelled and refunded.

## Caching

`App\Core\Cache` is a file cache with versioned groups:
- `catalog`: taxonomies, vocabulary, sitemap and suggestions. Bumped on product, inventory and taxonomy changes.
- `settings`: delivery zones. Bumped on settings changes.

## Email

`MailService` renders the DB templates (`{{var}}` escaped, `{{{var}}}` for trusted HTML) inside `resources/views/emails/layout.php`.
- Every message is recorded in `email_outbox` with an honest status: *logged* (dev), *sent* (SMTP 250), or *failed*.
- Marketing emails respect consent and the suppression list.
- Sending never throws, so mail problems cannot break checkout.
