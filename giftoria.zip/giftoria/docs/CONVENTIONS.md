# Giftoria code conventions

This is a custom MVC PHP application that must stay PHP 8.0-compatible (no readonly properties, enums, or `new` in default parameter values) (no framework, no runtime Composer dependencies) that runs on a stock XAMPP install. Read this before adding code.

## Request flow

`public/index.php` → `App\Core\Kernel` → session → **global CSRF check on every POST** → route match (`routes/*.php`) → middleware → controller method → `Response`.

- Controller methods receive `(Request $request, ...$routeParams)` and return a `Response` (or string).
- Extend `App\Controllers\Controller` and use `$this->view('dir/file', $data)` (storefront layout), `$this->adminView('dir/file', $data)` (admin layout; the view path is prefixed with `admin/`), `$this->redirect('/path')`, `$this->back()`, `$this->json($data, $status)`, `$this->validate($request, $rules)`.
- A `ValidationException` is caught by the kernel. It flashes `errors` and `old` and redirects back, or returns a 422 JSON response for AJAX requests.
- `HttpException(404|403|429)` renders the matching error page.
- `DomainException`/`RuntimeException` are not caught specially. Catch them in the controller and `flash('error', $e->getMessage())`.

## Routing

- `$router->get|post|any($pattern, [Controller::class, 'method'], ['middleware', ...])`. Patterns use `{id}` or `{id:\d+}`.
- Middleware: `auth` (customer), `guest`, `staff` (admin login), `staff.guest`, `can:perm.slug` (also `can:a|b` = any of).
- Admin module routes go in `routes/admin/<module>.php`. They are auto-loaded inside the `/admin` prefix group with `staff` middleware already applied, so write paths relative to `/admin` (for example `$router->get('/orders', ...)`). Add `['can:orders.view']` on each route.
- Customer account routes go in `routes/account.php`.

## Authorization (RBAC)

- `App\Core\Gate::allows('perm')`, `Gate::authorize('perm')` (throws 403 and audit-logs the denial), `Gate::any([...])`.
- Delegation: `Gate::canAssignRole($actorId, $roleId)` and `Gate::canGrantPermissions($actorId, $slugs)`. Only a Super Admin may assign `super-admin`. Never allow editing your own roles.
- Never rely on hiding UI alone. Use route `can:` middleware **and**, for sensitive POST actions (refunds, staff, roles, payments, settings), call `Gate::authorize()` again inside the controller.
- Permission slugs are listed in `config/permissions.php`.
- `Auth::staff()` / `Auth::staffId()` gives the logged-in staff user. `Auth::customer()` / `Auth::customerId()` gives the storefront customer. Their sessions are independent.

## Database

- `App\Core\Database` uses static helpers: `fetch`, `fetchAll`, `fetchColumn`, `fetchCol`, `insert($table, $data)` (returns id), `update($table, $data, $where)`, `delete`, `query`, `transaction(fn)`, `in('prefix', $values, $params)`.
- **Native prepared statements**: never reuse a named placeholder twice in one query (`:q` and `:q2`), and never bind a parameter that is not in the SQL. Interpolate `LIMIT`/`OFFSET` as `(int)` values.
- Timestamps are stored in UTC (`Database::now()`, `UTC_TIMESTAMP()`). Display them with `local_date($utc)` (Asia/Kathmandu). Convert `datetime-local` inputs with `local_to_utc()`.
- Money is `DECIMAL(12,2)`. Format it with `money($amount)` → `NPR 1,250`.
- No SQL in templates. Put queries in repositories (`app/Repositories`) or services (`app/Services`).
- After any catalog, product or inventory change, call `App\Core\Cache::bump('catalog')`. After a settings or delivery-zone change, call `Cache::bump('settings')` and `SettingsService::flush()`.

## Domain services (reuse; do not duplicate logic)

| Need | Use |
|---|---|
| Stock change of any kind | `InventoryService::change($productId, $variantId, $delta, $type, $refType, $refId, $userId, $note)` or `setQuantity()`. Types: sale, release, adjustment, receive, return, damage, initial |
| Order status change | `OrderService::transition($orderId, $to, $staffId, $note)` (enforces `OrderStateMachine`, handles stock release/refund side effects, emails) |
| Allowed next statuses | `OrderStateMachine::nextOrderStates($status)`; labels in `OrderStateMachine::ORDER_LABELS` |
| Payment re-verification | `PaymentService::reverifyOrder($orderId)` |
| Totals | `PricingService::calculate($lines, $options)` |
| Manual order | `OrderService::place($data, $lines)` (same validation as web checkout) |
| Emails | `MailService::send($to, $templateKey, $vars)`, `MailService::orderEmail($key, $order)`, `MailService::deliver($to, $subject, $html)` |
| Audit | `AuditLogger::log($action, $entityType, $entityId, $old, $new)` for every staff write |
| Settings | `setting('key', $default)`, `SettingsService::set('key', $value, 'group')` |
| Uploads | `Uploader::image($request->file('image'), 'products')` returns a path relative to `public/`; `Uploader::delete($path)` |
| Pagination | `$p = Paginator::fromRequest($total, 25)`, then `LIMIT {$p->perPage} OFFSET {$p->offset}` and `<?= $p->links() ?>` |
| Campaign status | `CampaignService::statusOf($row)` → draft, scheduled, live or ended |
| Nepal districts | `config('nepal.provinces')`, `ShippingService::districts()`, `ShippingService::isValidDistrict()` |

## Views

- Plain PHP templates in `resources/views`. **Escape every dynamic value with `e()`**. Never echo user content raw.
- Helpers: `url('/path', $query)`, `admin_url('orders/5')`, `asset('assets/..')`, `image_url($path)`, `csrf_field()`, `old('field')`, `field_error('field')`, `errors('field')`, `flash('success', 'msg')`, `money()`, `local_date()`, `icon('name')` (see `app/Helpers/Icons.php`), `status_label()`, `partial('components/x', [...])`, `can('perm')`, `str_limit()`.
- Every POST form must include `<?= csrf_field() ?>`. Destructive forms add `data-confirm="Are you sure?"`.
- Storefront CSS lives in `public/assets/css/app.css`: `.btn .btn-primary|accent|outline|light|ghost|sm|lg|block`, `.input .select .textarea .field .form-row .check`, `.panel .panel-head`, `.table`, `.badge-*`, `.chip`, `.alert-*`, `.empty-state` (via `partial('components/empty-state', [...])`), `.account-layout .account-nav`, `.address-card`, `.recipient-card`, `.avatar`, `.stat-row .stat`.
- Admin CSS lives in `public/assets/css/admin.css`: `.admin-page-head`, `.admin-actions`, `.card .card-head .card-flush`, `.kpis .kpi`, `.data-table` (`.num` for numbers), `.filter-bar`, `.status .status-<state>`, `.tabs`, `.form-grid .span-2`, `.form-actions`, `.checkbox-grid`, `.perm-group`, `.list-plain`, `.chart-box`, `.image-manager`, `.sortable-list`, `.code-block`, `.timeline-admin`, `.weight-row`, `.admin-grid .admin-grid-2|3|3-1`.
- Admin charts: set `'useCharts' => true` in the view data and render `<div class="chart-box"><canvas data-chart='<?= json_attr([...]) ?>'></canvas></div>` (see `public/assets/js/admin.js`).
- Admin drag sorting: `<ul class="sortable-list" data-sortable data-input="hidden_input_id">` with `<li data-id="..">` children.
- JS conventions (in `app.js`): `data-add-to-cart` forms, `data-wishlist="productId"` buttons, `data-autosubmit` selects, `data-confirm` forms, `data-loading` forms, `data-qty-step="-1|1"`, `data-province-select data-district-target="id" data-districts='json'`.

## Security checklist for every feature

1. Validate all input server-side (`Validator` rules). Treat browser-sent prices, totals and ids as untrusted.
2. Check ownership: a customer may only see their own orders, addresses, recipients, tickets and wishlists. Always filter with `user_id = :me`.
3. Put a permission check on every admin route and repeat it for sensitive actions.
4. Escape output, use prepared statements, and audit-log staff changes.
5. Never store or display plaintext passwords, tokens or payment secrets.

## Linting

Use the portable PHP binary (see README) or XAMPP's: `php -l path/to/file.php`.
