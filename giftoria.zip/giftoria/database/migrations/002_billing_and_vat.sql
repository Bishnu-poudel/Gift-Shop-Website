-- Billing: VAT breakdown, sequential bill numbers per Nepali fiscal year, buyer PAN and
-- a snapshot of the seller's details at the time the bill was issued.

ALTER TABLE orders
  ADD COLUMN bill_number VARCHAR(40) NULL AFTER order_number,
  ADD COLUMN bill_issued_at DATETIME NULL AFTER bill_number,
  ADD COLUMN vat_registered TINYINT(1) NOT NULL DEFAULT 0 AFTER grand_total,
  ADD COLUMN vat_rate DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER vat_registered,
  ADD COLUMN prices_include_vat TINYINT(1) NOT NULL DEFAULT 1 AFTER vat_rate,
  ADD COLUMN taxable_amount DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER prices_include_vat,
  ADD COLUMN vat_amount DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER taxable_amount,
  ADD COLUMN buyer_pan VARCHAR(20) NULL AFTER phone,
  ADD COLUMN buyer_company VARCHAR(150) NULL AFTER buyer_pan,
  ADD COLUMN seller_snapshot TEXT NULL,
  ADD UNIQUE KEY uq_orders_bill_number (bill_number);

-- Gapless bill numbering: one row per fiscal year, incremented under a row lock.
CREATE TABLE bill_sequences (
  fiscal_year VARCHAR(10) PRIMARY KEY,
  last_number INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
