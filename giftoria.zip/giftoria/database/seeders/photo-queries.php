<?php
/*
 | Search queries for bin/fetch-photos.php (Openverse, CC0/public-domain only).
 | key => [width, height, [query, fallback query, ...]]
 | Keys: product:<sku>, product2:<sku>, recipient:<slug>, occasion:<slug>, interest:<slug>, misc:<name>, maker:<slug>
 | Recipient tiles deliberately use object/still-life photos (no identifiable people → no model-release issues).
 */

$P = [960, 1200];   // product 4:5
$S = [600, 600];    // square tile
$T = [800, 1000];   // occasion card 4:5

$products = [
    'GFT-1001' => ['rag doll', 'handmade doll'],
    'GFT-1002' => ['toy crown', 'princess crown'],
    'GFT-1003' => ['elephant plush toy', 'stuffed elephant'],
    'GFT-1004' => ['wooden shape sorter toy', 'wooden toy blocks'],
    'GFT-1005' => ['children board book', 'children picture book'],
    'GFT-1006' => ['wooden puzzle letters', 'wooden alphabet puzzle'],
    'GFT-1007' => ['baby rattle', 'wooden baby toy'],
    'GFT-1008' => ['toy tea set', 'miniature tea set'],
    'GFT-1009' => ['felt toys', 'toy tea party'],
    'GFT-1010' => ['knitted baby booties', 'baby knitwear'],
    'GFT-1011' => ['baby memory book', 'baby photo album'],
    'GFT-1012' => ['action figures toys', 'superhero toy'],
    'GFT-1013' => ['silver bangle', 'silver bracelet'],
    'GFT-1014' => ['stacking rings toy', 'rainbow wooden toy'],
    'GFT-1015' => ['illustrated story book', 'fairy tale book'],
    'GFT-1016' => ['fairy lights canopy', 'fairy lights bedroom'],
    'GFT-1017' => ['busy board toy', 'wooden educational toy'],
    'GFT-1018' => ['finger puppets', 'felt animals'],
    'GFT-1019' => ['baby gift box', 'gift box baby'],
    'GFT-1020' => ['volcano science kit', 'kids science experiment'],
    'GFT-1021' => ['robot kit', 'toy robot'],
    'GFT-1022' => ['watercolor paint set', 'watercolour palette'],
    'GFT-1023' => ['board game pieces', 'board game'],
    'GFT-1024' => ['jigsaw puzzle pieces', 'jigsaw puzzle'],
    'GFT-1025' => ['journal and pens', 'notebook pens desk'],
    'GFT-1026' => ['kids backpack', 'school backpack'],
    'GFT-1027' => ['star projector night light', 'night light lamp'],
    'GFT-1028' => ['woven shawl', 'woven textile pattern'],
    'GFT-1029' => ['handmade paper notebook', 'leather journal'],
    'GFT-1030' => ['tea tins', 'loose leaf tea'],
    'GFT-1031' => ['wooden photo frame', 'picture frame'],
    'GFT-1032' => ['silver earrings', 'filigree jewelry'],
    'GFT-1033' => ['brass oil lamp diya', 'oil lamps'],
    'GFT-1034' => ['gift hamper basket', 'dried fruit nuts'],
    'GFT-1035' => ['singing bowl', 'tibetan singing bowl'],
    'GFT-1036' => ['leather wallet', 'wallet'],
    'GFT-1037' => ['pour over coffee', 'coffee dripper'],
    'GFT-1038' => ['succulents pots', 'succulent plants'],
    'GFT-1039' => ['herb garden pots', 'basil plant pot'],
    'GFT-1040' => ['spa gift set', 'candle bath salts'],
    'GFT-1041' => ['himalayan salt lamp', 'salt lamp'],
    'GFT-1042' => ['dumplings cooking', 'momo dumplings'],
    'GFT-1043' => ['hiking backpack', 'trekking backpack'],
    'GFT-1044' => ['yoga mat', 'yoga mat cork'],
    'GFT-1045' => ['wireless charger phone', 'phone charging stand'],
    'GFT-1046' => ['coffee mug', 'mug of tea'],
    'GFT-1047' => ['star map night sky', 'night sky stars'],
    'GFT-1048' => ['desk stationery set', 'notebook pen desk'],
    'GFT-1049' => ['embroidery hoop', 'embroidery'],
    'GFT-1050' => ['dog collar', 'dog with collar'],
    'GFT-1051' => ['potted plant gift', 'small potted plant'],
    'GFT-1052' => ['fountain pen', 'pen gift box'],
    'GFT-1053' => ['wooden jewelry box', 'carved wooden box'],
    'GFT-1054' => ['photo album', 'old photographs album'],
    'GFT-1055' => ['chocolate box roses', 'chocolates and rose'],
    'GFT-1056' => ['pashmina scarf', 'cashmere scarf'],
    'GFT-1057' => ['fitness tracker watch', 'smartwatch'],
    'GFT-1058' => ['cookware pans', 'frying pan kitchen'],
    'GFT-1059' => ['snack basket', 'nuts and snacks'],
    'GFT-1060' => ['bamboo toothbrush', 'zero waste bathroom'],
    'GFT-1061' => ['tulle dress', 'princess dress up costume'],
];

$q = [];
foreach ($products as $sku => $queries) {
    $q['product:' . $sku] = [$P[0], $P[1], $queries];
    $q['product2:' . $sku] = [$P[0], $P[1], array_merge(array_reverse($queries), ['gift wrapped present'])];
}

$recipients = [
    'baby-girl' => ['pink baby shoes', 'baby clothes pink'],
    'baby-boy' => ['blue baby clothes', 'baby toys blue'],
    'child' => ['wooden toy train', 'colorful wooden toys', 'toy car'],
    'teenager' => ['skateboard', 'white sneakers', 'skateboard deck'],
    'mother' => ['flowers and tea', 'bouquet of flowers'],
    'father' => ['wristwatch leather', 'mens accessories'],
    'sister' => ['jewelry box', 'perfume bottle'],
    'brother' => ['sneakers', 'gaming controller'],
    'wife' => ['red roses', 'roses bouquet'],
    'husband' => ['coffee and book', 'leather watch'],
    'girlfriend' => ['pink roses', 'love heart gift'],
    'boyfriend' => ['camera vintage', 'guitar'],
    'friend' => ['friendship bracelets', 'cups coffee table'],
    'grandparent' => ['reading glasses book', 'vintage tea cup'],
    'colleague' => ['office desk plant', 'desk workspace'],
    'teacher' => ['apple books', 'books stack'],
    'couple' => ['two coffee cups', 'two wine glasses'],
    'pet-lover' => ['dog', 'cat'],
    'anyone-else' => ['wrapped gifts', 'gift boxes', 'present ribbon'],
];
foreach ($recipients as $slug => $queries) {
    $q['recipient:' . $slug] = [$S[0], $S[1], $queries];
}

$occasions = [
    'birthday' => ['birthday cake candles', 'birthday cake'],
    'baby-shower' => ['baby shower', 'baby shoes gift'],
    'birth-celebration' => ['baby shoes', 'baby blanket', 'baby booties'],
    'naming-ceremony' => ['baby name letters', 'baby blocks letters'],
    'first-birthday' => ['cupcake candle', 'birthday cupcake', 'birthday candle'],
    'anniversary' => ['champagne toast', 'roses candles', 'champagne glasses'],
    'wedding' => ['wedding rings', 'wedding flowers'],
    'graduation' => ['graduation cap tassel', 'diploma ribbon', 'graduation hat'],
    'festival' => ['festival lights', 'string lights'],
    'dashain' => ['kite', 'flying kite', 'marigold flowers'],
    'tihar' => ['diwali diya', 'diya lamp', 'marigold garland'],
    'valentines-day' => ['valentine heart', 'red heart roses'],
    'mothers-day' => ['tulips bouquet', 'spring flowers'],
    'fathers-day' => ['tie and watch', 'mens shoes'],
    'thank-you' => ['thank you card', 'flowers card'],
    'housewarming' => ['house keys', 'home interior plants'],
    'corporate-gifting' => ['brown gift box', 'kraft paper gift', 'gift box twine'],
    'just-because' => ['wrapped gift ribbon', 'small gift box'],
];
foreach ($occasions as $slug => $queries) {
    $q['occasion:' . $slug] = [$T[0], $T[1], $queries];
}

$interests = [
    'dolls' => ['doll', 'rag doll'], 'action-figures' => ['tin toy robot', 'vintage robot toy', 'wind up robot'],
    'princess-toys' => ['princess crown', 'tiara'], 'stuffed-animals' => ['teddy bear', 'plush toy'],
    'educational-toys' => ['wooden educational toy', 'abacus'], 'building-blocks' => ['toy blocks', 'wooden blocks', 'stacking blocks'],
    'books-storytelling' => ['books', 'open book'], 'arts-crafts' => ['paint brushes', 'crayons'],
    'science-stem' => ['test tubes', 'laboratory glassware', 'microscope'], 'music' => ['guitar', 'musical instruments'],
    'fashion' => ['scarf fashion', 'handbag'], 'jewelry' => ['jewelry', 'necklace'],
    'personalized-keepsakes' => ['keepsake box', 'wooden box', 'memory box'], 'home-decor' => ['home decor', 'candles interior'],
    'games-puzzles' => ['jigsaw puzzle', 'chess'], 'outdoor-activities' => ['hiking trail mountains', 'camping tent'],
    'sports' => ['football ball', 'tennis ball', 'basketball'], 'technology' => ['laptop', 'gadgets'],
    'cooking' => ['cooking kitchen', 'spices'], 'gardening' => ['gardening tools', 'potted plants'],
    'beauty-wellness' => ['spa candles', 'essential oils'], 'handmade-products' => ['pottery handmade', 'weaving loom'],
    'sustainable-gifts' => ['zero waste', 'bamboo products'], 'experiences' => ['concert lights', 'hot air balloon', 'tickets'],
    'gift-hampers' => ['gift basket', 'hamper'],
];
foreach ($interests as $slug => $queries) {
    $q['interest:' . $slug] = [$S[0], $S[1], $queries];
}

$q['misc:hero'] = [1000, 1100, ['gift boxes ribbon', 'wrapped gifts', 'gift box']];
$q['misc:personalized'] = [1000, 800, ['handwritten card gift', 'gift tag', 'wrapped gift name tag']];
$q['misc:baby'] = [1000, 800, ['baby toys', 'wooden baby toys', 'nursery toys']];
$q['misc:campaign-tihar'] = [1600, 700, ['marigold flowers', 'candle flames', 'candles lit']];
$q['misc:story'] = [1000, 800, ['artisan hands craft', 'pottery wheel hands', 'weaving']];

$makers = [
    'kathmandu-felt-studio' => ['felt fabric colorful', 'wool felt balls', 'colorful felt'],
    'palpa-dhaka-weavers' => ['handloom weaving', 'loom weaving'],
    'lokta-leaf-paper' => ['handmade paper texture', 'paper craft', 'paper sheets'],
    'patan-metalcraft' => ['brass metal craft', 'metalwork'],
    'little-sprouts-toys' => ['wooden car toy', 'wooden toy', 'wooden toys shelf'],
    'himalayan-tea-collective' => ['tea leaves', 'green tea', 'tea garden'],
];
foreach ($makers as $slug => $queries) {
    $q['maker:' . $slug] = [800, 600, $queries];
}

return $q;
