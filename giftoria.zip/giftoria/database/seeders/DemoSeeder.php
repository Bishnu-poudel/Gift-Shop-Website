<?php
declare(strict_types=1);

namespace Database\Seeders;

use App\Core\Database;
use App\Services\InventoryService;
use App\Services\OrderService;
use App\Services\PlaceholderArt;

/**
 * Demo catalogue for local development and acceptance testing.
 * - Products are original placeholder items with generated SVG art (replace before launch).
 * - No reviews or ratings are fabricated; ratings appear only from real, moderated reviews.
 * - Demo customers/staff get random passwords printed once by the CLI (never fixed passwords).
 */
final class DemoSeeder
{
    private array $ids = [];

    private const MAKERS = [
        'kathmandu-felt-studio' => ['Kathmandu Felt Studio', 'Thamel, Kathmandu', 'A women-led studio hand-felting New Zealand and Himalayan wool into toys and decor since 2009.', 1],
        'palpa-dhaka-weavers' => ['Palpa Dhaka Weavers', 'Tansen, Palpa', 'A cooperative of weavers keeping the dhaka handloom tradition alive, one patterned metre at a time.', 1],
        'lokta-leaf-paper' => ['Lokta Leaf Paper Co.', 'Bhaktapur', 'Paper made by hand from the bark of the Himalayan lokta bush, harvested so the plant regrows.', 1],
        'patan-metalcraft' => ['Patan Metalcraft', 'Patan, Lalitpur', 'Third-generation metalworkers hand-hammering brass and silver using lost-wax techniques.', 1],
        'little-sprouts-toys' => ['Little Sprouts Toys', 'Pokhara, Kaski', 'Wooden toys finished with child-safe, water-based paints and tested against EN 71 guidance.', 0],
        'himalayan-tea-collective' => ['Himalayan Tea Collective', 'Ilam', 'Small-holder tea gardens in Ilam sharing orthodox teas grown above 1,200 metres.', 0],
    ];

    /**
     * [sku, name, category, price, sale, recipients, occasions, interests, prefs, ageMin, ageMax, smallParts,
     *  personalization [label, maxChars]|null, maker, motif, stock, flags (f=featured b=bestseller), leadDays, valleyOnly, short, materials]
     */
    private function products(): array
    {
        $babies = ['baby-girl', 'baby-boy'];
        return [
            ['GFT-1001', 'Rani the Rag Doll', 'dolls-plush', 1450, null, ['baby-girl', 'child'], ['birthday', 'first-birthday', 'naming-ceremony'], ['dolls', 'handmade-products', 'stuffed-animals'], ['handmade', 'sentimental'], 6, 60, 0, null, 'kathmandu-felt-studio', 'heart', 18, 'fb', 0, 0, 'A soft, hand-stitched cotton doll in a tiny sari — gentle enough for small hands, with embroidered (not button) eyes.', 'Organic cotton, wool felt'],
            ['GFT-1002', 'Little Princess Felt Crown & Wand Set', 'dolls-plush', 1250, 990, ['baby-girl', 'child'], ['first-birthday', 'birthday'], ['princess-toys', 'handmade-products'], ['handmade', 'ready-to-gift'], 12, 72, 0, null, 'kathmandu-felt-studio', 'star', 25, 'b', 0, 0, 'A soft felt crown with an adjustable elastic band and a padded star wand for royal dress-up days.', 'Wool felt, elastic'],
            ['GFT-1003', 'Organic Cotton Elephant Plush', 'baby-essentials', 1800, null, $babies, ['birth-celebration', 'baby-shower', 'naming-ceremony', 'first-birthday'], ['stuffed-animals', 'sustainable-gifts'], ['eco-friendly', 'ready-to-gift'], 0, 36, 0, null, 'kathmandu-felt-studio', 'heart', 30, 'fb', 0, 0, 'A floppy-eared elephant made from GOTS-certified cotton and filled with washable fibre.', 'Organic cotton'],
            ['GFT-1004', 'Wooden Shape Sorter & Stacker', 'learning-toys', 2200, null, $babies, ['first-birthday', 'birthday'], ['educational-toys', 'building-blocks'], ['educational', 'eco-friendly'], 12, 36, 0, null, 'little-sprouts-toys', 'boxes', 22, 'b', 0, 0, 'Chunky, oversized shapes that build hand–eye coordination — every piece is larger than a choke-test cylinder.', 'Sustainably sourced pine, water-based paint'],
            ['GFT-1005', 'My First Nepali Alphabet Board Book', 'books-stationery', 650, null, ['baby-girl', 'baby-boy', 'child'], ['first-birthday', 'naming-ceremony', 'birthday'], ['books-storytelling', 'educational-toys'], ['educational'], 6, 48, 0, null, null, 'file', 40, 'b', 0, 0, 'Bright, wipe-clean pages introducing क to ज्ञ with friendly illustrations.', 'Board book, soy inks'],
            ['GFT-1006', 'Personalized Wooden Name Puzzle', 'keepsakes', 2400, null, ['baby-girl', 'baby-boy', 'child'], ['first-birthday', 'birthday', 'naming-ceremony'], ['educational-toys', 'personalized-keepsakes', 'games-puzzles'], ['personalized', 'educational', 'sentimental'], 12, 72, 0, ['Child’s name (letters only)', 10], 'little-sprouts-toys', 'pen', 15, 'f', 3, 0, 'Their name as chunky, peg-free letters cut from solid wood — a puzzle today, a keepsake forever.', 'Solid wood, water-based paint'],
            ['GFT-1007', 'Musical Rattle & Teether Duo', 'baby-essentials', 850, null, $babies, ['birth-celebration', 'baby-shower'], ['music', 'educational-toys'], ['practical'], 3, 18, 0, null, 'little-sprouts-toys', 'bell', 35, '', 0, 0, 'A soft chime rattle and a food-grade silicone teether, sized for first grasps.', 'Beech wood, food-grade silicone'],
            ['GFT-1008', 'Princess Wooden Tea Party Set', 'learning-toys', 2450, null, ['baby-girl', 'child'], ['birthday', 'festival'], ['princess-toys', 'educational-toys'], ['educational'], 24, 96, 0, null, 'little-sprouts-toys', 'cake', 12, '', 0, 0, 'A painted teapot, cups and cakes for pretend tea parties. Suitable from two years.', 'Wood, water-based paint'],
            ['GFT-1009', 'Soft Fabric Tea Party Set', 'dolls-plush', 1650, null, ['baby-girl', 'baby-boy', 'child'], ['first-birthday', 'birthday'], ['princess-toys', 'educational-toys', 'stuffed-animals'], ['educational', 'handmade'], 12, 48, 0, null, 'kathmandu-felt-studio', 'cake', 20, 'f', 0, 0, 'A squishy felt teapot, cups and biscuits for safe first pretend play — no hard edges.', 'Wool felt, cotton'],
            ['GFT-1010', 'Hand-knitted Baby Booties & Hat', 'baby-essentials', 1100, null, $babies, ['birth-celebration', 'baby-shower', 'naming-ceremony'], ['handmade-products', 'fashion'], ['handmade', 'practical', 'sentimental'], 0, 12, 0, null, 'kathmandu-felt-studio', 'heart', 16, '', 0, 0, 'Warm merino booties and a matching bonnet, knitted by hand in soft neutrals.', 'Merino wool'],
            ['GFT-1011', "Baby's First Year Memory Book", 'keepsakes', 1350, null, $babies, ['birth-celebration', 'baby-shower', 'first-birthday'], ['books-storytelling', 'personalized-keepsakes'], ['sentimental', 'personalized'], 0, 24, 0, ['Baby’s name for the cover', 20], 'lokta-leaf-paper', 'file', 24, 'b', 2, 0, 'Prompts for firsts, milestones and festivals, bound in handmade lokta paper.', 'Lokta paper, cotton thread'],
            ['GFT-1012', 'Action Hero Figure Set (5 pieces)', 'learning-toys', 1850, null, ['child'], ['birthday'], ['action-figures'], ['funny'], 48, 144, 1, null, null, 'zap', 20, '', 0, 0, 'Five poseable heroes with swappable accessories. Contains small parts — not for children under 3.', 'ABS plastic'],
            ['GFT-1013', 'Engravable Silver Baby Bangle', 'jewelry-accessories', 3800, null, $babies, ['naming-ceremony', 'birth-celebration', 'first-birthday'], ['jewelry', 'personalized-keepsakes'], ['personalized', 'luxury', 'sentimental'], 0, 36, 0, ['Initials or date', 12], 'patan-metalcraft', 'sparkles', 10, 'f', 3, 0, 'A smooth, adjustable sterling silver bangle — a traditional keepsake for a naming ceremony.', '925 sterling silver'],
            ['GFT-1014', 'Rainbow Stacking Rings', 'learning-toys', 950, null, $babies, ['first-birthday', 'birthday', 'birth-celebration'], ['educational-toys', 'building-blocks'], ['educational'], 6, 36, 0, null, 'little-sprouts-toys', 'boxes', 28, 'b', 0, 0, 'Seven graduated rings in soft rainbow tones to sort, stack and nibble.', 'Beech wood, water-based paint'],
            ['GFT-1015', 'Folk Tales of Nepal Picture Book', 'books-stationery', 950, null, ['child'], ['birthday', 'dashain', 'tihar'], ['books-storytelling'], ['educational'], 36, 120, 0, null, null, 'file', 26, '', 0, 0, 'Twelve beloved folk tales retold for bedtime with lush illustrations.', 'Hardback'],
            ['GFT-1016', 'Fairy Lights Princess Canopy', 'kids-room', 4200, null, ['child'], ['birthday'], ['princess-toys', 'home-decor'], ['luxury'], 36, 144, 0, null, null, 'star', 8, '', 2, 1, 'A cotton voile canopy with warm LED fairy lights for a dreamy reading nook.', 'Cotton voile, LED lights'],
            ['GFT-1017', 'Toddler Activity Busy Board', 'learning-toys', 2350, null, ['baby-girl', 'baby-boy', 'child'], ['first-birthday', 'birthday'], ['educational-toys'], ['educational', 'handmade'], 12, 48, 0, null, 'little-sprouts-toys', 'grip', 14, 'f', 1, 0, 'Latches, spinners and zips fixed securely to a sanded board — busy hands, calm minds.', 'Plywood, fixed hardware'],
            ['GFT-1018', 'Felt Animal Finger Puppets (Set of 5)', 'dolls-plush', 750, null, ['baby-girl', 'baby-boy', 'child'], ['birthday', 'first-birthday'], ['stuffed-animals', 'books-storytelling', 'educational-toys'], ['handmade'], 12, 72, 0, null, 'kathmandu-felt-studio', 'hand', 40, '', 0, 0, 'A yak, tiger, rhino, red panda and danphe for storytelling and giggles.', 'Wool felt'],
            ['GFT-1019', 'Birthday Girl Gift Box: Doll, Book & Bib', 'gift-boxes', 2490, null, ['baby-girl'], ['first-birthday', 'birthday'], ['gift-hampers', 'dolls', 'books-storytelling'], ['ready-to-gift', 'sentimental'], 12, 36, 0, null, 'kathmandu-felt-studio', 'gift', 12, 'fb', 1, 0, 'A ready-wrapped box with a mini rag doll, a board book and an embroidered bib.', 'Mixed'],
            ['GFT-1020', 'Junior Scientist Volcano Kit', 'learning-toys', 1650, null, ['child'], ['birthday'], ['science-stem', 'educational-toys'], ['educational', 'funny'], 96, 144, 1, null, null, 'zap', 18, '', 0, 0, 'Build and erupt your own volcano, then dig for crystals. Adult supervision required.', 'Plaster, non-toxic powders'],
            ['GFT-1021', 'Coding Robot Starter Kit', 'tech-gadgets', 6900, null, ['child', 'teenager'], ['birthday', 'graduation'], ['technology', 'science-stem'], ['educational'], 96, 180, 1, null, null, 'zap', 9, '', 0, 0, 'A buildable robot programmed with picture blocks, growing into Python as skills grow.', 'Electronics, ABS'],
            ['GFT-1022', 'Watercolour Artist Set in Tin', 'books-stationery', 1890, null, ['child', 'teenager', 'anyone-else', 'friend'], ['birthday', 'just-because'], ['arts-crafts'], ['practical'], 72, null, 0, null, null, 'pen', 21, '', 0, 0, '24 artist-grade pans, two brushes and a lokta sketch pad in a keepsake tin.', 'Pigments, lokta paper'],
            ['GFT-1023', 'Himalayan Trails Strategy Board Game', 'games-puzzles', 2800, null, ['teenager', 'friend', 'couple', 'anyone-else'], ['birthday', 'just-because', 'festival', 'dashain', 'tihar'], ['games-puzzles'], ['funny'], 120, null, 1, null, null, 'map-pin', 15, 'b', 0, 0, 'Race to base camp, trade supplies and outwit the weather in 45 minutes.', 'Card, wood'],
            ['GFT-1024', '1000-Piece Jigsaw: Kathmandu Rooftops', 'games-puzzles', 1950, null, ['anyone-else', 'grandparent', 'couple', 'friend'], ['just-because', 'festival', 'dashain'], ['games-puzzles'], ['practical'], 144, null, 1, null, null, 'grip', 19, '', 0, 0, 'A slow afternoon of pagodas, prayer flags and pigeons — finished size 68 × 49 cm.', 'Recycled board'],
            ['GFT-1025', 'Teen Journal & Gel Pen Kit', 'books-stationery', 1250, null, ['teenager', 'sister'], ['birthday', 'graduation'], ['arts-crafts', 'books-storytelling'], ['practical'], 120, null, 0, null, 'lokta-leaf-paper', 'pen', 30, '', 0, 0, 'A dotted lokta journal, washi tapes and 12 gel pens for lists, doodles and plans.', 'Lokta paper'],
            ['GFT-1026', "Kids' Personalized Backpack", 'kids-room', 2600, null, ['child'], ['birthday'], ['fashion', 'personalized-keepsakes'], ['personalized', 'practical'], 36, 120, 0, ['Name to embroider', 12], null, 'bag', 17, '', 3, 0, 'A sturdy canvas backpack embroidered with their name — school-run ready.', 'Recycled canvas'],
            ['GFT-1027', 'Glow Star Night Projector', 'tech-gadgets', 2100, null, ['child', 'teenager'], ['birthday'], ['technology', 'home-decor'], ['practical'], 36, null, 0, null, null, 'star', 13, '', 0, 0, 'Projects a slowly turning starry sky with a 30-minute auto-off timer.', 'ABS, LED'],
            ['GFT-1028', 'Handwoven Dhaka Shawl', 'jewelry-accessories', 4500, 3990, ['mother', 'wife', 'grandparent', 'sister', 'girlfriend'], ['mothers-day', 'birthday', 'dashain', 'tihar', 'anniversary', 'wedding'], ['fashion', 'handmade-products'], ['handmade', 'luxury'], 216, null, 0, null, 'palpa-dhaka-weavers', 'tag', 14, 'fb', 0, 0, 'Hand-loomed on a traditional pit loom in Palpa — each geometric pattern is unique.', 'Cotton dhaka'],
            ['GFT-1029', 'Handmade Lokta Paper Journal', 'books-stationery', 950, null, ['teacher', 'colleague', 'friend', 'sister', 'brother', 'teenager', 'anyone-else'], ['thank-you', 'graduation', 'birthday', 'corporate-gifting'], ['books-storytelling', 'handmade-products', 'sustainable-gifts'], ['handmade', 'eco-friendly', 'practical'], 120, null, 0, null, 'lokta-leaf-paper', 'file', 45, 'b', 0, 0, 'Deckle-edged lokta pages bound with a wrap-around cord — tree-free and made to last.', 'Lokta paper'],
            ['GFT-1030', 'Himalayan Tea Tasting Box', 'gift-boxes', 2200, null, ['father', 'mother', 'colleague', 'grandparent', 'teacher', 'anyone-else'], ['thank-you', 'corporate-gifting', 'dashain', 'tihar', 'fathers-day', 'housewarming'], ['cooking', 'gift-hampers'], ['ready-to-gift', 'practical'], 216, null, 0, null, 'himalayan-tea-collective', 'gift', 40, 'fb', 0, 0, 'Six single-estate Ilam teas with a tasting card, packed in a reusable tin.', 'Tea, tin'],
            ['GFT-1031', 'Engraved Wooden Photo Frame', 'engraved', 1850, null, ['couple', 'mother', 'father', 'wife', 'husband', 'grandparent'], ['anniversary', 'wedding', 'mothers-day', 'fathers-day'], ['personalized-keepsakes', 'home-decor'], ['personalized', 'sentimental'], 216, null, 0, ['Engraving (names or a date)', 40], null, 'image', 22, '', 2, 0, 'A walnut-stained frame laser-engraved with your words. Fits a 5 × 7 in photo.', 'Walnut veneer'],
            ['GFT-1032', 'Silver Filigree Earrings', 'jewelry-accessories', 5500, null, ['wife', 'girlfriend', 'mother', 'sister'], ['anniversary', 'valentines-day', 'birthday', 'tihar'], ['jewelry'], ['luxury', 'handmade'], 216, null, 0, null, 'patan-metalcraft', 'sparkles', 9, 'f', 0, 0, 'Delicate drop earrings hand-twisted from fine silver wire in Patan.', '925 sterling silver'],
            ['GFT-1033', 'Brass Diyo Set for Tihar (Set of 5)', 'decor', 1450, null, ['anyone-else', 'mother', 'grandparent', 'couple', 'colleague'], ['tihar', 'festival', 'housewarming'], ['home-decor', 'handmade-products'], ['handmade'], 216, null, 0, null, 'patan-metalcraft', 'sparkles', 60, 'b', 0, 0, 'Hand-cast brass oil lamps to light up doorways and windows for Tihar.', 'Brass'],
            ['GFT-1034', 'Dashain Celebration Hamper', 'gift-boxes', 5800, 5200, ['anyone-else', 'father', 'mother', 'grandparent', 'colleague'], ['dashain', 'festival', 'corporate-gifting'], ['gift-hampers', 'cooking'], ['ready-to-gift', 'luxury'], 216, null, 0, null, 'himalayan-tea-collective', 'gift', 20, 'f', 1, 1, 'Dry fruits, Ilam tea, sel roti mix and a brass tika plate in a woven basket.', 'Mixed'],
            ['GFT-1035', 'Hand-hammered Singing Bowl (5 in)', 'decor', 3200, null, ['father', 'grandparent', 'friend', 'colleague', 'anyone-else'], ['housewarming', 'thank-you', 'just-because'], ['beauty-wellness', 'music', 'handmade-products'], ['handmade'], 216, null, 0, null, 'patan-metalcraft', 'bell', 12, '', 0, 0, 'A seven-metal bowl with a felted striker and cushion for meditation and calm.', 'Bell metal alloy'],
            ['GFT-1036', 'Leather Wallet with Initials', 'engraved', 2900, null, ['father', 'husband', 'boyfriend', 'brother'], ['fathers-day', 'birthday', 'anniversary', 'valentines-day'], ['fashion', 'personalized-keepsakes'], ['personalized', 'practical'], 216, null, 0, ['Initials (up to 3 letters)', 3], null, 'card', 25, 'b', 2, 0, 'Slim, full-grain leather bifold embossed with their initials.', 'Full-grain leather'],
            ['GFT-1037', 'Ceramic Pour-over Coffee Set', 'kitchen-dining', 3600, null, ['husband', 'boyfriend', 'friend', 'colleague', 'couple'], ['housewarming', 'birthday', 'just-because'], ['cooking'], ['practical'], 216, null, 0, null, null, 'cake', 11, '', 0, 0, 'A stoneware dripper, server and two cups glazed in speckled sand.', 'Stoneware'],
            ['GFT-1038', 'Succulent Trio in Clay Pots', 'garden-outdoors', 1350, null, ['anyone-else', 'mother', 'friend', 'colleague', 'teacher'], ['housewarming', 'thank-you', 'just-because'], ['gardening', 'home-decor', 'sustainable-gifts'], ['eco-friendly'], 156, null, 0, null, null, 'leaf', 30, '', 0, 1, 'Three easy-care succulents in hand-thrown terracotta. Delivered inside Kathmandu Valley only.', 'Live plants, terracotta'],
            ['GFT-1039', 'Kitchen Herb Garden Starter Kit', 'garden-outdoors', 1650, null, ['mother', 'grandparent', 'couple', 'anyone-else'], ['housewarming', 'mothers-day'], ['gardening', 'cooking', 'sustainable-gifts'], ['eco-friendly', 'educational'], 120, null, 0, null, null, 'leaf', 24, '', 0, 0, 'Coriander, basil and mint seeds with coir pots and a growing guide.', 'Coir, seeds'],
            ['GFT-1040', 'Aromatherapy Spa Gift Box', 'wellness-beauty', 3400, null, ['mother', 'wife', 'girlfriend', 'sister', 'friend'], ['mothers-day', 'birthday', 'valentines-day', 'just-because'], ['beauty-wellness', 'gift-hampers'], ['luxury', 'ready-to-gift'], 216, null, 0, null, null, 'sparkles', 18, 'fb', 0, 0, 'Himalayan wintergreen oil, a soy candle, bath salts and a cotton face cloth.', 'Mixed'],
            ['GFT-1041', 'Himalayan Salt Lamp', 'decor', 2500, null, ['anyone-else', 'colleague', 'friend'], ['housewarming', 'just-because'], ['home-decor', 'beauty-wellness'], ['practical'], 216, null, 0, null, null, 'home', 16, '', 0, 1, 'A warm amber glow from a hand-carved salt crystal on a sheesham base.', 'Rock salt, sheesham'],
            ['GFT-1042', "Couples' Cooking Class Voucher", 'experiences', 4800, null, ['couple', 'wife', 'husband', 'girlfriend', 'boyfriend'], ['anniversary', 'valentines-day', 'wedding'], ['experiences', 'cooking'], ['sentimental'], 216, null, 0, null, null, 'calendar', 50, '', 0, 1, 'A three-hour momo and achar class for two in Jhamsikhel. Valid 6 months.', 'Voucher'],
            ['GFT-1043', 'Recycled Fabric Trekking Day-Pack', 'garden-outdoors', 4200, null, ['brother', 'boyfriend', 'husband', 'friend', 'teenager'], ['birthday', 'graduation'], ['outdoor-activities', 'sports', 'sustainable-gifts'], ['practical', 'eco-friendly'], 156, null, 0, null, null, 'map-pin', 14, '', 0, 0, 'A 22-litre pack made from recycled PET with a rain cover and hip belt.', 'Recycled PET'],
            ['GFT-1044', 'Cork Yoga Mat & Strap Set', 'wellness-beauty', 3900, null, ['wife', 'sister', 'friend', 'mother'], ['birthday', 'just-because'], ['sports', 'beauty-wellness', 'sustainable-gifts'], ['eco-friendly', 'practical'], 156, null, 0, null, null, 'leaf', 12, '', 0, 0, 'A grippy natural-cork mat with a cotton carry strap.', 'Cork, natural rubber'],
            ['GFT-1045', 'Wooden Wireless Charging Stand', 'tech-gadgets', 3300, null, ['colleague', 'husband', 'brother', 'father', 'boyfriend'], ['corporate-gifting', 'birthday', 'graduation'], ['technology'], ['practical'], 156, null, 0, null, null, 'zap', 20, '', 0, 0, 'A 15 W Qi charger set in solid walnut. Works with most modern phones.', 'Walnut, electronics'],
            ['GFT-1046', '“Chiya First” Funny Mug', 'kitchen-dining', 650, null, ['colleague', 'friend', 'brother', 'sister', 'teacher', 'anyone-else'], ['just-because', 'birthday', 'thank-you'], ['cooking'], ['funny', 'practical'], 156, null, 0, null, null, 'cake', 55, 'b', 0, 0, 'Because nothing happens before the first cup. Dishwasher safe.', 'Ceramic'],
            ['GFT-1047', 'Personalized Star Map Print', 'keepsakes', 3500, null, ['couple', 'wife', 'husband', 'girlfriend', 'boyfriend'], ['anniversary', 'wedding', 'valentines-day'], ['personalized-keepsakes', 'home-decor'], ['personalized', 'sentimental'], 216, null, 0, ['Date and place (e.g. 12 Feb 2022, Pokhara)', 60], null, 'star', 30, 'f', 3, 0, 'The night sky exactly as it was on your special date, printed on archival paper and framed.', 'Archival paper, wood frame'],
            ['GFT-1048', 'Corporate Desk Gift Set', 'gift-boxes', 1950, null, ['colleague', 'teacher'], ['corporate-gifting', 'thank-you'], ['books-storytelling', 'gift-hampers'], ['practical', 'ready-to-gift'], 216, null, 0, null, 'lokta-leaf-paper', 'card', 80, '', 0, 0, 'A lokta notebook, brass pen and Ilam tea sachets in a branded-ready box.', 'Mixed'],
            ['GFT-1049', 'Embroidered Pet Portrait Hoop', 'keepsakes', 2800, null, ['pet-lover'], ['birthday', 'just-because'], ['personalized-keepsakes', 'handmade-products', 'home-decor'], ['personalized', 'handmade'], 156, null, 0, ['Pet’s name (send the photo after ordering)', 20], 'kathmandu-felt-studio', 'leaf', 10, '', 7, 0, 'Their best friend, hand-embroidered from your photo in an 8-inch hoop.', 'Cotton, bamboo hoop'],
            ['GFT-1050', 'Handmade Dog Collar with Name Tag', 'keepsakes', 1200, null, ['pet-lover'], ['just-because', 'birthday'], ['personalized-keepsakes', 'handmade-products'], ['personalized', 'handmade'], 156, null, 0, ['Name for the tag', 12], 'palpa-dhaka-weavers', 'leaf', 25, '', 2, 0, 'A dhaka-woven collar with an engraved brass tag. Sizes S–L.', 'Dhaka cotton, brass'],
            ['GFT-1051', "Teacher's Thank-You Planter", 'keepsakes', 990, null, ['teacher'], ['thank-you', 'graduation'], ['gardening', 'personalized-keepsakes'], ['sentimental', 'personalized'], 216, null, 0, ['Message (e.g. Thank you, Miss Sita!)', 30], null, 'leaf', 30, '', 2, 0, 'A glazed planter printed with your message and a hardy money plant cutting.', 'Ceramic'],
            ['GFT-1052', 'Engraved Graduation Pen in Gift Case', 'engraved', 2700, null, ['teenager', 'friend', 'brother', 'sister', 'colleague'], ['graduation'], ['personalized-keepsakes'], ['personalized', 'luxury'], 156, null, 0, ['Name or message', 25], null, 'pen', 26, '', 2, 0, 'A weighted brass rollerball engraved for the new graduate.', 'Brass'],
            ['GFT-1053', 'Rosewood Wedding Keepsake Box', 'keepsakes', 4900, null, ['couple'], ['wedding', 'anniversary'], ['personalized-keepsakes', 'home-decor', 'handmade-products'], ['luxury', 'sentimental', 'handmade', 'personalized'], 216, null, 0, ['Names and wedding date', 40], 'patan-metalcraft', 'heart', 8, 'f', 4, 0, 'A hand-carved rosewood box for cards, tika and memories, engraved on the lid.', 'Rosewood, brass'],
            ['GFT-1054', 'Grandparents’ Memory Photo Album', 'keepsakes', 2300, null, ['grandparent'], ['birthday', 'festival', 'dashain'], ['personalized-keepsakes', 'books-storytelling'], ['sentimental', 'personalized'], 216, null, 0, ['Cover title', 30], 'lokta-leaf-paper', 'image', 15, '', 2, 0, 'A lokta-paper album with prompts for family stories and space for 60 photos.', 'Lokta paper'],
            ['GFT-1055', 'Valentine Chocolate & Rose Box', 'gift-boxes', 2400, null, ['wife', 'girlfriend', 'husband', 'boyfriend'], ['valentines-day', 'anniversary'], ['gift-hampers', 'cooking'], ['ready-to-gift'], 216, null, 0, null, null, 'heart', 30, '', 0, 1, 'Hand-made truffles and a preserved rose. Delivered inside Kathmandu Valley.', 'Chocolate, preserved rose'],
            ['GFT-1056', 'Luxury Pashmina Stole', 'jewelry-accessories', 12500, null, ['mother', 'wife', 'grandparent'], ['wedding', 'anniversary', 'dashain', 'mothers-day'], ['fashion', 'handmade-products'], ['luxury', 'handmade'], 216, null, 0, null, 'palpa-dhaka-weavers', 'tag', 6, '', 0, 0, 'Featherlight hand-woven pashmina in deep saffron, finished with hand-twisted fringe.', '100% pashmina'],
            ['GFT-1057', 'Smart Fitness Band', 'tech-gadgets', 8900, null, ['father', 'husband', 'brother', 'boyfriend', 'friend'], ['birthday', 'fathers-day', 'graduation'], ['technology', 'sports'], ['practical'], 156, null, 0, null, null, 'zap', 10, '', 0, 0, 'Heart-rate, sleep and step tracking with a 10-day battery.', 'Electronics'],
            ['GFT-1058', 'Non-stick Cookware Set', 'kitchen-dining', 7800, null, ['mother', 'couple'], ['housewarming', 'wedding'], ['cooking'], ['practical'], 216, null, 0, null, null, 'home', 7, '', 0, 0, 'A frying pan, saucepan and kadhai with PFOA-free ceramic coating.', 'Aluminium, ceramic coating'],
            ['GFT-1059', 'Anytime Snack & Tea Hamper', 'gift-boxes', 1800, null, ['anyone-else', 'colleague', 'friend'], ['just-because', 'thank-you', 'corporate-gifting', 'festival'], ['gift-hampers', 'cooking'], ['ready-to-gift'], 36, null, 0, null, 'himalayan-tea-collective', 'gift', 35, 'b', 0, 0, 'Spiced nuts, chiura crackers and Ilam tea — a cheerful thank-you for anyone.', 'Mixed'],
            ['GFT-1060', 'Bamboo Eco Bathroom Kit', 'wellness-beauty', 750, null, ['anyone-else', 'friend', 'sister'], ['just-because'], ['sustainable-gifts', 'beauty-wellness'], ['eco-friendly', 'practical'], 36, null, 0, null, null, 'leaf', 40, '', 0, 0, 'Bamboo toothbrushes, a loofah and handmade soap in a cotton pouch.', 'Bamboo, cotton'],
            ['GFT-1061', 'Dress-up Princess Gown', 'kids-room', 2200, null, ['child'], ['birthday', 'festival'], ['princess-toys', 'fashion'], ['funny'], 36, 96, 0, null, null, 'star', 15, '', 0, 0, 'A twirly tulle gown with a soft cotton lining. Sizes 3–8 years.', 'Tulle, cotton'],
        ];
    }

    public function run(bool $withStaff = false): array
    {
        $log = [];
        if ((int) Database::fetchColumn('SELECT COUNT(*) FROM products') > 0) {
            return ['Demo products already exist — skipped.'];
        }
        $this->loadIds();
        foreach (self::MAKERS as $slug => [$name, $loc, $story, $featured]) {
            Database::insert('makers', ['name' => $name, 'slug' => $slug, 'location' => $loc, 'story' => $story, 'is_featured' => $featured, 'image' => 'assets/images/makers/' . $slug . '.svg']);
        }
        $makerIds = array_column(Database::fetchAll('SELECT id, slug FROM makers'), 'id', 'slug');
        $inventory = new InventoryService();

        foreach ($this->products() as $i => $row) {
            [$sku, $name, $cat, $price, $sale, $recips, $occs, $ints, $prefs, $ageMin, $ageMax, $small, $pers, $maker, $motif, $stock, $flags, $lead, $valley, $short, $materials] = $row;
            $slug = str_slug($name);
            $pid = Database::insert('products', [
                'sku' => $sku, 'name' => $name, 'slug' => $slug,
                'short_description' => $short,
                'description' => $short . "\n\nEvery " . setting('store_name', 'Giftoria') . " gift is checked by hand before it is packed. Add gift wrapping and a handwritten note at checkout.",
                'price' => $price, 'sale_price' => $sale, 'cost_price' => round($price * 0.55, 2),
                'category_id' => $this->ids['categories'][$cat] ?? null,
                'maker_id' => $maker ? (int) $makerIds[$maker] : null,
                'materials' => $materials,
                'age_min_months' => $ageMin, 'age_max_months' => $ageMax, 'has_small_parts' => $small,
                'safety_info' => $ageMax !== null && $ageMax <= 48
                    ? 'Tested for ages ' . age_range_label($ageMin, $ageMax) . ' per the manufacturer. Always supervise young children during play.'
                    : ($small ? 'Contains small parts. Not suitable for children under 3 years — choking hazard.' : null),
                'gender_neutral' => count(array_intersect($recips, ['baby-girl', 'baby-boy'])) === 1 ? 0 : 1,
                'is_personalizable' => $pers ? 1 : 0,
                'personalization_label' => $pers[0] ?? null,
                'personalization_max_chars' => $pers[1] ?? null,
                'gift_wrap_available' => 1,
                'valley_only' => $valley,
                'delivery_restrictions' => $valley ? 'Delivered inside Kathmandu Valley only.' : null,
                'lead_time_days' => $lead,
                'status' => 'active',
                'is_featured' => str_contains($flags, 'f') ? 1 : 0,
                'is_bestseller' => str_contains($flags, 'b') ? 1 : 0,
                'seo_title' => $name . ' — Gift',
                'seo_description' => $short,
                'created_at' => gmdate('Y-m-d H:i:s', time() - (61 - $i) * 86400 * 2),
            ]);
            PlaceholderArt::write('uploads/products/demo/' . $slug . '.svg', $sku, $motif);
            Database::insert('product_images', ['product_id' => $pid, 'path' => 'uploads/products/demo/' . $slug . '.svg', 'alt' => $name, 'sort_order' => 0]);
            PlaceholderArt::write('uploads/products/demo/' . $slug . '-2.svg', $sku . 'b', $motif === 'gift' ? 'heart' : 'gift');
            Database::insert('product_images', ['product_id' => $pid, 'path' => 'uploads/products/demo/' . $slug . '-2.svg', 'alt' => $name . ' — gift wrapped', 'sort_order' => 1]);
            Database::insert('product_attributes', ['product_id' => $pid, 'name' => 'Materials', 'value' => $materials, 'sort_order' => 0]);
            if ($ageMin !== null) {
                Database::insert('product_attributes', ['product_id' => $pid, 'name' => 'Recommended age', 'value' => age_range_label($ageMin, $ageMax), 'sort_order' => 1]);
            }
            foreach ($recips as $s) {
                Database::insert('product_recipients', ['product_id' => $pid, 'recipient_id' => $this->ids['recipients'][$s]]);
            }
            foreach ($occs as $s) {
                Database::insert('product_occasions', ['product_id' => $pid, 'occasion_id' => $this->ids['occasions'][$s]]);
            }
            foreach ($ints as $s) {
                Database::insert('product_interests', ['product_id' => $pid, 'interest_id' => $this->ids['interests'][$s]]);
            }
            foreach ($prefs as $s) {
                Database::insert('product_tags', ['product_id' => $pid, 'tag_id' => $this->ids['tags'][$s]]);
            }
            $inventory->change($pid, 0, $stock, 'initial', 'seed', null, null, 'Demo stock');
            Database::query('UPDATE inventory SET low_stock_threshold = :t WHERE product_id = :p', ['t' => 5, 'p' => $pid]);
        }

        // Variants for two products (each variant has its own stock).
        $this->variants('GFT-1001', [['Pink sari', 'GFT-1001-PNK', 0, 8], ['Blue kurta', 'GFT-1001-BLU', 0, 6]], $inventory);
        $this->variants('GFT-1028', [['Crimson', 'GFT-1028-CRM', 0, 5], ['Teal', 'GFT-1028-TEA', 0, 4], ['Saffron', 'GFT-1028-SAF', 250, 3]], $inventory);
        // One item intentionally down to its last unit (for the overselling test).
        $last = (int) Database::fetchColumn("SELECT id FROM products WHERE sku = 'GFT-1053'");
        $inventory->setQuantity($last, 0, 1, null, 'Demo: last unit');

        $log[] = 'Seeded ' . count($this->products()) . ' demo products with generated artwork.';

        // Demo campaign + coupon
        $couponId = Database::insert('coupons', ['code' => 'WELCOME10', 'description' => '10% off your first order (max NPR 500)', 'type' => 'percent', 'value' => 10, 'min_subtotal' => 1000, 'max_discount' => 500, 'per_customer_limit' => 1, 'is_active' => 1]);
        Database::insert('coupons', ['code' => 'FREESHIP', 'description' => 'Free delivery over NPR 2,000', 'type' => 'free_shipping', 'value' => 0, 'min_subtotal' => 2000, 'is_active' => 1]);
        $ids = Database::fetchCol("SELECT p.id FROM products p JOIN product_occasions po ON po.product_id = p.id JOIN occasions o ON o.id = po.occasion_id WHERE o.slug IN ('tihar','dashain') GROUP BY p.id LIMIT 12");
        Database::insert('campaigns', [
            'name' => 'Festival edit', 'slug' => 'festival-edit', 'type' => 'seasonal', 'headline' => 'The festival gifting edit',
            'subheadline' => 'Diyos, hampers and keepsakes for Dashain and Tihar — wrapped and ready.', 'body' => "Celebrate the season with gifts made by Nepali artisans.\n\nUse code WELCOME10 for 10% off your first order.",
            'image' => 'assets/images/collections/campaign-tihar.svg', 'cta_label' => 'Shop the edit', 'cta_url' => '/campaign/festival-edit',
            'coupon_id' => $couponId, 'product_ids' => implode(',', $ids), 'theme_color' => '#b4532a', 'is_active' => 1,
        ]);

        // Demo customers (random passwords, shown once).
        $customers = [['Asha Shrestha', 'asha.demo@example.com', 'Lalitpur'], ['Bikash Gurung', 'bikash.demo@example.com', 'Kaski']];
        $customerIds = [];
        foreach ($customers as [$name, $email, $district]) {
            $password = rtrim(strtr(base64_encode(random_bytes(12)), '+/', 'Aa'), '=');
            $uid = Database::insert('users', ['type' => 'customer', 'name' => $name, 'email' => $email, 'password_hash' => password_hash($password, PASSWORD_DEFAULT), 'status' => 'active', 'email_verified_at' => gmdate('Y-m-d H:i:s'), 'phone' => '98' . random_int(10000000, 49999999)]);
            Database::insert('customer_profiles', ['user_id' => $uid, 'marketing_opt_in' => 1]);
            Database::insert('wishlists', ['user_id' => $uid, 'name' => 'My Wishlist']);
            Database::insert('addresses', ['user_id' => $uid, 'label' => 'Home', 'full_name' => $name, 'phone' => '9841000000', 'province' => \App\Services\ShippingService::provinceOf($district), 'district' => $district, 'municipality' => $district === 'Lalitpur' ? 'Lalitpur Metropolitan City' : 'Pokhara Metropolitan City', 'ward' => '3', 'street' => 'Demo Street', 'is_default' => 1]);
            $customerIds[] = $uid;
            $log[] = "Demo customer: $email / $password";
        }

        // Demo orders through the real order service (COD), spread over the last 30 days.
        $orders = new OrderService();
        $productIds = Database::fetchCol("SELECT id FROM products WHERE status = 'active' AND id NOT IN (SELECT product_id FROM product_variants) AND sku <> 'GFT-1053' ORDER BY id");
        mt_srand(42);
        for ($n = 0; $n < 18; $n++) {
            $uid = $customerIds[$n % 2];
            $pick = array_rand(array_flip($productIds), 2);
            $lines = Database::fetchAll(
                'SELECT 0 AS id, p.id AS product_id, 0 AS variant_id, 1 AS quantity, NULL AS personalization, p.status, p.price, p.sale_price, 0 AS price_adjustment,
                        1 AS variant_active, p.allow_backorder, COALESCE(i.quantity,0) AS stock, p.gift_wrap_available, p.lead_time_days, p.valley_only,
                        p.name, p.sku, NULL AS variant_sku, NULL AS variant_name, p.cost_price, p.category_id
                 FROM products p LEFT JOIN inventory i ON i.product_id = p.id AND i.variant_id = 0 WHERE p.id IN (' . (int) $pick[0] . ',' . (int) $pick[1] . ')'
            );
            $addr = Database::fetch('SELECT * FROM addresses WHERE user_id = :u LIMIT 1', ['u' => $uid]);
            $user = Database::fetch('SELECT * FROM users WHERE id = :id', ['id' => $uid]);
            try {
                $order = $orders->place([
                    'customer_name' => $user['name'], 'email' => $user['email'], 'phone' => '9841000000', 'payment_method' => 'cod',
                    'shipping' => $addr, 'billing' => null, 'gift_wrap' => $n % 3 === 0, 'gift_message' => $n % 3 === 0 ? 'Happy birthday!' : '',
                    'requested_delivery_date' => null, 'coupon_code' => null, 'checkout_token' => null, 'user_id' => $uid, 'source' => 'web',
                ], $lines);
            } catch (\Throwable $e) {
                $log[] = 'Demo order skipped: ' . $e->getMessage();
                continue;
            }
            $flow = $n < 10 ? ['processing', 'packed', 'shipped', 'delivered'] : ($n < 14 ? ['processing', 'packed', 'shipped'] : ($n < 16 ? ['processing'] : []));
            foreach ($flow as $to) {
                $orders->transition((int) $order['id'], $to, null, 'Demo data');
            }
            $daysAgo = 30 - $n * 1.6;
            $ts = gmdate('Y-m-d H:i:s', (int) (time() - $daysAgo * 86400));
            Database::query('UPDATE orders SET created_at = :c WHERE id = :id', ['c' => $ts, 'id' => (int) $order['id']]);
            Database::query('UPDATE order_status_history SET created_at = :c WHERE order_id = :id', ['c' => $ts, 'id' => (int) $order['id']]);
        }
        Database::query("DELETE FROM email_outbox WHERE body_html LIKE '%example.com%' OR to_email LIKE '%@example.com'");
        $log[] = 'Created demo orders for the dashboard.';

        if ($withStaff) {
            $roles = ['marketing-staff' => 'Mina Marketing', 'product-manager' => 'Prakash Products', 'sales-manager' => 'Sunita Sales', 'warehouse-staff' => 'Wangdi Warehouse', 'auditor' => 'Anil Auditor'];
            $n = 1;
            foreach ($roles as $slug => $name) {
                $password = rtrim(strtr(base64_encode(random_bytes(12)), '+/', 'Aa'), '=');
                $email = $slug . '.demo@example.com';
                $uid = Database::insert('users', ['type' => 'staff', 'name' => $name, 'email' => $email, 'password_hash' => password_hash($password, PASSWORD_DEFAULT), 'status' => 'active', 'email_verified_at' => gmdate('Y-m-d H:i:s')]);
                Database::insert('staff_profiles', ['user_id' => $uid, 'employee_id' => sprintf('DEMO-%02d', $n++), 'job_title' => $name]);
                Database::insert('user_roles', ['user_id' => $uid, 'role_id' => (int) Database::fetchColumn('SELECT id FROM roles WHERE slug = :s', ['s' => $slug])]);
                $log[] = "Demo staff ($slug): $email / $password";
            }
        }
        return $log;
    }

    private function loadIds(): void
    {
        foreach (['recipients', 'occasions', 'interests', 'categories', 'tags'] as $t) {
            $this->ids[$t] = array_map('intval', array_column(Database::fetchAll("SELECT id, slug FROM `$t`"), 'id', 'slug'));
        }
    }

    private function variants(string $sku, array $variants, InventoryService $inventory): void
    {
        $pid = (int) Database::fetchColumn('SELECT id FROM products WHERE sku = :s', ['s' => $sku]);
        // Base product stock moves to the variants.
        $inventory->setQuantity($pid, 0, 0, null, 'Stock moved to variants');
        foreach ($variants as $i => [$name, $vsku, $adj, $qty]) {
            $vid = Database::insert('product_variants', ['product_id' => $pid, 'sku' => $vsku, 'name' => $name, 'options_json' => json_encode(['Option' => $name]), 'price_adjustment' => $adj, 'sort_order' => $i]);
            $inventory->change($pid, $vid, $qty, 'initial', 'seed', null, null, 'Demo stock');
        }
    }
}
