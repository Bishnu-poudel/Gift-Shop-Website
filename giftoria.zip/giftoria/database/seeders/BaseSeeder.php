<?php
declare(strict_types=1);

namespace Database\Seeders;

use App\Core\Database;

/**
 * Essential configuration data (safe to re-run; existing rows are updated, not duplicated):
 * permissions, roles, gift taxonomies, synonyms, budgets, age ranges, categories, delivery zones,
 * settings, homepage sections and email templates. Contains no demo products or people.
 */
final class BaseSeeder
{
    public function run(): void
    {
        $this->permissionsAndRoles();
        $this->taxonomies();
        $this->categories();
        $this->zones();
        $this->settings();
        $this->homepage();
        $this->emailTemplates();
    }

    private function upsert(string $table, array $row, array $updateCols): void
    {
        $cols = array_keys($row);
        $sets = implode(', ', array_map(static fn ($c) => "`$c` = VALUES(`$c`)", $updateCols));
        Database::query(
            sprintf('INSERT INTO `%s` (%s) VALUES (%s) ON DUPLICATE KEY UPDATE %s', $table,
                implode(', ', array_map(static fn ($c) => "`$c`", $cols)),
                implode(', ', array_map(static fn ($c) => ':' . $c, $cols)),
                $sets ?: '`' . $cols[0] . '` = `' . $cols[0] . '`'),
            $row
        );
    }

    private function permissionsAndRoles(): void
    {
        foreach (config('permissions.permissions') as $group => $perms) {
            foreach ($perms as $slug => $name) {
                $this->upsert('permissions', ['slug' => $slug, 'name' => $name, 'group_name' => $group], ['name', 'group_name']);
            }
        }
        $permIds = [];
        foreach (Database::fetchAll('SELECT id, slug FROM permissions') as $p) {
            $permIds[$p['slug']] = (int) $p['id'];
        }
        foreach (config('permissions.roles') as $slug => [$name, $description, $perms]) {
            $exists = Database::fetchColumn('SELECT id FROM roles WHERE slug = :s', ['s' => $slug]);
            if ($exists) {
                continue; // never overwrite roles an administrator may have customised
            }
            $roleId = Database::insert('roles', ['name' => $name, 'slug' => $slug, 'description' => $description, 'is_system' => 1]);
            foreach ($perms as $p) {
                if ($p !== '*' && isset($permIds[$p])) {
                    Database::insert('role_permissions', ['role_id' => $roleId, 'permission_id' => $permIds[$p]]);
                }
            }
        }
    }

    private function taxonomies(): void
    {
        // slug => [name, audience, age_min, age_max, synonyms]
        $recipients = [
            'baby-girl' => ['Baby girl', 'baby', 0, 24, 'little princess, newborn girl, infant girl, toddler girl, baby daughter, baby granddaughter'],
            'baby-boy' => ['Baby boy', 'baby', 0, 24, 'newborn boy, infant boy, toddler boy, little prince, baby son, baby grandson'],
            'child' => ['Child', 'child', 36, 143, 'kid, kids, children, son, daughter, niece, nephew, little one, boy, girl, grandchild'],
            'teenager' => ['Teenager', 'teen', 156, 215, 'teen, teens, teenage, adolescent, high schooler, teen girl, teen boy'],
            'mother' => ['Mother', 'adult', 216, null, 'mom, mum, mommy, mummy, aama, mother in law, mama, mamu'],
            'father' => ['Father', 'adult', 216, null, 'dad, daddy, papa, buwa, father in law, baba'],
            'sister' => ['Sister', 'adult', null, null, 'didi, bahini, sis, sister in law'],
            'brother' => ['Brother', 'adult', null, null, 'dai, bhai, bro, brother in law'],
            'wife' => ['Wife', 'adult', 216, null, 'spouse, partner, wifey'],
            'husband' => ['Husband', 'adult', 216, null, 'hubby, spouse'],
            'girlfriend' => ['Girlfriend', 'adult', 216, null, 'gf'],
            'boyfriend' => ['Boyfriend', 'adult', 216, null, 'bf'],
            'friend' => ['Friend', 'adult', null, null, 'bestie, best friend, buddy, mate, friends, sathi'],
            'grandparent' => ['Grandparent', 'adult', 216, null, 'grandma, grandpa, grandmother, grandfather, hajurama, hajurbuwa, grandparents, granny'],
            'colleague' => ['Colleague', 'adult', 216, null, 'coworker, co worker, boss, office, employee, client, team'],
            'teacher' => ['Teacher', 'adult', 216, null, 'guru, mentor, professor, tutor, teachers, sir, miss'],
            'couple' => ['Couple', 'adult', 216, null, 'couples, newlyweds, husband and wife, parents, mr and mrs'],
            'pet-lover' => ['Pet lover', 'any', null, null, 'dog lover, cat lover, pet owner, pets, pet, dog, cat'],
            'anyone-else' => ['Anyone else', 'any', null, null, 'anyone, everyone, someone, unisex, all'],
        ];
        $i = 0;
        foreach ($recipients as $slug => [$name, $aud, $min, $max, $syn]) {
            $this->upsert('recipients', ['slug' => $slug, 'name' => $name, 'audience' => $aud, 'age_min_months' => $min, 'age_max_months' => $max, 'synonyms' => $syn, 'sort_order' => $i++, 'image' => 'assets/images/tiles/recipient-' . $slug . '.svg'],
                ['name', 'audience', 'age_min_months', 'age_max_months', 'synonyms', 'image']);
        }

        $occasions = [
            'birthday' => ['Birthday', 'bday, birthday party, happy birthday, birthdays', 0],
            'baby-shower' => ['Baby shower', 'expecting, pregnancy, mom to be, mother to be, dhau', 0],
            'birth-celebration' => ['Birth celebration', 'new baby, birth, welcome baby, new arrival, just born', 0],
            'naming-ceremony' => ['Naming ceremony', 'nwaran, naming, name giving, nuwaran', 0],
            'first-birthday' => ['First birthday', '1st birthday, first bday, turning one, one year old, 1st bday', 0],
            'anniversary' => ['Anniversary', 'wedding anniversary, anniversaries', 0],
            'wedding' => ['Wedding', 'marriage, bihe, bridal, engagement, wedding gift', 0],
            'graduation' => ['Graduation', 'graduate, convocation, passing out, exam results, see results', 0],
            'festival' => ['Festival', 'festive, holiday, holidays, celebration, new year', 1],
            'dashain' => ['Dashain', 'dasain, vijaya dashami, dashain tika, bada dashain', 1],
            'tihar' => ['Tihar', 'deepawali, diwali, bhai tika, laxmi puja, deepavali', 1],
            'valentines-day' => ["Valentine's Day", 'valentine, valentines, romantic, love', 1],
            'mothers-day' => ["Mother's Day", 'mothers day, aama ko mukh herne din, mata tirtha aunsi', 1],
            'fathers-day' => ["Father's Day", 'fathers day, buwa ko mukh herne din, kushe aunsi', 1],
            'thank-you' => ['Thank-you gift', 'thanks, thank you, appreciation, gratitude, thankyou', 0],
            'housewarming' => ['Housewarming', 'new home, griha prabesh, house warming, moving in, new house', 0],
            'corporate-gifting' => ['Corporate gifting', 'corporate, business gift, employees, clients, bulk order, company', 0],
            'just-because' => ['Just because', 'no reason, surprise, cheer up, get well, miss you', 0],
        ];
        $i = 0;
        foreach ($occasions as $slug => [$name, $syn, $seasonal]) {
            $this->upsert('occasions', ['slug' => $slug, 'name' => $name, 'synonyms' => $syn, 'is_seasonal' => $seasonal, 'sort_order' => $i++, 'image' => 'assets/images/tiles/occasion-' . $slug . '.svg'],
                ['name', 'synonyms', 'is_seasonal', 'image']);
        }

        $interests = [
            'dolls' => ['Dolls', 'doll, baby doll, rag doll, dollhouse'],
            'action-figures' => ['Action figures', 'action figure, superhero, superheroes, figurine, robot toy'],
            'princess-toys' => ['Princess toys', 'princess, fairy, tiara, crown, castle, dress up'],
            'stuffed-animals' => ['Stuffed animals', 'plush, soft toy, teddy, teddy bear, stuffed toy, cuddly toy'],
            'educational-toys' => ['Educational toys', 'educational, learning toy, learning, montessori, early learning, pretend play'],
            'building-blocks' => ['Building blocks', 'blocks, lego, stacking, construction toy'],
            'books-storytelling' => ['Books & storytelling', 'book, storybook, reading, stories, picture book, story'],
            'arts-crafts' => ['Arts & crafts', 'art, craft, drawing, painting, colouring, coloring, sketch'],
            'science-stem' => ['Science & STEM', 'science, stem, experiment, coding, engineering, robotics'],
            'music' => ['Music', 'musical, instrument, songs, singing, musician'],
            'fashion' => ['Fashion', 'clothing, clothes, accessories, style, scarf, shawl'],
            'jewelry' => ['Jewelry', 'jewellery, necklace, earrings, bracelet, ring, bangle'],
            'personalized-keepsakes' => ['Personalized keepsakes', 'keepsake, memory, memories, engraved gift, custom gift'],
            'home-decor' => ['Home decor', 'decor, decoration, interior, candles, wall art'],
            'games-puzzles' => ['Games & puzzles', 'game, puzzle, board game, jigsaw, card game'],
            'outdoor-activities' => ['Outdoor activities', 'outdoor, hiking, trekking, camping, adventure, travel'],
            'sports' => ['Sports', 'sport, football, cricket, fitness, yoga, gym'],
            'technology' => ['Technology', 'tech, gadget, gadgets, electronics, techie'],
            'cooking' => ['Cooking', 'kitchen, baking, chef, food, foodie, tea, coffee, chiya'],
            'gardening' => ['Gardening', 'garden, plants, plant, succulent, flowers, gardener'],
            'beauty-wellness' => ['Beauty & wellness', 'beauty, wellness, spa, skincare, self care, relaxation, meditation'],
            'handmade-products' => ['Handmade products', 'handcrafted, artisan, made in nepal, local craft'],
            'sustainable-gifts' => ['Sustainable gifts', 'sustainable, zero waste, organic, recycled, eco gifts'],
            'experiences' => ['Experiences', 'experience, class, workshop, voucher, activity'],
            'gift-hampers' => ['Gift hampers', 'hamper, gift box, gift basket, gift set, basket'],
        ];
        $i = 0;
        foreach ($interests as $slug => [$name, $syn]) {
            $this->upsert('interests', ['slug' => $slug, 'name' => $name, 'synonyms' => $syn, 'sort_order' => $i++, 'image' => 'assets/images/tiles/interest-' . $slug . '.svg'], ['name', 'synonyms', 'image']);
        }

        $ages = [
            ['0–6 months', '0-6-months', 'child', 0, 6], ['6–12 months', '6-12-months', 'child', 6, 12], ['1–2 years', '1-2-years', 'child', 12, 35],
            ['3–5 years', '3-5-years', 'child', 36, 71], ['6–8 years', '6-8-years', 'child', 72, 107], ['9–12 years', '9-12-years', 'child', 108, 155],
            ['13–17 years', '13-17-years', 'child', 156, 215], ['18–25 years', '18-25-years', 'adult', 216, 311], ['26–40 years', '26-40-years', 'adult', 312, 491],
            ['41–60 years', '41-60-years', 'adult', 492, 731], ['60+ years', '60-plus-years', 'adult', 732, 1200],
        ];
        foreach ($ages as $i => [$label, $slug, $aud, $min, $max]) {
            $this->upsert('age_ranges', ['label' => $label, 'slug' => $slug, 'audience' => $aud, 'min_months' => $min, 'max_months' => $max, 'sort_order' => $i], ['label', 'audience', 'min_months', 'max_months', 'sort_order']);
        }

        if (!(int) Database::fetchColumn('SELECT COUNT(*) FROM budget_ranges')) {
            foreach ([['Under NPR 500', 0, 500], ['NPR 500–1,000', 500, 1000], ['NPR 1,000–2,500', 1000, 2500], ['NPR 2,500–5,000', 2500, 5000], ['NPR 5,000–10,000', 5000, 10000], ['Above NPR 10,000', 10000, null]] as $i => [$label, $min, $max]) {
                Database::insert('budget_ranges', ['label' => $label, 'min_amount' => $min, 'max_amount' => $max, 'sort_order' => $i]);
            }
        }

        $prefs = ['handmade' => 'Handmade', 'personalized' => 'Personalized', 'eco-friendly' => 'Eco-friendly', 'educational' => 'Educational', 'luxury' => 'Luxury',
            'practical' => 'Practical', 'funny' => 'Funny', 'sentimental' => 'Sentimental', 'ready-to-gift' => 'Ready-to-gift'];
        foreach ($prefs as $slug => $name) {
            $this->upsert('tags', ['slug' => $slug, 'name' => $name, 'type' => 'preference'], ['name', 'type']);
        }

        $synonyms = [
            'little princess' => 'recipient:baby-girl,interest:princess-toys',
            'first birthday girl' => 'recipient:baby-girl,occasion:first-birthday',
            'first birthday boy' => 'recipient:baby-boy,occasion:first-birthday',
            'toddler girl' => 'recipient:baby-girl,agemonths:12-35',
            'toddler boy' => 'recipient:baby-boy,agemonths:12-35',
            'toddler' => 'agemonths:12-35',
            'baby' => 'agemonths:0-24',
            'infant' => 'agemonths:0-12',
            'newborn' => 'agemonths:0-6',
            'new mom' => 'recipient:mother,occasion:birth-celebration',
            'personalized' => 'flag:personalized',
            'personalised' => 'flag:personalized',
            'custom' => 'flag:personalized',
            'engraved' => 'flag:personalized',
            'monogram' => 'flag:personalized',
            'eco friendly' => 'pref:eco-friendly',
            'eco' => 'pref:eco-friendly',
            'luxury' => 'pref:luxury',
            'funny' => 'pref:funny',
            'quirky' => 'pref:funny',
            'sentimental' => 'pref:sentimental',
            'last minute' => 'pref:ready-to-gift',
            'pretend play' => 'interest:educational-toys,interest:princess-toys',
            'office gift' => 'occasion:corporate-gifting,recipient:colleague',
            'for mom' => 'recipient:mother',
            'for dad' => 'recipient:father',
        ];
        foreach ($synonyms as $phrase => $maps) {
            $this->upsert('search_synonyms', ['phrase' => $phrase, 'maps_to' => $maps], ['maps_to']);
        }
    }

    private function categories(): void
    {
        $tree = [
            'baby-kids' => ['Baby & Kids', 'Thoughtfully chosen, age-appropriate gifts for little ones.', ['baby-essentials' => 'Baby Essentials', 'kids-room' => "Kids' Room"]],
            'toys-games' => ['Toys & Games', 'Play that sparks imagination — from first rattles to strategy games.', ['dolls-plush' => 'Dolls & Plush', 'learning-toys' => 'Learning Toys', 'games-puzzles' => 'Games & Puzzles']],
            'personalized' => ['Personalized', 'Make it theirs with names, dates and messages.', ['keepsakes' => 'Keepsakes', 'engraved' => 'Engraved Gifts']],
            'home-living' => ['Home & Living', 'Pieces that make a house feel like home.', ['decor' => 'Decor', 'kitchen-dining' => 'Kitchen & Dining', 'candles-scents' => 'Candles & Scents']],
            'jewelry-accessories' => ['Jewelry & Accessories', 'Handmade jewelry, shawls and everyday accessories.', []],
            'books-stationery' => ['Books & Stationery', 'Stories, journals and handmade paper goods.', []],
            'wellness-beauty' => ['Wellness & Beauty', 'Rituals for rest, calm and self-care.', []],
            'gift-boxes' => ['Gift Boxes & Hampers', 'Curated, beautifully packed and ready to give.', []],
            'garden-outdoors' => ['Garden & Outdoors', 'For growers, hikers and fresh-air lovers.', []],
            'tech-gadgets' => ['Tech & Gadgets', 'Clever, useful gadgets with a gift-worthy finish.', []],
            'experiences' => ['Experiences', 'Classes and memorable moments to share.', []],
        ];
        $i = 0;
        foreach ($tree as $slug => [$name, $desc, $children]) {
            $this->upsert('categories', ['slug' => $slug, 'name' => $name, 'description' => $desc, 'sort_order' => $i++, 'parent_id' => null], ['name', 'description', 'sort_order']);
            $parentId = (int) Database::fetchColumn('SELECT id FROM categories WHERE slug = :s', ['s' => $slug]);
            $j = 0;
            foreach ($children as $cslug => $cname) {
                $this->upsert('categories', ['slug' => $cslug, 'name' => $cname, 'parent_id' => $parentId, 'sort_order' => $j++], ['name', 'parent_id', 'sort_order']);
            }
        }
    }

    private function zones(): void
    {
        if ((int) Database::fetchColumn('SELECT COUNT(*) FROM delivery_zones')) {
            return;
        }
        Database::insert('delivery_zones', ['name' => 'Kathmandu Valley', 'districts' => 'Kathmandu,Lalitpur,Bhaktapur', 'is_valley' => 1, 'rate' => 100, 'free_shipping_threshold' => 3000, 'est_days_min' => 1, 'est_days_max' => 2, 'cod_available' => 1, 'sort_order' => 0]);
        Database::insert('delivery_zones', ['name' => 'Major cities', 'districts' => 'Kaski,Chitwan,Rupandehi,Morang,Sunsari,Parsa,Banke,Jhapa,Dhanusha,Kailali,Makwanpur,Kavrepalanchok', 'rate' => 200, 'free_shipping_threshold' => 6000, 'est_days_min' => 2, 'est_days_max' => 4, 'cod_available' => 1, 'sort_order' => 1]);
        Database::insert('delivery_zones', ['name' => 'Rest of Nepal', 'districts' => '', 'is_default' => 1, 'rate' => 300, 'free_shipping_threshold' => null, 'est_days_min' => 3, 'est_days_max' => 7, 'cod_available' => 0, 'sort_order' => 2]);
    }

    private function settings(): void
    {
        foreach (\App\Services\SettingsService::DEFAULTS as $key => $value) {
            Database::query(
                'INSERT IGNORE INTO site_settings (setting_key, value, group_name) VALUES (:k, :v, :g)',
                ['k' => $key, 'v' => json_encode($value, JSON_UNESCAPED_UNICODE), 'g' => str_starts_with($key, 'reco_') ? 'recommendations' : 'general']
            );
        }
    }

    private function homepage(): void
    {
        if ((int) Database::fetchColumn('SELECT COUNT(*) FROM homepage_sections')) {
            return;
        }
        $sections = [
            ['hero', 'hero', 'Gifts as <em>thoughtful</em> as you are', 'Original, beautifully made gifts for every person and every occasion — chosen with care, delivered across Nepal.', ['eyebrow' => 'Curated in Kathmandu', 'image' => 'assets/images/hero.svg', 'cta_label' => 'Find the perfect gift', 'cta_url' => '/gift-finder', 'secondary_label' => 'Shop bestsellers', 'secondary_url' => '/bestsellers']],
            ['gift_finder', 'gift_finder', 'Not sure what to get?', 'Tell us who it is for and we will match gifts to their age, interests and your budget.', []],
            ['recipients', 'taxonomy_grid', 'Shop by recipient', 'From first birthdays to grandparents — find gifts that fit the person.', ['taxonomy' => 'recipients', 'slugs' => ['baby-girl', 'baby-boy', 'child', 'teenager', 'mother', 'father', 'wife', 'husband', 'friend', 'grandparent', 'colleague', 'teacher'], 'limit' => 12]],
            ['occasions', 'taxonomy_grid', 'Shop by occasion', 'Celebrate the big days and the small ones.', ['taxonomy' => 'occasions', 'slugs' => ['birthday', 'first-birthday', 'anniversary', 'wedding', 'dashain', 'tihar', 'baby-shower', 'housewarming'], 'limit' => 8]],
            ['interests', 'taxonomy_grid', 'Shop by interest', 'Gifts for what they love.', ['taxonomy' => 'interests', 'slugs' => ['books-storytelling', 'cooking', 'gardening', 'arts-crafts', 'educational-toys', 'beauty-wellness', 'jewelry', 'outdoor-activities', 'games-puzzles', 'handmade-products', 'technology', 'music'], 'limit' => 12]],
            ['budget', 'budget_grid', 'Shop by budget', 'Wonderful gifts at every price.', []],
            ['bestsellers', 'products', 'Bestselling gifts', 'Loved by our customers, ranked by real orders.', ['source' => 'bestseller', 'limit' => 8]],
            ['new', 'products', 'New & trending', 'Just landed from our makers.', ['source' => 'new', 'limit' => 8]],
            ['personalized', 'collection', 'Personalized gifts', 'Names, dates and messages — made just for them.', ['source' => 'personalized', 'limit' => 4, 'image' => 'assets/images/collections/personalized.svg', 'cta_label' => 'Shop personalized', 'cta_url' => '/personalized-gifts']],
            ['baby-kids', 'collection', 'For babies & little ones', 'Age-appropriate toys, books and keepsakes, checked for safety guidance.', ['source' => 'category', 'value' => 'baby-kids', 'limit' => 4, 'image' => 'assets/images/collections/baby.svg', 'cta_label' => 'Shop baby & kids', 'cta_url' => '/category/baby-kids']],
            ['gift-boxes', 'products', 'Curated gift boxes', 'Thoughtfully assembled and ready to give.', ['source' => 'category', 'value' => 'gift-boxes', 'limit' => 4]],
            ['last-minute', 'products', 'Last-minute gifts', 'In stock and ready to dispatch — no making time needed.', ['source' => 'last_minute', 'limit' => 4]],
            ['campaigns', 'campaigns', 'In season', null, []],
            ['story', 'story', 'Made by people, chosen with care', 'We work directly with independent makers across Nepal — weavers in Palpa, paper makers in Bhaktapur, felt artists in Kathmandu — and pay fairly for their craft.', []],
            ['makers', 'makers', 'Meet our makers', 'The hands behind the gifts.', []],
            ['reviews', 'reviews', 'What customers say', 'Verified reviews from real orders.', []],
            ['newsletter', 'newsletter', 'Gift ideas, a few times a month', 'New arrivals, festival edits and occasion reminders. No spam — unsubscribe anytime.', []],
            ['trust', 'trust', null, null, []],
        ];
        foreach ($sections as $i => [$key, $type, $title, $subtitle, $cfg]) {
            Database::insert('homepage_sections', ['section_key' => $key, 'type' => $type, 'title' => $title, 'subtitle' => $subtitle, 'config_json' => json_encode($cfg), 'sort_order' => $i, 'is_enabled' => 1]);
        }
    }

    private function emailTemplates(): void
    {
        $btn = static fn (string $var, string $label) => '<p style="margin:28px 0"><a href="{{' . $var . '}}" style="background:#1f1b16;color:#fffdf9;padding:13px 26px;border-radius:999px;text-decoration:none;font-weight:600;display:inline-block">' . $label . '</a></p>';
        $templates = [
            'account_verification' => ['Account verification', 'Confirm your {{store_name}} account', '<p>Hi {{customer_name}},</p><p>Welcome to {{store_name}}! Please confirm your email address to activate your account.</p>' . $btn('verify_url', 'Verify my email') . '<p style="color:#7a6f63;font-size:13px">This link expires in 48 hours. If you did not create an account, you can ignore this email.</p>', 'customer_name, verify_url'],
            'account_exists' => ['Registration attempt for existing account', 'You already have a {{store_name}} account', '<p>Hi {{customer_name}},</p><p>Someone (hopefully you) tried to create a new account with this email address. You already have an account — just sign in.</p>' . $btn('login_url', 'Sign in') . '<p>Forgot your password? <a href="{{reset_url}}">Reset it here</a>.</p>', 'customer_name, login_url, reset_url'],
            'password_reset' => ['Password reset', 'Reset your {{store_name}} password', '<p>Hi {{customer_name}},</p><p>We received a request to reset your password.</p>' . $btn('reset_url', 'Choose a new password') . '<p style="color:#7a6f63;font-size:13px">This link expires in 1 hour and can be used once. If you did not request it, no action is needed.</p>', 'customer_name, reset_url'],
            'order_confirmation' => ['Order confirmation', 'Order {{order_number}} confirmed', '<p>Hi {{customer_name}},</p><p>Thank you for your order! We are getting it ready with care.</p>{{{items_table}}}<p>Payment: {{payment_method}}</p>' . $btn('order_url', 'View your order'), 'customer_name, order_number, order_total, payment_method, items_table, order_url'],
            'payment_confirmation' => ['Payment confirmation', 'Payment received for {{order_number}}', '<p>Hi {{customer_name}},</p><p>We have verified your payment of <strong>{{order_total}}</strong> via {{payment_method}} for order {{order_number}}.</p>' . $btn('order_url', 'View order'), 'customer_name, order_number, order_total, payment_method, order_url'],
            'payment_failed' => ['Payment failure', 'Payment not completed for {{order_number}}', '<p>Hi {{customer_name}},</p><p>Your payment for order {{order_number}} was not completed. Your items are reserved for a limited time — you can try again without placing a new order.</p>' . $btn('pay_url', 'Retry payment') . '<p style="color:#7a6f63;font-size:13px">If money was deducted from your wallet, it will be reconciled automatically. Contact us if you need help.</p>', 'customer_name, order_number, pay_url'],
            'order_shipped' => ['Order shipment', 'Your order {{order_number}} is on its way', '<p>Hi {{customer_name}},</p><p>Good news — your order has been dispatched.</p><p>Carrier: {{carrier}}<br>Tracking number: {{tracking_number}}</p>' . $btn('order_url', 'Track your order'), 'customer_name, order_number, carrier, tracking_number, tracking_url, order_url'],
            'order_delivered' => ['Delivery confirmation', 'Delivered: order {{order_number}}', '<p>Hi {{customer_name}},</p><p>Your order {{order_number}} has been delivered. We hope it brings a smile!</p><p>Loved it? Leave a review from your order page.</p>' . $btn('order_url', 'Review your gifts'), 'customer_name, order_number, order_url'],
            'order_cancelled' => ['Cancellation', 'Order {{order_number}} cancelled', '<p>Hi {{customer_name}},</p><p>Your order {{order_number}} has been cancelled. If you had already paid, a refund will be processed and you will receive an update.</p>' . $btn('order_url', 'View order'), 'customer_name, order_number, order_url'],
            'refund_update' => ['Refund update', 'Refund update for {{order_number}}', '<p>Hi {{customer_name}},</p><p>Refund of {{refund_amount}} for order {{order_number}} has been processed. Depending on your provider it may take a few working days to appear.</p>' . $btn('order_url', 'View order'), 'customer_name, order_number, refund_amount, order_url'],
            'wishlist_reminder' => ['Wishlist reminder', 'Still thinking about these?', '<p>Hi {{customer_name}},</p><p>Items in your wishlist are still available.</p>{{{items_table}}}' . $btn('wishlist_url', 'View wishlist') . '<p style="font-size:12px;color:#7a6f63">You receive this because you opted in to wishlist reminders. <a href="{{unsubscribe_url}}">Manage preferences</a>.</p>', 'customer_name, items_table, wishlist_url, unsubscribe_url'],
            'gift_reminder' => ['Gift occasion reminder', 'Coming up: {{reminder_title}} on {{event_date}}', '<p>Hi {{customer_name}},</p><p>A friendly reminder that <strong>{{reminder_title}}</strong> is coming up on {{event_date}}.</p><p>We have picked gift ideas for {{recipient_name}}.</p>' . $btn('finder_url', 'See gift ideas') . '<p style="font-size:12px;color:#7a6f63">You set this reminder in your Gift Center. <a href="{{unsubscribe_url}}">Manage reminders</a>.</p>', 'customer_name, reminder_title, event_date, recipient_name, finder_url, unsubscribe_url'],
            'abandoned_cart' => ['Abandoned cart reminder', 'You left something in your bag', '<p>Hi {{customer_name}},</p><p>Your bag is saved and waiting for you.</p>{{{items_table}}}' . $btn('cart_url', 'Return to your bag') . '<p style="font-size:12px;color:#7a6f63">You receive this because you opted in to marketing emails. <a href="{{unsubscribe_url}}">Unsubscribe</a>.</p>', 'customer_name, items_table, cart_url, unsubscribe_url'],
            'staff_invitation' => ['Staff invitation', 'You have been invited to {{store_name}} Admin', '<p>Hi {{staff_name}},</p><p>{{inviter}} has invited you to join the {{store_name}} admin team. Set your password to activate your account.</p>' . $btn('invite_url', 'Set up my account') . '<p style="color:#7a6f63;font-size:13px">This invitation expires in 3 days.</p>', 'staff_name, inviter, invite_url'],
            'low_stock_alert' => ['Low-stock alert', 'Low stock: {{count}} products need attention', '<p>The following products are at or below their low-stock threshold:</p>{{{items_table}}}' . $btn('inventory_url', 'Open inventory'), 'count, items_table, inventory_url'],
            'ticket_received' => ['Support ticket received', 'We received your request {{ticket_number}}', '<p>Hi {{customer_name}},</p><p>Thanks for contacting us about “{{subject}}”. Your reference is <strong>{{ticket_number}}</strong>. We usually reply within one working day.</p>', 'customer_name, ticket_number, subject'],
            'support_ticket_received' => ['Support ticket received (account)', 'We received your request {{ticket_number}}', '<p>Hi {{customer_name}},</p><p>Thanks for contacting us about “{{ticket_subject}}”. Your reference is <strong>{{ticket_number}}</strong>. We usually reply within one working day.</p>' . $btn('ticket_url', 'View your request'), 'customer_name, ticket_number, ticket_subject, ticket_url'],
            'ticket_reply' => ['Support ticket reply', 'Re: {{subject}} [{{ticket_number}}]', '<p>Hi {{customer_name}},</p><p>Our team replied to your request {{ticket_number}}:</p><blockquote style="border-left:3px solid #b4532a;margin:16px 0;padding:4px 16px;color:#4a4239">{{message}}</blockquote>' . $btn('ticket_url', 'View conversation'), 'customer_name, ticket_number, subject, message, ticket_url'],
        ];
        foreach ($templates as $key => [$name, $subject, $body, $vars]) {
            Database::query(
                'INSERT IGNORE INTO email_templates (template_key, name, subject, body_html, variables) VALUES (:k, :n, :s, :b, :v)',
                ['k' => $key, 'n' => $name, 's' => $subject, 'b' => $body, 'v' => $vars]
            );
        }
    }
}
