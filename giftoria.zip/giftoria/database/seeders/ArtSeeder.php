<?php
declare(strict_types=1);

namespace Database\Seeders;

use App\Services\PlaceholderArt;

/** Generates the original SVG artwork for tiles, hero and collections (re-runnable). */
final class ArtSeeder
{
    public const RECIPIENT_MOTIFS = [
        'baby-girl' => 'baby', 'baby-boy' => 'baby', 'child' => 'sparkles', 'teenager' => 'zap', 'mother' => 'heart', 'father' => 'user',
        'sister' => 'heart', 'brother' => 'user', 'wife' => 'heart', 'husband' => 'heart', 'girlfriend' => 'heart', 'boyfriend' => 'heart',
        'friend' => 'users', 'grandparent' => 'home', 'colleague' => 'card', 'teacher' => 'file', 'couple' => 'users', 'pet-lover' => 'leaf', 'anyone-else' => 'gift',
    ];
    public const OCCASION_MOTIFS = [
        'birthday' => 'cake', 'baby-shower' => 'baby', 'birth-celebration' => 'baby', 'naming-ceremony' => 'pen', 'first-birthday' => 'cake',
        'anniversary' => 'heart', 'wedding' => 'heart', 'graduation' => 'star', 'festival' => 'sparkles', 'dashain' => 'star', 'tihar' => 'sparkles',
        'valentines-day' => 'heart', 'mothers-day' => 'heart', 'fathers-day' => 'user', 'thank-you' => 'hand', 'housewarming' => 'home',
        'corporate-gifting' => 'card', 'just-because' => 'gift',
    ];
    public const INTEREST_MOTIFS = [
        'dolls' => 'heart', 'action-figures' => 'zap', 'princess-toys' => 'star', 'stuffed-animals' => 'heart', 'educational-toys' => 'sparkles',
        'building-blocks' => 'boxes', 'books-storytelling' => 'file', 'arts-crafts' => 'pen', 'science-stem' => 'zap', 'music' => 'bell',
        'fashion' => 'tag', 'jewelry' => 'sparkles', 'personalized-keepsakes' => 'pen', 'home-decor' => 'home', 'games-puzzles' => 'grip',
        'outdoor-activities' => 'map-pin', 'sports' => 'zap', 'technology' => 'zap', 'cooking' => 'cake', 'gardening' => 'leaf',
        'beauty-wellness' => 'sparkles', 'handmade-products' => 'hand', 'sustainable-gifts' => 'leaf', 'experiences' => 'calendar', 'gift-hampers' => 'gift',
    ];

    public function run(): void
    {
        foreach (self::RECIPIENT_MOTIFS as $slug => $m) {
            PlaceholderArt::write('assets/images/tiles/recipient-' . $slug . '.svg', 'r' . $slug, $m, 600, 600);
        }
        foreach (self::OCCASION_MOTIFS as $slug => $m) {
            PlaceholderArt::write('assets/images/tiles/occasion-' . $slug . '.svg', 'o' . $slug, $m, 800, 1000);
        }
        foreach (self::INTEREST_MOTIFS as $slug => $m) {
            PlaceholderArt::write('assets/images/tiles/interest-' . $slug . '.svg', 'i' . $slug, $m, 600, 600);
        }
        PlaceholderArt::write('assets/images/hero.svg', 'hero-giftoria', 'gift', 1000, 1100);
        PlaceholderArt::write('assets/images/collections/personalized.svg', 'col-personalized', 'pen', 1000, 800);
        PlaceholderArt::write('assets/images/collections/baby.svg', 'col-baby', 'baby', 1000, 800);
        PlaceholderArt::write('assets/images/collections/campaign-tihar.svg', 'campaign-tihar', 'sparkles', 1600, 700);
        PlaceholderArt::write('assets/images/collections/story.svg', 'story', 'hand', 1000, 800);
        PlaceholderArt::write('assets/images/placeholder.svg', 'placeholder', 'image', 960, 1200);
        foreach (['kathmandu-felt-studio', 'palpa-dhaka-weavers', 'lokta-leaf-paper', 'patan-metalcraft', 'little-sprouts-toys', 'himalayan-tea-collective'] as $i => $slug) {
            PlaceholderArt::write('assets/images/makers/' . $slug . '.svg', 'maker' . $slug, ['heart', 'tag', 'file', 'star', 'sparkles', 'leaf'][$i], 800, 600);
        }
    }
}
